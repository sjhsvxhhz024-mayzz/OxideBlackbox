param(
    [string]$NdkRoot,
    [int]$Jobs = [Math]::Min(8, [Environment]::ProcessorCount),
    [ValidateSet('phone', 'pc', 'all')]
    [string]$Target = 'all',
    [switch]$AllAbis,
    [switch]$Help
)

$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$workspaceRoot = Split-Path -Parent $projectRoot
$projectName = Split-Path -Leaf $projectRoot

if ($Help) {
    Write-Host 'Build: double-click build.cmd for one universal Avis_tools_v2.6.sh, or run .\build.cmd -Target phone|pc|all.'
    Write-Host 'Targets: phone = Android arm64-v8a; pc = Android x86_64 emulator; all = both.'
    Write-Host 'Options: -NdkRoot "C:\path\to\ndk", -Jobs 8.'
    Write-Host 'Output: dist\avistools_arm64 / dist\avistools_x86_64 and dist\SHA256SUMS.'
    return
}

if (-not $NdkRoot) {
    if ($env:ANDROID_NDK_HOME) {
        $NdkRoot = $env:ANDROID_NDK_HOME
    } elseif ($env:NDK) {
        $NdkRoot = $env:NDK
    } else {
        $sdkNdkDir = Join-Path $env:LOCALAPPDATA 'Android\Sdk\ndk'
        $installed = Get-ChildItem -LiteralPath $sdkNdkDir -Directory -ErrorAction SilentlyContinue |
            Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'ndk-build.cmd') -PathType Leaf } |
            Sort-Object { try { [version]$_.Name } catch { [version]'0.0' } } -Descending |
            Select-Object -First 1
        if ($installed) { $NdkRoot = $installed.FullName }
    }
}

if (-not $NdkRoot) {
    throw 'Android NDK not found. Install NDK in Android SDK, or pass -NdkRoot "C:\path\to\ndk".'
}

$ndkBuild = Join-Path $NdkRoot 'ndk-build.cmd'
$readelf = Join-Path $NdkRoot 'toolchains\llvm\prebuilt\windows-x86_64\bin\llvm-readelf.exe'
if (-not (Test-Path -LiteralPath $ndkBuild -PathType Leaf)) {
    throw "ndk-build.cmd not found: $ndkBuild. Pass -NdkRoot or set ANDROID_NDK_HOME."
}
if (-not (Test-Path -LiteralPath $readelf -PathType Leaf)) {
    throw "llvm-readelf.exe not found: $readelf"
}
if ($Jobs -lt 1) { throw 'Jobs must be at least 1.' }
if ($projectName.Contains(' ')) { throw "Project directory must not contain spaces: $projectName" }

if ($AllAbis) { $Target = 'all' }
switch ($Target) {
    'phone' { $artifacts = @(@{ Abi = 'arm64-v8a'; Name = 'avistools_arm64'; Machine = 'AArch64' }) }
    'pc'    { $artifacts = @(@{ Abi = 'x86_64'; Name = 'avistools_x86_64'; Machine = 'Advanced Micro Devices X86-64' }) }
    'all'   { $artifacts = @(
        @{ Abi = 'arm64-v8a'; Name = 'avistools_arm64'; Machine = 'AArch64' },
        @{ Abi = 'x86_64'; Name = 'avistools_x86_64'; Machine = 'Advanced Micro Devices X86-64' }
    ) }
}
Write-Host "Building Avis tools 1.15.11966: $Target"

# ndk-build rejects a project path containing spaces, so map its parent to a
# temporary drive letter. The mapping is always removed, including on failure.
$drive = @('R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z') |
    Where-Object { -not (Get-PSDrive -Name $_ -ErrorAction SilentlyContinue) } |
    Select-Object -First 1
if (-not $drive) { throw 'No free drive letter available for the NDK build.' }
$driveSpec = '{0}:' -f $drive
$mappedProject = '{0}:/{1}' -f $drive, $projectName
$mappedWindowsPath = '{0}:\{1}' -f $drive, $projectName

& subst.exe $driveSpec $workspaceRoot
if ($LASTEXITCODE -ne 0) { throw "subst failed for $driveSpec -> $workspaceRoot" }
try {
    Push-Location -LiteralPath $mappedWindowsPath
    try {
        $ndkArgs = @(
            "-j$Jobs"
            "NDK_PROJECT_PATH=$mappedProject"
            "APP_BUILD_SCRIPT=$mappedProject/Android.mk"
            "NDK_APPLICATION_MK=$mappedProject/Application.mk"
        )
        if ($Target -eq 'phone') { $ndkArgs += 'APP_ABI=arm64-v8a' }
        if ($Target -eq 'pc') { $ndkArgs += 'APP_ABI=x86_64' }
        & $ndkBuild @ndkArgs
        if ($LASTEXITCODE -ne 0) { throw "ndk-build failed with exit code $LASTEXITCODE" }
    } finally {
        Pop-Location
    }
} finally {
    & subst.exe $driveSpec /D
    if ($LASTEXITCODE -ne 0) { Write-Warning "Could not remove temporary drive $driveSpec" }
}

$dist = Join-Path $projectRoot 'dist'
New-Item -ItemType Directory -Path $dist -Force | Out-Null
$sums = foreach ($artifact in $artifacts) {
    $source = Join-Path $projectRoot "libs\$($artifact.Abi)\avistools"
    $artifactPath = Join-Path $dist $artifact.Name
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        throw "Build output missing: $source"
    }
    Copy-Item -LiteralPath $source -Destination $artifactPath -Force
    $header = & $readelf -h $artifactPath
    if ($LASTEXITCODE -ne 0 -or -not ($header -match "Machine:\s+$([regex]::Escape($artifact.Machine))")) {
        throw "Unexpected ELF architecture: $artifactPath"
    }
    if (-not ($header -match 'Class:\s+ELF64') -or -not ($header -match 'Type:\s+DYN')) {
        throw "Expected ELF64 PIE executable: $artifactPath"
    }
    $stream = [System.IO.File]::OpenRead($artifactPath)
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    try {
        $hash = [System.BitConverter]::ToString($sha256.ComputeHash($stream)).Replace('-', '').ToLowerInvariant()
    } finally {
        $stream.Dispose()
        $sha256.Dispose()
    }
    Write-Host "OK: $artifactPath ($($artifact.Machine))"
    "$hash  $($artifact.Name)"
}
[System.IO.File]::WriteAllLines((Join-Path $dist 'SHA256SUMS'), [string[]]$sums, [System.Text.Encoding]::ASCII)
Write-Host "Hashes: $(Join-Path $dist 'SHA256SUMS')"
if ($Target -eq 'all') {
    $packer = Join-Path $projectRoot 'tools\pack_universal.py'
    if (Get-Command py -ErrorAction SilentlyContinue) {
        & py -3 $packer
    } elseif (Get-Command python3 -ErrorAction SilentlyContinue) {
        & python3 $packer
    } else {
        throw 'Python 3 is required to pack Avis_tools_v2.6.sh.'
    }
    if ($LASTEXITCODE -ne 0) { throw "Universal pack failed with exit code $LASTEXITCODE" }
    $bundlePath = Join-Path $dist 'Avis_tools_v2.6.sh'
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    $stream = [System.IO.File]::OpenRead($bundlePath)
    try {
        $bundleHash = [System.BitConverter]::ToString($sha256.ComputeHash($stream)).Replace('-', '').ToLowerInvariant()
    } finally {
        $stream.Dispose()
        $sha256.Dispose()
    }
    [System.IO.File]::AppendAllText((Join-Path $dist 'SHA256SUMS'), "$bundleHash  Avis_tools_v2.6.sh`n", [System.Text.Encoding]::ASCII)
}
