#ifndef OXLOG_H
#define OXLOG_H

// ============================================================================
//  Avis tools — детальный файловый логгер.
//  Пишет в /sdcard/Download/avis_tools_<timestamp>.log (+ дублирует в stdout).
//  Задача: максимально подробная трассировка резолва памяти, камеры и W2S,
//  чтобы диагностировать оффсеты и математику без доступа к устройству.
// ============================================================================

#include <cstdint>
#include <cstddef>

namespace oxlog {

// Инициализация: открывает файл лога. Вызывать один раз в начале main().
// Возвращает путь к созданному файлу (для вывода в stdout).
const char* init();

// Каталог, в который пишутся все артефакты (лог, dump метадаты и т.п.).
// Заполняется в init() первым каталогом из CANDIDATE_DIRS, куда удалось
// открыть файл. Возвращает пустую строку до init().
const char* activeDir();

// Закрыть лог (flush + close). Обычно не требуется — flush идёт после каждой строки.
void shutdown();

// Форматированная строка с таймстампом и уровнем.
//   level: 'I' info, 'W' warn, 'E' error, 'D' debug, 'T' trace, 'B' блок (как 'I', но без подавления повторов)
void logf(char level, const char* fmt, ...) __attribute__((format(printf, 2, 3)));
// Небольшие обязательные строки диагностики ПК: пишутся в уже открытый
// файл даже после включения пользовательского переключателя Disable logs.
void diagf(const char* fmt, ...) __attribute__((format(printf, 1, 2)));

// Заголовок секции (визуальный разделитель в логе).
void section(const char* title);

// Hex-дамп произвольного буфера (сырые байты памяти игры).
//   addr — виртуальный адрес в процессе игры (для подписи), buf — локальная копия.
void hexdump(const char* label, uint64_t addr, const void* buf, size_t size);

// Логировать один шаг ptr-chain: "label: [addr] -> value".
void ptrstep(const char* label, uint64_t addr, uint64_t value);

// Управление детализацией.
extern bool verbose;       // подробный режим (hex-дампы, каждый шаг цепочки)
extern bool enabled;       // включён ли лог вообще
extern int  frameCounter;  // номер текущего кадра обновления кэша

// Сколько кадров логировать в verbose-режиме подробно, потом — реже.
// (первые кадры пишем всё, дальше — только сводку, чтобы файл не разросся).
bool shouldLogFull();

// Включить подробный лог ещё на N кадров начиная с текущего.
// Вызывается при важных событиях (найден список игроков, вход в матч).
void armFull(int frames);

} // namespace oxlog

// ============================================================================
//  РЕЛИЗ: логирование вырезано на этапе компиляции.
//
//  Цена одной строки была высокой: vsnprintf, затем ТРИ синхронные операции —
//  printf + fflush(stdout), __android_log_write и fprintf в файл на /sdcard.
//  В цикле отрисовки таких вызовов больше десятка, и каждый упирался в диск.
//
//  Макросы ниже разворачиваются в do{}while(0): вызова нет, а аргументы всё
//  равно «упоминаются» через sizeof в невыполняемом контексте — компилятор их
//  не вычисляет, но и не ругается на неиспользуемые переменные. Строки
//  форматов при этом полностью исчезают из бинарника.
//
//  Собрать с логом обратно: -DOX_ENABLE_LOG.
// ============================================================================
#ifdef OX_ENABLE_LOG
  #define OXLOGI(...) do { if (__builtin_expect(oxlog::enabled, 0)) oxlog::logf('I', __VA_ARGS__); } while (0)
  #define OXLOGW(...) do { if (__builtin_expect(oxlog::enabled, 0)) oxlog::logf('W', __VA_ARGS__); } while (0)
  #define OXLOGE(...) do { if (__builtin_expect(oxlog::enabled, 0)) oxlog::logf('E', __VA_ARGS__); } while (0)
  #define OXLOGD(...) do { if (__builtin_expect(oxlog::enabled, 0)) oxlog::logf('D', __VA_ARGS__); } while (0)
  #define OXLOGT(...) do { if (__builtin_expect(oxlog::enabled, 0)) oxlog::logf('T', __VA_ARGS__); } while (0)
  #define OXLOGB(...) do { if (__builtin_expect(oxlog::enabled, 0)) oxlog::logf('B', __VA_ARGS__); } while (0)   // «блок»: без ограничителя частоты, для разовых таблиц и проверок
#else
  // sizeof не вычисляет выражение — побочных эффектов у аргументов не будет,
  // даже если внутри вызов функции.
  #define OX_LOG_SINK(...) do { (void)sizeof(__VA_ARGS__); } while (0)
  #define OXLOGI(...) OX_LOG_SINK(__VA_ARGS__)
  #define OXLOGW(...) OX_LOG_SINK(__VA_ARGS__)
  #define OXLOGE(...) OX_LOG_SINK(__VA_ARGS__)
  #define OXLOGD(...) OX_LOG_SINK(__VA_ARGS__)
  #define OXLOGT(...) OX_LOG_SINK(__VA_ARGS__)
  #define OXLOGB(...) OX_LOG_SINK(__VA_ARGS__)
#endif

#endif // OXLOG_H
