#ifndef MEMORY_H
#define MEMORY_H

#include <stdint.h>
#include <sys/types.h>
#include <unistd.h>
#include <string>
#include <vector>
#include "Vector3.h"
#include "utils.h"

struct String {
    uint64_t klass;
    uint64_t monitor_data;
    int length;
    char first_char[256];
    
    std::string Get();
};

extern int game_pid;
extern uint64_t il2cpp_base;
extern int abs_ScreenX, abs_ScreenY;

// вспомогательные функции
pid_t get_pid(const char *pkgname);
int open_proccess_memory(const pid_t pid);
bool pvm(void *address, void *buffer, size_t size, bool iswrite);
bool vm_readv(unsigned long address, void *buffer, size_t size);
// Несколько удалённых диапазонов одинакового размера за ОДИН системный вызов (покадровое чтение костей).
bool vm_readv_multi(const uint64_t *addrs, int n, size_t each, void *out);
bool vm_writev(unsigned long address, const void *buffer, size_t size);

// ── Кэш чтений на кадр (только поток, который его включил) ───────────────────────────────────────────────────────────────────────
// Каждое чтение памяти игры — системный вызов process_vm_readv, а он берёт блокировку адресного пространства процесса игры и мешает
// ей самой (аллокации, GC, подгрузка страниц). Поток отрисовки читает сотни мелких кусков (поля одного объекта по очереди), поэтому
// При включённом кэше чтение до 64 байт обслуживается блоком в 256 байт, выровненным по 256: блок лежит целиком внутри одной страницы, значит, читается
// либо целиком, либо не читается вовсе (ошибка кэшируется на кадр). Каждый новый кадр (vm_cache_new_frame) и любая запись этого потока
// сбрасывают кэш, поэтому значения не старше кадра, а запись видна сразу. Остальные потоки читают напрямую.
void vm_cache_enable(bool on);        // для ТЕКУЩЕГО потока
void vm_cache_new_frame();            // начало кадра: всё закэшированное устарело
struct VmStats {
    uint64_t reads, hits, syscalls, writes, bytes;     // все потоки; hits — попадания в кэш; bytes — байт прочитано системными вызовами
    uint64_t thReads, thHits, thSyscalls;               // только текущий поток
};
VmStats vm_stats();
uint64_t vm_cache_fallbacks();
struct VmReadFallbackStats { uint64_t attempts, success; };
VmReadFallbackStats vm_read_fallback_stats();
bool mem_addr_virtophy(unsigned long vaddr);

// ТОЛЬКО ЧТЕНИЕ
template<typename T>
T rpm(uint64_t addr) {
    T data{};
    if (addr < 0x1000) {
        return data;
    }
    if (!vm_readv(addr, &data, sizeof(T))) return T{};
    return data;
}

template<typename T>
bool wpm(uint64_t addr, const T& value) {
    if (addr < 0x1000) {
        return false;
    }
    return vm_writev(addr, &value, sizeof(T));
}

#endif
