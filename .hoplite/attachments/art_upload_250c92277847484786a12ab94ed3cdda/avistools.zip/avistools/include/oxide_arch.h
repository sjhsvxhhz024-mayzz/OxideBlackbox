#pragma once
// Всё, что зависит от архитектуры процесса игры. Мод собирается под две архитектуры и читает игру той же архитектуры:
//   arm64-v8a — телефон; x86_64 — Android на ПК (эмулятор), там libil2cpp собран под x86_64 (дамп «pc»).
// Для 1.15.11966 есть отдельные dump.cs/script.json для ARM64 и x86_64.
// Игровые field-оффсеты сверены по обоим дампам; TypeInfo RVA берутся из
// соответствующего script.json, а не переносятся между архитектурами.
//
// Для хост-тестов, написанных под адреса телефона, перед включением заголовка определяют OX_ARCH_FORCE_ARM64.
#include <stdint.h>

namespace oxarch {

struct Arch {
    const char *name;
    // Допустимый диапазон указателей в процессе игры. arm64 Android: 39-битное адресное пространство (до 0x8000000000);
    // x86_64 Linux: 47 бит, кучи и библиотеки лежат около 0x7f…, поэтому нижняя граница выше, чтобы пары int в одном слове не принимались за указатель.
    uint64_t ptrMin, ptrMax;
    // Слоты Il2CppClass* в libil2cpp (RVA от базы модуля).
    uint64_t tiPlayerManager, tiGameController, tiNetworkClient, tiEquipRegistry, tiWeaponRegistry, tiWorldStreaming;
    uint64_t tiBuildingPiece, tiPlayerVitals;
    int sysProcessVmReadv, sysProcessVmWritev;
};

constexpr Arch kArm64 = {
    "arm64-v8a",
    0x1000000000ULL, 0x8000000000ULL,
    // 1.15.11966, ARM64 ScriptMetadata из предоставленного дампа.
    0xDEA09F8ULL, 0xDE9BCB0ULL, 0xDE9FC60ULL, 0xDEA65C0ULL, 0xDE9ACA0ULL, 0xDEA5540ULL,
    0xDE98CA8ULL, 0xDEA0A58ULL,
    270, 271,
};

// 1.15.11966: x86_64 ScriptMetadata (_c записи) из ПК-дампа.
constexpr Arch kX86_64 = {
    "x86_64",
    0x100000000000ULL, 0x800000000000ULL,
    0xDB6D178ULL, 0xDB68430ULL, 0xDB6C3E0ULL, 0xDB72D40ULL, 0xDB67420ULL, 0xDB71CC0ULL,
    0xDB65428ULL, 0xDB6D1D8ULL,
    310, 311,
};

#if defined(OX_ARCH_FORCE_ARM64) || defined(__aarch64__)
inline constexpr const Arch &kCur = kArm64;
#elif defined(__x86_64__)
inline constexpr const Arch &kCur = kX86_64;
#else
#error "Поддерживаются только arm64-v8a и x86_64 (игра 64-битная, 32-битная сборка читать её не сможет)"
#endif

constexpr bool isPtr(const Arch &a, uint64_t p) { return p >= a.ptrMin && p < a.ptrMax; }
inline bool isPtr(uint64_t p) { return isPtr(kCur, p); }

}  // namespace oxarch
