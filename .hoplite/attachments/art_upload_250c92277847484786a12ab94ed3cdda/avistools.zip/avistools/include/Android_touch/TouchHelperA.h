#pragma once


bool Touch_Init(int w, int h, uint32_t orientation_, bool readOnly);
void UpdateScreenData(int w, int h, uint32_t orientation_);

void Touch_Close();
// Drain evdev events only on the render thread, before ImGui::NewFrame().
void Touch_PumpInput();
struct TouchStats {
    int sources, touchSources, pointerSources;
    unsigned long long rawEvents, queuedEvents, pumpedEvents;
    unsigned long long mtPositionEvents, mtTrackingEvents, touchButtonEvents;
    unsigned long long mouseButtonEvents, absPointerEvents, relPointerEvents;
    int lastType, lastCode, lastValue;
    float lastX, lastY;
    bool lastDown;
};
TouchStats Touch_GetStats();
void Touch_Down(float x, float y);
void Touch_Move(float x, float y);
void Touch_Up();
