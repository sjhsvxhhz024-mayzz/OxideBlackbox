#ifndef OXIDE_OFFSETS_H
#define OXIDE_OFFSETS_H

// ============================================================================
//  Oxide Survival Island — оффсеты (Il2CppDumper; ARM64 1.15.11966,
//  x86_64 1.15.11966)
//  Источники: отдельные dump.cs / script.json для ARM64 и x86_64 1.15.11966.
//  Движок Unity il2cpp, сеть Mirror (NetworkBehaviour).
//
//  Для обеих архитектур 1.15 подтверждены PM_OBSERVED_PLAYER,
//  IZ_PLAYERS_LIST, INVCLIENT_HOTBAR, FPSPEAR_PREFAB. Именованные игровые поля
//  сверены по обоим дампам; нативные цепочки требуют libil2cpp.so.
//
//  Иерархия виталов: PlayerVitals : EntityVitals : GenericVitals.
//  TypeInfo RVA для обеих архитектур подтверждены по ScriptMetadata.
//  Нативные metadata RVA требуют libil2cpp.so и global-metadata.dat.
// ============================================================================
namespace ox {

// --- Пакет и модуль ---
static constexpr const char *PACKAGE = "com.catsbit.oxidesurvivalisland";
static constexpr const char *MODULE  = "libil2cpp.so";
static constexpr const char *MODULE_NATIVE = "liboxidesurvivalisland.so";

// === TypeInfos из script.json 1.15.11966 ===
// RVA от базы libil2cpp.so; каждая ABI использует собственный набор.
#if defined(__x86_64__) && !defined(OX_ARCH_FORCE_ARM64)
// x86_64 1.15.11966: ScriptMetadata из ПК-дампа (_c записи).
static constexpr uint64_t PLAYERMANAGER_TYPEINFO  = 0xDB6D178; // Oxide.PlayerManager_c
static constexpr uint64_t BUILDINGPIECE_TYPEINFO  = 0xDB65428; // Oxide.Building.BuildingPiece_c
static constexpr uint64_t PLAYERVITALS_TYPEINFO   = 0xDB6D1D8; // Oxide.PlayerVitals_c
#else
static constexpr uint64_t PLAYERMANAGER_TYPEINFO  = 0xDEA09F8; // ARM64 1.15.11966 ScriptMetadata
static constexpr uint64_t BUILDINGPIECE_TYPEINFO  = 0xDE98CA8; // ARM64 1.15.11966 ScriptMetadata
static constexpr uint64_t PLAYERVITALS_TYPEINFO   = 0xDEA0A58; // ARM64 1.15.11966 ScriptMetadata
#endif

// --- il2cpp статическая цепочка до списка игроков ---
// base + PLAYERMANAGER_TYPEINFO -> Il2CppClass*
//   klass + CLASS_STATIC_FIELDS -> static_fields*
//   statics + STATIC_ACTIVE_LIST -> List<PlayerManager> activePlayerList
// CLASS_STATIC_FIELDS = 0xB8 — ПОДТВЕРЖДЕНО offline disasm BuildingPiece.cctor:
//   ldr x8,[classptr] ; ldr x8,[x8,#0xb8] (static_fields) ; str x19,[x8] (saveList).
static constexpr uint64_t CLASS_STATIC_FIELDS    = 0xB8;      // Il2CppClass.static_fields (VERIFY OK)
static constexpr uint64_t STATIC_PLAYER_LIST  = 0x10;  // PlayerManager.clientPlayerList (List<PlayerManager>), static_fields+0x10
static constexpr uint64_t GC_STATIC_LOCAL_PM  = 0x10;  // GameControllerBase: static PlayerManager (локальный игрок)
static constexpr uint64_t STATIC_ACTIVE_LIST     = 0x8;       // activePlayerList (уточняется авто-сканом)
// ── BuildingPiece static collections (offline-verified через .cctor disasm) ──
//   static_fields + 0x0 -> HashSet<BuildingPiece> saveList   (str x19,[x8])
//   static_fields + 0x8 -> Dictionary<int,BuildingPiece> saveLookup (str x19,[x0,#8])
// КРИТИЧНО: saveList — это HashSet<T>, НЕ List<T>! Старый код читал его как
// List (items@0x10,size@0x18) -> всегда мусор/пусто -> LOS не работал вообще.
// dump.cs:296932  public static HashSet<Oxide.Building.BuildingPiece> saveList; // 0x0
// dump.cs:296933  public static Dictionary<int,Oxide.Building.BuildingPiece> saveLookup; // 0x8
static constexpr uint64_t STATIC_BUILDING_SAVELIST   = 0x0;   // HashSet<BuildingPiece>
static constexpr uint64_t STATIC_BUILDING_SAVELOOKUP = 0x8;   // Dictionary<int,BuildingPiece>

// --- Il2CppClass ---
static constexpr uint64_t CLASS_NAME      = 0x10; // const char* name
static constexpr uint64_t CLASS_NAMESPACE = 0x18; // const char* namespaze

// --- generic List<T> ---
static constexpr uint64_t LIST_ITEMS = 0x10; // T[] _items
static constexpr uint64_t LIST_SIZE  = 0x18; // int _size

// --- Il2CppArray ---
static constexpr uint64_t ARRAY_COUNT = 0x18; // il2cpp_array_size_t max_length
static constexpr uint64_t ARRAY_DATA  = 0x20; // начало элементов

// --- Mono System.Collections.Generic.HashSet<T> (managed ref-object layout) ---
// Резолвится в этом билде как Mono/классический HashSet (Slot[]+_lastIndex),
// НЕ .NET Core (Entry[]+_freeList head). Подтверждено il2cpp.h полями
// { _buckets,_slots,_count,_lastIndex,_freeList,_comparer,_version,_siInfo }
// и disasm (HashSet.Add читает _count @ +0x20). 64-bit il2cpp object header = 0x10.
//   +0x00 Il2CppObject.klass, +0x08 monitor
static constexpr uint64_t HASHSET_SLOTS      = 0x18; // Slot[] _slots (Il2CppArray*)
static constexpr uint64_t HASHSET_COUNT      = 0x20; // int _count  (живых элементов)  VERIFY OK (disasm)
static constexpr uint64_t HASHSET_LASTINDEX  = 0x24; // int _lastIndex (верхняя граница занятых слотов)
// Slot value-type в массиве: { int hashCode; int next; T value } -> stride 0x10 (ref T),
// value @ slot+0x8. Занятый слот: hashCode >= 0 (свободные помечены < 0).
static constexpr uint64_t HASHSET_SLOT_STRIDE   = 0x10;
static constexpr uint64_t HASHSET_SLOT_HASHCODE = 0x0;
static constexpr uint64_t HASHSET_SLOT_VALUE    = 0x8;

// --- Mono System.Collections.Generic.Dictionary<TKey,TValue> (fallback source) ---
// saveLookup = Dictionary<int,BuildingPiece>. Entry { int hashCode; int next;
// TKey key; TValue value }. Для <int, ref>: hashCode@0x0, next@0x4, key@0x8,
// value@0x10 -> stride 0x18. entries @ Dictionary+0x18, count @ +0x28.
static constexpr uint64_t DICT_ENTRIES        = 0x18; // Entry[] entries
static constexpr uint64_t DICT_COUNT          = 0x20; // int _count (дамп 1.13.946: _buckets 0x10, _entries 0x18, _count 0x20, _freeList 0x24, _freeCount 0x28). Было 0x28 = freeCount, из-за чего обходы словарей молча давали 0
static constexpr uint64_t DICT_ENTRY_STRIDE   = 0x18; // {int,int,int,ptr} align8
static constexpr uint64_t DICT_ENTRY_HASHCODE = 0x0;
static constexpr uint64_t DICT_ENTRY_VALUE    = 0x10; // BuildingPiece* (ключ int @0x8)

// --- Авто-скан статиков ---
static constexpr uint64_t STATIC_SCAN_MAX = 0x400; // сколько байт static_fields сканировать
static constexpr int      LIST_COUNT_MAX  = 100;   // разумный максимум игроков в списке

// --- PlayerManager instance (сверено с dump.cs 2026/07/23, TypeDefIndex 8251) ---
static constexpr uint64_t PM_TRANSFORM         = 0x68;  // Transform worldCameraRoot (держит YAW камеры)
// Прямая позиция игрока в мире: server-authoritative анти-чит поле.
// Работает для ВСЕХ игроков (local + remote). worldCameraRoot есть только у
// локального — remote игроки его не имеют, отсюда баг "ESP крепится к камере".
// Vector3 @ 0x1E8 (12 байт: float x,y,z). UPDATE 1.13.946: было 0x1C8.
static constexpr uint64_t PM_KCC_REFERENCE     = 0xB0;  // InterfaceReference<KCC>; компонент проверяется по KCC.player
static constexpr uint64_t PM_LAST_TICK_POS     = 0x1E8;
static constexpr uint64_t PM_LAST_SAVED_POS    = 0x1F4;
static constexpr uint64_t PM_CHARACTER_MODEL   = 0x150; // GameObject* characterModel
static constexpr uint64_t PM_MOUSELOOK         = 0x70;  // Oxide.MouseLook mouseLook (VERIFY OK il2cpp.h)
static constexpr uint64_t PM_FPMANAGER         = 0x90;  // Oxide.FPManager fpManager (VERIFY OK) — живой FOV + ADS
static constexpr uint64_t PM_RAYCASTMANAGER    = 0x88;  // Oxide.RaycastManager raycastManager
static constexpr uint64_t PM_VITALS            = 0xC8;  // Oxide.PlayerVitals vitals
static constexpr uint64_t PM_LOOK_ANGLE        = 0x1C8; // float lookAngle (диагностика). UPDATE: было 0x1A8
// Прямого флага isLocalPlayer НЕТ. UPDATE 1.13.946: bool k__BackingField @0x1A8
// (было 0x188), Animator @0x1B0 (было 0x190), observedPlayer @0x370 (было 0x310).
// Надёжный локал-детект — через netIdentity (0x40) -> NI_IS_LOCAL_PLAYER (0x4A).
static constexpr uint64_t PM_IS_LOCAL_PLAYER   = 0x1A8; // [НЕТ прямого флага] bool k__BackingField — НЕнадёжно
static constexpr uint64_t PM_OBSERVED_PLAYER   = 0x3C8; // ARM64/x86_64 1.15.11966: PlayerManager.observedPlayer
static constexpr uint64_t PM_ANIMATOR          = 0x1B0; // Animator animator
// team-объект @0x120 (RBY), строковое имя команды teamName @0x2A0 (было 0x280).
// teamName (0x280) — Mirror SyncVar [string], реплицируется НА ВСЕХ клиентов для
// ВСЕХ игроков -> самый надёжный кросс-игроковый идентификатор команды.
// Подтверждено дампом 1.13.946: PlayerManager.teamName // 0x2A0.
static constexpr uint64_t PM_TEAM             = 0x120; // RBY team (компонент команды)
static constexpr uint64_t PM_TEAM_ID           = 0x120; // (алиас, историч.)
static constexpr uint64_t PM_TEAM_NAME         = 0x2A0; // string teamName (SyncVar). UPDATE: было 0x280
static constexpr uint64_t PM_USER_ID           = 0x298; // string userID. UPDATE: было 0x278
// v21: nicklabel (dM) — готовый флаг isTeammate, вычисленный самой игрой.
// PM_NICKLABEL (0x130) уже объявлен ниже; тут только под-оффсеты флагов.
static constexpr uint64_t NICKLABEL_IS_TEAMMATE = 0x91; // bool dM.isTeammate
static constexpr uint64_t NICKLABEL_IS_FRIEND   = 0x90; // bool dM.isFriend
// v22: детект стрельбы (режим Fire) использует существующие PM_FPMANAGER (0x90)
// и FP_CURRENT_WEAPON (0x50) — объявлены ниже.

// ── Доп. поля PlayerManager для расширенного ESP (дамп 1.13.946) ──────────
static constexpr uint64_t PM_NICKLABEL         = 0x130; // dM* nicklabel (UI-подпись игрока)
static constexpr uint64_t PM_CLAN_ID           = 0x2B0; // string clanId (SyncVar)
static constexpr uint64_t PM_CLAN_TAG          = 0x2B8; // string clanTag (SyncVar)
// Текущее HP. GenericVitals.m_MaxHealth (VITALS_HEALTH) — это МАКСИМУМ; живое значение лежит в
// событийной модели игрока: Rys (PM.playerEventHandler, наследник Ryk) -> Ryk.Health = RyV<float, ...>.
// У RyV два float подряд (rgf, rgL); какой из них «текущий», а какой «предыдущий/базовый» — не определено
// по дампу, поэтому ox_readHpLive выбирает по тому, как значения меняются (см. main.cpp). Дамп 1.13.946.
static constexpr uint64_t PM_EVENT_HANDLER     = 0x78;  // Rys* playerEventHandler
static constexpr uint64_t VITALS_ENTITY        = 0x68;  // RyX.Entity (Ryk*)
static constexpr uint64_t VITALS_PLAYER_EVENT  = 0x108; // PlayerVitals.PlayerEvent (Rys*)
static constexpr uint64_t RYS_MANAGER          = 0xD0;  // Rys.manager -> PlayerManager (обратная ссылка для проверки)
static constexpr uint64_t RYK_HEALTH           = 0x98;  // Ryk.Health -> RyV<float, ReasonedValueReasonHealthEvent>*
static constexpr uint64_t REASONED_VALUE_A     = 0x20;  // RyV: float rgf
static constexpr uint64_t REASONED_VALUE_B     = 0x24;  // RyV: float rgL

// ── Настоящие ники: реестр игроков матча ──────────────────────────────────────────────────────────
// Ник не приходит SyncVar'ом и не лежит в PlayerManager (там только userID/clanTag); подпись над головой
// (dM.nickname.m_Text) у чужих игроков остаётся заготовкой «Nickname». Настоящие ники хранит список игроков матча:
// PM.team (RBY) -> RBY.rUk (iZ, менеджер команд) -> iZ.playersList (RBK) -> RBK.playerModels (PlayerModel[]).
// PlayerModel — структура {string id; string nick; string clanId; string clanTag; bool premium; int level; bool prime}.
static constexpr uint64_t RBY_TEAM_MANAGER     = 0x80;  // RBY.rUk -> iZ
static constexpr uint64_t IZ_PLAYERS_LIST      = 0x70;  // ARM64/x86_64 1.15.11966: qH.playersList -> hAO
static constexpr uint64_t RBK_TEAM_MANAGER     = 0x88;  // RBK.teamManager -> iZ (обратная ссылка)
static constexpr uint64_t RBK_MAX_PLAYERS      = 0x98;  // int maxPlayers
static constexpr uint64_t RBK_PLAYERS_COUNT    = 0x9C;  // int playersCount
static constexpr uint64_t RBK_PLAYER_MODELS    = 0xB0;  // PlayerModel[]
static constexpr uint64_t PLAYERMODEL_STRIDE   = 0x30;  // размер структуры в массиве
static constexpr uint64_t PLAYERMODEL_ID       = 0x00;  // string id (== PM.userID)
static constexpr uint64_t PLAYERMODEL_NICK     = 0x08;  // string nick
static constexpr uint64_t PLAYERMODEL_CLAN_TAG = 0x18;  // string clanTag
static constexpr uint64_t PLAYERMODEL_LEVEL    = 0x24;  // int level
static constexpr uint64_t RYK_DISPLAY_NAME     = 0x88;  // Ryk.DisplayName (запасной источник ника)
static constexpr uint64_t RBK_PLAYER_DICT      = 0xC8;  // Dictionary<string, PlayerModel> (id -> модель): запасной источник ников

// ── Контроллер игры (синглтон) и баллистика ────────────────────────────────────────────────────────
// GameControllerBase: статическое поле <Instance> (static_fields + 0x60) и его экземпляр. Через него достижимы
// реестр игроков (playersListManager) и менеджер пуль всех игроков (ballisticShots, Qe).
static constexpr uint64_t GC_STATIC_INSTANCE   = 0x60;  // static GameControllerBase (синглтон)
static constexpr uint64_t GC_BALLISTIC_SHOTS   = 0xD8;  // Qe ballisticShots
static constexpr uint64_t GC_PLAYERS_LIST      = 0x198; // RBK playersListManager (1.14.11949; в 1.13.946 было 0x1A8)
// Qe: список ЖИВЫХ пуль (List<Qr>) — в нём пули, выпущенные любыми игроками.
static constexpr uint64_t QE_BULLETS           = 0x20;  // List<Qr>
static constexpr uint64_t QR_STATE_POS         = 0x38;  // BallisticState.Position (Vector3)
static constexpr uint64_t QR_STATE_VEL         = 0x44;  // BallisticState.Velocity (Vector3)
static constexpr uint64_t QR_OWNER_OBJ         = 0x60;  // QV owner — оружие стрелка (FPHitscan и т.п.)
static constexpr uint64_t QR_KIND              = 0x90;  // ShotKind: 0 hitscan, 1 projectile
static constexpr uint64_t QR_SHOT_ID           = 0xB4;  // int ShotId
static constexpr uint64_t QR_OWNER_ID          = 0xB8;  // uint OwnerId (netId стрелка)
static constexpr uint64_t QR_GRAVITY          = 0x50;  // BallisticParams.Gravity (float) внутри пули: Ff.ayd (дамп 1.14.11949)
static constexpr uint64_t QR_SIZE              = 0xF0;  // читаем весь объект одним вызовом

// ── Попадания локального игрока и урон оружия ────────────────────────────────────────────────────
// Сервер не присылает клиенту HP чужих игроков (нет ни SyncVar, ни RPC; игра показывает лишь маркер попадания
// HitData{IsCritical, IsKill}). Поэтому полоска HP — оценка по ВАШИМ попаданиям: событие даёт Rys.LastLocalHitTime/Point,
// цель — игрок под прицелом (Rys.AimRaycast -> RyT.PlayerManager) или ближайший к точке попадания.
// Ryr<T> — реактивное значение: два значения подряд (rgC, rgE) после двух указателей (Action, Filter).
static constexpr uint64_t RYS_LOOK_DIRECTION   = 0x140; // Rys.LookDirection (Vsf<Vector3>): направление взгляда, из него игра берёт направление выстрела; значение по RYR_VALUE_A
static constexpr uint64_t HSCFG_BULLET_SPEED   = 0x30;  // HitscanWeaponConfig.BulletSpeed (float)
static constexpr uint64_t HSCFG_BALLISTIC      = 0x60;  // HitscanWeaponConfig.ballistic (BallisticProfile*)
static constexpr uint64_t BPROFILE_GRAVITY     = 0x10;  // BallisticProfile.gravity (float)
static constexpr uint64_t RYS_AIM_RAYCAST      = 0x168; // Ryr<RyT>
static constexpr uint64_t RYS_LAST_HIT_POINT   = 0x170; // Ryr<Vector3>
static constexpr uint64_t RYS_LAST_HIT_TIME    = 0x178; // Ryr<float>
static constexpr uint64_t RYS_AIM_STATE        = 0x298; // Rys.Aim (VsC): состояние «целюсь», bool по +0x10 (1.13.946: Ryz, то же смещение)
static constexpr uint64_t VSC_VALUE            = 0x10;  // VsC.<value> bool
static constexpr uint64_t RYS_RECOIL           = 0x138; // Rys.Recoil (Vsf<Vector2>): текущая отдача, 2 float по RYR_VALUE_A
static constexpr uint64_t PW_WEAPON_STATE      = 0x120; // PlayerWeapon.weaponState (enum WeaponState: Idle 0, Reload 1, Attack 2, Draw 3, Holster 4, Fire 5, LoopReload 6)
// Auto-heal inventory bridge; verified against ARM64 and x86_64 1.14.11949 dumps.
static constexpr uint64_t PM_INVENTORY        = 0x98;
static constexpr uint64_t PINV_DATA           = 0x20;  // PlayerInventory._playerInventoryData
static constexpr uint64_t PINV_CLIENT         = 0x28;  // PlayerInventory._playerInventoryClient
static constexpr uint64_t PINV_DATA_PLAYER    = 0x10;  // PlayerInventoryData.player
static constexpr uint64_t INVCLIENT_HOTBAR    = 0xA0;  // ARM64/x86_64 1.15.11966: hCf.Hotbar backing field
static constexpr uint64_t HOTBAR_SLOTS        = 0x88;  // Hotbar.lgz : List<Slot>
static constexpr uint64_t HOTBAR_SELECTED     = 0x90;  // Hotbar.lgi : Slot
static constexpr uint64_t UI_SLOT_CELL        = 0x268; // Slot.lFS : VYy
static constexpr uint64_t CELL_ITEM           = 0x10;  // VYy.qIP : Item
static constexpr uint64_t RYS_EQUIPPED_ITEM    = 0x1B8; // Ryr<Item>
static constexpr uint64_t RYR_VALUE_A          = 0x20;  // Ryr<I>.rgC
static constexpr uint64_t RYR_VALUE_B_REF      = 0x28;  // rgE у ссылочных типов (RyT, Item)
static constexpr uint64_t RYR_VALUE_B_VEC3     = 0x2C;  // rgE у Vector3 (сразу за rgC: читаются одним вызовом)
static constexpr uint64_t RYT_PLAYER           = 0x40;  // RyT.PlayerManager (кто под прицелом)
static constexpr uint64_t PM_WEAPONS           = 0x1B8; // FPWeaponBase[] weapons
static constexpr uint64_t PM_WEAPON_REF        = 0xF0;  // InterfaceReference<QF> weaponReference
static constexpr uint64_t FPOBJECT_PLAYER      = 0xC0;  // FPObject.Player
static constexpr uint64_t FPOBJECT_ITEM        = 0x40;  // FPObject.Item (привязанный предмет)
static constexpr uint64_t FPHITSCAN_CONFIG     = 0x130; // FPHitscan.config (HitscanWeaponConfig)
static constexpr uint64_t FPROCKET_CONFIG      = 0x128; // FPRocketLauncher.config
static constexpr uint64_t FPCROSSBOW_CONFIG    = 0x138; // FPCrossbow.config
// Стрелковое оружие со снарядом ShaftedProjectile (дамп 1.14.11949): у лука и копья HitscanWeaponConfig нет, скорость лежит в префабе снаряда.
static constexpr uint64_t FPBOW_ARROW_PREFAB      = 0x150; // FPBow.m_ArrowPrefab (ShaftedProjectile)
static constexpr uint64_t FPCROSSBOW_ARROW_PREFAB = 0x148; // FPCrossbow.m_ArrowPrefab
static constexpr uint64_t FPSPEAR_PREFAB          = 0x178; // ARM64/x86_64 1.15.11966: FPSpear.m_SpearPrefab
static constexpr uint64_t SP_MODEL                = 0x68;  // ShaftedProjectile.m_Model (Transform)
static constexpr uint64_t SP_PIVOT                = 0x70;  // ShaftedProjectile.m_Pivot (Transform)
static constexpr uint64_t SP_WEAPON_LAUNCHED      = 0x90;  // FPWeaponBase m_WeaponLaunched
static constexpr uint64_t SP_LAUNCH_SPEED         = 0xA8;  // float m_LaunchSpeed
static constexpr uint64_t SP_GRAVITY              = 0xAC;  // float gravity
static constexpr uint64_t SP_AIR_DRAG             = 0xB0;  // float airDrag
static constexpr uint64_t HSCFG_DAMAGE         = 0x18;  // float damage
static constexpr uint64_t HSCFG_MAX_DISTANCE   = 0x2C;  // float MaxDistance
static constexpr uint64_t HSCFG_FIRE_RATE      = 0x34;  // float fireRate
static constexpr uint64_t HSCFG_PELLETS        = 0x38;  // int projectilesPerShot
static constexpr uint64_t PM_PLAYER_FLAGS      = 0x270; // PlayerFlags (Sleeping/Spectating/Muted). UPDATE: было 0x250
static constexpr uint64_t PM_PRIME             = 0x274; // bool prime. UPDATE: было 0x254
static constexpr uint64_t PM_IS_IN_AIR         = 0x1D8; // bool isInAir. UPDATE: было 0x1B8
static constexpr uint64_t PM_RESPAWNING        = 0x228; // bool respawning. UPDATE: было 0x208

// nicklabel (класс lH): держит UI-тексты с ником и id игрока.
//   lH + 0x38 -> UnityEngine.UI.Text nickname
//   lH + 0x40 -> UnityEngine.UI.Text playerId
// UnityEngine.UI.Text + 0xE0 -> String m_Text
static constexpr uint64_t NICKLABEL_NICKNAME   = 0x38;
static constexpr uint64_t NICKLABEL_PLAYERID   = 0x40;
static constexpr uint64_t UITEXT_M_TEXT        = 0xE0;

// ── Оружие в руках: PM -> FPManager -> FPObject -> Item -> ItemData -> имя ──
//   PM         + 0x90 -> FPManager
//   FPManager  + 0x50 -> FPObject _currentWeapon
//   FPObject   + 0x40 -> Item     (_cSb_k__BackingField)
//   Item       + 0x20 -> ItemData <rBk>k__BackingField (1.13.946; было 0x28)
//   ItemData   + 0x20 -> String   m_ShortName   (короткое имя, для ESP-подписи)
//   ItemData   + 0x18 -> String   m_Name
static constexpr uint64_t FPOBJ_ITEM           = 0x40; // Item* <rGJ>k__BackingField
static constexpr uint64_t ITEM_DATA            = 0x20; // ItemData* <rBk>k__BackingField. UPDATE 1.13.946: было 0x28
static constexpr uint64_t ITEMDATA_SHORTNAME   = 0x20; // string m_ShortName
static constexpr uint64_t ITEMDATA_NAME        = 0x18; // string m_Name

// ── Броня: GenericVitals + 0x90 -> ProtectionValues ────────────────────────
static constexpr uint64_t VITALS_PROTECTION    = 0x90; // ProtectionValues*
// --- WNn (team component) -> pf (team data) --- для corroborating team-check.
//   WNn.team (pf*) @ 0x90 ; pf.mYs (string teamId) @ 0x10 ; pf.mYo (string) @ 0x18
// pf — ШАРЕННЫЙ объект данных команды; у сокомандников совпадает pf.mYs (teamId).
static constexpr uint64_t WNN_TEAM_DATA        = 0x98; // RBY.team (im*). UPDATE: было 0x90
// nWc (компонент команды на PM+0x120) -> Cc team @0x90 — тот же объект данных
// команды. Держим как второй путь: если один указатель не заполнен, работает
// другой. Cc: dCs(0x10) teamId, dCQ(0x18) teamName, dCI(0x20) List<TeamMember>.
static constexpr uint64_t NWC_TEAM_DATA        = 0x98; // UPDATE 1.13.946: было 0x90
// nWc.TeammateStates — Dictionary<string userID, TeammateStatus>. В этом билде
// nWc.team(0x90) приходит НУЛЁМ даже когда игрок в команде (лог: lpf=0x0 при
// живом lw), а вот словарь состояний заполнен. Ключи — userID сокомандников,
// ровно то, что нужно для сверки с PM.userID цели.
static constexpr uint64_t NWC_TEAMMATE_STATES  = 0x78; // UPDATE 1.13.946: было 0x70
static constexpr uint64_t NWC_PLAYER           = 0x88; // обратная ссылка на PM. UPDATE: было 0x80
static constexpr uint64_t NWC_ONLINE           = 0xA0; // int online (размер команды). UPDATE: было 0x98
// Dictionary с КЛЮЧОМ-ссылкой (string): entry = {hash, next, key*, value}
static constexpr uint64_t DICT_SENTRY_STRIDE   = 0x20;
static constexpr uint64_t DICT_SENTRY_HASHCODE = 0x0;
static constexpr uint64_t DICT_SENTRY_KEY      = 0x10;
static constexpr uint64_t DICT_SENTRY_VALUE    = 0x18;
// RaycastManager.teamManager(0x28) -> CW: UI-менеджер панели команды.
// CW.membersList(0x90) — List<nWR>, по строке на каждого сокомандника.
// nWR.identificator(0x38) — UI.Text с userID участника. Это ТРЕТИЙ независимый
// путь: он живёт в UI-слое и заполнен, даже когда nWc.team и TeammateStates
// пустые (панель команды рендерится из своих данных).
// ── Mirror.NetworkClient (static class, TDI 23916) ─────────────────────────
// spawned — Dictionary<uint netId, NetworkIdentity> ВСЕХ сетевых объектов,
// которые знает клиент. Резервный источник построек для LOS: BuildingPiece
// добавляется в saveList только на СЕРВЕРЕ (OnStartServer), поэтому у клиента
// тот список пустой (в логах count=0), а spawned заполнен всегда.
// NetworkIdentity.NetworkBehaviours(0x80) — массив компонентов объекта; среди
// них и лежит BuildingPiece, опознаваемый по обратной валидации полей.
// ── ОДНОЗНАЧНЫЙ признак локального игрока ──────────────────────────────────
// PlayerManager наследует Mirror.NetworkBehaviour, у которого netIdentity
// лежит на 0x40. В самом NetworkIdentity есть флаг isLocalPlayer (0x4A) —
// Mirror выставляет его РОВНО ОДНОМУ объекту за матч, тому, которым управляет
// этот клиент.
//
// Это решает старую проблему: ox_localPlayerAlive проверяла лишь наличие
// MouseLook+RaycastManager, а они есть у ВСЕХ игроков, поэтому «локальным»
// мог оказаться чужой PM — и базис камеры строился из чужих углов. Свою
// камеру поворачиваешь, а боксы считаются от чужой: ESP «плавает».
static constexpr uint64_t NB_NET_IDENTITY      = 0x40; // NetworkIdentity*
static constexpr uint64_t NI_IS_LOCAL_PLAYER   = 0x4A; // bool isLocalPlayer
static constexpr uint64_t NI_IS_OWNED          = 0x4B; // bool isOwned
static constexpr uint64_t NC_SPAWNED_DICT      = 0x30; // static_fields + 0x30. UPDATE 1.13.946: было 0x28
static constexpr uint64_t NI_NET_ID            = 0x58; // uint netId
static constexpr uint64_t NI_BEHAVIOURS        = 0x80; // NetworkBehaviour[]
static constexpr int      SPAWNED_SCAN_MAX     = 4000; // потолок обхода за проход
static constexpr uint64_t RM_TEAM_MANAGER      = 0x28; // CW* teamManager
static constexpr uint64_t CC_TEAM_ID           = 0x10;
static constexpr uint64_t CC_TEAM_NAME         = 0x18;
static constexpr uint64_t CC_TEAM_MEMBERS      = 0x20;
// pf (класс команды, TypeDefIndex 548):
//   +0x10 string mYs                    — teamId
//   +0x18 string mYo                    — teamName
//   +0x20 List<TeamMember> mYK          — СОСТАВ команды
// TeamMember (TypeDefIndex 549):
//   +0x10 string id     — userID участника (совпадает с PM.userID @0x278)
//   +0x18 string clanTag
//   +0x20 string nick
//   +0x28 int    lvl
//   +0x2C uint   netId
// Прямая проверка «этот игрок — мой сокомандник»: берём pf локального игрока,
// идём по mYK и сверяем TeamMember.id с PM.userID цели. Не зависит от того,
// заполнены строковые поля команды или нет.
static constexpr uint64_t PF_TEAM_MEMBERS      = 0x20; // List<TeamMember> mYK
static constexpr uint64_t TEAMMEMBER_ID        = 0x10; // string id (== PM.userID)  // pf team (data object)
static constexpr uint64_t PF_TEAM_ID_STR       = 0x10;  // string mYs (team id)

// --- MouseLook (Oxide.MouseLook, TypeDefIndex 7902) ---
// ============================================================================
//  ГЛАВНЫЙ ФИКС ДРЕЙФА ESP (bug #1/#2/#3).
//  Offline disasm MouseLook.uae (0x52B0AD4) на erafox libil2cpp (byte-identical
//  игре), Unity 6000.3.18f1 — ГРУНТ-ТРУС того, что реально хранится в полях:
//
//   * m_LookRoot @0x28 — Transform (PITCH-пивот, ребёнок yaw-пивота). Его
//     localRotation КАЖДЫЙ кадр ставится игрой как:
//        m_LookRoot.localRotation = Quaternion.Euler( kqP.x°, 0, roll )
//     (disasm: ldr s9,[x19,#0x60]; ...Internal_FromEulerRad; set_localRotation).
//     Значит kqP.x (0x60) = ПИТЧ В ГРАДУСАХ (+вниз). Yaw на m_LookRoot = 0.
//   * kqP.y (0x64) = YAW В ГРАДУСАХ (аккумулятор, применяется к телу через
//     WPr.GTv). Совпадает с конвенцией, которую пишет аимбот
//     (yaw=atan2(dx,dz), pitch=-atan2(dy,horiz)) — проверено численно.
//
//  ПОЧЕМУ РАНЬШЕ ДРЕЙФИЛО: ESP-базис строился из МИРОВОГО кватерниона
//  m_LookRoot, читаемого через НАТИВНЫЙ Transform (matrixData+0xA0). Но:
//    (a) matrixData читался по internal+0x28, а 0x28 в Unity Transform_internal
//        = `self` (back-ptr), НЕ mData (mData@0x38) — читался мусор;
//    (b) даже с верным 0x38 нативный world-кватернион лежит в libunity
//        (icall get_rotation_Injected) — оффсет непроверяем из libil2cpp.
//  РЕШЕНИЕ: базис камеры строим ИЗ УГЛОВ kqP.x/kqP.y (managed float'ы,
//  100% проверяемо, без libunity). См. ox_readLookBasis в main.cpp.
//
//  Для aimbot-ПИСЬМА в 0x60/0x64 (движок сам строит из них поворот) — как было.
// ============================================================================
// UPDATE 1.13.946: раскладка MouseLook ИЗМЕНИЛАСЬ (пропали пары float 0x4C..0x5C
// и Vector2 @0x60). Точный field питча/йава из дампа однозначно не выводится,
// поэтому mid=публичное свойство Vector2 (<rvL>k__BackingField @0x88) — как
// единственный именованный источник углов. ТРЕБУЕТ рантайм-подтверждения
// (лог [sweep]/angle-basis) или повторного дизасма MouseLook.Update.
static constexpr uint64_t ML_ANGLES_BACKING = 0x88; // Vector2 <rvL>k__BackingField. UPDATE: было 0x90
static constexpr uint64_t ML_ANGLES   = 0x88; // (алиас)
static constexpr uint64_t ML_LOOKROOT = 0x28; // Transform m_LookRoot (PITCH-пивот)
static constexpr uint64_t ML_PITCH    = 0x88; // rvL.x — PITCH В ГРАДУСАХ (+вниз). read(ESP)+write(aim). UNVERIFIED
static constexpr uint64_t ML_YAW      = 0x8C; // rvL.y — YAW В ГРАДУСАХ. read(ESP)+write(aim). UNVERIFIED
static constexpr uint64_t ML_SENSITIVITY = 0x34; // float m_Sensitivity
static constexpr uint64_t ML_INVERT      = 0x30; // bool m_Invert
static constexpr uint64_t ML_DEFAULT_LOOK_LIMITS = 0x38; // Vector2 (min,max pitch) standing
static constexpr uint64_t ML_CROUCH_LOOK_LIMITS  = 0x40; // Vector2 (min,max pitch) crouched

// --- Oxide.FPManager (PM+0x90) — живой FOV камеры + ADS-детект ---
// ============================================================================
//  Offline disasm FPManager.LateUpdate (0x52DAE88) + jWU (0x52DAA2C):
//    kYl  @0xA0 — интерполированный ТЕКУЩИЙ ВЕРТИКАЛЬНЫЙ FOV (движок пишет его
//                 в Camera.set_fieldOfView каждый LateUpdate). VERIFY OK.
//    kSP  @0xB4 — FOV-оффсет (отдача/дыхание). Эффективный FOV = kYl - kSP.
//    _kSQ @0xAC — БАЗОВЫЙ верт. FOV (из PlayerPrefs, с коррекцией на aspect).
//  Итог: реальный вертикальный FOV камеры = kYl(0xA0) - kSP(0xB4).
//  ADS-детект: при прицеле kYl падает ниже _kSQ (зум) -> aiming = kYl < _kSQ*τ.
//  Это заменяет ФИКСИРОВАННЫЙ camFov-слайдер (тот игнорировал реальный и
//  меняющийся при прицеле FOV -> боксы уезжали к краям / грубо врали в прицеле).
// ============================================================================
static constexpr uint64_t FP_WORLD_CAMERA   = 0x20; // UnityEngine.Camera m_WorldCamera
static constexpr uint64_t FP_CURRENT_WEAPON  = 0x50; // Oxide.FPObject _currentWeapon
static constexpr uint64_t FP_FOV_CURRENT     = 0xA0; // float kYl — интерполир. текущий верт. FOV  VERIFY OK
static constexpr uint64_t FP_FOV_BASE        = 0xAC; // float _kSQ — базовый верт. FOV             VERIFY OK
static constexpr uint64_t FP_FOV_OFFSET      = 0xB4; // float kSP — FOV-оффсет (recoil)            VERIFY OK
// FPObject (_currentWeapon) — для доп. ADS-инфо (статический конфиг оружия).
static constexpr uint64_t FPOBJ_NORMAL_FOV   = 0x80; // int normalFOV
static constexpr uint64_t FPOBJ_AIM_FOV      = 0x84; // int aimFOV
// Порог ADS: aiming, если текущий FOV меньше базового в этот раз.
static constexpr float    ADS_FOV_RATIO      = 0.90f; // kYl < _kSQ*0.90 => прицеливается
static constexpr float    EYE_FOV_MIN        = 5.0f;  // санитарный минимум верт. FOV
static constexpr float    EYE_FOV_MAX        = 160.0f;// санитарный максимум верт. FOV

// --- RaycastManager (TypeDefIndex 8048) ---
// PlayerManager+0x88. Собственный слой raycast'ов прицела.
// dump.cs 2026/07/23: player @0x20, teamManager @0x28, дальше камера и маски.
// Прошлый «-0x8 сдвиг» был ОШИБОЧНЫМ — реальные оффсеты ниже.
static constexpr uint64_t RM_PLAYER         = 0x20; // PlayerManager player (новое поле)
static constexpr uint64_t RM_WORLD_CAMERA   = 0x30; // Camera m_WorldCamera (FIX: было 0x28)
static constexpr uint64_t RM_RAY_LENGTH     = 0x38; // float m_RayLength (FIX: было 0x30)
static constexpr uint64_t RM_AIM_RAY_LENGTH = 0x3C; // float m_AimRayLength (FIX: было 0x34)
static constexpr uint64_t RM_LAYER_MASK     = 0x48; // LayerMask m_LayerMask (FIX: было 0x40)
static constexpr uint64_t RM_AIM_LAYER_MASK = 0x4C; // LayerMask m_AimLayerMask (FIX: было 0x44)

// --- PlayerVitals / GenericVitals base ---
// Иерархия: PlayerVitals : EntityVitals : GenericVitals. m_MaxHealth @0x88 (GenericVitals)
// читается и через указатель PlayerVitals. Отдельного поля «текущее HP» нет;
// для alive-чека (>0) хватает.
static constexpr uint64_t VITALS_HEALTH = 0x88; // float m_MaxHealth (GenericVitals, подтв.)

// --- UnityEngine.Transform -> нативная цепочка (стандарт il2cpp) ---
// managed Transform + 0x10 -> m_CachedPtr (нативный Transform*)
static constexpr uint64_t OBJ_CACHED_PTR      = 0x10;

// ── Скелет: цепочка от PlayerManager до костей модели ──────────────────────
// PM.animator (0x190) -> Animator; но нам нужен PlayerModelInfo, который
// висит на CharacterAnimation. Путь (все оффсеты из il2cpp.h дампа 2026/07/24):
//   PM + PM_ANIMATOR(0x190)              -> UnityEngine.Animator
//   PM + PM_CHARACTER_MODEL(0x150)       -> GameObject модели
// PlayerModelInfo (HyperHug...Player.PlayerModelInfo):
//   +0x20 head          Transform    <- голова
//   +0x28 rightWeaponHolder Transform <- правая кисть
//   +0x30 leftWeaponHolder  Transform <- левая кисть
//   +0x40 body          Transform    <- корпус (таз/грудь)
//   +0x60 characterAnimation -> CharacterAnimation
// CharacterAnimation:
//   +0x30 playerModelInfo -> обратно на PlayerModelInfo
//   +0x38 ragdoll         -> Ragdoll (у него +0x88 m_Bones — массив всех костей)
static constexpr uint64_t PMI_HEAD            = 0x20; // Transform head
static constexpr uint64_t PMI_RIGHT_HAND      = 0x28; // Transform rightWeaponHolder
static constexpr uint64_t PMI_LEFT_HAND       = 0x30; // Transform leftWeaponHolder
static constexpr uint64_t PMI_BODY            = 0x40; // Transform body
static constexpr uint64_t PMI_EQUIPMENT       = 0x38; // Transform equipmentHolder
static constexpr uint64_t PMI_HEAD_MODEL      = 0x48; // Transform headModel
static constexpr uint64_t PMI_CHAR_ANIM       = 0x60; // CharacterAnimation*
static constexpr uint64_t CHARANIM_MODELINFO  = 0x30; // PlayerModelInfo*
static constexpr uint64_t CHARANIM_PLAYER     = 0x78; // CharacterAnimation.player (PlayerManager*) — обратная ссылка для самопроверки
static constexpr uint64_t CHARANIM_RAGDOLL    = 0x38; // Ragdoll*
static constexpr uint64_t RAGDOLL_PELVIS      = 0x20; // Rigidbody m_Pelvis
static constexpr uint64_t RAGDOLL_BONES       = 0x88; // Rigidbody[] m_Bones (1.15; константа сейчас не используется)
// KCC (HyperHug...Player.KCC) — альтернативный источник головы:
static constexpr uint64_t KCC_PLAYER          = 0x78; // PlayerManager*
static constexpr uint64_t KCC_HEAD            = 0x88; // Transform head
static constexpr uint64_t KCC_MOTOR           = 0x68; // KinematicCharacterMotor* <Motor>k__BackingField

// ── РЕАЛЬНЫЙ СКЕЛЕТ через lag-comp хитбоксы (dump verified, arm64 2026/07) ──
//  Цепочка: PM.kccReference(0xB0) -> [SingleKcc] -> hitBoxRecorderRoot(0x78)
//    -> BnM (eR[]) @0x80 -> eR[i] { HitBox* @0x10, worldPos(Vector3) @0x34 }.
//  eR.worldPos = ЖИВАЯ мировая позиция кости-хитбокса каждый тик (лаг-комп),
//  ЕДИНСТВЕННЫЙ источник, живой у remote-игроков (KCC.head=null, Motor заморожен).
//  SingleKcc отличается от KinematicCharacterMotor: у него player-backref @0x80.
static constexpr uint64_t SKCC_PLAYER         = 0x80; // SingleKcc.player (back-ref на PM)
static constexpr uint64_t SKCC_MOTOR          = 0x70; // SingleKcc.<Motor>k__BackingField (x86_64 dump)
static constexpr uint64_t SKCC_RECORDER       = 0x78; // SingleKcc.hitBoxRecorderRoot
static constexpr uint64_t SKCC_CHARANIM       = 0xC0; // [STALE 1.13.946] SingleKcc.@0xC0 теперь TG, не CharacterAnimation (константа не используется)
static constexpr uint64_t HBR_BNM             = 0x98; // HitBoxRecorderRoot.mYx (Ls[] = бывший eR[]). UPDATE 1.13.946: было 0x80
static constexpr uint64_t HBR_HITBOXES        = 0x68; // HitBoxRecorderRoot.hitBoxes (HitBox[])
static constexpr uint64_t ER_HITBOX           = 0x10; // eR.BnW (HitBox* back-ref)
static constexpr uint64_t ER_WORLDPOS         = 0x34; // eR.BnV (Vector3) — мировая позиция кости
static constexpr uint64_t ER_WORLDROT         = 0x40; // eR.Bnr (Quaternion)
static constexpr uint64_t HB_HITAREA          = 0x68; // HitBox.m_HitArea (0 Head,1 Chest,2 Leg,3 Foot,4 Hand)
static constexpr uint64_t HB_ID               = 0x6C; // HitBox.id
// ── KinematicCharacterMotor: интерполированная позиция отрисовки ───────────
// LastInterpolatedPosition — это позиция, которой игра РИСУЕТ модель в
// текущем кадре. В отличие от PM.lastTickPosition (серверный тик 10-20 Гц)
// она обновляется каждый кадр, поэтому бокс не отстаёт от бегущей цели.
static constexpr uint64_t MOTOR_INTERP_POS    = 0x1EC; // Vector3 LastInterpolatedPosition
static constexpr uint64_t MOTOR_TICK_POS      = 0x1E0; // Vector3 InitialTickPosition
static constexpr uint64_t MOTOR_BASE_VELOCITY = 0x210; // Vector3 BaseVelocity
static constexpr uint64_t MOTOR_TRANSFORM     = 0x118; // Transform Wzu
// ЖИВАЯ высота капсулы. Игра уменьшает её при приседе с KCC.normalHeight до
// KCC.m_CrouchHeight — это читаемый снаружи признак приседа, которого не было
// в PlayerFlags. Прицел, построенный как доля от неё, приседает вместе с целью.
static constexpr uint64_t MOTOR_CAPSULE_HEIGHT = 0x34; // float CapsuleHeight
static constexpr uint64_t MOTOR_CAPSULE_YOFF   = 0x38; // float CapsuleYOffset
static constexpr uint64_t MOTOR_CAPSULE_RADIUS = 0x30; // float CapsuleRadius
static constexpr uint64_t KCC_NORMAL_HEIGHT    = 0xA0; // float normalHeight
static constexpr uint64_t KCC_CROUCH_HEIGHT    = 0xA4; // float m_CrouchHeight
static constexpr uint64_t KCC_LOOK_HEIGHT_OFF = 0x90; // float lookHeightOffset

// --- ПРЯМАЯ мировая позиция (нативные оффсеты движка, НЕ из dump.cs) ---
// нативный Transform хранит указатель на TRS-данные:
//   internal + 0x28 -> matrixData
//   matrixData + 0x90 position, +0xA0 rotation (quat), +0xB0 scale
// forward = quatRotate(rot, (0,0,1)). Эти оффсеты Unity-внутренние, сверяются
// рантайм-дампом (PDUMP), а не dump.cs.
static constexpr uint64_t TR_INT_MATRIXPTR    = 0x28;
static constexpr uint64_t TR_MATRIX_WORLDPOS  = 0x90;
static constexpr uint64_t TR_MATRIX_ROT       = 0xA0;
static constexpr uint64_t TR_MATRIX_SCALE     = 0xB0;

static constexpr uint64_t TR_INT_HIERARCHY    = 0x38;
static constexpr uint64_t TR_INT_INDEX        = 0x40;
static constexpr uint64_t TR_HIER_LOCALDATA   = 0x18;
static constexpr uint64_t TR_HIER_PARENTIDX   = 0x20;
static constexpr uint64_t TR_DATA_STRIDE      = 0x30; // Quaternion(0x10)+Vec3(0x0C)+Vec3(0x0C)->pad 0x30
static constexpr uint64_t TR_DATA_LOCALROT    = 0x00; // Quaternion (x,y,z,w)
static constexpr uint64_t TR_DATA_LOCALPOS    = 0x10; // Vector3
static constexpr uint64_t TR_DATA_LOCALSCALE  = 0x1C; // Vector3
static constexpr int      TR_MAX_PARENTS      = 64;   // защита от циклов

// --- Валидация HP «живой сущности» (как в эталоне libesp) ---
static constexpr float HP_MIN = 1.0f;
static constexpr float HP_MAX = 200.0f;

// --- Камера / W2S ---
// Unity 6000.3.18f1: Camera.fieldOfView = ВЕРТИКАЛЬНЫЙ FOV. Игру читаем НАПРЯМУЮ
// (FPManager.kYl - kSP -> реальный верт. FOV), поэтому W2S теперь работает в
// ВЕРТИКАЛЬНОМ FOV (tanV напрямую; tanH = tanV*(W/H)). Базис камеры строится из
// углов kqP.x(pitch)/kqP.y(yaw) — оба managed, проверяемы, без libunity icall'ов.
static constexpr float EYE_HEIGHT   = 1.6f;   // высота глаз над ногами игрока (стоя)
static constexpr float PLAYER_TOP   = 1.85f;  // макушка (для верхней точки бокса)
static constexpr float DEFAULT_VFOV = 60.0f;  // верт. FOV (град) fallback, если FPManager недоступен
static constexpr float DEFAULT_FOV  = 60.0f;  // (истор. алиас — верт. fallback)
// ox_readPos возвращает lastTickPosition (server-authoritative anti-cheat поле).
// Уровень этой точки зависит от того где у контроллера pivot — ноги, центр
// капсулы или голова. На дампе 2026/07/24 бокс вставал ВЫШЕ цели, значит pos
// не на ногах. Поэтому вертикальная привязка вынесена в живой слайдер
// espBoxYOffset (меню ESP -> BOX -> Vertical offset), а эти две константы
// задают только ВЫСОТУ бокса относительно привязки.
static constexpr float BOX_FOOT     = 0.0f;   // низ бокса = pos + yOffset
static constexpr float BOX_HEAD     = 1.85f;  // верх бокса = pos + yOffset + BOX_HEAD

// ============================================================================
//  BuildingPiece — для LOS-чек (аимбот не наводится через стены)
// ============================================================================
//  Oxide.Building.BuildingPiece : Mirror.NetworkBehaviour (TypeDefIndex 8521)
//
//  m_Bounds (0xD0) — Bounds в ЛОКАЛЬНЫХ координатах префаба. Мировую position
//  берём через m_CorrectPosition (0x8C). World-bounds = m_CorrectPosition +
//  m_Bounds.center ± m_Bounds.extents.
//  additionalBounds (0xF8) — доп. Bounds[] (для составных построек).
//  m_MeshCollider (0x130) / m_Colliders (0x170) — настоящие коллайдеры (на потом).
//  saveList (static 0x0) — HashSet<BuildingPiece> ВСЕХ построек (НЕ List!).
//  saveLookup (static 0x8) — Dictionary<int,BuildingPiece> (fallback-источник).
//  BuildingPiece.OnStartServer вызывает saveList.Add(this) (offline disasm
//  0x53fa314: bl HashSet.Add). Клиент читает saveList/saveLookup в десятках
//  методов (decay/neighbor/grade) -> коллекции существуют и на клиенте.
// ВСЕ оффсеты ниже сверены с il2cpp.h/dump.cs (Unity 6000.3.18f1, erafox dump).
static constexpr uint64_t BP_PIECE_NAME         = 0x80;  // string m_PieceName (подтв.)
static constexpr uint64_t BP_CORRECT_POSITION  = 0x8C;  // Vector3 m_CorrectPosition (подтв.)
static constexpr uint64_t BP_CORRECT_ROTATION   = 0x98;  // Vector3 m_CorrectRotation (подтв.)
static constexpr uint64_t BP_BOUNDS             = 0xD0;  // Bounds m_Bounds { center; extents } (FIX: было 0xC0)
static constexpr uint64_t BP_ADDITIONAL_BOUNDS  = 0xF8;  // Bounds[] additionalBounds (FIX: было 0xD8)
static constexpr uint64_t BP_M_GRADE             = 0x1B8; // BuildingGrade.Enum m_Grade. UPDATE 1.13.946: было 0x190
static constexpr uint64_t BP_GRADE_HOLDER        = 0x1C0; // Transform gradeHolder. UPDATE 1.13.946: было 0x198
static constexpr uint64_t BP_HEALTH             = 0x3B8; // float health (>0 = стоит). UPDATE 1.13.946: было 0x380
static constexpr uint64_t BP_MAXHEALTH          = 0x3BC; // float maxHealth. UPDATE 1.13.946: было 0x384
static constexpr uint64_t BP_ID                 = 0x3C4; // int id. UPDATE 1.13.946: было 0x38C

// Bounds struct (UnityEngine): m_Center, m_Extents. min = center-extents, max = center+extents
static constexpr uint64_t BOUNDS_CENTER  = 0x0;
static constexpr uint64_t BOUNDS_EXTENTS = 0xC;

// LOS-чек настройки
static constexpr float    LOS_AABB_INFLATE   = 0.30f;  // расширим AABB на 30см — conservatism
static constexpr int      LOS_SAVELIST_MAX   = 2000;   // верхнее ограничение (защита от мусора)
static constexpr float    LOS_TARGET_EPS     = 1.0f;   // 1 м — чтобы не ложно-позитивить у цели


// --- Экипировка и руда (дамп 1.13.946) ---
static constexpr uint64_t PM_EQUIPMENT        = 0xE8;  // RBr equipment
static constexpr uint64_t EQUIP_SLOTS_DICT    = 0xA8;  // RBr.Dictionary<RBX, int>: надетые предметы (RBX.Item @0x10)
static constexpr uint64_t SLOT_ITEM           = 0x10;  // RBX.<Item>
static constexpr uint64_t GC_ITEM_DATABASE    = 0x70;  // GameControllerBase.m_ItemDatabase
static constexpr uint64_t ITEMDB_BY_ID        = 0x28;  // ItemDatabase.m_ById (Dictionary<int, ItemData>)
static constexpr uint64_t ITEMDATA_ID         = 0x58;  // ItemData.m_Id
static constexpr uint64_t ITEMDATA_DISPLAY    = 0x40;  // ItemData.m_DisplayName (Phrase*): английское название для подписей (дамп 1.14.11949)
static constexpr uint64_t PHRASE_ENGLISH      = 0x18;  // Phrase.english (string)
// SyncList<EquipPiece> чужого игрока начинается с элементов, не являющихся бронью (0 и 1 включены у всех), поэтому индекс реестра
// equipments[] = индекс списка - смещение. По логам включённый набор 12..15 даёт полный металлический набор только при смещении 2
// (сапоги, нагрудник, поножи, шлем; без смещения — поножи, шлем, тыква и шапка Санты). Смещение уточняется по согласованности наборов.
static constexpr int      EQUIP_LIST_SHIFT    = 2;
static constexpr uint64_t PW_PLAYER           = 0x138; // PlayerWeapon.<player> (обратная ссылка на PM)
static constexpr uint64_t PW_WEAPON_PIECE     = 0x110; // PlayerWeapon.QnK: WeaponPiece {enabled 0, number 2, skin 4, loaded 7} (SyncVar)
static constexpr uint64_t EQUIP_PIECES        = 0xA0;  // RBr.SyncList<EquipPiece> {enabled 0, skin 4}, шаг 8
static constexpr uint64_t SYNCLIST_OBJECTS    = 0x60;  // Mirror.SyncList<T>.objects (SyncObject: 3 ссылочных поля + заголовок), подтверждено логом
static constexpr uint64_t MINE_ENTITY_TYPE    = 0xD8;  // MineableObject.entityType (int enum EntityType)
static constexpr uint64_t MINE_CURRENT_HEALTH = 0x78;  // float m_CurrentHealth
static constexpr uint64_t MINE_RESISTANCE     = 0x74;  // float m_Resistance ([Range(0.01, 1)])
static constexpr uint64_t SLEEPBAG_NAME       = 0x90;  // Oxide.SleepingBag.customName (string)
static constexpr uint64_t SLEEPER_NICK        = 0x118; // DisconnectedSleeper.Nick (string)
static constexpr uint64_t SLEEPER_CLAN        = 0x138; // DisconnectedSleeper.ClanTag (string)
static constexpr int      ENT_BEAR = 1, ENT_BOAR = 2, ENT_DEER = 3, ENT_RABBIT = 4, ENT_CHICKEN = 5, ENT_FISH = 6, ENT_CANNIBAL = 7, ENT_HARE = 22, ENT_RAT = 25;   // EntityType животных (дамп 1.14.11949)
static constexpr int      ENT_TREE = 8, ENT_STONE = 9, ENT_IRON = 10, ENT_SULFUR = 11, ENT_ICE = 12;   // EntityType (дамп 1.14.11949)
static constexpr uint64_t MINE_LOOT           = 0xA0;  // MineableObject.m_Loot (List<LootItem>)
static constexpr uint64_t MINE_TRANSFORM      = 0xC8;  // MineableObject.rru (Transform)
static constexpr uint64_t MINE_MAX_HEALTH     = 0xC0;  // float m_MaxHealth
static constexpr uint64_t LOOTITEM_NAME       = 0x10;  // LootItem.ItemName
} // namespace ox

#endif // OXIDE_OFFSETS_H
