#!/usr/bin/env bash
# Avis tools 1.15.11966: выбор ABI с отдельными ARM64/x86_64 оффсетами.
#   bash build.sh --phone         — телефон Android ARM64
#   bash build.sh --pc            — Android x86_64 на ПК (эмулятор)
#   bash build.sh --all           — обе архитектуры
#   bash build.sh --check --phone — перед сборкой прогнать хост-тесты
# Без аргумента собирает обе архитектуры и упаковывает их в один .sh.
#   AVIS_API_URL=https://host bash build.sh — вшить адрес сервера ключей (иначе берётся из server.txt на устройстве)
# Результат: dist/Avis_tools_v2.6.sh (если --all или без аргументов).
set -euo pipefail
cd "$(dirname "$0")"

target=""
run_checks=false
for arg in "$@"; do
    case "$arg" in
        --phone|phone) target=phone ;;
        --pc|pc) target=pc ;;
        --all|all) target=all ;;
        --check) run_checks=true ;;
        --help|-h)
            echo "Usage: bash build.sh [--phone|--pc|--all] [--check]"
            echo "Phone: Android arm64-v8a; PC: Android emulator x86_64 (not Windows EXE)."
            exit 0 ;;
        *) echo "Неизвестный аргумент: $arg" >&2; exit 2 ;;
    esac
done
if [ -z "$target" ]; then target=all; fi
case "$target" in
    phone) abis="arm64-v8a"; outputs=("arm64-v8a:avistools_arm64:aarch64") ;;
    pc)    abis="x86_64";    outputs=("x86_64:avistools_x86_64:x86-64") ;;
    all)   abis="arm64-v8a x86_64"; outputs=("arm64-v8a:avistools_arm64:aarch64" "x86_64:avistools_x86_64:x86-64") ;;
esac

NDK="${ANDROID_NDK_HOME:-${NDK:-}}"
if [ -z "$NDK" ]; then NDK="$(ls -d /opt/android-ndk/android-ndk-* 2>/dev/null | sort -V | tail -1 || true)"; fi
if [ -z "$NDK" ] || [ ! -x "$NDK/ndk-build" ]; then
    echo "NDK не найден: задай ANDROID_NDK_HOME (нужен r26+; проверено на r30)" >&2; exit 2
fi

if $run_checks; then
    for t in arch weapon_patch silent_core arrow_ballistics target_life gear_names stretch_core boost_core quick_actions overlay_stability overlay_jobs bones touch_queue auto_heal cupboard_finder auth_http; do
        g++ -std=c++17 -O1 -pthread -Isrc -Iinclude "tools/test_$t.cpp" -o "/tmp/ox_t_$t"
        result=$("/tmp/ox_t_$t")
        printf '%-14s %s\n' "$t" "$(printf '%s\n' "$result" | tail -1)"
    done
    result=$(bash tools/test_touch_reader.sh)
    printf '%-14s %s\n' "touch reader" "$(printf '%s\n' "$result" | tail -1)"
    result=$(bash tools/test_auto_heal_transport.sh)
    printf '%-14s %s\n' "heal transport" "$(printf '%s\n' "$result" | tail -1)"
    result=$(bash tools/test_menu_ui.sh)
    printf '%-14s %s\n' "menu UI" "$(printf '%s\n' "$result" | tail -1)"
    result=$(bash tools/test_auth_retry.sh)
    printf '%-14s %s\n' "auth retry" "$(printf '%s\n' "$result" | tail -1)"
    result=$(bash tools/test_quick_actions_ui.sh)
    printf '%-14s %s\n' "quick UI" "$(printf '%s\n' "$result" | tail -1)"
    # Кэш чтений проверяется на настоящем process_vm_readv (читает сам тест), поэтому линкуется с memory.cpp.
    g++ -std=c++17 -O1 -Wno-format -Iinclude -Iinclude/ImGui -Isrc tools/test_vmcache.cpp src/memory.cpp -o /tmp/ox_t_vmcache
    result=$(/tmp/ox_t_vmcache)
    printf '%-14s %s\n' "vmcache" "$(printf '%s\n' "$result" | tail -1)"
    bash ci/verify-syntax.sh | tail -1
    result=$(bash tools/test_sound.sh)
    printf '%-14s %s\n' "sound" "$(printf '%s\n' "$result" | tail -1)"
    # Клиент ключей против настоящего сервера (нужны python3 с aiohttp и cryptography; иначе пропускаем).
    if python3 -c 'import aiohttp, cryptography' 2>/dev/null && [ -f server/signing_key.pem ]; then bash tools/test_auth.sh | grep -E '^(==|ALL OK|FAIL)'
    else echo "auth: пропущено (нужны aiohttp, cryptography и локальный ключ подписи; секреты не входят в исходники)"; fi
fi

# The clipboard helper is generated from source, not a required checked-in binary.
if [ ! -s assets/trial/avis_clip.jar ]; then
    if ! command -v javac >/dev/null; then
        echo "Нет avis_clip.jar: установи JDK 17+ (javac), затем повтори сборку" >&2; exit 2
    fi
    bash tools/clip/build.sh
fi

jobs="$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 4)"
"$NDK/ndk-build" -j"$jobs" NDK_PROJECT_PATH="$PWD" APP_BUILD_SCRIPT="$PWD/Android.mk" NDK_APPLICATION_MK="$PWD/Application.mk" "APP_ABI=$abis"

mkdir -p dist
selected=()
for entry in "${outputs[@]}"; do
    IFS=: read -r abi name arch <<< "$entry"
    cp "libs/$abi/avistools" "dist/$name"
    chmod +x "dist/$name"
    if ! file "dist/$name" | grep -qi "$arch"; then
        echo "ОШИБКА: dist/$name — неверная архитектура: $(file "dist/$name")" >&2
        exit 1
    fi
    selected+=("$name")
    echo "OK: dist/$name ($arch)"
done
( cd dist && sha256sum "${selected[@]}" > SHA256SUMS )
if [ "$target" = all ]; then
    python3 tools/pack_universal.py
    ( cd dist && sha256sum Avis_tools_v2.6.sh >> SHA256SUMS )
fi
echo "SHA256: dist/SHA256SUMS"
