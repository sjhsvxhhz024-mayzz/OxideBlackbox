#include "overlay_jobs.h"
#include <atomic>
#include <cassert>
#include <chrono>
#include <cstdio>
#include <thread>
int main() {
    overlaycore::DiscoveryJob<int> job;
    std::atomic<bool> entered{false},release{false};
    assert(job.Available());
    assert(job.Start([&] { entered=true;while(!release.load()) std::this_thread::yield();return 17;}));
    while(!entered.load()) std::this_thread::yield();
    // Frame submits/takes do not wait for slow discovery, and no queue builds.
    int out=0;
    for (int i=0;i<10000;++i) {
        assert(!job.Available());
        assert(!job.Start([]{return 999;})); assert(!job.Take(out));
    }
    release=true;
    const auto end=std::chrono::steady_clock::now()+std::chrono::seconds(5);
    while(!job.Take(out)) {assert(std::chrono::steady_clock::now()<end);std::this_thread::yield();}
    assert(out==17);assert(!job.Take(out));
    assert(job.Start([]{return 23;}));
    while(!job.Take(out)) {assert(std::chrono::steady_clock::now()<end);std::this_thread::yield();}
    assert(out==23);
    puts("ALL OK: discovery never waits in rendering; one slot, no duplicate jobs");
}
