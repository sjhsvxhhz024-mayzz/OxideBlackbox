#!/usr/bin/env python3
"""Pack the two Android ELF executables into one self-extracting shell file."""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
import re
import sys


ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"
ARM = DIST / "avistools_arm64"
PC = DIST / "avistools_x86_64"
OUT = DIST / "Avis_tools_v2.6.sh"


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as source:
        while block := source.read(1024 * 1024):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    for path in (ARM, PC):
        if not path.is_file() or path.stat().st_size == 0:
            raise SystemExit(f"Missing build output: {path}. Build both ABIs first.")

    arm_size, pc_size = ARM.stat().st_size, PC.stat().st_size
    arm_hash, pc_hash = digest(ARM), digest(PC)
    # Decimal fields stay 16 bytes wide, so replacing them cannot change the
    # byte offset of either embedded ELF. Pad on the RIGHT: Android toybox
    # treats a leading zero as octal and rejects values containing 8 or 9.
    stub = """#!/system/bin/sh
# Avis tools v2.6 - one Android launcher containing ARM64 and x86_64 builds.
set -eu
umask 077

case "$(uname -m)" in
    aarch64|arm64) offset=@ARM_OFFSET____@; length=@ARM_LENGTH____@; expected=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA ;;
    x86_64|amd64) offset=@PC_OFFSET_____@; length=@PC_LENGTH_____@; expected=PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP ;;
    *) echo 'Avis tools: only Android ARM64 and x86_64 are supported' >&2; exit 2 ;;
esac

temp_dir=$(mktemp -d "${TMPDIR:-/data/local/tmp}/avis-tools.XXXXXX") || exit 1
trap 'rm -rf "$temp_dir"' EXIT HUP INT TERM
program="$temp_dir/avistools"
tail -c "+$((offset + 1))" "$0" | head -c "$length" > "$program"
actual_size=$(wc -c < "$program" | tr -d ' ')
if [ "$actual_size" -ne "$length" ]; then
    echo 'Avis tools: embedded executable is truncated' >&2
    exit 1
fi
actual_hash=$(sha256sum "$program" | cut -d ' ' -f 1)
if [ "$actual_hash" != "$expected" ]; then
    echo 'Avis tools: embedded executable checksum mismatch' >&2
    exit 1
fi
chmod 700 "$program"
"$program" "$@"
status=$?
exit "$status"
# AVIS_EMBEDDED_ELF_DATA_FOLLOWS
"""
    header = stub.encode("ascii")
    arm_offset = len(header)
    pc_offset = arm_offset + arm_size
    replacements = {
        b"@ARM_OFFSET____@": f"{arm_offset:<16d}".encode(),
        b"@ARM_LENGTH____@": f"{arm_size:<16d}".encode(),
        b"@PC_OFFSET_____@": f"{pc_offset:<16d}".encode(),
        b"@PC_LENGTH_____@": f"{pc_size:<16d}".encode(),
        b"A" * 64: arm_hash.encode(),
        b"P" * 64: pc_hash.encode(),
    }
    for key, value in replacements.items():
        if len(key) != len(value):
            raise AssertionError(f"placeholder size changed: {key!r}")
        header = header.replace(key, value)
    if len(header) != arm_offset:
        raise AssertionError("embedded offsets changed while filling the header")
    if re.search(rb"(?:offset|length)=0[0-9]", header):
        raise AssertionError("Android toybox rejects zero-padded byte counts")

    tmp = OUT.with_name(OUT.name + ".tmp")
    with tmp.open("wb") as target:
        target.write(header)
        for path in (ARM, PC):
            with path.open("rb") as source:
                while block := source.read(1024 * 1024):
                    target.write(block)
    os.replace(tmp, OUT)
    try:
        OUT.chmod(0o755)
    except OSError:
        pass
    with OUT.open("rb") as source:
        for label, offset, length, expected in (
            ("ARM64", arm_offset, arm_size, arm_hash),
            ("x86_64", pc_offset, pc_size, pc_hash),
        ):
            source.seek(offset)
            h = hashlib.sha256()
            remaining = length
            first = True
            while remaining:
                block = source.read(min(1024 * 1024, remaining))
                if not block:
                    raise AssertionError(f"{label} ELF is truncated")
                if first and not block.startswith(b"\x7fELF"):
                    raise AssertionError(f"{label} ELF offset is wrong")
                first = False
                h.update(block)
                remaining -= len(block)
            if h.hexdigest() != expected:
                raise AssertionError(f"{label} ELF hash changed in the bundle")
    print(f"OK: {OUT} ({OUT.stat().st_size} bytes, ARM64 + x86_64)")
    print(f"SHA256: {digest(OUT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
