#!/usr/bin/env bash
# Хост-тест звуков (синтез и микшер). С аргументом — ещё и запись демо:  bash tools/test_sound.sh /tmp/demo.wav
set -euo pipefail
cd "$(dirname "$0")/.."
g++ -std=c++17 -O1 -Wall -Isrc tools/test_sound.cpp -o /tmp/avis_test_sound
if [ $# -gt 0 ]; then /tmp/avis_test_sound --wav "$1"; else /tmp/avis_test_sound; fi
