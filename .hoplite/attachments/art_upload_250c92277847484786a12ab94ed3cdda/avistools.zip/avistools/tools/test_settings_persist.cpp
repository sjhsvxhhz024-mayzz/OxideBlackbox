#include "trial_config.h"
#include "trial_configs.h"
#include <cstdio>
#include <cstring>
#include <cmath>
Settings g_cfg;
bool espdraw = false;
bool espbox = false;
bool espfill = false;
bool espCornerBox = false;
bool esplines_enabled = false;
bool skeleton = false;
bool espname = false;
bool espclan = false;
bool espweapon = false;
bool espArmor = false;
bool espdist = false;
bool espFlags = false;
bool espDistColor = false;
bool radarEnabled = false;
bool oreEsp = false;
bool oreStone = false;
bool oreMetal = false;
bool oreSulfur = false;
bool oreCoal = false;
bool oreDistText = false;
bool silentAim = false, silentPredict = false, silentSkipSleeping = false, silentSkipSpectating = false, silentDrawFov = false;
int silentZone = 0, silentMode = 0;
bool silentOnlyFiring = false;
float silentFovPx = 0, silentRange = 0, silentLeadMs = 0, silentMaxCorr = 0;
bool animalEsp = false, animalBear = false, animalBoar = false, animalDeer = false, animalRabbit = false, animalHare = false;
bool baseEsp = false, baseCupboard = false, baseTurret = false, baseBag = false, baseSleeper = false, baseDistText = false;
bool animalChicken = false, animalFish = false, animalRat = false, animalCannibal = false, animalDistText = false;
bool aimm = false;
bool stretchOn = false;
int stretchMode = 3;
float stretchCustom = 1.5f;
bool boostDraw = false, boostGrass = false, boostTrees = false, boostNoLog = false;
float boostDrawDist = 400.f;
int boostFpsMode = 0;
bool aimPrediction = false;
bool aimDrawFov = false;
bool aimDrawTarget = false;
bool aimSticky = false;
bool aimHoriz = false;
bool aimVert = false;
bool aimSkipSleeping = false;
bool aimSkipSpectating = false;
bool aimvisible = false;
bool aimSmoothConst = false;
bool aimRecoilComp = false;
float espstroke = 0;
float espfillp = 0;
float esplines_thickness = 0;
float espCornerLength = 0;
float skeleton_stroke = 0;
float espnamesize = 0;
float espclansize = 0;
float espMaxDistance = 0;
float oreMaxDist = 0;
float animalMaxDist = 0;
float baseMaxDist = 0;
float radarRange = 0;
float radarSize = 0;
float radarAlpha = 0;
float aimFovPixels = 0;
float aimSmooth = 0;
float aimMaxDistance = 0;
float aimMaxSpeed = 0;
float aimDeadzone = 0;
float aimSwitchMargin = 0;
float aimFireHold = 0;
float aimSettleDeg = 0;
float aimRampMs = 0;
float aimProjectileSpeed = 0;
float aimLatencyMs = 0;
float aimMaxLeadTime = 0;
float aimProjectileGravity = 0;
float aimPredictIters = 0;
int esplines_position = 0;
int aimTriggerMode = 0;
int aimcurbone = 0;
float espboxcolor[3] = {0.5f,0.5f,0.5f};
float esplines_color[3] = {0.5f,0.5f,0.5f};
float skeleton_color[3] = {0.5f,0.5f,0.5f};
float espnamecolor[3] = {0.5f,0.5f,0.5f};
float espclancolor[3] = {0.5f,0.5f,0.5f};
bool noRecoil = false;
bool noSpread = false;
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { ++fails; printf("FAIL line %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)
static void clearFile() { unlink("/sdcard/Download/AvisTools/settings.cfg"); }
int main() {
    clearFile();
    espboxcolor[0] = espboxcolor[1] = espboxcolor[2] = 1; aimSmooth = 6; aimFovPixels = 220; espstroke = .85f; g_cfg.accent = 1; aimm = false; espdraw = true; oreMaxDist = 150; aimTriggerMode = 1;
    Cfg_Snapshot();
    Cfg_AutoLoad();                                           // файла нет: ничего не меняется, ничего не пишется
    CHECK(aimSmooth == 6 && !aimm, "first start must keep defaults");
    for (int i = 0; i < 20; ++i) Cfg_AutoTick(0.1f);
    CHECK(access("/sdcard/Download/AvisTools/settings.cfg", F_OK) != 0, "nothing changed -> nothing written");
    // пользователь меняет настройки
    aimm = true; aimSmooth = 11.5f; aimFovPixels = 333; espCornerBox = true; espboxcolor[0] = .2f; espboxcolor[1] = .9f; oreMaxDist = 220; aimTriggerMode = 4; g_cfg.accent = 3; espdraw = false;
    for (int i = 0; i < 4; ++i) Cfg_AutoTick(0.1f);          // 0.4 с: ещё в окне ожидания
    CHECK(access("/sdcard/Download/AvisTools/settings.cfg", F_OK) != 0, "must wait for the debounce, not write on every tick");
    for (int i = 0; i < 12; ++i) Cfg_AutoTick(0.1f);          // всего >1.2 с
    CHECK(access("/sdcard/Download/AvisTools/settings.cfg", F_OK) == 0, "must be written after the debounce");
    // «перезапуск»: все значения сброшены, затем загрузка
    aimm = false; aimSmooth = 6; aimFovPixels = 220; espCornerBox = false; espboxcolor[0] = 1; espboxcolor[1] = 1; oreMaxDist = 150; aimTriggerMode = 1; g_cfg.accent = 1; espdraw = true;
    Cfg_AutoLoad();
    CHECK(aimm, "aimbot switch must be restored");
    CHECK(fabsf(aimSmooth - 11.5f) < 1e-4f && aimFovPixels == 333 && espCornerBox && fabsf(espboxcolor[0] - .2f) < 1e-3f && fabsf(espboxcolor[1] - .9f) < 1e-3f, "values restored: %.2f %.0f", aimSmooth, aimFovPixels);
    CHECK(oreMaxDist == 220 && aimTriggerMode == 4 && g_cfg.accent == 3 && !espdraw, "more values restored");
    // вкладка Memory: переключатели сохраняются, но пресеты, слоты и сброс их не трогают
    noRecoil = true; noSpread = true; for (int i = 0; i < 16; ++i) Cfg_AutoTick(0.1f); noRecoil = false; noSpread = false; Cfg_AutoLoad();
    CHECK(noRecoil && noSpread, "memory toggles must persist");
    Cfg_ApplyPreset(2); Cfg_ResetDefaults(); CHECK(noRecoil && noSpread, "presets/reset must not flip memory toggles");
    // Stretch: включатель и выбранное соотношение сторон переживают перезапуск
    stretchOn = true; stretchMode = 4; stretchCustom = 2.2f; for (int i = 0; i < 16; ++i) Cfg_AutoTick(0.1f);
    stretchOn = false; stretchMode = 3; stretchCustom = 1.5f; Cfg_AutoLoad();
    CHECK(stretchOn && stretchMode == 4 && fabsf(stretchCustom - 2.2f) < 1e-4f, "stretch settings must persist: %d %d %.2f", (int)stretchOn, stretchMode, stretchCustom);
    stretchOn = false; for (int i = 0; i < 16; ++i) Cfg_AutoTick(0.1f);
    // Boost: включатели и значения переживают перезапуск, но не входят в пресеты и сброс
    boostDraw = true; boostDrawDist = 250.f; boostGrass = true; boostTrees = true; boostFpsMode = 2; boostNoLog = true; for (int i = 0; i < 16; ++i) Cfg_AutoTick(0.1f);
    boostDraw = false; boostDrawDist = 400.f; boostGrass = false; boostTrees = false; boostFpsMode = 0; boostNoLog = false; Cfg_AutoLoad();
    CHECK(boostDraw && boostGrass && boostTrees && boostNoLog && boostFpsMode == 2 && fabsf(boostDrawDist - 250.f) < 1e-3f, "boost settings must persist");
    Cfg_ApplyPreset(2); Cfg_ResetDefaults(); CHECK(boostDraw && boostGrass && boostFpsMode == 2, "presets/reset must not flip boost settings");
    boostDraw = boostGrass = boostTrees = boostNoLog = false; boostFpsMode = 0; for (int i = 0; i < 16; ++i) Cfg_AutoTick(0.1f);
    Cfg_SaveSlot(1); noRecoil = false; Cfg_LoadSlot(1); CHECK(!noRecoil, "slot must not carry memory toggles"); noRecoil = false; noSpread = false; for (int i = 0; i < 16; ++i) Cfg_AutoTick(0.1f);
    // включатель не попадает в пресет и слот, не сбрасывается
    Cfg_ApplyPreset(1); CHECK(aimm, "preset must not change the aimbot switch");
    Cfg_ResetDefaults(); CHECK(aimm, "factory reset must not change the aimbot switch");
    Cfg_SaveSlot(0); aimm = false; Cfg_LoadSlot(0); CHECK(!aimm, "slot must not carry the aimbot switch");
    // изменения после загрузки снова пишутся
    aimSmooth = 3; for (int i = 0; i < 16; ++i) Cfg_AutoTick(0.1f);
    aimSmooth = 6; Cfg_AutoLoad(); CHECK(aimSmooth == 3, "later change persisted: %.1f", aimSmooth);
    // битые файлы не ломают запуск
    FILE *f = fopen("/sdcard/Download/AvisTools/settings.cfg", "w"); fputs("\x01\x02garbage\naimSmooth=nan\naimFovPixels=1e99\nespboxcolor=9,9,9\n=\nkey\n", f); fclose(f);
    aimSmooth = 6; Cfg_AutoLoad();
    CHECK(aimSmooth == 6 && std::isfinite(aimFovPixels) && aimFovPixels <= 1e5f && espboxcolor[0] <= 1.f, "corrupt file tolerated");
    f = fopen("/sdcard/Download/AvisTools/settings.cfg", "w"); fclose(f);   // пустой файл
    Cfg_AutoLoad();
    CHECK(true, "empty file");
    // выход: немедленная запись
    aimSmooth = 7.25f; CHECK(Cfg_AutoSaveNow(), "save now"); aimSmooth = 6; Cfg_AutoLoad(); CHECK(fabsf(aimSmooth - 7.25f) < 1e-4f, "shutdown save");
    clearFile(); unlink("/sdcard/Download/AvisTools/configs/custom_1.cfg");
    printf(fails ? "FAILED %d\n" : "ALL OK\n", fails);
    return fails != 0;
}
