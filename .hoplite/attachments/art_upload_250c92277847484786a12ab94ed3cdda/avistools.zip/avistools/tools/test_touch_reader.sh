#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
BIN=$(mktemp /tmp/avis_touch_test.XXXXXX)
trap 'rm -f "$BIN"' EXIT
g++ -std=c++17 -O1 -pthread -Iinclude/ImGui -Isrc \
 tools/test_touch_reader.cpp src/ImGui/imgui.cpp src/ImGui/imgui_draw.cpp \
 src/ImGui/imgui_tables.cpp src/ImGui/imgui_widgets.cpp -o "$BIN"
"$BIN"
