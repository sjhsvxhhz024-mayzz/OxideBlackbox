// Хост-тест клиента ключей против настоящего сервера (server/tests/serve_for_client.py): HTTP, HTTPS, подпись, nonce.
// Запуск целиком: bash tools/test_auth.sh
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <time.h>

#include "auth/auth_client.h"
#include "auth/auth_clip.h"
#include "auth/auth_config.h"
#include "auth/auth_net.h"
#include "auth/auth_proto.h"

// Вместо вшитого jar (его символы определяет trial_assets.S, а в хост-тесте её нет).
extern "C" { const unsigned char trial_clipjar_start[] = {1, 2, 3}; const unsigned char trial_clipjar_end[] = {0}; }

static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)

static bool waitFor(bool (*f)(), int ms) {
    for (int t = 0; t < ms; t += 20) { if (f()) return true; usleep(20000); }
    return f();
}
static bool infoReady() { return avis::Get().infoReady; }
static bool active() { return avis::Active(); }

static void writeServer(const std::string &dir, const std::string &url) {
    FILE *f = fopen((dir + "/server.txt").c_str(), "wb");
    fwrite(url.data(), 1, url.size(), f);
    fclose(f);
}

int main(int argc, char **argv) {
    if (argc < 3) { printf("usage: test_auth <server-url> <good-key>\n"); return 2; }
    const std::string url = argv[1], goodKey = argv[2];

    // ---- чистые функции ----
    CHECK(avis::NormalizeKey("avis-abcd-efgh-jklm") == "AVIS-ABCD-EFGH-JKLM");
    CHECK(avis::NormalizeKey("  ABCDEFGHJKLM ") == "AVIS-ABCD-EFGH-JKLM");
    CHECK(avis::NormalizeKey("AVIS ABCD EFGH JKLM\n") == "AVIS-ABCD-EFGH-JKLM");
    CHECK(avis::NormalizeKey("AVIS-ABCD-EFGH-JKL0").empty());          // 0 не входит в алфавит
    CHECK(avis::NormalizeKey("AVIS-ABCD-EFGH").empty());
    CHECK(avis::NormalizeKey("").empty());
    CHECK(avis::NormalizeKey("t.me/AvisTools") == avis::kLocalKey);
    CHECK(avis::NormalizeKey("T.ME/AVISTOOLS") == avis::kLocalKey); // экранная клавиатура показывает прописные
    CHECK(avis::NormalizeKey("t.me/AvisTools-extra").empty());
    CHECK(avis::NormalizeKey("https://t.me/AvisTools").empty());
    CHECK(avis::RandomHex(16).size() == 32);
    CHECK(avis::Sha256Hex("abc") == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");

    // буфер обмена Android: ключ в UTF-16 внутри дампа parcel (слова little-endian)
    {
        std::string k = "AVIS-ABCD-EFGH-JKLM", dump = "Result: Parcel(\n  0x00000000: 00000000 00000001 ffffffff 00000001 '................'\n";
        std::string bytes;
        for (char c : k) { bytes += c; bytes += '\0'; }
        while (bytes.size() % 4) bytes += '\0';
        char line[128];
        for (size_t i = 0; i < bytes.size(); i += 16) {
            snprintf(line, sizeof(line), "  0x%08zx:", 16 + i);
            dump += line;
            for (size_t j = i; j < i + 16 && j < bytes.size(); j += 4) {
                unsigned w = (unsigned char)bytes[j] | ((unsigned char)bytes[j + 1] << 8) | ((unsigned char)bytes[j + 2] << 16) | ((unsigned)(unsigned char)bytes[j + 3] << 24);
                snprintf(line, sizeof(line), " %08x", w);
                dump += line;
            }
            dump += "  '..A.V.I.S.'\n";
        }
        dump += ")\n";
        CHECK(avis::ExtractKeyFromParcelDump(dump) == k);
        CHECK(avis::ExtractKeyFromParcelDump("Result: Parcel(\n  0x00000000: 00000000 00000000 '....')\n").empty());
    }

    // ---- ключ в произвольном тексте ----
    CHECK(avis::FindKeyInText("Твой ключ: AVIS-7KQ2-M9XP-LR4T (нажми, чтобы скопировать)") == "AVIS-7KQ2-M9XP-LR4T");
    CHECK(avis::FindKeyInText("avis 7kq2 m9xp lr4t") == "AVIS-7KQ2-M9XP-LR4T");
    CHECK(avis::FindKeyInText("7KQ2M9XPLR4T") == "AVIS-7KQ2-M9XP-LR4T");
    CHECK(avis::FindKeyInText("  \nAVIS-7KQ2-M9XP-LR4T\n") == "AVIS-7KQ2-M9XP-LR4T");
    CHECK(avis::FindKeyInText("AVIS-7KQ2-M9XP-LR40").empty());          // 0 не входит в алфавит
    CHECK(avis::FindKeyInText("привет, это не ключ").empty());
    CHECK(avis::FindKeyInText("").empty());
    CHECK(avis::FindKeyInText("AVIS-7KQ2-M9XP").empty());                // обрезанный
    CHECK(avis::FindKeyInText("t.me/AvisTools") == avis::kLocalKey);
    CHECK(avis::FindKeyInText("Ключ: https://t.me/AvisTools (скопировать)") == avis::kLocalKey);
    CHECK(avis::FindKeyInText("t.me/AvisToolsFake").empty());

    // ---- Parcel от `service call` ----
    {
        auto st = [](const char *words) { return avis::ParcelStatus(avis::ParcelBytes(std::string("Result: Parcel(\n  0x00000000: ") + words + " '................')\n")); };
        CHECK(st("00000000 00000001 00000010 00000001") == 1);          // клип вернулся
        CHECK(st("00000000 00000000") == 0);                            // клипа нет
        CHECK(st("ffffffff 0000001c 00650053") == -1);                  // SecurityException
        CHECK(avis::ParcelStatus(avis::ParcelBytes("")) == -1);
        CHECK(avis::ParcelStatus(avis::ParcelBytes("Error: service not found")) == -1);
    }

    // ---- вывод хелпера avis.Clip ----
    {
        std::string t;
        CHECK(avis::ParseHelperOutput("OK 0KLQstC+0Lkg0LrQu9GO0Yc6IEFWSVMtN0tRMi1NOVhQLUxSNFQg8J+Zgg==\n", t) == avis::HelperStatus::Ok);
        CHECK(avis::FindKeyInText(t) == "AVIS-7KQ2-M9XP-LR4T");
        CHECK(avis::ParseHelperOutput("WARNING: linker: something\nOK 0KLQstC+0Lkg0LrQu9GO0Yc6IEFWSVMtN0tRMi1NOVhQLUxSNFQg8J+Zgg==\r\n", t) == avis::HelperStatus::Ok);   // шум до строки результата
        CHECK(avis::ParseHelperOutput("EMPTY\n", t) == avis::HelperStatus::Empty);
        CHECK(avis::ParseHelperOutput("ERR SecurityException: Package com.android.shell does not belong to 0\n", t) == avis::HelperStatus::Error);
        CHECK(t.find("SecurityException") == 0);
        CHECK(avis::ParseHelperOutput("", t) == avis::HelperStatus::Error);
        CHECK(avis::ParseHelperOutput("OK !!!not-base64", t) == avis::HelperStatus::Error);
    }

    // ---- запуск процессов: вывод, код выхода, таймаут, смена uid ----
    {
        avis::RunResult r = avis::RunProcess({"/bin/sh", "-c", "echo hello; echo err 1>&2; exit 3"}, {}, -1, 3000);
        CHECK(r.started && !r.timedOut && r.exitCode == 3);
        CHECK(r.output == "hello\nerr\n");
        r = avis::RunProcess({"/bin/sh", "-c", "echo $AVIS_T"}, {"AVIS_T=через-окружение"}, -1, 3000);
        CHECK(r.output == "через-окружение\n");
        timespec t0, t1;
        clock_gettime(CLOCK_MONOTONIC, &t0);
        r = avis::RunProcess({"/bin/sleep", "5"}, {}, -1, 300);
        clock_gettime(CLOCK_MONOTONIC, &t1);
        CHECK(r.started && r.timedOut);
        CHECK((t1.tv_sec - t0.tv_sec) * 1000 + (t1.tv_nsec - t0.tv_nsec) / 1000000 < 2000);   // убит по таймауту, а не ждали 5 с
        r = avis::RunProcess({"/нет/такого"}, {}, -1, 1000);
        CHECK(r.started && r.exitCode == 127);
        if (geteuid() == 0) {                                             // как на устройстве: root меняет uid на shell перед exec
            r = avis::RunProcess({"/usr/bin/id", "-u"}, {}, 2000, 3000);
            CHECK(r.output == "2000\n");
            r = avis::RunProcess({"/usr/bin/id", "-u"}, {}, 0, 3000);
            CHECK(r.output == "0\n");
        } else printf("(не root: проверка смены uid пропущена)\n");
    }

    // ---- сеть: подпись, nonce ----
    {
        avis::HttpResponse r;
        std::string err;
        const std::string nonce = "00112233445566778899aabbccddeeff";
        CHECK(avis::HttpRequest(url + "/api/v1/info?nonce=" + nonce, "GET", "", r, err));
        CHECK(r.status == 200);
        avis::Reply rep;
        CHECK(avis::ParseReply(r.body, "info", nonce, "", rep, err));
        CHECK(rep.status == "ok" && rep.a == "AvisToolsTestBot" && rep.b == "AvisTools");
        CHECK(!avis::ParseReply(r.body, "info", "ffffffffffffffffffffffffffffffff", "", rep, err));   // чужой nonce = повтор
        CHECK(err == "nonce");
        std::string tampered = r.body;
        tampered[10] = tampered[10] == 'o' ? 'x' : 'o';
        CHECK(!avis::ParseReply(tampered, "info", nonce, "", rep, err));
        CHECK(err == "bad signature");
        CHECK(!avis::ParseReply(r.body, "verify", nonce, "", rep, err));                               // подмена типа ответа
        // ответ, подписанный другим ключом, не принимается
        const char *otherPem = "-----BEGIN PUBLIC KEY-----\nMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEbTfs33p9+fcbRwSv0czZTKks1/81\n8hA4ptlNVHt0dV8MQ4UkGAfvchDCmUe5Adlbqmsa0hcyX93hKWOTdjRv6A==\n-----END PUBLIC KEY-----\n";
        CHECK(!avis::ParseReplyWithKey(otherPem, r.body, "info", nonce, "", rep, err));
        // недоступный адрес -> быстрая ошибка, не зависание
        avis::HttpResponse r2;
        CHECK(!avis::HttpRequest("http://127.0.0.1:9/x", "GET", "", r2, err));
    }

    // ---- полный сценарий клиента (Init одноразовый на процесс: HTTP и HTTPS гоняются отдельными запусками) ----
    {
        const std::string dir = std::string("/tmp/avis_test_") + std::to_string(getpid());
        mkdir(dir.c_str(), 0777);
        // HTTP and HTTPS runs share one issued key. Containers without
        // /etc/machine-id otherwise generate two different fallback HWIDs,
        // correctly producing "hwid" on the second transport test.
        if (const char *identity = getenv("AVIS_TEST_IDENTITY")) {
            FILE *f = fopen((dir + "/.id").c_str(), "wb");
            if (f) { fwrite(identity, 1, strlen(identity), f); fclose(f); }
        }
        // Локальный ключ работает и сохраняется при недоступном сервере.
        writeServer(dir, "http://127.0.0.1:9");
        avis::Init(dir.c_str());
        avis::Submit(avis::kLocalKey);
        CHECK(avis::Active());
        CHECK(avis::Get().localKey && avis::Get().phase == avis::Phase::Active);
        CHECK(avis::Get().verifyAttempts == 0 && avis::RemainingSec() == 0);
        char p[256];
        snprintf(p, sizeof(p), "%s/key.txt", dir.c_str());
        CHECK(access(p, F_OK) == 0);
        usleep(250000); // фоновый поток не перепроверяет локальную сессию
        CHECK(avis::Active() && avis::Get().verifyAttempts == 0);
        avis::Shutdown();
        avis::Init(dir.c_str());
        CHECK(avis::Active() && avis::Get().localKey); // автовход без сети
        avis::Logout();
        CHECK(!avis::Active() && access(p, F_OK) != 0);
        avis::Shutdown();

        writeServer(dir, url);
        avis::Init(dir.c_str());
        CHECK(waitFor(infoReady, 6000));
        avis::Snapshot s = avis::Get();
        CHECK(s.phase == avis::Phase::NeedKey && s.serverSet && s.bot == "AvisToolsTestBot");

        avis::Submit("AVIS-AAAA-BBBB-CCCC");               // валидный формат, но не выдавался
        for (int i = 0; i < 300 && avis::Get().phase != avis::Phase::NeedKey; ++i) usleep(20000);
        CHECK(avis::Get().msg == avis::Msg::Invalid);
        CHECK(!avis::Active());

        avis::Submit("не ключ");
        CHECK(avis::Get().msg == avis::Msg::BadFormat);

        avis::Submit(goodKey);
        CHECK(waitFor(active, 6000));
        s = avis::Get();
        CHECK(s.phase == avis::Phase::Active && s.remainingSec > 23 * 3600 && s.remainingSec <= 24 * 3600);
        CHECK(avis::DeviceId().size() == 64);
        CHECK(access(p, F_OK) == 0);                        // ключ сохранён для автовхода

        avis::Logout();
        CHECK(!avis::Active());
        CHECK(access(p, F_OK) != 0);
        avis::Shutdown();
    }
    printf(fails ? "FAILED: %d\n" : "ALL OK\n", fails);
    return fails ? 1 : 0;
}
