// Хост-тест звуков экрана ключа (синтез и микшер): bash tools/test_sound.sh   |   --wav out.wav — записать демо для прослушивания.
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>

#include "auth/sound_core.h"

static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #c); ++fails; } } while (0)

static int peak(const std::vector<int16_t> &v) { int m = 0; for (int16_t x : v) m = m > abs(x) ? m : abs(x); return m; }

static void writeWav(const char *path, const std::vector<int16_t> &pcm) {
    FILE *f = fopen(path, "wb");
    const uint32_t data = (uint32_t)pcm.size() * 2, rate = avsnd::kRate;
    const uint16_t ch = 1, bits = 16, blk = 2, fmt = 1;
    const uint32_t riff = 36 + data, fmtLen = 16, byteRate = rate * 2;
    fwrite("RIFF", 1, 4, f); fwrite(&riff, 4, 1, f); fwrite("WAVEfmt ", 1, 8, f); fwrite(&fmtLen, 4, 1, f);
    fwrite(&fmt, 2, 1, f); fwrite(&ch, 2, 1, f); fwrite(&rate, 4, 1, f); fwrite(&byteRate, 4, 1, f);
    fwrite(&blk, 2, 1, f); fwrite(&bits, 2, 1, f); fwrite("data", 1, 4, f); fwrite(&data, 4, 1, f);
    fwrite(pcm.data(), 2, pcm.size(), f);
    fclose(f);
}

int main(int argc, char **argv) {
    avsnd::Bank bank;
    CHECK((int)bank.s.size() == avsnd::COUNT);

    // каждый звук: непустой, нормальной длины и громкости, без щелчков на краях
    for (int i = 0; i < avsnd::COUNT; ++i) {
        const std::vector<int16_t> &s = bank.s[i];
        const double sec = (double)s.size() / avsnd::kRate;
        const int pk = peak(s);
        CHECK(sec > 0.05 && sec < 1.2);
        CHECK(pk >= 0.44 * 32767 && pk < 0.70 * 32767);                       // слышно, но не на пределе
        CHECK(abs(s.front()) < 0.05 * pk);                                    // старт без щелчка
        CHECK(abs(s.back()) < 0.01 * pk);                                     // плавный конец
        for (int k = 1; k <= 16; ++k) CHECK(abs(s[s.size() - k]) < 0.01 * pk);
    }
    // варианты высоты у клавиши различаются, но все короткие (отзывчивость)
    for (int i = 1; i < avsnd::KEY_COUNT; ++i) {
        CHECK(bank.s[i] != bank.s[i - 1]);
        CHECK(bank.s[i].size() < 0.13 * avsnd::kRate);
    }
    // воспроизводимость: два вызова дают одно и то же
    CHECK(avsnd::Synth(avsnd::ENTER) == bank.s[avsnd::ENTER]);

    // микшер: сумма голосов, ограничение, тишина после конца
    {
        avsnd::Mixer m(bank);
        std::vector<int16_t> out(2048, 7);
        m.Mix(out.data(), 2048);
        bool allZero = true;
        for (int16_t v : out) allZero = allZero && v == 0;
        CHECK(allZero && m.Idle());                                           // без команд — тишина
        m.Post(avsnd::KEY0, 1.0f);
        m.Post(avsnd::KEY0 + 3, 1.0f);
        m.Post(avsnd::BACK, 1.0f);
        std::vector<int16_t> mix(avsnd::kRate / 4);
        m.Mix(mix.data(), (int)mix.size());
        CHECK(peak(mix) > 0 && peak(mix) <= 32767);
        std::vector<int16_t> tail(256);
        m.Mix(tail.data(), 256);
        CHECK(peak(tail) == 0 && m.Idle());                                   // голоса доиграли и освободились

        // 40 команд подряд: кольцо и голоса не ломаются
        for (int i = 0; i < 40; ++i) m.Post(i % avsnd::COUNT, 1.0f);
        std::vector<int16_t> burst(4096);
        m.Mix(burst.data(), 4096);
        CHECK(peak(burst) <= 32767);
        // громкость 8 одинаковых голосов не выходит за пределы int16
        for (int i = 0; i < 8; ++i) m.Post(avsnd::SUCCESS, 5.0f);
        std::vector<int16_t> loud(8000);
        m.Mix(loud.data(), 8000);
        CHECK(peak(loud) <= 32767);
    }
    // микс кусками по 64 кадра == одним куском (граница буферов аудиопотока не должна давать щелчков)
    {
        avsnd::Mixer a(bank), b(bank);
        a.Post(avsnd::ENTER, 0.8f); b.Post(avsnd::ENTER, 0.8f);
        std::vector<int16_t> whole(6000), parts(6000);
        a.Mix(whole.data(), 6000);
        for (int i = 0; i < 6000; i += 64) b.Mix(parts.data() + i, std::min(64, 6000 - i));
        CHECK(whole == parts);
    }

    if (argc > 2 && !strcmp(argv[1], "--wav")) {         // демо: «печатаем» ключ, стираем, вставляем, входим
        std::vector<int16_t> pcm;
        auto gap = [&](double sec) { pcm.insert(pcm.end(), (size_t)(sec * avsnd::kRate), 0); };
        auto add = [&](int idx, double at, double gain) {
            const size_t start = (size_t)(at * avsnd::kRate);
            if (pcm.size() < start + bank.s[idx].size()) pcm.resize(start + bank.s[idx].size(), 0);
            for (size_t i = 0; i < bank.s[idx].size(); ++i) pcm[start + i] = (int16_t)std::max(-32768.0, std::min(32767.0, pcm[start + i] + bank.s[idx][i] * gain));
        };
        gap(0.3);
        double t = 0.3;
        const int seq[] = {5, 1, 6, 2, 7, 0, 4, 3, 6, 2, 5, 1};      // «набор» 12 символов
        for (int i = 0; i < 12; ++i) { add(avsnd::KEY0 + seq[i], t, 0.55); t += 0.17 + 0.03 * (i % 3); }
        t += 0.4; add(avsnd::BACK, t, 0.55); t += 0.13; add(avsnd::BACK, t, 0.55); t += 0.13; add(avsnd::BACK, t, 0.55);
        t += 0.6; add(avsnd::CLEAR, t, 0.55);
        t += 0.8; add(avsnd::PASTE, t, 0.55);
        t += 0.8; add(avsnd::ENTER, t, 0.55);
        t += 0.9; add(avsnd::SUCCESS, t, 0.55);
        t += 1.6; add(avsnd::ERROR_, t, 0.55);
        t += 0.8; add(avsnd::TOGGLE, t, 0.55);
        gap(0.6);
        writeWav(argv[2], pcm);
        printf("записано %s (%.1f c)\n", argv[2], (double)pcm.size() / avsnd::kRate);
    }
    printf(fails ? "FAILED: %d\n" : "ALL OK\n", fails);
    return fails ? 1 : 0;
}
