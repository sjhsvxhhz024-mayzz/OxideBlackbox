"""Local HTTP/TLS delayed/fragmented/keep-alive/truncated response tests."""
import datetime, http.server, socket, ssl, subprocess, sys, tempfile, threading, time
from pathlib import Path
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID
class Handler(http.server.BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def log_message(self,*args):pass
 def do_GET(self):
  try:
   path=self.path
   if path=='/stall':time.sleep(6)
   if path=='/delayed':time.sleep(1.6)
   self.send_response(200)
   self.send_header('Connection','keep-alive')
   if path=='/chunked':self.send_header('Transfer-Encoding','chunked')
   else:self.send_header('Content-Length','20' if path=='/truncated' else '5')
   self.end_headers()
   if path=='/fragmented':
    self.wfile.write(b'he');self.wfile.flush();time.sleep(1.6);self.wfile.write(b'llo')
   elif path=='/chunked':self.wfile.write(b'5;x=yes\r\nhello\r\n0\r\nX-Test: one\r\n\r\n')
   else:self.wfile.write(b'hello')
   self.wfile.flush()
   if path=='/truncated':self.close_connection=True
   elif path in ['/keepalive','/chunked']:time.sleep(6);self.close_connection=True
  except (OSError,ssl.SSLError):self.close_connection=True
with tempfile.TemporaryDirectory() as temp:
 key=ec.generate_private_key(ec.SECP256R1());name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'localhost')]);now=datetime.datetime.now(datetime.timezone.utc)
 cert=x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(days=1)).not_valid_after(now+datetime.timedelta(days=1)).sign(key,hashes.SHA256())
 p=Path(temp);(p/'key.pem').write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()));(p/'cert.pem').write_bytes(cert.public_bytes(serialization.Encoding.PEM))
 a=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);b=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
 ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.load_cert_chain(str(p/'cert.pem'),str(p/'key.pem'));b.socket=ctx.wrap_socket(b.socket,server_side=True)
 for server in [a,b]:threading.Thread(target=server.serve_forever,daemon=True).start()
 result=subprocess.run([sys.argv[1],f'http://127.0.0.1:{a.server_port}',f'https://127.0.0.1:{b.server_port}'])
 for server in [a,b]:server.shutdown();server.server_close()
 sys.exit(result.returncode)
