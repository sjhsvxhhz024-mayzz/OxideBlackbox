#include "auth/auth_net.h"
#include "auth/auth_proto.h"
#include <cassert>
#include <chrono>
#include <cstdio>
int main(int argc,char**argv){
 if(argc!=3)return 2;
 for(int i=1;i<=2;++i){const std::string base=argv[i];
  for(const char*path:{"/delayed","/fragmented","/keepalive","/chunked"}){
   avis::HttpResponse r;std::string err;auto t=std::chrono::steady_clock::now();
   const bool ok=avis::HttpRequest(base+path,"GET","",r,err);
   const double sec=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();
   if(!ok||r.status!=200||r.body!="hello"){std::printf("FAIL %s %s: %s\n",i==1?"HTTP":"HTTPS",path,err.c_str());return 1;}
   if(std::string(path)=="/keepalive"||std::string(path)=="/chunked")assert(sec<2.0);
   std::printf("%s %s complete in %.2fs OK\n",i==1?"HTTP":"HTTPS",path,sec);
  }
  for(const char*path:{"/truncated","/stall"}){
   avis::HttpResponse r;std::string err;auto t=std::chrono::steady_clock::now();
   assert(!avis::HttpRequest(base+path,"GET","",r,err));
   const double sec=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();
   assert(sec<6.5);if(std::string(path)=="/stall")assert(sec>4.5);
   std::printf("%s %s rejected in %.2fs OK\n",i==1?"HTTP":"HTTPS",path,sec);
  }
 }
 puts("ALL OK");
}
