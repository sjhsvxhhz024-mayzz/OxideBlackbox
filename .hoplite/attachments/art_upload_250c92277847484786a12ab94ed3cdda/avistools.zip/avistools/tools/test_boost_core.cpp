// Хост-тест Boost: g++ -std=c++17 -O1 -Wall -Isrc tools/test_boost_core.cpp -o /tmp/t && /tmp/t
#include "boost_core.h"
#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
using namespace boost;
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { ++fails; printf("FAIL line %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

struct Mem {
    uint64_t base = 0x7000000000ULL; std::vector<uint8_t> m = std::vector<uint8_t>(0x100, 0); int writes = 0; bool readOk = true;
    bool rd(uint64_t a, void *b, size_t n) { if (!readOk || a < base || a + n > base + m.size()) return false; memcpy(b, &m[a - base], n); return true; }
    bool wr(uint64_t a, const void *b, size_t n) { if (a < base || a + n > base + m.size()) return false; memcpy(&m[a - base], b, n); ++writes; return true; }
    uint8_t &at(uint64_t a) { return m[a - base]; }
};

int main() {
    const uint64_t G = 0x7000000018ULL, T = 0x7000000019ULL;
    {   // Выключить -> значение 0; вернуть -> исходное 1; соседний байт не тронут.
        Mem mem; mem.at(G) = 1; mem.at(T) = 1; BoolPatch p; double t = 0;
        CHECK(p.tick(mem, G, true, t += 0.3) == Result::Held && mem.at(G) == 0 && mem.at(T) == 1, "hide grass only");
        CHECK(p.taken && p.original == 1, "original remembered");
        CHECK(p.tick(mem, G, false, t += 0.3) == Result::Idle && mem.at(G) == 1 && !p.taken, "restore to 1");
        const int w = mem.writes; for (int i = 0; i < 10; ++i) p.tick(mem, G, false, t += 0.3);
        CHECK(mem.writes == w, "idle writes nothing");
    }
    {   // Игра сама держала поле выключенным: возврат оставляет 0.
        Mem mem; mem.at(G) = 0; BoolPatch p; double t = 0;
        p.tick(mem, G, true, t += 0.3); CHECK(mem.at(G) == 0 && p.original == 0 && mem.writes == 0, "already off: no write, original 0");
        p.tick(mem, G, false, t += 0.3); CHECK(mem.at(G) == 0 && mem.writes == 0, "restore keeps 0");
    }
    {   // Игра перезаписывает поле: запись повторяется, счётчик растёт.
        Mem mem; mem.at(G) = 1; BoolPatch p; double t = 0;
        p.tick(mem, G, true, t += 0.3); mem.at(G) = 1; p.tick(mem, G, true, t += 0.3); mem.at(G) = 1; p.tick(mem, G, true, t += 0.3);
        CHECK(mem.at(G) == 0 && p.overwrites == 2, "overwrites %d value %d", p.overwrites, mem.at(G));
        p.tick(mem, G, true, t += 0.01); mem.at(G) = 1; p.tick(mem, G, true, t += 0.01); CHECK(mem.at(G) == 1, "throttled to 4 Hz");
    }
    {   // Не bool в поле: ничего не пишем, не считаем «взятым».
        Mem mem; mem.at(G) = 0x7F; BoolPatch p; double t = 0;
        CHECK(p.tick(mem, G, true, t += 0.3) == Result::Invalid && mem.writes == 0 && !p.taken, "garbage byte rejected");
    }
    {   // Адрес недоступен / нечитаем.
        Mem mem; BoolPatch p; double t = 0;
        CHECK(p.tick(mem, 0, true, t += 0.3) == Result::Waiting && mem.writes == 0, "no address");
        mem.readOk = false; CHECK(p.tick(mem, G, true, t += 0.3) == Result::Waiting && mem.writes == 0, "unreadable");
    }
    {   // Адрес сменился (перезапуск игры): новый адрес не получает чужой «оригинал».
        Mem mem; mem.at(G) = 1; mem.at(T) = 0; BoolPatch p; double t = 0;
        p.tick(mem, G, true, t += 0.3);
        p.tick(mem, T, false, t += 0.3);
        CHECK(!p.taken && mem.at(T) == 0 && mem.at(G) == 0, "address change drops state, old value not 'restored' onto the new address");
    }
    {   // Выключено с самого начала: ни чтений, ни записей.
        Mem mem; mem.at(G) = 1; BoolPatch p; double t = 0;
        for (int i = 0; i < 20; ++i) p.tick(mem, G, false, t += 0.3);
        CHECK(mem.writes == 0 && mem.at(G) == 1, "off from start");
    }
    {   // Ограничитель кадров: период 1/cap минус запас; без ограничения не спит; устаревшее время не вешает цикл.
        CHECK(frameSleep(10.0, 10.001, 0) == 0.0 && frameSleep(10.0, 10.001, -5) == 0.0, "no cap -> no sleep");
        CHECK(fabs(frameSleep(10.0, 10.001, 60) - (1.0 / 60 - 0.003 - 0.001)) < 1e-9, "60 fps: %.5f", frameSleep(10.0, 10.001, 60));
        CHECK(fabs(frameSleep(10.0, 10.0, 30) - (1.0 / 30 - 0.003)) < 1e-9, "30 fps");
        CHECK(frameSleep(10.0, 10.2, 60) == 0.0, "already late -> no sleep");
        CHECK(frameSleep(100.0, 10.0, 30) <= 1.0 / 30 + 1e-9, "stale lastEnd in the future is clamped: %.4f", frameSleep(100.0, 10.0, 30));
        CHECK(frameSleep(10.0, 10.0, 1000) == 0.0, "very high cap: margin exceeds period");
        // Моделирование: экран 120 Гц, отрисовка 2 мс, предел 60: кадр должен укладываться в период 16.67 мс, а не в 25 мс.
        double vsync = 0.0, period = 1.0 / 120.0; double t = 0.0, last = 0.0; int frames = 0; const double render = 0.002;
        for (int i = 0; i < 600; ++i) {
            t = last + frameSleep(last, last, 60);                 // сон после возврата из swap
            t += render;                                           // отрисовка
            double next = ((long)(t / period) + 1) * period;      // swap ждёт ближайшего vsync
            if (t / period == (double)(long)(t / period)) next = t;
            last = next; ++frames; vsync = next;
        }
        const double fps = frames / vsync;
        CHECK(fps > 58.0 && fps < 61.0, "simulated 120 Hz panel with cap 60 gives %.1f fps", fps);
        double v2 = 0, l2 = 0; int f2 = 0; const double p2 = 1.0 / 60.0;
        for (int i = 0; i < 300; ++i) { double t2 = l2 + frameSleep(l2, l2, 30) + render; double n2 = ((long)(t2 / p2) + 1) * p2; l2 = n2; ++f2; v2 = n2; }
        CHECK(f2 / v2 > 29.0 && f2 / v2 < 31.0, "simulated 60 Hz panel with cap 30 gives %.1f fps", f2 / v2);
    }
    printf(fails ? "FAILED: %d\n" : "ALL OK\n", fails);
    return fails ? 1 : 0;
}
