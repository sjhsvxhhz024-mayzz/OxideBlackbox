#!/usr/bin/env bash
# Headless ImGui test: tap, drag, auth gate, persistence, all 22 dropdown choices.
# No Android SDK, OpenGL headers, device, game, or network required.
set -euo pipefail
cd "$(dirname "$0")/.."
BIN=$(mktemp /tmp/avis_quick_ui.XXXXXX)
trap 'rm -f "$BIN"' EXIT
g++ -std=c++17 -O1 -Wall -Wextra -Iinclude/ImGui -Iinclude -Isrc -Isrc/trial \
    tools/test_quick_actions_ui.cpp src/trial/trial_ui.cpp src/trial/i18n.cpp \
    src/ImGui/imgui.cpp src/ImGui/imgui_draw.cpp src/ImGui/imgui_tables.cpp src/ImGui/imgui_widgets.cpp \
    -o "$BIN"
"$BIN"