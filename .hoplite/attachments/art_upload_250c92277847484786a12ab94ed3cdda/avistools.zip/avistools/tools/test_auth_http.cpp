#include "auth/auth_http.h"
#include <cassert>
#include <cstdio>
int main(){using namespace avis;
 const std::string h="HTTP/1.1 200 OK\r\nContent-Length: 5\r\nConnection: keep-alive\r\n\r\n";
 for(size_t n=0;n<h.size()+5;++n)assert(InspectHttpFrame((h+"hello").substr(0,n))==HttpFrame::Pending);
 assert(InspectHttpFrame(h+"hello")==HttpFrame::Complete);
 assert(InspectHttpFrame("HTTP/1.1 200 OK\r\n\r\nhello")==HttpFrame::UntilClose);
 const std::string c="HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n";
 assert(InspectHttpFrame(c+"5\r\nhello\r\n0\r\n\r\n")==HttpFrame::Complete);
 assert(InspectHttpFrame(c+"5;x=y\r\nhello\r\n0\r\nX-Test: yes\r\n\r\n")==HttpFrame::Complete);
 assert(InspectHttpFrame(c+"5\r\nhell")==HttpFrame::Pending);
 assert(InspectHttpFrame(c+"5\r\nhello\r\n0\r\n")==HttpFrame::Pending);
 assert(InspectHttpFrame(c+"g\r\n")==HttpFrame::Invalid);
 assert(InspectHttpFrame(c+"5\r\nhello!!")==HttpFrame::Invalid);
 for(auto value:{"-1","abc","32769","999999999999999999999",""})assert(InspectHttpFrame(std::string("HTTP/1.1 200 OK\r\nContent-Length: ")+value+"\r\n\r\n")==HttpFrame::Invalid);
 assert(InspectHttpFrame("HTTP/1.1 200 OK\r\nContent-Length: 0\r\nContent-Length: 2\r\n\r\n")==HttpFrame::Invalid);
 assert(InspectHttpFrame(c.substr(0,c.size()-2)+"Content-Length: 0\r\n\r\n")==HttpFrame::Invalid);
 puts("HTTP framing: complete, fragmented, keep-alive, chunks, trailers, truncated and invalid cases OK");
}
