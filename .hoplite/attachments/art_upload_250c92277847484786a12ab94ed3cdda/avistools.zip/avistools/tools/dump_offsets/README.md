# Сверка оффсетов между версиями игры

Обновление под новую версию без запуска игры:

```bash
python3 parse_dump.py <старый dump.cs> /tmp/old.pkl
python3 parse_dump.py <новый dump.cs> /tmp/new.pkl
python3 translate.py        # /tmp/translate.txt: константа, старое и новое смещение, имена полей
```

Имена полей между версиями обфусцируются заново, поэтому поля сопоставляются по типу и порядку (`align.py`).
Метки классов и TypeDefIndex в `translate.py` берутся для пары версий 1.13.946 -> 1.14.11949; для следующей пары TDI нужно
пересчитать (поиск по читаемым именам полей — `fuzzy()` в `align.py`).

RVA слотов `Il2CppClass*` (`OX_TI_*` в `src/main.cpp`) берутся из `script.json` нового дампа: секция `ScriptMetadata`,
записи с именем `<Namespace.Class>_TypeInfo` (для обфусцированных классов — по новому имени из `dump.cs`).
