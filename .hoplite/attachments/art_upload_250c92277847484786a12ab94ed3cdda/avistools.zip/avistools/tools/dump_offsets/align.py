import pickle, re, difflib, sys

old = pickle.load(open('/tmp/old.pkl', 'rb'))
new = pickle.load(open('/tmp/new.pkl', 'rb'))
oldNames = {c['name'] for c in old.values()}
newNames = {c['name'] for c in new.values()}
stableNames = {n for n in oldNames & newNames if len(n) >= 5}
PRIM = {'int', 'uint', 'float', 'bool', 'byte', 'short', 'ushort', 'long', 'ulong', 'double', 'string', 'sbyte', 'char', 'object'}


def normType(t):
    def rep(m):
        w = m.group(0)
        return w if (w in PRIM or w in stableNames or w in ('List', 'Dictionary', 'HashSet', 'Action', 'Func')) else '?'
    return re.sub(r'[A-Za-z_][A-Za-z_0-9]*', rep, t)


def keyOf(f, other):
    return (f[0] if f[0] in other else '?', normType(f[1]))


def align(oc, nc):
    of = sorted([f for f in oc['fields'] if not f[3]], key=lambda f: f[2])
    nf = sorted([f for f in nc['fields'] if not f[3]], key=lambda f: f[2])
    onames = {f[0] for f in of}; nnames = {f[0] for f in nf}
    a = [keyOf(f, nnames) for f in of]
    b = [keyOf(f, onames) for f in nf]
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    res = {}
    for blk in sm.get_matching_blocks():
        for k in range(blk.size):
            res[of[blk.a + k][2]] = (nf[blk.b + k][2], of[blk.a + k][0], nf[blk.b + k][0], of[blk.a + k][1])
    return res, of, nf


def classScore(oc, nc):
    of = sorted([f for f in oc['fields'] if not f[3]], key=lambda f: f[2])
    nf = sorted([f for f in nc['fields'] if not f[3]], key=lambda f: f[2])
    if not of or abs(len(of) - len(nf)) > 3:
        return 0
    onames = {f[0] for f in of}; nnames = {f[0] for f in nf}
    a = [keyOf(f, nnames) + (f[2],) for f in of]
    b = [keyOf(f, onames) + (f[2],) for f in nf]
    return difflib.SequenceMatcher(None, a, b, autojunk=False).ratio()


def fuzzy(oc, limit=3):
    """поиск нового класса для обфусцированного старого: тот же namespace и базовый класс, максимальное сходство полей"""
    cands = [c for c in new.values() if c['kind'] == oc['kind'] and c['ns'] == oc['ns'] and abs(len([f for f in c['fields'] if not f[3]]) - len([f for f in oc['fields'] if not f[3]])) <= 3]
    sc = sorted(((classScore(oc, c), c) for c in cands), key=lambda x: -x[0])[:limit]
    return sc


if __name__ == '__main__':
    pass
