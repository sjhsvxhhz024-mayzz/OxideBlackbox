import re, sys, pickle

CLS = re.compile(r'^(?:public |internal |private |protected )?(?:sealed |abstract |static |readonly )*(class|struct|enum|interface) (\S+?)(?: : (.*?))? // TypeDefIndex: (\d+)')
FLD = re.compile(r'^\t(?:public |private |protected |internal )?((?:static |const |readonly )*)([^=(;]+?) (\S+); // 0x([0-9A-Fa-f]+)$')


def parse(path):
    classes = {}
    cur = None
    ns = ''
    with open(path, 'rb') as f:
        for raw in f:
            line = raw.decode('utf-8', 'replace').rstrip('\n')
            if line.startswith('// Namespace:'):
                ns = line[13:].strip()
                continue
            m = CLS.match(line)
            if m:
                cur = {'kind': m.group(1), 'name': m.group(2), 'base': (m.group(3) or '').split(',')[0].strip(),
                       'tdi': int(m.group(4)), 'ns': ns, 'fields': []}
                classes[cur['tdi']] = cur
                continue
            if cur is not None and line.startswith('\t') and '(' not in line.split('//')[0]:
                m = FLD.match(line)
                if m:
                    cur['fields'].append((m.group(3), m.group(2).strip(), int(m.group(4), 16), 'static' in m.group(1)))
    return classes


if __name__ == '__main__':
    c = parse(sys.argv[1])
    pickle.dump(c, open(sys.argv[2], 'wb'))
    print(sys.argv[2], len(c))
