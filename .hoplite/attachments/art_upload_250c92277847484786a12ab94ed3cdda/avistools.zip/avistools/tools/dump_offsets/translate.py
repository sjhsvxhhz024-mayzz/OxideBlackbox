import sys
sys.path.insert(0, '/tmp')
from align import *

# (константа, метка, старый TDI, новый TDI, старое смещение, статика?)
PM = (9624, 9722); ML = (9237, 9334); FPM = (9320, 9417); RM = (9355, 9452); PV = (9261, 9358); GV = (9250, 9347)
RYS = (9272, 9369); RYK = (9271, 9368); RYX = (9268, 9365); RBR = (9608, 9706); RBY = (9633, 9731); RBK = (9636, 9734); RBX = (9548, 9645)
RYT = (9353, 9450); DM = (437, 435); GC = (9496, 9593); PMI = (4283, 4324); RAG = (1809, 1801); KCC = (4242, 4283); SKCC = (2202, 2216)
MOT = (10733, 10828); FPO = (9327, 9424); ITD = (9556, 9653); ITEM = (1977, 1970); MINE = (9379, 9476); PW = (1895, 1888)
CHA = (4211, 4252); LOOT = (9373, 9470); NI = (25623, 25715); NB = (25597, 25689); HBR = (4385, 4426); HB = (9257, 9354); IDB = (9562, 9659)

ROWS = [
    ('PM_TRANSFORM', PM, 0x68, 0), ('PM_KCC_REFERENCE', PM, 0xB0, 0), ('PM_LAST_TICK_POS', PM, 0x1E8, 0), ('PM_LAST_SAVED_POS', PM, 0x1F4, 0),
    ('PM_CHARACTER_MODEL', PM, 0x150, 0), ('PM_MOUSELOOK', PM, 0x70, 0), ('PM_FPMANAGER', PM, 0x90, 0), ('PM_RAYCASTMANAGER', PM, 0x88, 0),
    ('PM_VITALS', PM, 0xC8, 0), ('PM_LOOK_ANGLE', PM, 0x1C8, 0), ('PM_IS_LOCAL_PLAYER', PM, 0x1A8, 0), ('PM_OBSERVED_PLAYER', PM, 0x370, 0),
    ('PM_ANIMATOR', PM, 0x1B0, 0), ('PM_TEAM', PM, 0x120, 0), ('PM_TEAM_NAME', PM, 0x2A0, 0), ('PM_USER_ID', PM, 0x298, 0), ('PM_NICKLABEL', PM, 0x130, 0),
    ('PM_CLAN_ID', PM, 0x2B0, 0), ('PM_CLAN_TAG', PM, 0x2B8, 0), ('PM_EVENT_HANDLER', PM, 0x78, 0), ('PM_WEAPONS', PM, 0x1B8, 0), ('PM_WEAPON_REF', PM, 0xF0, 0),
    ('PM_PLAYER_FLAGS', PM, 0x270, 0), ('PM_PRIME', PM, 0x274, 0), ('PM_IS_IN_AIR', PM, 0x1D8, 0), ('PM_RESPAWNING', PM, 0x228, 0), ('PM_EQUIPMENT', PM, 0xE8, 0),
    ('PM_INVENTORY', PM, 0x98, 0),
    ('VITALS_ENTITY', RYX, 0x68, 0), ('VITALS_PLAYER_EVENT', PV, 0x108, 0), ('VITALS_HEALTH', GV, 0x88, 0), ('VITALS_PROTECTION', GV, 0x90, 0),
    ('RYS_MANAGER', RYS, 0xD0, 0), ('RYS_AIM_RAYCAST', RYS, 0x168, 0), ('RYS_LAST_HIT_POINT', RYS, 0x170, 0), ('RYS_LAST_HIT_TIME', RYS, 0x178, 0), ('RYS_EQUIPPED_ITEM', RYS, 0x1B8, 0),
    ('RYK_HEALTH', RYK, 0x98, 0), ('RYK_DISPLAY_NAME', RYK, 0x88, 0), ('RYT_PLAYER', RYT, 0x40, 0),
    ('RBY_TEAM_MANAGER', RBY, 0x80, 0), ('RBK_PLAYER_MODELS', RBK, 0xB0, 0), ('RBK_PLAYER_DICT', RBK, 0xC8, 0), ('RBK_MAX_PLAYERS', RBK, 0x98, 0), ('RBK_PLAYERS_COUNT', RBK, 0x9C, 0),
    ('GC_STATIC_INSTANCE', GC, 0x60, 1), ('GC_STATIC_LOCAL_PM', GC, 0x10, 1), ('GC_STATIC_LOCAL_RYS', GC, 0x18, 1), ('GC_BALLISTIC_SHOTS', GC, 0xD8, 0), ('GC_PLAYERS_LIST', GC, 0x1A8, 0), ('GC_ITEM_DATABASE', GC, 0x70, 0),
    ('NICKLABEL_IS_TEAMMATE', DM, 0x91, 0), ('NICKLABEL_NICKNAME', DM, 0x38, 0), ('NICKLABEL_PLAYERID', DM, 0x40, 0),
    ('ITEM_DATA', ITEM, 0x20, 0), ('FPOBJ_ITEM', FPO, 0x40, 0), ('ITEMDATA_SHORTNAME', ITD, 0x20, 0), ('ITEMDATA_NAME', ITD, 0x18, 0), ('ITEMDATA_ID', ITD, 0x58, 0),
    ('ITEMDB_BY_ID', IDB, 0x28, 0),
    ('FP_WORLD_CAMERA', FPM, 0x20, 0), ('FP_CURRENT_WEAPON', FPM, 0x50, 0), ('FP_FOV_CURRENT', FPM, 0xA0, 0), ('FP_FOV_BASE', FPM, 0xAC, 0), ('FP_FOV_OFFSET', FPM, 0xB4, 0),
    ('FPOBJ_NORMAL_FOV', FPO, 0x80, 0), ('FPOBJ_AIM_FOV', FPO, 0x84, 0),
    ('ML_LOOKROOT', ML, 0x28, 0), ('ML_PITCH(=Vector2 0x88)', ML, 0x88, 0),
    ('RM_PLAYER', RM, 0x20, 0), ('RM_TEAM_MANAGER', RM, 0x28, 0), ('RM_WORLD_CAMERA', RM, 0x30, 0), ('RM_RAY_LENGTH', RM, 0x38, 0), ('RM_AIM_RAY_LENGTH', RM, 0x3C, 0),
    ('RM_LAYER_MASK', RM, 0x48, 0), ('RM_AIM_LAYER_MASK', RM, 0x4C, 0),
    ('PMI_HEAD', PMI, 0x20, 0), ('PMI_RIGHT_HAND', PMI, 0x28, 0), ('PMI_LEFT_HAND', PMI, 0x30, 0), ('PMI_EQUIPMENT', PMI, 0x38, 0), ('PMI_BODY', PMI, 0x40, 0), ('PMI_HEAD_MODEL', PMI, 0x48, 0), ('PMI_CHAR_ANIM', PMI, 0x60, 0),
    ('CHARANIM_MODELINFO', CHA, 0x30, 0), ('CHARANIM_RAGDOLL', CHA, 0x38, 0), ('CHARANIM_PLAYER', CHA, 0x78, 0),
    ('RAGDOLL_PELVIS', RAG, 0x20, 0), ('RAGDOLL_BONES', RAG, 0x88, 0),
    ('KCC_PLAYER', KCC, 0x78, 0), ('KCC_HEAD', KCC, 0x88, 0), ('KCC_MOTOR', KCC, 0x68, 0), ('KCC_NORMAL_HEIGHT', KCC, 0xA0, 0), ('KCC_CROUCH_HEIGHT', KCC, 0xA4, 0), ('KCC_LOOK_HEIGHT_OFF', KCC, 0x90, 0),
    ('SKCC_PLAYER', SKCC, 0x80, 0), ('SKCC_RECORDER', SKCC, 0x78, 0),
    ('HBR_HITBOXES', HBR, 0x68, 0), ('HB_HITAREA', HB, 0x68, 0), ('HB_ID', HB, 0x6C, 0),
    ('MOTOR_INTERP_POS', MOT, 0x1EC, 0), ('MOTOR_TICK_POS', MOT, 0x1E0, 0), ('MOTOR_BASE_VELOCITY', MOT, 0x210, 0), ('MOTOR_TRANSFORM', MOT, 0x118, 0),
    ('MOTOR_CAPSULE_HEIGHT', MOT, 0x34, 0), ('MOTOR_CAPSULE_YOFF', MOT, 0x38, 0), ('MOTOR_CAPSULE_RADIUS', MOT, 0x30, 0),
    ('MINE_LOOT', MINE, 0xA0, 0), ('MINE_TRANSFORM', MINE, 0xC8, 0), ('MINE_MAX_HEALTH', MINE, 0xC0, 0), ('LOOTITEM_NAME', LOOT, 0x10, 0),
    ('PW_PLAYER', PW, 0x138, 0), ('PW_WEAPON_PIECE', PW, 0x110, 0),
    ('EQUIP_PIECES', RBR, 0xA0, 0), ('EQUIP_SLOTS_DICT', RBR, 0xA8, 0), ('SLOT_ITEM', RBX, 0x10, 0),
    ('NB_NET_IDENTITY', NB, 0x40, 0), ('NI_IS_LOCAL_PLAYER', NI, 0x4A, 0), ('NI_NET_ID', NI, 0x58, 0), ('NI_BEHAVIOURS', NI, 0x80, 0),
]


def alignStatic(oc, nc):
    of = sorted([f for f in oc['fields'] if f[3]], key=lambda f: f[2]); nf = sorted([f for f in nc['fields'] if f[3]], key=lambda f: f[2])
    onames = {f[0] for f in of}; nnames = {f[0] for f in nf}
    a = [keyOf(f, nnames) for f in of]; b = [keyOf(f, onames) for f in nf]
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False); res = {}
    for blk in sm.get_matching_blocks():
        for k in range(blk.size):
            res[of[blk.a + k][2]] = (nf[blk.b + k][2], of[blk.a + k][0], nf[blk.b + k][0], of[blk.a + k][1])
    return res


cache = {}
out = []
for name, (ot, nt), off, st in ROWS:
    key = (ot, nt, st)
    if key not in cache:
        cache[key] = alignStatic(old[ot], new[nt]) if st else align(old[ot], new[nt])[0]
    m = cache[key].get(off)
    if m is None:
        # поле могло быть без имени в списке (Vector2 backing и т.п.): ищем ближайшее старое поле, перекрывающее смещение
        out.append('%-26s old=0x%X  NOT-MATCHED (%s -> %s)' % (name, off, old[ot]['name'], new[nt]['name']))
    else:
        flag = '' if m[0] == off else '  <== CHANGED'
        out.append('%-26s old=0x%X new=0x%X  %s -> %s [%s]%s' % (name, off, m[0], m[1], m[2], m[3][:24], flag))
open('/tmp/translate.txt', 'w').write('\n'.join(out))
print(len(out), 'rows;', sum('CHANGED' in l for l in out), 'changed;', sum('NOT-MATCHED' in l for l in out), 'unmatched')
