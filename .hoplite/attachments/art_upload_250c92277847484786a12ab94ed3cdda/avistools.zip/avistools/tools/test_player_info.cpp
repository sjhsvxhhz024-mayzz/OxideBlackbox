// Хост-тест ников, клана, живого HP, оценки урона и выстрелов всех игроков. Берёт НАСТОЯЩИЙ код из main.cpp (между
// маркерами «Ник, клан, HP и урон») и гоняет его по поддельной памяти игры. Запуск из корня репозитория:
//   python3 -c "s=open('src/main.cpp',encoding='utf-8').read(); a=s.index('// ── Ник, клан, HP и урон: begin'); b=s.index('// ── Ник, клан, HP и урон: end'); open('/tmp/pi_block.inc','w',encoding='utf-8').write(s[a:b])"
//   g++ -O1 -std=c++17 -Iinclude -I/tmp tools/test_player_info.cpp -o /tmp/t3 && /tmp/t3
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cctype>
#include <atomic>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <iterator>
#include <algorithm>
#include "oxide_offsets.h"
#include "Vector3.h"
using std::isfinite;

static bool g_verbose = false;
#define OXLOGI(...) do { if (g_verbose) { printf("   I "); printf(__VA_ARGS__); printf("\n"); } } while (0)
#define OXLOGW(...) do { if (g_verbose) { printf("   W "); printf(__VA_ARGS__); printf("\n"); } } while (0)

// ── поддельная память игры ──
static std::map<uint64_t, std::vector<uint8_t>> g_reg;
static uint64_t g_next = 0x7000000000ULL;
static uint8_t *at(uint64_t a, size_t n) {
    auto it = g_reg.upper_bound(a);
    if (it == g_reg.begin()) return nullptr;
    --it;
    if (a >= it->first && a + n <= it->first + it->second.size()) return it->second.data() + (a - it->first);
    return nullptr;
}
static uint64_t alloc(size_t n) { const uint64_t a = g_next; g_next += (n + 0xFFF) & ~0xFFFULL; g_reg[a].assign(n, 0); return a; }
template <class T> static void put(uint64_t a, T v) { uint8_t *p = at(a, sizeof(T)); if (p) memcpy(p, &v, sizeof(T)); else printf("PUT FAIL %llx\n", (unsigned long long)a); }
static long g_calls = 0;
static bool vm_readv(unsigned long a, void *b, size_t n) { ++g_calls; uint8_t *p = at(a, n); if (!p) return false; memcpy(b, p, n); return true; }
template <class T> static T rpm(uint64_t a) { ++g_calls; T v{}; uint8_t *p = at(a, sizeof(T)); if (p) memcpy(&v, p, sizeof(T)); return v; }
static bool ox_isPtr(uint64_t p) { return p > 0x10000 && p < 0x0000800000000000ULL; }
namespace ImGui { static double g_t = 0; static double GetTime() { return g_t; } }

uint64_t g_localPlayer = 0;
float esphpdamage = 0.f, esphpcrit = 2.f;
static inline float ox_boxYOffset() { return 0.f; }
struct PlayerCacheData {
    uint64_t address = 0; Vector3 position; Vector3 velocity; bool usedModelAnchor = false; Vector3 anchorFeet, anchorHead;
    float hpNow = -1.f, hpMax = 0.f; std::string name, clan; bool nameFromRoster = false;
};

#include "pi_block.inc"

static int fails = 0;
#define CHECK(c, ...) do { if(!(c)) { ++fails; printf("FAIL: "); printf(__VA_ARGS__); printf("\n"); } } while(0)

// ── строители объектов ──
static uint64_t mkStr(const std::u16string &s) {
    const uint64_t a = alloc(0x20 + s.size() * 2);
    put<int>(a + 0x10, (int)s.size());
    for (size_t i = 0; i < s.size(); ++i) put<uint16_t>(a + 0x14 + i * 2, (uint16_t)s[i]);
    return a;
}

struct World {
    uint64_t rbk = 0, iz = 0, arr = 0;
    int nModels = 0;
    void initRoster(int capacity) {
        iz = alloc(0x100); rbk = alloc(0x100);
        put<uint64_t>(iz + ox::IZ_PLAYERS_LIST, rbk);
        put<uint64_t>(rbk + ox::RBK_TEAM_MANAGER, iz);
        put<int>(rbk + ox::RBK_MAX_PLAYERS, 50); put<int>(rbk + ox::RBK_PLAYERS_COUNT, 0);
        arr = alloc(0x20 + (size_t)capacity * ox::PLAYERMODEL_STRIDE);
        put<uint64_t>(arr + ox::ARRAY_COUNT, (uint64_t)capacity);
        put<uint64_t>(rbk + ox::RBK_PLAYER_MODELS, arr);
    }
    void writeModel(uint64_t e, const std::u16string &id, const std::u16string &nick, const std::u16string &clan, int level) {
        put<uint64_t>(e + ox::PLAYERMODEL_ID, mkStr(id));
        put<uint64_t>(e + ox::PLAYERMODEL_NICK, mkStr(nick));
        put<uint64_t>(e + 0x10, mkStr(u"clanId"));
        put<uint64_t>(e + ox::PLAYERMODEL_CLAN_TAG, clan.empty() ? 0 : mkStr(clan));
        put<int>(e + ox::PLAYERMODEL_LEVEL, level);
    }
    void addModel(const std::u16string &id, const std::u16string &nick, const std::u16string &clan, int level) {
        writeModel(arr + ox::ARRAY_DATA + (uint64_t)nModels * ox::PLAYERMODEL_STRIDE, id, nick, clan, level);
        ++nModels;
        put<int>(rbk + ox::RBK_PLAYERS_COUNT, nModels);
    }
    uint64_t mkPM(const std::u16string &userId, const std::u16string &clanTag, const std::u16string &label, const std::u16string &display, bool team, uint32_t netId = 0) {
        const uint64_t pm = alloc(0x400), rys = alloc(0x400), vit = alloc(0x200), health = alloc(0x40);
        put<uint64_t>(pm + ox::PM_VITALS, vit); put<float>(vit + ox::VITALS_HEALTH, 100.f);
        put<uint64_t>(pm + ox::PM_EVENT_HANDLER, rys);
        put<uint64_t>(rys + ox::RYS_MANAGER, pm); put<uint64_t>(rys + ox::RYK_HEALTH, health);
        put<float>(health + ox::REASONED_VALUE_A, 100.f); put<float>(health + ox::REASONED_VALUE_B, 100.f);
        put<uint64_t>(pm + ox::PM_USER_ID, mkStr(userId));
        if (!clanTag.empty()) put<uint64_t>(pm + ox::PM_CLAN_TAG, mkStr(clanTag));
        if (!display.empty()) put<uint64_t>(rys + ox::RYK_DISPLAY_NAME, mkStr(display));
        if (!label.empty()) {
            const uint64_t dm = alloc(0x100), tx = alloc(0x200);
            put<uint64_t>(pm + ox::PM_NICKLABEL, dm); put<uint64_t>(dm + ox::NICKLABEL_NICKNAME, tx); put<uint64_t>(tx + ox::UITEXT_M_TEXT, mkStr(label));
        }
        if (team && rbk) { const uint64_t rby = alloc(0x100); put<uint64_t>(pm + ox::PM_TEAM, rby); put<uint64_t>(rby + ox::RBY_TEAM_MANAGER, iz); }
        if (netId) { const uint64_t ni = alloc(0x100); put<uint64_t>(pm + ox::NB_NET_IDENTITY, ni); put<uint32_t>(ni + ox::NI_NET_ID, netId); }
        return pm;
    }
};
static uint64_t rysOf(uint64_t pm) { return rpm<uint64_t>(pm + ox::PM_EVENT_HANDLER); }
static uint64_t healthOf(uint64_t pm) { return rpm<uint64_t>(rysOf(pm) + ox::RYK_HEALTH); }
static void setHealth(uint64_t pm, float a, float b) { put<float>(healthOf(pm) + ox::REASONED_VALUE_A, a); put<float>(healthOf(pm) + ox::REASONED_VALUE_B, b); }
static void resetAll() {
    g_reg.clear(); g_next = 0x7000000000ULL; g_rbk = 0; g_roster.clear(); g_rosterNextResolve = g_rosterNextRead = g_rosterNextLog = 0.0; g_rosterStage = 0; g_rosterFails = 0;
    g_rosterSrc = ""; g_dictLayout = OxDictLayout();
    g_selfNick.clear(); g_selfClan.clear(); g_hpStates.clear(); g_hpEst.clear(); g_hpVoteA = g_hpVoteB = 0; g_hpPathName = ""; g_hit = OxHitWatch();
    g_gcKlass.store(0); g_gcInst = g_gcRbk = g_gcQe = 0; g_gcNext = 0.0; g_gcStage = 0;
    g_bullets.clear(); g_shotsSeen = g_shotHits = g_bulletBad = g_bulletLogged = 0; g_bulletState = "нет данных"; g_netToPm.clear(); g_netToPmNext = 0.0;
    g_localPlayer = 0; esphpdamage = 0.f; esphpcrit = 2.f; g_espStatus.clear();
}

// ═══════════════ 1. ники и клан ═══════════════
static void testUtf8() {
    resetAll();
    auto rd = [&](const std::u16string &s, int maxc = 64) { return ox_readStringUtf8(mkStr(s), maxc); };
    CHECK(rd(u"Привет") == "Привет", "кириллица");
    CHECK(rd(std::u16string(u"\xD83D\xDE00")) == "\xF0\x9F\x98\x80", "суррогатная пара");
    CHECK(rd(std::u16string(u"A\xD83D") + u"B") == "AB", "одинокий старший суррогат отбрасывается");
    CHECK(rd(std::u16string(u"A\xDE00") + u"B") == "AB", "одинокий младший суррогат отбрасывается");
    CHECK(rd(std::u16string(u"A\x01\x1F\x7F") + u"B") == "AB", "управляющие символы отбрасываются");
    CHECK(rd(std::u16string(u"Zed\x200B")) == "Zed", "невидимый пробел нулевой ширины отбрасывается");
    CHECK(rd(std::u16string(u"\xFEFF") + u"Zed") == "Zed", "BOM отбрасывается");
    CHECK(rd(std::u16string(u"  Zed\xA0 ")) == "Zed", "края обрезаются, неразрывный пробел считается пробелом");
    CHECK(rd(u"中文") == "中文", "CJK");
    CHECK(rd(u"abcdefghij", 4) == "abcd", "усечение по maxChars");
    CHECK(rd(u"").empty(), "пустая строка");
    CHECK(ox_readStringUtf8(0).empty(), "null");
    const uint64_t bad = mkStr(u"x"); put<int>(bad + 0x10, 5000);                               // длина-мусор
    CHECK(ox_readStringUtf8(bad).empty(), "мусорная длина строки");
    printf("  UTF-8: кириллица, суррогаты, невидимые символы, CJK, мусор — проверено\n");
    CHECK(ox_nickValid("Zed") && ox_nickValid("Игрок_Вася") && ox_nickValid("_x_") && ox_nickValid("player1") && ox_nickValid("Nick_the_Great"), "валидные ники");
    const char *placeholders[] = { "", "Nickname", "NICKNAME", "nIcKnAmE", "Nickname 2", "Nickname (1)", "nickname_3", "Player", "New Text", "---", "Никнейм", "Игрок", "Ник",
                                   "deadbeefdeadbeef0123", "0123456789abcdef-0123" };
    for (const char *p : placeholders) CHECK(!ox_nickValid(p), "заготовка '%s' принята за ник", p);
    printf("  заготовки («Nickname», «Nickname 2», «Никнейм», hex-ID) отброшены\n");
}

static void testNicks() {
    resetAll(); ImGui::g_t = 1000.0;
    World W; W.initRoster(16);
    W.addModel(u"id_local", u"MyRealNick", u"MYCL", 7);
    W.addModel(u"id_ru",  u"Игрок_Вася", u"ТЕГ", 12);
    W.addModel(u"id_zed", u"Zed", u"", 3);
    W.addModel(u"id_emo", std::u16string(u"\xD83D\xDE00") + u"Bob", u"", 5);                  // 😀Bob: суррогатная пара
    W.addModel(u"id_ph",  u"Nickname", u"AB", 1);                                              // заготовка в списке
    const uint64_t local = W.mkPM(u"id_local", u"", u"Nickname", u"", true);
    const uint64_t ru  = W.mkPM(u"id_ru",  u"", u"Nickname", u"", true);
    const uint64_t zed = W.mkPM(u"id_zed", u"XY", u"Nickname", u"", true);
    const uint64_t emo = W.mkPM(u"id_emo", u"", u"Nickname", u"", true);
    const uint64_t ph  = W.mkPM(u"id_ph",  u"", u"Nickname", u"Dmitry", true);                 // в списке заготовка -> DisplayName
    const uint64_t lab = W.mkPM(u"id_none1", u"", u"LabelNick", u"", true);                    // нет в списке -> подпись
    const uint64_t non = W.mkPM(u"id_none2", u"", u"Nickname", u"Player", true);               // везде заготовки -> пусто
    g_localPlayer = local;
    ImGui::g_t += 10;
    struct C { const char *name; uint64_t pm; const char *nick; const char *clan; bool fromRoster; } cs[] = {
        { "кириллица", ru, "Игрок_Вася", "ТЕГ", true }, { "латиница + PM.clanTag", zed, "Zed", "XY", true }, { "эмодзи", emo, "\xF0\x9F\x98\x80" "Bob", "", true },
        { "заготовка в списке -> DisplayName", ph, "Dmitry", "AB", false }, { "нет в списке -> подпись", lab, "LabelNick", "", false }, { "везде заготовки", non, "", "", false },
    };
    for (const C &c : cs) {
        bool fr = false;
        const std::string n = ox_playerNick(c.pm, &fr), cl = ox_playerClan(c.pm);
        printf("  ник %-36s -> '%s'  клан '%s'  из списка=%d\n", c.name, n.c_str(), cl.c_str(), (int)fr);
        CHECK(n == c.nick, "ник '%s': ожидал '%s', получил '%s'", c.name, c.nick, n.c_str());
        CHECK(cl == c.clan, "клан '%s': ожидал '%s', получил '%s'", c.name, c.clan, cl.c_str());
        CHECK(fr == c.fromRoster, "источник ника '%s': из списка=%d", c.name, (int)fr);
    }
    printf("  свой ник для превью: '%s' [%s]\n", g_selfNick.c_str(), g_selfClan.c_str());
    CHECK(g_selfNick == "MyRealNick" && g_selfClan == "MYCL", "g_selfNick/g_selfClan");

    // новый игрок появился в списке позже: первый запрос — промах, после ускоренного перечитывания — находим
    const uint64_t late = W.mkPM(u"id_late", u"", u"Nickname", u"", true);
    std::string first = ox_playerNick(late);
    W.addModel(u"id_late", u"Опоздавший", u"", 2);
    ImGui::g_t += 0.5;
    std::string second = ox_playerNick(late);
    printf("  новый игрок: сначала '%s', затем '%s'\n", first.c_str(), second.c_str());
    CHECK(first.empty() && second == "Опоздавший", "новый игрок: '%s' -> '%s'", first.c_str(), second.c_str());
}

static void testNickFailures() {
    resetAll(); ImGui::g_t = 2000.0;
    World W; W.initRoster(4); W.addModel(u"a", u"RegNick", u"", 1);
    // 1) у PM нет PM.team: реестр не найден, ник берётся из запасных источников
    uint64_t p1 = W.mkPM(u"a", u"", u"Nickname", u"FromDisplay", false);
    g_localPlayer = p1;
    std::string n = ox_playerNick(p1);
    printf("  без PM.team: ник '%s', этап обрыва %d\n", n.c_str(), g_rosterStage);
    CHECK(n == "FromDisplay" && g_rosterStage == 1 && g_rbk == 0, "без PM.team");
    // 2) пустой массив игроков
    resetAll(); ImGui::g_t = 2100.0; World W2; W2.initRoster(4);
    uint64_t p2 = W2.mkPM(u"a", u"", u"Lab", u"", true); g_localPlayer = p2;
    n = ox_playerNick(p2);
    printf("  пустой список: ник '%s', этап %d\n", n.c_str(), g_rosterStage);
    CHECK(n == "Lab" && g_rosterStage == 5, "пустой список");
    // 3) мусор в счётчиках
    resetAll(); ImGui::g_t = 2200.0; World W3; W3.initRoster(4); W3.addModel(u"a", u"X", u"", 1); put<int>(W3.rbk + ox::RBK_MAX_PLAYERS, -5);
    uint64_t p3 = W3.mkPM(u"a", u"", u"", u"", true); g_localPlayer = p3;
    n = ox_playerNick(p3);
    CHECK(n.empty() && g_rosterStage == 3 && g_rbk == 0, "мусор в счётчиках (этап %d)", g_rosterStage);
    // 4) матч сменился: массив пропал -> реестр сбрасывается после трёх сбоев и находится заново
    resetAll(); ImGui::g_t = 2300.0; World W4; W4.initRoster(4); W4.addModel(u"a", u"First", u"", 1);
    uint64_t p4 = W4.mkPM(u"a", u"", u"", u"", true); g_localPlayer = p4;
    n = ox_playerNick(p4); CHECK(n == "First", "до смены матча");
    put<uint64_t>(W4.rbk + ox::RBK_PLAYER_MODELS, 0);
    ImGui::g_t += 2.0; n = ox_playerNick(p4);
    CHECK(g_rbk != 0 && n == "First", "один сбой чтения не сбрасывает список: '%s'", n.c_str());
    ImGui::g_t += 2.0; ox_playerNick(p4); ImGui::g_t += 2.0; ox_playerNick(p4);
    CHECK(g_rbk == 0, "реестр должен сброситься после трёх сбоев подряд");
    World W5 = W4;
    const uint64_t arr2 = alloc(0x20 + 4 * ox::PLAYERMODEL_STRIDE);
    put<uint64_t>(arr2 + ox::ARRAY_COUNT, 4); put<uint64_t>(W4.rbk + ox::RBK_PLAYER_MODELS, arr2);
    W5.arr = arr2; W5.nModels = 0; W5.addModel(u"a", u"Second", u"", 1);
    ImGui::g_t += 3.0; n = ox_playerNick(p4);
    printf("  смена матча: '%s'\n", n.c_str());
    CHECK(n == "Second", "новый матч: '%s'", n.c_str());
}

// Контроллер игры -> реестр: работает, даже когда у PM нет цепочки PM.team -> RBY.rUk -> iZ.
struct Gc { uint64_t klass = 0, statics = 0, inst = 0, qe = 0; };
static Gc mkGc(World &W, uint64_t instStaticOff = ox::GC_STATIC_INSTANCE) {
    Gc g;
    g.klass = alloc(0x100); g.statics = alloc(0x100); g.inst = alloc(0x400);
    put<uint64_t>(g.klass + ox::CLASS_STATIC_FIELDS, g.statics);
    if (instStaticOff != ~0ULL) put<uint64_t>(g.statics + instStaticOff, g.inst);
    put<uint64_t>(g.inst + ox::GC_PLAYERS_LIST, W.rbk);
    g.qe = alloc(0x100); const uint64_t list = alloc(0x40), items = alloc(0x20 + 8 * 96);
    put<uint64_t>(g.qe + ox::QE_BULLETS, list); put<uint64_t>(list + ox::LIST_ITEMS, items); put<uint64_t>(items + ox::ARRAY_COUNT, 96);
    put<uint64_t>(g.inst + ox::GC_BALLISTIC_SHOTS, g.qe);
    return g;
}
static void testGameController() {
    { resetAll(); ImGui::g_t = 7000; World W; W.initRoster(8); W.addModel(u"id_a", u"ЧужойИгрок", u"КЛ", 5); W.addModel(u"id_loc", u"Я", u"", 1);
      const Gc g = mkGc(W);
      const uint64_t pm = W.mkPM(u"id_a", u"", u"Nickname", u"Nickname", false);       // у PM нет team: только контроллер игры может помочь
      const uint64_t loc = W.mkPM(u"id_loc", u"", u"Nickname", u"", false); g_localPlayer = loc;
      std::string n0 = ox_playerNick(pm);
      CHECK(n0.empty() && g_rosterStage == 1, "до klass список недоступен (этап %d, ник '%s')", g_rosterStage, n0.c_str());
      g_gcKlass.store(g.klass); ImGui::g_t += 3;
      bool fr = false; std::string n = ox_playerNick(pm, &fr), cl = ox_playerClan(pm);
      printf("  через контроллер игры: ник '%s' клан '%s' (этап gc=%d, источник '%s'), Qe=%s\n", n.c_str(), cl.c_str(), g_gcStage, g_rosterSrc, g_gcQe == g.qe ? "найден" : "нет");
      CHECK(n == "ЧужойИгрок" && cl == "КЛ" && fr && g_gcStage == 4 && g_gcRbk == W.rbk && g_gcQe == g.qe, "через контроллер игры"); }
    { resetAll(); ImGui::g_t = 7100; World W; W.initRoster(8); W.addModel(u"id_a", u"Zed", u"", 5);
      const Gc g = mkGc(W, 0x68);                                                      // смещение статики съехало: экземпляр на +0x68
      g_gcKlass.store(g.klass); ox_gcTick(ImGui::g_t);
      CHECK(g_gcStage == 4 && g_gcInst == g.inst && g_gcRbk == W.rbk, "поиск экземпляра рядом со смещением (этап %d)", g_gcStage);
      printf("  экземпляр не на +0x60, а на +0x68: найден поиском по статике\n"); }
    { resetAll(); ImGui::g_t = 7200; World W; W.initRoster(8); const Gc g = mkGc(W, ~0ULL);   // экземпляр не создан
      g_gcKlass.store(g.klass); ox_gcTick(ImGui::g_t); CHECK(g_gcStage == 2 && g_gcRbk == 0, "нет экземпляра (этап %d)", g_gcStage); }
    { resetAll(); ImGui::g_t = 7300; World W; W.initRoster(8); const Gc g = mkGc(W); put<uint64_t>(g.klass + ox::CLASS_STATIC_FIELDS, 0);
      g_gcKlass.store(g.klass); ox_gcTick(ImGui::g_t); CHECK(g_gcStage == 1, "нет static_fields (этап %d)", g_gcStage); }
    { resetAll(); ImGui::g_t = 7400; World W; W.initRoster(8); const Gc g = mkGc(W); put<int>(W.rbk + ox::RBK_MAX_PLAYERS, 0);   // «RBK» с мусорными числами
      g_gcKlass.store(g.klass); ox_gcTick(ImGui::g_t); CHECK(g_gcStage == 2 && g_gcRbk == 0, "неправдоподобный RBK отвергнут (этап %d)", g_gcStage); }
    { resetAll(); World W; W.initRoster(8); CHECK(!ox_looksLikeRbk(0) && !ox_looksLikeRbk(0x1234) && !ox_looksLikeRbk(alloc(0x200)) && ox_looksLikeRbk(W.rbk), "ox_looksLikeRbk");
      printf("  ox_looksLikeRbk: отвергает нули, мусор и случайные объекты\n"); }
    // RBK найден через указатель в RBY, даже если RBY.rUk пуст
    { resetAll(); ImGui::g_t = 7500; World W; W.initRoster(8); W.addModel(u"id_a", u"ViaRby", u"", 1);
      const uint64_t pm = W.mkPM(u"id_a", u"", u"", u"", true); g_localPlayer = pm;
      const uint64_t rby = rpm<uint64_t>(pm + ox::PM_TEAM); put<uint64_t>(rby + ox::RBY_TEAM_MANAGER, 0); put<uint64_t>(rby + 0x98, W.iz);   // iZ лежит в соседнем поле
      std::string n = ox_playerNick(pm); CHECK(n == "ViaRby" && std::string(g_rosterSrc) == "PM.team", "поиск iZ среди полей RBY: '%s' (%s)", n.c_str(), g_rosterSrc);
      printf("  RBY.rUk пуст, но iZ найден среди других полей RBY\n"); }
}

// Словарь Dictionary<string, PlayerModel> вместо массива: обе раскладки записи.
static void testDictionary() {
    struct L { int stride, keyOff; const char *name; } layouts[] = { { 0x40, 8, "запись 0x40, ключ +8" }, { 0x48, 0x10, "запись 0x48, ключ +0x10" } };
    for (const L &lay : layouts) {
        resetAll(); ImGui::g_t = 8000; World W; W.initRoster(4);                          // массив пуст: playerModels есть, записей нет
        put<uint64_t>(W.arr + ox::ARRAY_COUNT, 0);
        const uint64_t dict = alloc(0x80), entries = alloc(0x20 + 6 * (size_t)lay.stride);
        put<uint64_t>(dict + ox::DICT_ENTRIES, entries); put<int>(dict + ox::DICT_COUNT, 5); put<uint64_t>(entries + ox::ARRAY_COUNT, 6);
        put<uint64_t>(W.rbk + ox::RBK_PLAYER_DICT, dict); put<int>(W.rbk + ox::RBK_PLAYERS_COUNT, 4);
        const char16_t *ids[5] = { u"d_one", u"d_two", u"d_free", u"d_four", u"d_five" };
        const char16_t *nicks[5] = { u"Первый", u"Second", u"", u"Четвёртый", u"Fifth" };
        for (int i = 0; i < 5; ++i) {
            const uint64_t e = entries + ox::ARRAY_DATA + (uint64_t)i * lay.stride;
            if (i == 2) { put<int>(e, -1); put<int>(e + 4, -1); continue; }                // свободная запись
            put<int>(e, 1000 + i); put<int>(e + 4, -1);
            put<uint64_t>(e + lay.keyOff, mkStr(ids[i]));
            W.writeModel(e + lay.keyOff + 8, ids[i], nicks[i], i == 1 ? u"CL" : u"", 3 + i);
        }
        const uint64_t pm1 = W.mkPM(u"d_one", u"", u"Nickname", u"", true), pm5 = W.mkPM(u"d_five", u"", u"Nickname", u"", true), pm2 = W.mkPM(u"d_two", u"", u"", u"", true);
        g_localPlayer = pm1; ImGui::g_t += 5;
        const std::string a = ox_playerNick(pm1), b = ox_playerNick(pm5), c = ox_playerClan(pm2);
        printf("  словарь (%s): '%s' '%s' клан '%s', раскладка определена: шаг 0x%x ключ +0x%x\n", lay.name, a.c_str(), b.c_str(), c.c_str(), g_dictLayout.stride, g_dictLayout.keyOff);
        CHECK(a == "Первый" && b == "Fifth" && c == "CL", "словарь %s", lay.name);
        CHECK(g_dictLayout.stride == lay.stride && g_dictLayout.keyOff == lay.keyOff, "раскладка словаря %s", lay.name);
    }
    // мусор вместо словаря: ничего не принимается
    { resetAll(); ImGui::g_t = 8100; World W; W.initRoster(4); put<uint64_t>(W.arr + ox::ARRAY_COUNT, 0);
      const uint64_t dict = alloc(0x80), entries = alloc(0x20 + 0x400); put<uint64_t>(dict + ox::DICT_ENTRIES, entries); put<int>(dict + ox::DICT_COUNT, 6); put<uint64_t>(entries + ox::ARRAY_COUNT, 8);
      for (int i = 0; i < 0x400 / 8; ++i) put<uint64_t>(entries + 0x20 + i * 8, 0x7123456780ULL + i);
      put<uint64_t>(W.rbk + ox::RBK_PLAYER_DICT, dict);
      CHECK(ox_rosterReadDict(W.rbk, nullptr) == 0 && g_dictLayout.stride == 0, "мусорный словарь отвергнут"); }
}

// Подпись над головой — одинаковая у разных игроков (заготовка): отбрасывается без списка слов.
static void testDedupe() {
    std::vector<PlayerCacheData> v(7);
    const char *names[7] = { "Nickname", "nickname", "RealLabel", "FromServer", "FromServer", "Дубль", "Дубль" };
    for (int i = 0; i < 7; ++i) { v[i].address = 0x1000 + i; v[i].name = names[i]; }
    v[3].nameFromRoster = v[4].nameFromRoster = true;                                   // одинаковые, но от сервера — оставить
    ox_dropDuplicateNicks(v);
    printf("  одинаковые подписи: [%s] [%s] [%s] [%s] [%s] [%s] [%s]\n", v[0].name.c_str(), v[1].name.c_str(), v[2].name.c_str(), v[3].name.c_str(), v[4].name.c_str(), v[5].name.c_str(), v[6].name.c_str());
    CHECK(v[0].name.empty() && v[1].name.empty() && v[5].name.empty() && v[6].name.empty(), "одинаковые подписи не очищены");
    CHECK(v[2].name == "RealLabel" && v[3].name == "FromServer" && v[4].name == "FromServer", "уникальные и серверные имена должны остаться");
}

// ═══════════════ 2. живое HP (реальная пара float) ═══════════════
static float stepHp(uint64_t pm, float a, float b, double &t) {
    setHealth(pm, a, b); t += 1.0 / 60.0; ImGui::g_t = t;
    PlayerCacheData pc; const bool ok = ox_readHpLive(pm, pc);
    return ok ? pc.hpNow : -999.f;
}
static void testHpPair() {
    for (int path = 0; path < 3; ++path) {
        resetAll(); World W; double t = 3000.0 + path * 100; ImGui::g_t = t;
        const uint64_t pm = W.mkPM(u"x", u"", u"", u"", false);
        if (path > 0) {                                   // Rys доступен только через vitals
            const uint64_t rys = rysOf(pm), vit = rpm<uint64_t>(pm + ox::PM_VITALS);
            put<uint64_t>(pm + ox::PM_EVENT_HANDLER, 0);
            put<uint64_t>(vit + (path == 1 ? ox::VITALS_PLAYER_EVENT : ox::VITALS_ENTITY), rys);
        }
        PlayerCacheData pc; const bool ok = ox_readHpLive(pm, pc);
        printf("  путь %d (%s): ok=%d hp=%.0f max=%.0f\n", path, g_hpPathName, ok, pc.hpNow, pc.hpMax);
        CHECK(ok && pc.hpNow == 100.f && pc.hpMax == 100.f, "путь %d не найден", path);
    }
    { resetAll(); World W; double t = 3500; ImGui::g_t = t; const uint64_t pm = W.mkPM(u"x", u"", u"", u"", false); float g[6];
      stepHp(pm, 100, 100, t); g[0] = stepHp(pm, 80, 100, t); g[1] = stepHp(pm, 60, 80, t); g[2] = stepHp(pm, 45, 60, t); g[3] = stepHp(pm, 45, 60, t); g[4] = stepHp(pm, 100, 45, t); g[5] = stepHp(pm, 0, 100, t);
      const float w[6] = { 80, 60, 45, 45, 100, 0 }; for (int i = 0; i < 6; ++i) CHECK(g[i] == w[i], "пара (текущее, прежнее) шаг %d: %.0f vs %.0f", i, g[i], w[i]); }
    { resetAll(); World W; double t = 3600; ImGui::g_t = t; const uint64_t pm = W.mkPM(u"x", u"", u"", u"", false); float g[6];
      stepHp(pm, 100, 100, t); g[0] = stepHp(pm, 100, 80, t); g[1] = stepHp(pm, 80, 60, t); g[2] = stepHp(pm, 60, 45, t); g[3] = stepHp(pm, 60, 45, t); g[4] = stepHp(pm, 45, 100, t); g[5] = stepHp(pm, 100, 0, t);
      const float w[6] = { 80, 60, 45, 45, 100, 0 }; for (int i = 0; i < 6; ++i) CHECK(g[i] == w[i], "пара (прежнее, текущее) шаг %d: %.0f vs %.0f", i, g[i], w[i]); }
    { resetAll(); World W; double t = 3700; ImGui::g_t = t; const uint64_t pm = W.mkPM(u"x", u"", u"", u"", false);
      stepHp(pm, 90, 90, t); const float b1 = stepHp(pm, NAN, NAN, t), b2 = stepHp(pm, 1e9f, 1e9f, t); t += 2.5; stepHp(pm, 55, 55, t); t += 2.5; const float ok2 = stepHp(pm, 55, 55, t);
      printf("  мусор: NaN->%.0f 1e9->%.0f  после починки ->%.0f\n", b1, b2, ok2);
      CHECK(b1 == -999.f && b2 == -999.f && ok2 == 55.f, "мусор в HP"); }
    { resetAll(); World W; double t = 3800; ImGui::g_t = t; const uint64_t pm = W.mkPM(u"x", u"", u"", u"", false);
      stepHp(pm, 80, 80, t); put<uint64_t>(rysOf(pm) + ox::RYS_MANAGER, 0x7999999999ULL); t += 1.5; const float r = stepHp(pm, 80, 80, t);
      CHECK(r == -999.f, "чужой Rys принят"); }
    { resetAll(); World W; double t = 3900; ImGui::g_t = t; const uint64_t pm = W.mkPM(u"x", u"", u"", u"", false);
      put<float>(rpm<uint64_t>(pm + ox::PM_VITALS) + ox::VITALS_HEALTH, 150.f); PlayerCacheData pc; ox_readHpLive(pm, pc); CHECK(pc.hpMax == 150.f, "максимум из vitals"); }
    { resetAll(); World W; double t = 4000; ImGui::g_t = t; const uint64_t pm = W.mkPM(u"x", u"", u"", u"", false); stepHp(pm, 100, 100, t);
      long used = 0;
      for (int i = 0; i < 60; ++i) { setHealth(pm, 100, 100); t += 1.0 / 60.0; ImGui::g_t = t; PlayerCacheData pc; const long c0 = g_calls; ox_readHpLive(pm, pc); used += g_calls - c0; }
      printf("  установившийся режим: %.2f обращений к памяти на игрока за кадр\n", (double)used / 60.0); CHECK((double)used / 60.0 < 1.5, "слишком много чтений"); }
}

// ═══════════════ 3. попадания локального игрока и оценка урона ═══════════════
struct Fight {
    World W; uint64_t local = 0, rys = 0, tObj = 0, pObj = 0, aObj = 0, ryt = 0, eqObj = 0, wrap = 0;
    uint64_t fp[3] = { 0, 0, 0 }; uint64_t cfg[3] = { 0, 0, 0 };
    double t = 5000;
    std::vector<PlayerCacheData> players;
    int timeScheme = 0, pointScheme = 0;       // 0: (текущее, прежнее)   1: (прежнее, текущее)
    float prevTime = 10.f; float prevPt[3] = { 0, 0, 0 };

    void cfgInit(uint64_t c, float damage) { put<float>(c + ox::HSCFG_DAMAGE, damage); put<float>(c + ox::HSCFG_MAX_DISTANCE, 150.f); put<float>(c + ox::HSCFG_FIRE_RATE, 10.f); put<int>(c + ox::HSCFG_PELLETS, 1); }
    void init(float dmgA = 35.f, float dmgB = 22.f, float dmgC = 80.f) {
        resetAll(); ImGui::g_t = t;
        W.initRoster(8);
        local = W.mkPM(u"loc", u"", u"", u"", true); g_localPlayer = local;
        rys = rysOf(local);
        tObj = alloc(0x40); pObj = alloc(0x60); aObj = alloc(0x40); ryt = alloc(0x80); eqObj = alloc(0x40);
        put<uint64_t>(rys + ox::RYS_LAST_HIT_TIME, tObj); put<uint64_t>(rys + ox::RYS_LAST_HIT_POINT, pObj); put<uint64_t>(rys + ox::RYS_AIM_RAYCAST, aObj); put<uint64_t>(rys + ox::RYS_EQUIPPED_ITEM, eqObj);
        put<float>(tObj + ox::RYR_VALUE_A, 10.f); put<float>(tObj + 0x24, 10.f);
        // оружие: три FP-объекта разных классов (смещения конфига различаются), активный — второй
        const uint64_t arr = alloc(0x20 + 8 * 3); put<uint64_t>(arr + ox::ARRAY_COUNT, 3); put<uint64_t>(local + ox::PM_WEAPONS, arr);
        const uint64_t offs[3] = { ox::FPHITSCAN_CONFIG, ox::FPCROSSBOW_CONFIG, ox::FPROCKET_CONFIG };
        const float dm[3] = { dmgA, dmgB, dmgC };
        for (int i = 0; i < 3; ++i) {
            fp[i] = alloc(0x400); cfg[i] = alloc(0x100);
            put<uint64_t>(arr + ox::ARRAY_DATA + 8 * i, fp[i]);
            put<uint64_t>(fp[i] + ox::FPOBJECT_PLAYER, local); put<uint64_t>(fp[i] + ox::FPOBJECT_ITEM, alloc(0x40));
            put<uint64_t>(fp[i] + offs[i], cfg[i]); cfgInit(cfg[i], dm[i]);
        }
        wrap = alloc(0x80); put<uint64_t>(local + ox::PM_WEAPON_REF, wrap); put<uint64_t>(wrap + 0x10, fp[1]);   // активное: FPCrossbow (урон dmgB)
    }
    uint64_t addPlayer(float x, float z) {
        const uint64_t pm = W.mkPM(u"p", u"", u"", u"", true);
        PlayerCacheData pc; pc.address = pm; pc.position = Vector3(x, 0.f, z); pc.hpNow = 100.f; players.push_back(pc);
        return pm;
    }
    void aim(uint64_t pm) {
        if (!pm) { put<uint64_t>(aObj + 0x20, 0); put<uint64_t>(aObj + 0x28, 0); return; }
        put<uint64_t>(ryt + ox::RYT_PLAYER, pm); put<uint64_t>(aObj + 0x20, ryt); put<uint64_t>(aObj + 0x28, ryt);
    }
    void frame() { t += 1.0 / 60.0; ImGui::g_t = t; ox_hitUpdate(players, t); }
    // Одно попадание: время растёт, точка меняется (разные схемы хранения пары значений).
    void hit(float x, float y, float z, float dt = 0.4f) {
        for (int i = 0; i < 3; ++i) frame();
        const float nt = prevTime + dt;
        if (timeScheme == 0) { put<float>(tObj + 0x20, nt); put<float>(tObj + 0x24, prevTime); } else { put<float>(tObj + 0x20, prevTime); put<float>(tObj + 0x24, nt); }
        float pt[3] = { x, y, z };
        if (pointScheme == 0) { memcpy(at(pObj + 0x20, 12), pt, 12); memcpy(at(pObj + 0x2C, 12), prevPt, 12); }
        else { memcpy(at(pObj + 0x20, 12), prevPt, 12); memcpy(at(pObj + 0x2C, 12), pt, 12); }
        prevTime = nt; memcpy(prevPt, pt, 12);
        frame();
    }
    float hp(uint64_t pm) { PlayerCacheData pc; t += 1.0 / 60.0; ImGui::g_t = t; return ox_readHpLive(pm, pc) ? pc.hpNow : -999.f; }
};

static void testHits() {
    for (int scheme = 0; scheme < 2; ++scheme) {
        Fight F; F.timeScheme = F.pointScheme = scheme; F.init();
        const uint64_t a = F.addPlayer(10, 0), b = F.addPlayer(30, 0);
        F.frame(); F.frame();
        CHECK(F.hp(a) == 100.f && F.hp(b) == 100.f, "без попаданий HP полное");
        F.hit(10.1f, 1.0f, 0.0f);                              // тело игрока A, оружие в руках — арбалет (22)
        float ha = F.hp(a);
        printf("  [схема %d] тело: A=%.0f (ожидал 78: урон конфига активного оружия 22)\n", scheme, ha);
        CHECK(ha == 78.f && F.hp(b) == 100.f, "урон по телу");
        F.hit(9.9f, 1.75f, 0.0f);                              // голова: 22 * 2
        ha = F.hp(a);
        printf("  [схема %d] голова: A=%.0f (ожидал 34)\n", scheme, ha);
        CHECK(ha == 34.f, "урон по голове");
        F.hit(60.0f, 0.0f, 5.0f);                              // мимо игроков (земля вдали)
        CHECK(F.hp(a) == 34.f && F.hp(b) == 100.f && g_hit.misses == 1, "попадание не по игроку проигнорировано (misses=%d)", g_hit.misses);
        F.hit(30.2f, 0.9f, 0.1f);                              // игрок B
        CHECK(F.hp(b) == 78.f && F.hp(a) == 34.f, "ближайший игрок: B=%.0f", F.hp(b));
        F.aim(b); F.hit(31.8f, 1.0f, 0.0f);                    // точка в 1.8 м от B (дальше метра), но B под прицелом
        CHECK(F.hp(b) == 56.f, "игрок под прицелом, точка рядом: B=%.0f", F.hp(b));
        const float aBefore = F.hp(a);
        F.hit(10.2f, 1.0f, 0.0f);                              // B всё ещё под прицелом, но точка в 20 м от него и на теле A
        CHECK(F.hp(a) == aBefore - 22.f && F.hp(b) == 56.f, "точка на другом игроке важнее прицела: A=%.0f B=%.0f", F.hp(a), F.hp(b));
        F.aim(0);
        F.hit(10, 1.0f, 0); F.hit(10, 1.0f, 0); F.hit(10, 1.0f, 0);
        const float low = F.hp(a);
        printf("  [схема %d] после серии A=%.1f (жив по данным игры -> не ниже 3%%)\n", scheme, low);
        CHECK(low > 0.f && low <= 4.f, "нижний предел оценки: %.2f", low);
        setHealth(a, 0, 0);                                    // игра сообщила о смерти
        CHECK(F.hp(a) == 0.f, "смерть -> 0");
        F.hit(10, 1.0f, 0); CHECK(F.hp(a) == 0.f, "мёртвого не бьём");
        setHealth(a, 100, 100);                                // воскрес
        CHECK(F.hp(a) == 100.f, "воскрес -> оценка сброшена: %.0f", F.hp(a));
        F.hit(30, 1.0f, 0); const float bb = F.hp(b); setHealth(b, 20, 20); CHECK(F.hp(b) == 20.f, "реальное HP ниже оценки (%.0f -> %.0f)", bb, F.hp(b));
        F.hit(30, 1.0f, 0); CHECK(F.hp(b) <= 4.f, "дальше от реального: %.1f", F.hp(b));
    }
}

static void testWeaponDamage() {
    Fight F; F.init(35.f, 22.f, 80.f);
    const uint64_t a = F.addPlayer(10, 0); F.frame(); F.frame();
    CHECK(ox_weaponDamage(F.local, 6000.0) == 22.f, "weaponReference (обёртка): %.1f", ox_weaponDamage(F.local, 6000.0));
    put<uint64_t>(F.wrap + 0x10, F.fp[0]); CHECK(ox_weaponDamage(F.local, 6001.0) == 35.f, "смена оружия (FPHitscan)");
    put<uint64_t>(F.wrap + 0x10, F.fp[2]); CHECK(ox_weaponDamage(F.local, 6002.0) == 80.f, "ракетница по смещению 0x128");
    put<uint64_t>(F.local + ox::PM_WEAPON_REF, F.fp[0]); CHECK(ox_weaponDamage(F.local, 6003.0) == 35.f, "weaponReference указывает прямо на оружие");
    put<uint64_t>(F.local + ox::PM_WEAPON_REF, 0);
    const uint64_t item1 = rpm<uint64_t>(F.fp[1] + ox::FPOBJECT_ITEM); put<uint64_t>(F.eqObj + 0x20, 0x7777000000ULL); put<uint64_t>(F.eqObj + 0x28, item1);
    CHECK(ox_weaponDamage(F.local, 6004.0) == 22.f, "запасной путь по EquippedItem");
    put<uint64_t>(F.eqObj + 0x28, 0);
    CHECK(ox_weaponDamage(F.local, 6005.0) == 0.f, "оружие не определено");
    F.hit(10.1f, 1.0f, 0.f); CHECK(F.hp(a) == 70.f, "урон по умолчанию 30: %.0f", F.hp(a));
    esphpdamage = 12.f; F.hit(10.1f, 1.0f, 0.f); CHECK(F.hp(a) == 58.f, "ручной урон 12: %.0f", F.hp(a));
    esphpcrit = 3.0f; F.hit(10.0f, 1.8f, 0.f); CHECK(F.hp(a) == 22.f, "множитель головы 3: %.0f", F.hp(a));
    put<uint64_t>(F.local + ox::PM_WEAPON_REF, F.fp[1]); put<float>(F.cfg[1] + ox::HSCFG_FIRE_RATE, -3.f);
    CHECK(ox_weaponDamage(F.local, 6006.0) == 0.f, "невалидный конфиг отвергнут");
    printf("  урон оружия: обёртка, прямой указатель, 3 класса оружия, EquippedItem, ручной, по умолчанию — проверено\n");
}

static void testHitRobustness() {
    Fight F; F.init(); const uint64_t a = F.addPlayer(10, 0); F.frame(); F.frame();
    F.prevTime = 3.f; put<float>(F.tObj + 0x20, 3.f); put<float>(F.tObj + 0x24, 3.f); F.frame();
    CHECK(F.hp(a) == 100.f, "сброс времени игнорируется");
    F.frame(); put<float>(F.tObj + 0x20, NAN); F.frame(); put<float>(F.tObj + 0x20, 3.f); F.frame();
    CHECK(F.hp(a) == 100.f, "NaN игнорируется");
    g_hit = OxHitWatch(); put<uint64_t>(F.rys + ox::RYS_MANAGER, 0x7123123123ULL); F.t += 5; F.frame();
    CHECK(g_hit.timeObj == 0, "чужой Rys отвергнут");
    put<uint64_t>(F.rys + ox::RYS_MANAGER, F.local); F.t += 5; F.frame(); CHECK(g_hit.timeObj != 0, "слежение включилось");
    put<uint64_t>(F.rys + ox::RYS_LAST_HIT_POINT, 0); g_hit = OxHitWatch(); F.t += 5; F.frame(); F.aim(a); F.frame();
    put<float>(F.tObj + 0x20, 4.f); put<float>(F.tObj + 0x24, 3.f); F.frame(); F.frame();
    CHECK(F.hp(a) == 78.f, "без точки, но под прицелом: %.0f", F.hp(a));
    // устаревшие оценки удаляются (через 2 минуты без обращений)
    const uint64_t other = F.addPlayer(50, 50);
    ImGui::g_t += 200; PlayerCacheData pc; ox_readHpLive(other, pc);
    CHECK(g_hpEst.find(a) == g_hpEst.end(), "устаревшая оценка не удалена");
    Fight G; G.init(); G.addPlayer(10, 0); G.frame(); G.frame(); g_calls = 0; for (int i = 0; i < 60; ++i) G.frame();
    printf("  слежение без событий: %.2f обращений к памяти за кадр\n", (double)g_calls / 60.0);
    CHECK((double)g_calls / 60.0 <= 2.01, "слишком много чтений за кадр");
}

// Регенерация: без урона 20 с, дальше +0.5 HP/с. Оценка не «залипает» навсегда.
static void testRegen() {
    resetAll(); World W; double t = 9000; ImGui::g_t = t; const uint64_t pm = W.mkPM(u"x", u"", u"", u"", false);
    PlayerCacheData pc; ox_readHpLive(pm, pc);                                         // создаём состояние HP
    ox_applyDamage(pm, 40.f, t);
    float at20 = 0, at30 = 0, at200 = 0;
    for (int s = 1; s <= 200; ++s) {
        t += 1.0; ImGui::g_t = t; setHealth(pm, 100, 100);
        PlayerCacheData p; ox_readHpLive(pm, p);
        if (s == 20) at20 = p.hpNow; if (s == 30) at30 = p.hpNow; if (s == 200) at200 = p.hpNow;
    }
    printf("  регенерация: через 20 с %.1f, через 30 с %.1f, через 200 с %.1f (урон был 40 из 100)\n", at20, at30, at200);
    CHECK(at20 == 60.f && at30 > 64.f && at30 < 66.f && at200 == 100.f, "регенерация");
    // новый урон останавливает регенерацию
    ox_applyDamage(pm, 10.f, t); t += 5; ImGui::g_t = t; PlayerCacheData p; setHealth(pm, 100, 100); ox_readHpLive(pm, p);
    CHECK(p.hpNow == 90.f, "после нового урона регенерация не идёт сразу: %.1f", p.hpNow);
}

// ═══════════════ 4. выстрелы других игроков (менеджер пуль) ═══════════════
struct Ballistics {
    World W; uint64_t local = 0, shooter = 0, weapon = 0, cfg = 0, qe = 0, list = 0, items = 0;
    std::vector<PlayerCacheData> players;
    std::vector<uint64_t> qrs;
    double t = 12000; float dt = 1.f / 60.f;
    static constexpr uint32_t kLocalNet = 11, kShooterNet = 22;

    uint64_t addTarget(float x, float z, bool anchors = true) {
        const uint64_t pm = W.mkPM(u"t", u"", u"", u"", false, 100 + (uint32_t)players.size());
        PlayerCacheData pc; pc.address = pm; pc.position = Vector3(x, 1.6f, z); pc.hpNow = 100.f;
        if (anchors) { pc.usedModelAnchor = true; pc.anchorFeet = Vector3(x, 0.f, z); pc.anchorHead = Vector3(x, 1.7f, z); }
        players.push_back(pc);
        return pm;
    }
    void init(float damage = 22.f) {
        resetAll(); ImGui::g_t = t;
        W.initRoster(4);
        local = W.mkPM(u"loc", u"", u"", u"", false, kLocalNet); g_localPlayer = local;
        shooter = W.mkPM(u"shooter", u"", u"", u"", false, kShooterNet);
        PlayerCacheData sp; sp.address = shooter; sp.position = Vector3(0, 1.6f, 0); sp.usedModelAnchor = true; sp.anchorFeet = Vector3(0, 0, 0); sp.anchorHead = Vector3(0, 1.7f, 0);
        players.push_back(sp);
        weapon = alloc(0x400); cfg = alloc(0x100);
        put<uint64_t>(weapon + ox::FPOBJECT_PLAYER, shooter); put<uint64_t>(weapon + ox::FPHITSCAN_CONFIG, cfg);
        put<float>(cfg + ox::HSCFG_DAMAGE, damage); put<float>(cfg + ox::HSCFG_MAX_DISTANCE, 150.f); put<float>(cfg + ox::HSCFG_FIRE_RATE, 10.f); put<int>(cfg + ox::HSCFG_PELLETS, 1);
        qe = alloc(0x100); list = alloc(0x40); items = alloc(0x20 + 8 * 96);
        put<uint64_t>(qe + ox::QE_BULLETS, list); put<uint64_t>(list + ox::LIST_ITEMS, items); put<uint64_t>(items + ox::ARRAY_COUNT, 96);
        g_gcQe = qe;
    }
    uint64_t newQr() { const uint64_t q = alloc(ox::QR_SIZE + 0x20); qrs.push_back(q); return q; }
    void setQr(uint64_t q, const float pos[3], const float vel[3], uint32_t owner, int shot, uint64_t ownerObj, int kind = 0) {
        memcpy(at(q + ox::QR_STATE_POS, 12), pos, 12); memcpy(at(q + ox::QR_STATE_VEL, 12), vel, 12);
        put<uint32_t>(q + ox::QR_OWNER_ID, owner); put<int>(q + ox::QR_SHOT_ID, shot); put<int>(q + ox::QR_KIND, kind); put<uint64_t>(q + ox::QR_OWNER_OBJ, ownerObj);
    }
    void publish(const std::vector<uint64_t> &live) {
        put<int>(list + ox::LIST_SIZE, (int)live.size());
        for (size_t i = 0; i < live.size(); ++i) put<uint64_t>(items + ox::ARRAY_DATA + 8 * i, live[i]);
    }
    void tick() { t += dt; ImGui::g_t = t; ox_ballisticUpdate(players, t, dt); }
    // Пуля летит вдоль +X со скоростью 300 м/с на высоте y (и смещении z), пока не достигнет xEnd; после этого пропадает из списка.
    void fly(float y, float z, float xEnd, uint32_t owner, int shot, uint64_t ownerObj = 0, float speed = 300.f) {
        const uint64_t q = newQr();
        float x = 2.f;
        const float vel[3] = { speed, 0, 0 };
        while (x < xEnd) {
            const float pos[3] = { x, y, z };
            setQr(q, pos, vel, owner, shot, ownerObj ? ownerObj : weapon);
            publish({ q });
            tick();
            x += speed * dt;
        }
        publish({});
        tick(); tick();
    }
    float hp(uint64_t pm) { PlayerCacheData pc; t += dt; ImGui::g_t = t; return ox_readHpLive(pm, pc) ? pc.hpNow : -999.f; }
};

static void testBallistics() {
    { Ballistics B; B.init(22.f); const uint64_t tg = B.addTarget(60, 0);
      B.fly(1.2f, 0.f, 59.f, Ballistics::kShooterNet, 1);
      printf("  пуля в тело: цель %.0f из 100 (урон оружия стрелка 22), выстрелов %d, попаданий %d\n", B.hp(tg), g_shotsSeen, g_shotHits);
      CHECK(B.hp(tg) == 78.f && g_shotsSeen == 1 && g_shotHits == 1, "пуля в тело"); }
    { Ballistics B; B.init(22.f); const uint64_t tg = B.addTarget(60, 0);
      B.fly(1.62f, 0.f, 59.f, Ballistics::kShooterNet, 1);
      CHECK(B.hp(tg) == 56.f, "в голову x2: %.0f", B.hp(tg)); printf("  пуля в голову: цель %.0f (22 x 2)\n", B.hp(tg)); }
    { Ballistics B; B.init(); const uint64_t tg = B.addTarget(60, 0);
      B.fly(1.2f, 3.0f, 59.f, Ballistics::kShooterNet, 1);
      CHECK(B.hp(tg) == 100.f && g_shotHits == 0, "мимо на 3 м: %.0f", B.hp(tg)); }
    { Ballistics B; B.init(); const uint64_t tg = B.addTarget(60, 0);
      B.fly(1.2f, 0.f, 30.f, Ballistics::kShooterNet, 1);                      // пуля пропала на полпути (стена)
      CHECK(B.hp(tg) == 100.f, "пуля пропала до цели: %.0f", B.hp(tg)); printf("  пуля пропала на полпути (стена): урона нет\n"); }
    { Ballistics B; B.init(); const uint64_t tg = B.addTarget(60, 0);
      B.fly(1.2f, 0.f, 120.f, Ballistics::kShooterNet, 1);                     // пролетела сквозь и дальше
      CHECK(B.hp(tg) == 78.f, "пуля прошла через цель: %.0f", B.hp(tg)); }
    { Ballistics B; B.init(); const uint64_t t1 = B.addTarget(40, 0), t2 = B.addTarget(70, 0);
      B.fly(1.2f, 0.f, 39.f, Ballistics::kShooterNet, 1);                      // ближняя цель закрывает дальнюю
      B.fly(1.2f, 0.f, 69.f, Ballistics::kShooterNet, 2);
      const float a = B.hp(t1), b = B.hp(t2); printf("  две цели: ближняя %.0f, дальняя %.0f\n", a, b);
      CHECK(a == 56.f && b == 78.f, "две цели: %.0f %.0f", a, b); }
    { Ballistics B; B.init(); const uint64_t tg = B.addTarget(60, 0);
      B.fly(1.2f, 0.f, 59.f, 99999, 1);                                       // netId владельца неизвестен, стрелок определяется по оружию (FPObject.Player)
      CHECK(B.hp(tg) == 78.f, "стрелок по оружию: %.0f", B.hp(tg)); }
    { Ballistics B; B.init(); const uint64_t tg = B.addTarget(60, 0);
      B.fly(1.2f, 0.f, 59.f, 99999, 1, B.local ? 0x7123456780ULL : 0);        // и netId неизвестен, и оружие не читается
      CHECK(B.hp(tg) == 100.f, "стрелок неизвестен -> без урона: %.0f", B.hp(tg)); }
    { Ballistics B; B.init(); const uint64_t tg = B.addTarget(60, 0);          // стрелок — локальный игрок
      put<uint64_t>(B.weapon + ox::FPOBJECT_PLAYER, B.local); g_hit.timeObj = 0x7000000000ULL;
      B.fly(1.2f, 0.f, 59.f, Ballistics::kLocalNet, 1);
      CHECK(B.hp(tg) == 100.f, "свои выстрелы при работающем детекторе попаданий не дублируются: %.0f", B.hp(tg));
      g_hit.timeObj = 0; B.fly(1.2f, 0.f, 59.f, Ballistics::kLocalNet, 2);
      CHECK(B.hp(tg) == 78.f, "без детектора попаданий свои пули считаются: %.0f", B.hp(tg)); }
    { Ballistics B; B.init(); const uint64_t tg = B.addTarget(60, 0); esphpdamage = 15.f;                  // ручной урон приоритетнее оружия
      B.fly(1.2f, 0.f, 59.f, Ballistics::kShooterNet, 1);
      CHECK(B.hp(tg) == 85.f, "ручной урон: %.0f", B.hp(tg)); }
    { Ballistics B; B.init(0.f); const uint64_t tg = B.addTarget(60, 0); put<float>(B.cfg + ox::HSCFG_DAMAGE, 0.f);   // конфиг не читается -> урон по умолчанию 30
      B.fly(1.2f, 0.f, 59.f, Ballistics::kShooterNet, 1);
      CHECK(B.hp(tg) == 70.f, "урон по умолчанию 30: %.0f", B.hp(tg)); }
    { Ballistics B; B.init(); const uint64_t tg = B.addTarget(0.5f, 0);       // цель вплотную к стрелку
      B.fly(1.2f, 0.f, 6.f, Ballistics::kShooterNet, 1);
      CHECK(B.hp(tg) == 78.f, "вплотную: %.0f", B.hp(tg)); }
    { Ballistics B; B.init(); const uint64_t tg = B.addTarget(60, 0);          // пуля из пула: тот же объект Qr под новой пулей без паузы
      const uint64_t q = B.newQr(); const float v[3] = { 300, 0, 0 };
      for (float x = 2; x < 59; x += 5) { const float p[3] = { x, 1.2f, 0 }; B.setQr(q, p, v, Ballistics::kShooterNet, 1, B.weapon); B.publish({ q }); B.tick(); }
      const float p2[3] = { 100, 1.2f, 40 }; B.setQr(q, p2, v, Ballistics::kShooterNet, 2, B.weapon); B.publish({ q }); B.tick();                  // новая пуля в том же объекте
      B.publish({}); B.tick(); B.tick();
      CHECK(B.hp(tg) == 78.f && g_shotsSeen == 2, "объект из пула: цель %.0f, выстрелов %d", B.hp(tg), g_shotsSeen); }
    { Ballistics B; B.init(); const uint64_t tg = B.addTarget(60, 0);          // мусор: NaN, нулевая скорость, гигантские координаты
      const uint64_t q = B.newQr(); const float good[3] = { 2, 1.2f, 0 }; const float nanv[3] = { NAN, 0, 0 }, slow[3] = { 3, 0, 0 }, big[3] = { 1e9f, 0, 0 };
      const float vel[3] = { 300, 0, 0 };
      B.setQr(q, good, nanv, 22, 1, B.weapon); B.publish({ q }); B.tick();
      B.setQr(q, good, slow, 22, 1, B.weapon); B.publish({ q }); B.tick();
      B.setQr(q, big, vel, 22, 1, B.weapon); B.publish({ q }); B.tick();
      B.publish({}); B.tick();
      CHECK(B.hp(tg) == 100.f && g_bulletBad == 3 && g_shotsSeen == 0, "мусор отвергнут (плохих %d)", g_bulletBad); printf("  мусорные пули (NaN, нулевая скорость, гигантские координаты) отвергнуты\n"); }
    { Ballistics B; B.init(); B.addTarget(60, 0); put<int>(B.list + ox::LIST_SIZE, 100000); B.tick();
      CHECK(std::string(g_bulletState) == "размер списка пуль неверен", "мусорный размер списка (%s)", g_bulletState); }
    { Ballistics B; B.init(); B.addTarget(60, 0); g_gcQe = 0; B.tick(); CHECK(std::string(g_bulletState) == "нет менеджера пуль", "нет Qe (%s)", g_bulletState); }
    { Ballistics B; B.init(); const uint64_t tg = B.addTarget(60, 0);          // цель уже мертва по данным игры: добивать нечем
      setHealth(tg, 0, 0); PlayerCacheData pc; ImGui::g_t += 1; ox_readHpLive(tg, pc);
      B.fly(1.2f, 0.f, 59.f, Ballistics::kShooterNet, 1);
      CHECK(B.hp(tg) == 0.f, "мёртвая цель остаётся мёртвой: %.0f", B.hp(tg)); }
    { Ballistics B; B.init(); const uint64_t tg = B.addTarget(60, 0);          // серия: 5 пуль подряд, оценка не падает ниже предела
      for (int i = 0; i < 5; ++i) B.fly(1.2f, 0.f, 59.f, Ballistics::kShooterNet, 10 + i);
      const float hp = B.hp(tg); printf("  серия из 5 попаданий по 22: цель %.1f (оценка не ниже 3%%)\n", hp);
      CHECK(hp > 0.f && hp <= 4.f && g_shotHits == 5, "серия: %.1f, попаданий %d", hp, g_shotHits); }
    { Ballistics B; B.init(); B.addTarget(60, 0); long used = 0;               // стоимость при пустом списке пуль
      for (int i = 0; i < 60; ++i) { const long c0 = g_calls; B.tick(); used += g_calls - c0; }
      printf("  пустой список пуль: %.2f обращений к памяти за кадр\n", (double)used / 60.0); CHECK((double)used / 60.0 <= 3.1, "слишком много чтений"); }
}

static void testStatus() {
    resetAll(); World W; W.initRoster(4); W.addModel(u"a", u"A", u"", 1); W.addModel(u"b", u"B", u"", 1);
    std::vector<PlayerCacheData> v(3); v[0].name = "A"; v[1].name = "B";
    g_rbk = W.rbk; g_roster["a"] = {}; g_roster["b"] = {}; g_gcQe = 0x7000000000ULL; g_shotsSeen = 7; g_shotHits = 3; g_hit.events = 2;
    ox_statusUpdate(v, 100.0);
    printf("  состояние: [%s]\n", g_espStatus.c_str());
    CHECK(g_espStatus == "Nick: list 2, shown 2/3\nHP: shots 7, hits 3 (mine 2)", "строка состояния");
    resetAll(); g_rosterStage = 2; g_gcStage = 1; ox_statusUpdate(v, 200.0);
    CHECK(g_espStatus == "Nick: no list (st 2, gc 1)\nHP: no bullets (gc 1), mine 0", "строка состояния без списка");
}

int main() {
    printf("1. ники и клан\n"); testUtf8(); testNicks(); testNickFailures(); testGameController(); testDictionary(); testDedupe();
    printf("2. живое HP\n"); testHpPair();
    printf("3. попадания локального игрока\n"); testHits(); testWeaponDamage(); testHitRobustness(); testRegen();
    printf("4. выстрелы других игроков\n"); testBallistics(); testStatus();
    printf(fails ? "\n%d FAILED\n" : "\nALL PASSED\n", fails);
    return fails ? 1 : 0;
}
