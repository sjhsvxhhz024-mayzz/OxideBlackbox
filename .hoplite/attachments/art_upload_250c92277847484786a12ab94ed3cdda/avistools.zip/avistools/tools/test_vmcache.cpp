// Хост-тест кэша чтений: g++ -std=c++17 -O1 -Wall -Iinclude -Iinclude/ImGui -Isrc tools/test_vmcache.cpp src/memory.cpp -o /tmp/t && /tmp/t
// «Игра» здесь — сам тестовый процесс (game_pid = getpid()): проверяется настоящий process_vm_readv, а не подмена.
#include "memory.h"
#include <sys/mman.h>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <csignal>
#include <sys/wait.h>
#include <thread>
#include <vector>

int game_pid = -1;
uint64_t il2cpp_base = 0;
int abs_ScreenX = 0, abs_ScreenY = 0;

static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { ++fails; printf("FAIL line %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

int main() {
    game_pid = (int)getpid();
    const size_t page = (size_t)getpagesize();
    // Две страницы подряд, вторая потом отключается: проверка ошибок и границ.
    uint8_t *mem = (uint8_t *)mmap(nullptr, page * 3, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    CHECK(mem != MAP_FAILED, "mmap");
    for (size_t i = 0; i < page * 2; ++i) mem[i] = (uint8_t)(i * 7 + 3);
    munmap(mem + page * 2, page);                                      // третья страница не отображена
    const uint64_t A = (uint64_t)mem;

    {   // Без кэша: каждое чтение — системный вызов, значения верные.
        vm_cache_enable(false);
        const VmStats s0 = vm_stats();
        for (int i = 0; i < 10; ++i) { uint32_t v; CHECK(vm_readv(A + 8 * i, &v, 4), "plain read"); uint32_t w; memcpy(&w, mem + 8 * i, 4); CHECK(v == w, "plain value"); }
        const VmStats s1 = vm_stats();
        CHECK(s1.syscalls - s0.syscalls == 10 && s1.hits == s0.hits, "no cache: %llu syscalls for 10 reads", (unsigned long long)(s1.syscalls - s0.syscalls));
    }
    {   // С кэшем: поля одного блока читаются одним вызовом, значения те же.
        vm_cache_enable(true); vm_cache_new_frame();
        const VmStats s0 = vm_stats();
        for (int i = 0; i < 32; ++i) { uint64_t v; CHECK(vm_readv(A + 8 * i, &v, 8), "cached read"); uint64_t w; memcpy(&w, mem + 8 * i, 8); CHECK(v == w, "cached value %d", i); }
        const VmStats s1 = vm_stats();
        CHECK(s1.syscalls - s0.syscalls == 1, "32 reads inside one 256-byte block cost %llu syscalls", (unsigned long long)(s1.syscalls - s0.syscalls));
        CHECK(s1.hits - s0.hits == 31, "31 hits, got %llu", (unsigned long long)(s1.hits - s0.hits));
        // Два блока — два вызова; третий блок той же страницы — ещё один.
        uint8_t b; vm_readv(A + 300, &b, 1); vm_readv(A + 600, &b, 1);
        CHECK(vm_stats().syscalls - s1.syscalls == 2, "two more blocks");
    }
    {   // Новый кадр: значение меняется в «игре» — следующий кадр видит новое, текущий (в пределах кадра) — прежнее.
        vm_cache_enable(true); vm_cache_new_frame();
        uint32_t v; vm_readv(A + 16, &v, 4);
        const uint32_t old = v; const uint32_t nw = old ^ 0xFFFFFFFFu; memcpy(mem + 16, &nw, 4);
        uint32_t v2; vm_readv(A + 16, &v2, 4);
        CHECK(v2 == old, "inside a frame the value is the one read at frame start");
        vm_cache_new_frame();
        uint32_t v3; vm_readv(A + 16, &v3, 4);
        CHECK(v3 == nw, "next frame sees the change (%08x vs %08x)", v3, nw);
    }
    {   // Запись этим потоком сбрасывает кэш: чтение сразу после записи видит записанное.
        vm_cache_enable(true); vm_cache_new_frame();
        uint32_t v; vm_readv(A + 32, &v, 4);
        const uint32_t w = 0xDEADBEEFu; CHECK(vm_writev(A + 32, &w, 4), "write");
        uint32_t r; vm_readv(A + 32, &r, 4);
        CHECK(r == w, "read after write sees the written value: %08x", r);
    }
    {   // Ошибки: нечитаемая страница не даёт мусора, ошибка кэшируется на кадр (второй вызов — без системного).
        vm_cache_enable(true); vm_cache_new_frame();
        uint32_t v = 0x11111111u; const VmStats s0 = vm_stats();
        CHECK(!vm_readv(A + page * 2 + 8, &v, 4), "unmapped must fail");
        CHECK(!vm_readv(A + page * 2 + 64, &v, 4), "same block, cached failure");
        CHECK(vm_stats().syscalls - s0.syscalls == 1, "failure cached: %llu syscalls", (unsigned long long)(vm_stats().syscalls - s0.syscalls));
        CHECK(v == 0x11111111u, "buffer untouched on failure");
        // Последние байты последней отображённой страницы читаются (блок не выходит за страницу).
        uint32_t t; CHECK(vm_readv(A + page * 2 - 4, &t, 4), "last bytes of the last mapped page");
        uint32_t e; memcpy(&e, mem + page * 2 - 4, 4); CHECK(t == e, "last bytes value");
        // Через границу блока: прямое чтение, значение верное.
        uint64_t x; CHECK(vm_readv(A + 252, &x, 8), "straddling read"); uint64_t xe; memcpy(&xe, mem + 252, 8); CHECK(x == xe, "straddling value");
        // Адрес меньше блока выровнен вниз без переполнения.
        uint32_t z; CHECK(!vm_readv(8, &z, 4), "low address fails cleanly");
    }
    {   // Крупные чтения идут напрямую и не засоряют кэш.
        vm_cache_enable(true); vm_cache_new_frame();
        std::vector<uint8_t> big(512); const VmStats s0 = vm_stats();
        CHECK(vm_readv(A, big.data(), big.size()), "big read"); CHECK(memcmp(big.data(), mem, 512) == 0, "big value");
        CHECK(vm_stats().syscalls - s0.syscalls == 1 && vm_stats().hits == s0.hits, "big read: one syscall, no cache");
    }
    {   // Кэш виден только включившему его потоку: другой поток читает напрямую и всегда свежее.
        vm_cache_enable(true); vm_cache_new_frame();
        uint32_t main_v; vm_readv(A + 64, &main_v, 4);
        const uint32_t nw = main_v + 12345u; memcpy(mem + 64, &nw, 4);
        std::atomic<uint32_t> seen{0}; std::atomic<uint64_t> thHits{99};
        std::thread t([&] { uint32_t v; vm_readv(A + 64, &v, 4); seen = v; thHits = vm_stats().thHits; });
        t.join();
        CHECK(seen == nw, "other thread reads fresh memory");
        CHECK(thHits == 0, "other thread has no cache hits (%llu)", (unsigned long long)thHits.load());
        uint32_t again; vm_readv(A + 64, &again, 4); CHECK(again == main_v, "render thread still sees its frame snapshot");
    }
    {   // Смена pid (перезапуск игры) выбрасывает кэш: дочерний процесс — копия памяти на момент fork(), дальше они расходятся.
        vm_cache_enable(false);
        uint32_t v0 = 0x01010101u; memcpy(mem + 128, &v0, 4);
        const pid_t child = fork();
        if (child == 0) { pause(); _exit(0); }
        const int parent = game_pid;
        const uint32_t v1 = 0x02020202u; memcpy(mem + 128, &v1, 4);            // родитель изменил, у ребёнка осталось v0
        vm_cache_enable(true); vm_cache_new_frame();
        uint32_t r1; vm_readv(A + 128, &r1, 4); CHECK(r1 == v1, "parent value %08x", r1);
        game_pid = (int)child;
        uint32_t r2; const bool ok = vm_readv(A + 128, &r2, 4);
        CHECK(ok && r2 == v0, "after the pid change the child's memory is read, not the parent's cached block: ok=%d %08x want %08x", (int)ok, r2, v0);
        game_pid = parent;
        uint32_t r3; vm_readv(A + 128, &r3, 4); CHECK(r3 == v1, "back to the parent: %08x", r3);
        kill(child, SIGKILL); waitpid(child, nullptr, 0);
        // Нет игры (pid < 0): чтение не удаётся и не берёт данные из кэша.
        game_pid = -1; uint32_t bad = 0x55; CHECK(!vm_readv(A + 128, &bad, 4) && bad == 0x55, "no game -> failure without cache"); game_pid = parent;
    }
    {   // Конфликты ячеек: две выровненные области с одним индексом (разница 512*256) не путаются.
        vm_cache_enable(true); vm_cache_new_frame();
        uint8_t *big = (uint8_t *)mmap(nullptr, 512 * 256 + page * 2, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        const uint64_t base = ((uint64_t)big + 255) & ~255ULL;
        *(uint32_t *)base = 0xAAAA0001u; *(uint32_t *)(base + 512 * 256) = 0xBBBB0002u;
        uint32_t a, b; vm_readv(base, &a, 4); vm_readv(base + 512 * 256, &b, 4); uint32_t a2; vm_readv(base, &a2, 4);
        CHECK(a == 0xAAAA0001u && b == 0xBBBB0002u && a2 == 0xAAAA0001u, "slot collision handled: %08x %08x %08x", a, b, a2);
    }
    {   // Реальный счёт: цепочка из «объектов» по 40 полей каждый — кэш уменьшает число вызовов в разы.
        vm_cache_enable(false); VmStats s0 = vm_stats();
        for (int o = 0; o < 6; ++o) for (int f = 0; f < 40; ++f) { uint32_t v; vm_readv(A + o * 256 + f * 4, &v, 4); }
        const uint64_t plain = vm_stats().syscalls - s0.syscalls;
        vm_cache_enable(true); vm_cache_new_frame(); s0 = vm_stats();
        for (int o = 0; o < 6; ++o) for (int f = 0; f < 40; ++f) { uint32_t v; vm_readv(A + o * 256 + f * 4, &v, 4); }
        const uint64_t cached = vm_stats().syscalls - s0.syscalls;
        CHECK(plain == 240 && cached == 6, "plain %llu cached %llu", (unsigned long long)plain, (unsigned long long)cached);
    }
    printf(fails ? "FAILED: %d\n" : "ALL OK\n", fails);
    return fails ? 1 : 0;
}
