package avis;

import android.content.ClipData;
import android.os.IBinder;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Читает текст из буфера обмена Android и печатает одну строку:
 *   OK <base64(UTF-8)>   — текст прочитан
 *   EMPTY                — буфер доступен, но текста в нём нет
 *   ERR <причина>        — прочитать не удалось
 *
 * Запускается как `CLASSPATH=avis_clip.jar app_process / avis.Clip` от имени shell (uid 2000): так буфер читает scrcpy
 * на Android 10-15. Сигнатуры getPrimaryClip у версий Android разные (pkg, userId) / (pkg, attributionTag, userId) /
 * (pkg, attributionTag, userId, deviceId), поэтому аргументы подбираются по типам параметров, а не по номеру версии.
 */
public final class Clip {
    private static final String[] PACKAGES = {"com.android.shell", "android"};

    public static void main(String[] args) {
        String err = "";
        try {
            IBinder binder = (IBinder) Class.forName("android.os.ServiceManager")
                    .getMethod("getService", String.class).invoke(null, "clipboard");
            if (binder == null) {
                done("ERR no clipboard service");
                return;
            }
            Object clipboard = Class.forName("android.content.IClipboard$Stub")
                    .getMethod("asInterface", IBinder.class).invoke(null, binder);
            Method[] methods = Class.forName("android.content.IClipboard").getDeclaredMethods();
            for (String pkg : PACKAGES) {
                for (Method m : methods) {
                    if (!m.getName().equals("getPrimaryClip")) continue;
                    try {
                        ClipData data = (ClipData) m.invoke(clipboard, argsFor(m.getParameterTypes(), pkg));
                        if (data == null || data.getItemCount() == 0) {
                            done("EMPTY");
                            return;
                        }
                        CharSequence text = data.getItemAt(0).getText();
                        if (text == null) {
                            done("EMPTY");
                            return;
                        }
                        done("OK " + Base64.getEncoder().encodeToString(text.toString().getBytes(StandardCharsets.UTF_8)));
                        return;
                    } catch (InvocationTargetException e) {
                        Throwable c = e.getCause() != null ? e.getCause() : e;
                        err = c.getClass().getSimpleName() + ": " + c.getMessage();
                    } catch (Throwable e) {
                        err = e.getClass().getSimpleName() + ": " + e.getMessage();
                    }
                }
            }
        } catch (Throwable e) {
            err = e.getClass().getSimpleName() + ": " + e.getMessage();
        }
        done("ERR " + err.replace('\n', ' '));
    }

    /** Первый String — имя пакета, остальные (attributionTag) — null; int — 0 (пользователь 0, устройство 0). */
    private static Object[] argsFor(Class<?>[] types, String pkg) {
        Object[] a = new Object[types.length];
        int strings = 0;
        for (int i = 0; i < types.length; i++) {
            Class<?> t = types[i];
            if (t == String.class) a[i] = strings++ == 0 ? pkg : null;
            else if (t == int.class) a[i] = 0;
            else if (t == long.class) a[i] = 0L;
            else if (t == boolean.class) a[i] = false;
            else a[i] = null;
        }
        return a;
    }

    private static void done(String line) {
        System.out.println(line);
        System.out.flush();
        System.exit(0);
    }
}
