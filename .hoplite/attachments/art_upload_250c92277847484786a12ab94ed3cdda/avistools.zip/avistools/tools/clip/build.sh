#!/usr/bin/env bash
# Собирает assets/trial/avis_clip.jar из src/avis/Clip.java. Нужны JDK 17+ и интернет (кэш: ~/.cache/avis-clip).
# Хелпер читает буфер обмена Android (запускается клиентом через app_process, см. src/auth/auth_clip.cpp).
set -euo pipefail
cd "$(dirname "$0")"
CACHE="${AVIS_CLIP_CACHE:-$HOME/.cache/avis-clip}"
mkdir -p "$CACHE" build
[ -f "$CACHE/android-stubs.jar" ] || curl -sSL -o "$CACHE/android-stubs.jar" https://repo1.maven.org/maven2/com/google/android/android/4.1.1.4/android-4.1.1.4.jar
[ -f "$CACHE/r8.jar" ] || curl -sSL -o "$CACHE/r8.jar" https://dl.google.com/dl/android/maven2/com/android/tools/r8/8.5.35/r8-8.5.35.jar
rm -rf build/classes && mkdir -p build/classes
javac -encoding UTF-8 -source 8 -target 8 -Xlint:-options -cp "$CACHE/android-stubs.jar" -d build/classes src/avis/Clip.java
OUT=../../assets/trial/avis_clip.jar
rm -f "$OUT"
java -cp "$CACHE/r8.jar" com.android.tools.r8.D8 --release --min-api 26 --lib "$CACHE/android-stubs.jar" --output "$OUT" build/classes/avis/Clip.class
echo "готово: $(cd ../.. && ls -la assets/trial/avis_clip.jar | awk '{print $5, $9}')"
