#include "overlay_stability.h"
#include <cassert>
#include <limits>
#include <cstdio>
#include <initializer_list>
int main() {
    using namespace overlaycore;
    Lease a; a.Fresh(7,1); assert(a.Alive(7,1.03,.05));
    assert(!a.Alive(8,1.03,.05)); assert(!a.Alive(7,.9,.05));
    assert(!a.Alive(7,1.06,.05));
    assert(!a.Alive(7,std::numeric_limits<double>::quiet_NaN(),.05));
    ProjectionLatch p;
    assert(p.Update(9,1,true,false));
    assert(p.Update(9,1.01,false,false));
    assert(!p.Update(9,1.04,false,false));
    assert(p.Update(9,1.05,true,false));
    assert(p.Update(9,1.08,true,false));
    assert(p.Update(9,1.11,true,false));
    assert(!p.Update(10,1.12,false,false)); // camera change clears history
    assert(p.Update(10,1.13,true,false));
    assert(!p.Update(10,1.14,true,true)); // death wins over successful read
    assert(SelectOwner(7,0,OwnerStatus::Unknown)==7);
    assert(SelectOwner(7,0,OwnerStatus::Rejected)==0);
    assert(SelectOwner(7,8,OwnerStatus::Rejected)==8);
    assert(SelectOwner(0,0,OwnerStatus::Unknown)==0);
    OwnerRosterGuard roster;
    assert(!roster.Missing(7,true,false,1.));
    assert(!roster.Missing(7,true,false,1.2));
    assert(roster.Missing(7,true,false,1.26));
    assert(!roster.Missing(7,false,false,1.3)); // unreadable is not absent
    assert(!roster.Missing(7,true,false,1.4)); // fresh grace after partial read
    assert(!roster.Missing(7,true,true,1.5));
    assert(!roster.Missing(8,true,false,2.)); // respawn cannot inherit absence
    assert(!roster.Missing(8,true,false,1.9)); // backwards clock resets
    // Simulated repeated 10-second read failures: one failed frame does not
    // force a new angular source, and validated recovery has no quarantine.
    for (int hz : {30,60,120}) {
        ProjectionLatch t;
        for (int f=0;f<hz*120;++f) {
            const bool bad=f>0 && f%(hz*10)==0;
            assert(t.Update(7,(double)f/hz,!bad,false));
        }
    }
    float v[16]={},pr[16]={},out[16];
    for(int i=0;i<16;++i)out[i]=42;
    for(int i=0;i<4;++i)v[i*5]=pr[i*5]=1;
    v[12]=3; v[13]=5;
    assert(Compose(v,pr,out)); assert(out[12]==3 && out[13]==5 && out[15]==1);
    pr[2]=std::numeric_limits<float>::quiet_NaN();
    assert(!Compose(v,pr,out)); assert(out[12]==3 && out[13]==5 && out[15]==1);
    for(int hz : {30,60,120}) {
        ProjectionLatch t; assert(t.Update(4,0,true,false));
        for(int f=1;f<=hz;++f) {
            const double now=(double)f/hz;
            assert(t.Update(4,now,false,false)==(now<=.035));
        }
    }
    puts("ALL OK");
}
