// Хост-тест названий и выбора брони: g++ -std=c++17 -O1 -Wall -Isrc tools/test_gear_names.cpp -o /tmp/t && /tmp/t
#include "gear_names.h"
#include <cstdio>
#include <map>
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { ++fails; printf("FAIL line %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

// Реестр equipments[] и weapons[] из лога игры (avis_tools_20261011_170021.log).
static const char *kEquip[27] = { "bone.boots", "bone.chestplate", "bone.helmet", "bone.leggings", "elf.hat", "hazmat", "leather.boots", "leather.chestplate",
    "leather.helmet", "leather.leggings", "metal.boots", "metal.chestplate", "metal.leggings", "metal.helmet", "pumpkin.head", "santa.hat", "ski.head",
    "snowman.head", "witch.hat", "wood.chestplate", "wooden.helmet", "wooden.leggings", "wooden.sandals", "military.suit", "party.cone", "backpack", "backpack.big" };
static const char *kWeap[45] = { "stone.hatchet", "axe", "pickaxe", "revolver", "shotgun", "hunting.rifle", "assault.rifle", "bone.club", "wooden.spear", "iron.spear",
    "wooden.bow", "torch", "building.plan", "rocket.launcher", "building.hammer", "explosive.charge", "ice.spear", "snowball", "event.grenade.smoke", "submachine.gun",
    "flare.gun", "crossbow", "wooden.spiked.club", "machete", "mace", "desert.eagle", "thompson", "dmr", "pickaxehammer", "winchester", "event.grenade.makeshift",
    "dvl", "hmlmg", "saw.ripper", "handmade.pistol", "", "kriss.vector", "chainsaw", "jackhammer", "grenade.military", "steel.ball.gun", "grenade.cupcake", "fn.fal",
    "double.barrel", "weapon.flare.signal" };
static std::string equipAt(int r) { return r >= 0 && r < 27 ? kEquip[r] : ""; }
static auto lab = [](const std::string &id) { return gear::label(id); };

int main() {
    {   // Все id реестров имеют нормальные английские названия, а не сырые id.
        for (const char *id : kEquip) { const std::string l = gear::label(id); CHECK(l.find('.') == std::string::npos && isupper((unsigned char)l[0]), "armor label '%s' for %s", l.c_str(), id); }
        for (const char *id : kWeap) { if (!*id) continue; const std::string l = gear::label(id); CHECK(l.find('.') == std::string::npos && isupper((unsigned char)l[0]), "weapon label '%s' for %s", l.c_str(), id); }
        CHECK(gear::label("metal.chestplate") == "Metal Breastplate", "'%s'", gear::label("metal.chestplate").c_str());
        CHECK(gear::label("assault.rifle") == "Assault Rifle", "ak");
        CHECK(gear::label("fn.fal") == "FN FAL" && gear::label("dmr") == "DMR" && gear::label("hmlmg") == "HMLMG", "acronyms");
        CHECK(gear::label("some.new.item") == "Some New Item", "fallback '%s'", gear::label("some.new.item").c_str());
        CHECK(gear::label("smg.body") == "SMG Body", "'%s'", gear::label("smg.body").c_str());
    }
    {   // Название из игры главнее таблицы; мусорное отбрасывается.
        CHECK(gear::label("assault.rifle", "AK-47") == "AK-47", "game name wins");
        CHECK(gear::label("assault.rifle", "") == "Assault Rifle", "empty game name");
        CHECK(gear::label("assault.rifle", "Автомат") == "Assault Rifle", "non-ascii rejected");
        CHECK(gear::label("assault.rifle", "x") == "Assault Rifle", "too short rejected");
        CHECK(gear::label("assault.rifle", std::string(80, 'a')) == "Assault Rifle", "too long rejected");
        CHECK(gear::label("assault.rifle", "1234") == "Assault Rifle", "no letters rejected");
    }
    {   // Слоты и классы всех деталей реестра.
        const int slot[27] = { 3, 1, 0, 2, 0, 4, 3, 1, 0, 2, 3, 1, 2, 0, 0, 0, 0, 0, 0, 1, 0, 2, 3, 4, 0, 5, 5 };
        const int rank[27] = { 3, 3, 3, 3, 0, 5, 2, 2, 2, 2, 4, 4, 4, 4, 0, 0, 0, 0, 0, 1, 1, 1, 1, 6, 0, 1, 2 };
        for (int i = 0; i < 27; ++i) { const auto in = gear::armorInfo(kEquip[i]); CHECK(in.slot == slot[i] && in.rank == rank[i], "%s slot %d rank %d want %d/%d", kEquip[i], in.slot, in.rank, slot[i], rank[i]); }
        CHECK(gear::armorInfo("iron.helmet").slot == 0 && gear::armorInfo("iron.helmet").rank == 4, "heuristic fallback");
        CHECK(gear::armorInfo("assault.rifle").slot == -1, "weapon is not armor");
    }
    {   // Данные игры: включены индексы 12..15 (во всех пяти логах). Со смещением 2 это полный металлический набор.
        gear::ShiftVoter v;
        const std::vector<int> idx = { 12, 13, 14, 15 };
        CHECK(v.vote(idx, equipAt) == 2, "shift for logged set = %d", v.cur);
        CHECK(gear::shiftScore(idx, 2, equipAt) > gear::shiftScore(idx, 0, equipAt), "score 2 > score 0");
        std::vector<std::string> ids; for (int i : idx) ids.push_back(equipAt(i - v.cur));
        const auto worn = gear::pickWorn(ids, lab);
        CHECK(worn.size() == 4, "worn %zu", worn.size());
        if (worn.size() == 4) {
            CHECK(worn[0].label == "Metal Helmet" && worn[1].label == "Metal Breastplate" && worn[2].label == "Metal Leggings" && worn[3].label == "Metal Boots",
                  "%s | %s | %s | %s", worn[0].label.c_str(), worn[1].label.c_str(), worn[2].label.c_str(), worn[3].label.c_str());
        }
    }
    {   // Смещение 0 (если бы игра слала индексы реестра напрямую): набор 10..13 даёт тот же металл, и выбор остаётся 2 только при слабых данных.
        gear::ShiftVoter v;
        for (int base : { 0, 6, 10, 0, 6 }) v.vote({ base + 2, base + 3, base + 4, base + 5 }, equipAt);
        CHECK(v.cur == 2, "consistent +2 data keeps shift 2, got %d", v.cur);
        gear::ShiftVoter w;
        for (int base : { 0, 6, 10, 0, 6, 19 }) w.vote({ base, base + 1, base + 2, base + 3 }, equipAt);
        CHECK(w.cur == 0, "direct indexes must win after several sets: cur=%d votes0=%d votes2=%d", w.cur, w.votes[0], w.votes[2]);
        gear::ShiftVoter one; one.vote({ 12, 13, 14, 15 }, equipAt);
        CHECK(one.votes[2] == 12 && one.votes[2] > one.votes[0] + 5, "logged set: score(2)=%d score(0)=%d", one.votes[2], one.votes[0]);
    }
    {   // Выбор деталей: косметика не вытесняет броню, броня вытесняет косметику; костюм заменяет набор; рюкзак отдельной строкой.
        auto pick = [&](std::vector<std::string> ids) { return gear::pickWorn(ids, lab); };
        auto a = pick({ "metal.helmet", "santa.hat", "metal.boots" });
        CHECK(a.size() == 2 && a[0].label == "Metal Helmet" && a[1].label == "Metal Boots", "cosmetic must not displace helmet (%zu)", a.size());
        auto b = pick({ "santa.hat" });
        CHECK(b.size() == 1 && b[0].label == "Santa Hat", "cosmetic alone is shown");
        auto c = pick({ "hazmat", "metal.helmet", "metal.boots" });
        CHECK(c.size() == 1 && c[0].label == "Hazmat Suit", "suit replaces set");
        auto d = pick({ "military.suit", "hazmat" });
        CHECK(d.size() == 1 && d[0].label == "Military Suit", "better suit wins");
        auto e = pick({ "backpack.big", "leather.helmet", "leather.chestplate" });
        CHECK(e.size() == 3 && e[2].label == "Big Backpack", "backpack last (%zu)", e.size());
        auto f = pick({ "wooden.helmet", "metal.helmet" });
        CHECK(f.size() == 1 && f[0].label == "Metal Helmet", "higher rank wins in a slot");
        CHECK(pick({}).empty() && pick({ "", "assault.rifle" }).empty(), "nothing worn / non-armor ignored");
    }
    {   // Оружие в руке по номерам из реестра, как в логе: 6 и 30.
        CHECK(gear::label(kWeap[6]) == "Assault Rifle" && gear::label(kWeap[30]) == "Makeshift Grenade", "'%s' '%s'", gear::label(kWeap[6]).c_str(), gear::label(kWeap[30]).c_str());
        CHECK(gear::label(kWeap[10]) == "Wooden Bow" && gear::label(kWeap[21]) == "Crossbow" && gear::label(kWeap[8]) == "Wooden Spear", "bow/crossbow/spear");
    }
    printf(fails ? "FAILED: %d\n" : "ALL OK\n", fails);
    return fails ? 1 : 0;
}
