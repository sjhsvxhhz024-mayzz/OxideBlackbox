// Real auth_client worker/state machine; transport and signature decoder are
// deterministic test doubles. Real cryptography/TLS covered by test_auth.sh.
#include "auth/auth_client.h"
#include "auth/auth_proto.h"
#include "auth/auth_net.h"
#include "auth/auth_clip.h"
#include "auth/auth_retry.h"
#include <atomic>
#include <cassert>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <thread>
#include <mutex>
#include <vector>
#include <fstream>
#include <filesystem>
using Clock=std::chrono::steady_clock;
struct Step{bool transport;int status;std::string body;int delay=0;};
static std::mutex mu;static std::vector<Step> steps;static std::vector<Clock::time_point> started;
static std::atomic<int> calls{0};static std::string folder;
namespace avis {
std::string RandomHex(int bytes){return std::string(bytes*2,'a');}
std::string Sha256Hex(const std::string&){return std::string(64,'b');}
std::string NormalizeKey(const std::string&s){return s.size()==19?s:std::string();}
std::string FindKeyInText(const std::string&){return {};}
std::vector<unsigned char> ParcelBytes(const std::string&){return {};}
ClipResult ReadClipboard(const std::string&){return {};}
bool ParseReply(const std::string &text,const char*kind,const std::string&,const std::string&,Reply&r,std::string&err){
 if(text=="bad-signature"){err="signature";return false;}
 r.status=text;r.serverTime=100000;r.b="103600";
 if(std::string(kind)=="info"){r.status="ok";r.a="testbot";r.b="testchannel";}
 return true;
}
bool HttpRequest(const std::string&url,const char*,const std::string&,HttpResponse&r,std::string&err){
 if(url.find("/info")!=std::string::npos){r.status=200;r.body="ok";return true;}
 Step s;
 {std::lock_guard<std::mutex>l(mu);int i=calls.load();s=i<(int)steps.size()?steps[i]:Step{true,200,"ok"};started.push_back(Clock::now());++calls;}
 if(s.delay)std::this_thread::sleep_for(std::chrono::milliseconds(s.delay));
 r.status=s.status;r.body=s.body;err=s.transport?"":"timeout";return s.transport;
}
}
template<class F>static bool waitFor(F f,int ms=2500){for(int t=0;t<ms;t+=10){if(f())return true;std::this_thread::sleep_for(std::chrono::milliseconds(10));}return f();}
static const char *key="AVIS-ABCD-EFGH-JKLM";
static void setup(std::vector<Step> s,bool saved=false){
 char dir[]="/tmp/avis_retry_XXXXXX";assert(mkdtemp(dir));folder=dir;
 std::ofstream(folder+"/server.txt")<<"http://test.invalid";
 if(saved)std::ofstream(folder+"/key.txt")<<key;
 {std::lock_guard<std::mutex>l(mu);steps=std::move(s);started.clear();calls=0;}
 avis::Init(folder.c_str());
}
static void done(){avis::Shutdown();std::filesystem::remove_all(folder);}
int main(){
 using namespace avis;
 assert(RetryableHttpStatus(429)&&RetryableHttpStatus(503)&&RetryableHttpStatus(408));
 assert(!RetryableHttpStatus(400)&&!RetryableHttpStatus(403)&&!RetryableHttpStatus(404));
 setup({{false,0,""},{true,503,"unavailable"},{true,200,"ok"}});Submit(key);
 assert(waitFor([]{return calls==1&&Get().retrying;}));
 assert(Get().phase==Phase::Checking&&!Active()&&Get().retryInSec>0);
 assert(waitFor([]{return Active();},13000));assert(calls==3);
 {std::lock_guard<std::mutex>l(mu);for(size_t i=1;i<started.size();++i)assert(std::chrono::duration_cast<std::chrono::milliseconds>(started[i]-started[i-1]).count()>=5000);}
 assert(Get().verifyAttempts==3&&!Get().retrying&&Get().savedKey==key);done();puts("network/503 retry every five seconds -> verified success OK");
 setup({{true,429,""},{true,200,"invalid"}});Submit(key);
 assert(waitFor([]{return calls==2&&Get().phase==Phase::NeedKey;},8000));
 assert(Get().msg==Msg::Invalid&&!Active()&&!Get().retrying);done();puts("429 retries; signed invalid terminates OK");
 setup({{true,200,"bad-signature"}});Submit(key);
 assert(waitFor([]{return Get().msg==Msg::BadServer;}));assert(calls==1&&!Active());done();puts("signature failure is not accepted or retried as network OK");
 setup({{true,400,""}});Submit(key);
 assert(waitFor([]{return Get().msg==Msg::BadServer;}));assert(calls==1&&!Active());done();
 for(bool logout:{false,true}){
  setup({{true,200,"ok",350}});Submit(key);assert(waitFor([]{return calls==1;}));
  if(logout)Logout();else CancelCheck();
  std::this_thread::sleep_for(std::chrono::milliseconds(450));
  assert(!Active()&&Get().phase==Phase::NeedKey);done();
 }
 puts("cancel/logout ignore late success OK");
 setup({{false,0,""},{true,200,"ok"}});Submit(key);
 assert(waitFor([]{return Get().retrying;}));CancelCheck();assert(Get().phase==Phase::NeedKey);
 Submit(key);assert(waitFor([]{return Active();}));assert(calls==2);done();puts("cancel backoff, resubmit immediately OK");
 setup({{false,0,""},{true,200,"ok"}},true);
 assert(waitFor([]{return Get().retrying&&Get().autoLogin;}));
 assert(waitFor([]{return Active();},8000));assert(calls==2);done();puts("saved-key automatic login retries OK");
 setup({{false,0,""}});Submit(key);assert(waitFor([]{return Get().retrying;}));
 auto t=Clock::now();done();assert(std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now()-t).count()<500);
 puts("shutdown interrupts backoff OK\nALL OK");
}
