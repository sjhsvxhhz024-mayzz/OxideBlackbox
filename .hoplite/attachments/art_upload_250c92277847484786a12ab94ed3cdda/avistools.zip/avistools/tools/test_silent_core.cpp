// Хост-тест логики Silent aim: распознавание новых/своих пуль при опросе каждые ~3 мс и упреждение по движущейся цели.
// Сборка: g++ -std=c++17 -I../src test_silent_core.cpp -o /tmp/test_silent_core && /tmp/test_silent_core
#include "silent_core.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <unordered_map>

using namespace silentcore;

struct Bullet { int slot; V3 p, v; bool own; bool live; int id; };

// Физика игры: шаг 20 мс, пули из пула (LIFO), родились -> сразу один шаг (вариант B) или нет (вариант A).
static int runPool(bool stepOnSpawn, bool realistic, double pollMs, double jitterMs, int &ownTotal, int &ownSeen, int &falseOwn, int &ownDouble) {
    srand(11);
    const V3 cam{ 0, 1.6f, 0 }, fwd{ 0, 0, 1 };
    std::vector<Bullet> live; std::vector<int> freeSlots; for (int i = 7; i >= 0; --i) freeSlots.push_back(i);
    std::unordered_map<int, bool> detected;                         // id -> засчитана ли как своя
    std::unordered_map<int, int> idOfSlot;
    std::unordered_map<int, V3> prev, prevV; std::unordered_map<int, bool> havePrev;
    int sinceOwn = 99;
    double tick = 0.02, nextTick = tick, T = 0, nextPoll = 0, lastPoll = 0;
    int nextId = 1; ownTotal = ownSeen = falseOwn = ownDouble = 0;
    std::unordered_map<int, int> countedTimes;
    while (T < 60.0) {
        T += 0.0005;
        if (T >= nextTick) {                                        // FixedUpdate
            nextTick += tick;
            for (auto &b : live) { b.p = b.p + b.v * (float)tick; }
            for (size_t i = 0; i < live.size();) {                  // умершие возвращаются в пул
                if (rand() % 100 < (realistic ? 3 : 12) || (live[i].p.z > 160.f)) { freeSlots.push_back(live[i].slot); live.erase(live.begin() + i); } else ++i;
            }
            ++sinceOwn; int nOwn = 0;
            if (realistic) { if (sinceOwn >= 4 && (rand() % 100) < 85) { nOwn = 1; sinceOwn = 0; } }          // автоматический огонь ~12 выстр/с очередями
            else nOwn = (rand() % 100 < 70) ? 1 : 0;                                                          // стресс: почти каждый такт
            const int nOther = (rand() % 100 < 35) ? 1 : 0;
            for (int k = 0; k < nOwn + nOther && !freeSlots.empty(); ++k) {
                const bool own = k < nOwn; Bullet b; b.slot = freeSlots.back(); freeSlots.pop_back(); b.own = own; b.live = true; b.id = nextId++;
                if (own) { const float a = ((rand() % 1000) / 1000.f - 0.5f) * 0.15f; b.v = { sinf(a) * 500, ((rand() % 100) / 100.f - 0.5f) * 15, cosf(a) * 500 }; b.p = { 0.3f, 1.55f, 0.6f }; }
                else { const float a = (rand() % 628) / 100.f; b.v = { cosf(a) * 500, 0, sinf(a) * 500 }; b.p = { (float)(rand() % 100 - 50), 1.5f, (float)(40 + rand() % 90) }; }
                if (stepOnSpawn) b.p = b.p + b.v * ((rand() % 100) / 100.f * (float)tick);
                live.push_back(b); ownTotal += own;
            }
        }
        if (T >= nextPoll) {                                        // опрос читом
            const double dt = T - lastPoll; lastPoll = T;
            nextPoll = T + (pollMs + ((rand() % 1000) / 1000.0 - 0.5) * 2 * jitterMs) / 1000.0;
            std::unordered_map<int, V3> cur, curV;
            for (auto &b : live) {
                const bool hp = havePrev.count(b.slot) && havePrev[b.slot];
                const bool isNew = isNewBullet(hp, hp ? prev[b.slot] : V3(), hp ? prevV[b.slot] : V3(), b.p, b.v, (float)dt);
                cur[b.slot] = b.p; curV[b.slot] = b.v;
                if (!isNew) continue;
                if (isOwnBullet(cam, fwd, b.p, b.v)) { if (b.own) { ++ownSeen; if (++countedTimes[b.id] > 1) ++ownDouble; } else ++falseOwn; }
            }
            havePrev.clear(); prev.clear(); prevV.clear(); for (auto &kv : cur) { prev[kv.first] = kv.second; prevV[kv.first] = curV[kv.first]; havePrev[kv.first] = true; }
        }
    }
    return 0;
}

int main() {
    int bad = 0;
    // Moving targets are sampled at render rate on PC. A sub-15 ms frame
    // must accumulate displacement instead of resetting velocity to zero.
    for (double fps : {90.0, 120.0}) {
        MotionTrack track;
        V3 velocity{};
        for (int frame = 0; frame <= (int)fps; ++frame) {
            const double t = frame / fps;
            velocity = track.update(V3{(float)(5.0 * t), 0, 0}, t);
        }
        const bool ok = velocity.x > 4.5f && velocity.x < 5.5f;
        printf("motion %.0f FPS: %.2f m/s -> %s\n",fps,velocity.x,ok?"ok":"BAD");
        if (!ok) ++bad;
    }
    // 1. Распознавание: при опросе 3 мс (с джиттером) и физике 20 мс ловим практически все свои пули, чужие не считаем своими.
    //    Реалистичная стрельба — очередями ~12 выстр/с; стресс — выстрел почти каждый такт физики и частые смерти пуль (пул переиспользуется
    //    в тот же такт). Там допускаем меньше: часть таких пуль неотличима по позиции, различает только смена скорости.
    for (bool realistic : { true, false }) for (bool stepOnSpawn : { false, true }) for (double poll : { 3.0, 8.0, 20.0, 28.0 }) {
        int tot, seen, fo, dbl; runPool(stepOnSpawn, realistic, poll, poll * 0.3, tot, seen, fo, dbl);
        const double pct = 100.0 * seen / tot;
        const double need = realistic ? (poll <= 8.0 ? 99.0 : 90.0) : (poll <= 8.0 ? 95.0 : 85.0);
        const bool ok = pct > need && fo == 0 && dbl == 0;
        printf("%s %s опрос %2.0f мс: своих %d, поймано %d (%.1f%%, нужно >%.0f%%), ложных %d, повторов %d -> %s\n", realistic ? "очередями" : "стресс   ", stepOnSpawn ? "родилась+шаг " : "родилась     ", poll, tot, seen, pct, need, fo, dbl, ok ? "ok" : "ПЛОХО");
        if (!ok) ++bad;
    }
    // 2. Упреждение: цель бежит поперёк, пуля 500 м/с, g=5. Прицельная точка должна дать пролёт в пределах ~0.15 м от цели.
    {
        const V3 from{ 0, 1.5f, 0 }; float worst = 0;
        for (float dist : { 15.f, 40.f, 80.f, 150.f, 250.f }) for (float sp : { 0.f, 3.f, 6.f, 9.f }) for (float ang : { 0.f, 45.f, 90.f, 135.f }) {
            const float a = ang * 0.01745f; const V3 tgt{ sinf(0.2f) * dist, 1.2f, cosf(0.2f) * dist }; const V3 tv{ cosf(a) * sp, 0, sinf(a) * sp };
            float tof; const V3 aim = leadPoint(from, tgt, tv, 500.f, 5.f, 0.f, true, &tof);
            V3 d = aim - from; const float L = len(d); V3 v = d * (500.f / L); V3 p = from, tp = tgt; float best = 1e9f;
            for (int i = 0; i < 3000; ++i) { p = p + v * 0.0005f; v.y -= 5.f * 0.0005f; tp = tp + tv * 0.0005f; const float dd = len(p - tp); if (dd < best) best = dd; }
            if (best > worst) worst = best;
        }
        const bool ok = worst < 0.15f;
        printf("упреждение: худший пролёт мимо цели %.3f м по 80 сочетаниям (дистанция 15..250 м, скорость 0..9 м/с) -> %s\n", worst, ok ? "ok" : "ПЛОХО");
        if (!ok) ++bad;
    }
    // 3. Поправка leadAdj сдвигает точку по ходу цели, отрицательная — назад; без predict поправки нет.
    {
        const V3 from{ 0, 1.5f, 0 }, tgt{ 0, 1.2f, 60 }, tv{ 6, 0, 0 }; float t0, t1, t2;
        const V3 a0 = leadPoint(from, tgt, tv, 500.f, 5.f, 0.f, true, &t0), a1 = leadPoint(from, tgt, tv, 500.f, 5.f, 0.1f, true, &t1), a2 = leadPoint(from, tgt, tv, 500.f, 5.f, -0.1f, true, &t2);
        const V3 a3 = leadPoint(from, tgt, tv, 500.f, 5.f, 0.1f, false, nullptr);
        const bool ok = a1.x > a0.x + 0.4f && a2.x < a0.x - 0.4f && fabsf(a3.x) < 1e-3f && t1 > t0 && t2 < t0;
        printf("поправка времени полёта: x(-0.1)=%.2f x(0)=%.2f x(+0.1)=%.2f, без упреждения x=%.2f -> %s\n", a2.x, a0.x, a1.x, a3.x, ok ? "ok" : "ПЛОХО");
        if (!ok) ++bad;
    }
    // 4. Зона: голова/шея фиксированы, всё остальное — центр груди (самая большая цель).
    {
        const bool ok = silentcore::zoneFrac(0) > 0.9f && silentcore::zoneFrac(1) > 0.8f && silentcore::zoneFrac(1) < 0.9f &&
                        fabsf(silentcore::zoneFrac(2) - 0.68f) < 1e-4f && fabsf(silentcore::zoneFrac(7) - 0.68f) < 1e-4f;
        printf("зоны головы/шеи/груди -> %s\n", ok ? "ok" : "ПЛОХО");
        if (!ok) ++bad;
    }
    // 4b. Расстояние луча до отрезка: сквозь ось = 0, сбоку на 1 м = 1, мимо за конец отрезка считается до конца, луч назад не считается.
    {
        const V3 o{ 0, 1.5f, 0 }, d{ 0, 0, 1 }, a{ 0, 0, 10 }, b{ 0, 2, 10 };
        const float through = rayToSegment(o, d, a, b);
        const float side = rayToSegment(o, d, V3{ 1, 0, 10 }, V3{ 1, 2, 10 });
        const float above = rayToSegment(o, d, V3{ 0, 3, 10 }, V3{ 0, 4, 10 });
        const float behind = rayToSegment(o, d, V3{ 0, 0, -10 }, V3{ 0, 2, -10 });
        const float skew = rayToSegment(V3{ 0, 1, 0 }, V3{ 0.6f, 0, 0.8f }, V3{ 6, 0, 8 }, V3{ 6, 2, 8 });
        const bool ok = through < 1e-3f && fabsf(side - 1.f) < 1e-3f && fabsf(above - 1.5f) < 1e-3f && fabsf(behind - 10.f) < 0.2f && skew < 1e-3f;
        printf("луч-отрезок: сквозь %.3f, сбоку %.3f, выше %.3f, сзади %.2f, наискосок %.3f -> %s\n", through, side, above, behind, skew, ok ? "ok" : "ПЛОХО");
        if (!ok) ++bad;
    }
    // 5. Своя пуля: чужая сбоку/назад/в сторону от взгляда не принимается; своя с разбросом 8° принимается.
    {
        const V3 cam{ 0, 1.6f, 0 }, fwd{ 0, 0, 1 };
        const bool own = isOwnBullet(cam, fwd, V3{ 0.2f, 1.6f, 3.f }, V3{ 40, 0, 495 });
        const bool farOther = isOwnBullet(cam, fwd, V3{ 30.f, 1.6f, 60.f }, V3{ 495, 0, 40 });
        const bool behind = isOwnBullet(cam, fwd, V3{ 0, 1.6f, -20.f }, V3{ 0, 0, -500 });
        const bool towards = isOwnBullet(cam, fwd, V3{ 0, 1.6f, 6.f }, V3{ 0, 0, -500 });
        const bool ok = own && !farOther && !behind && !towards;
        printf("своя/чужая по камере: своя=%d чужая_сбоку=%d сзади=%d навстречу=%d -> %s\n", own, farOther, behind, towards, ok ? "ok" : "ПЛОХО");
        if (!ok) ++bad;
    }
    // 6. План выстрела с минимальной подменой. Пуля летит с гравитацией, цель бежит; исходный луч смещён от цели на разные расстояния.
    //    Проверяем в посекундной симуляции: (а) луч, уже идущий через зону, не трогаем; (б) иначе пуля проходит внутри радиуса зоны;
    //    (в) сдвиг пути у цели равен промаху минус запас, а не расстоянию до центра; (г) отсечка maxCorr.
    {
        const V3 from{ 0, 1.5f, 0 }; const float spd = 500.f, g = 5.f; int cases = 0, notHit = 0, wrongNoop = 0, wrongCorr = 0; float worstIn = 0.f;
        for (int zone : { 0, 1, 2, 3 }) for (float dist : { 12.f, 40.f, 90.f, 180.f }) for (float tvs : { 0.f, 4.f, 7.f }) for (float off : { 0.f, 0.15f, 0.5f, 1.2f, 3.f }) for (float ang : { 0.f, 90.f, 200.f }) {
            const V3 feet{ sinf(0.15f) * dist, 0.f, cosf(0.15f) * dist }; const V3 head{ feet.x, 1.75f, feet.z };
            const float a = ang * 0.01745f; const V3 tv{ cosf(a) * tvs, 0, sinf(a) * tvs };
            // исходный луч: на прямую к центру груди без упреждения, затем смещён вбок на off метров у цели
            const V3 chest{ feet.x, 1.0f, feet.z }; V3 d = chest - from; const float L = len(d); d = d * (1.f / L);
            const V3 side = V3{ d.z, 0, -d.x }; const float sl = len(side); const V3 sd = side * (1.f / sl);
            V3 d0 = (chest + sd * off) - from; d0 = d0 * (1.f / len(d0));
            const Plan pl = planShot(from, d0, spd, g, feet, head, tv, 0.32f, zone, true, 0.f, 50.f);
            // реальная траектория по плану; цель — ось [lo,hi] фигуры, двигающаяся с tv
            V3 dir = pl.noop ? d0 : (pl.aim - from); dir = dir * (1.f / len(dir)); V3 v = dir * spd, p = from; float lo, hi, rad; zoneSpan(zone, 0.32f, &lo, &hi, &rad);
            float best = 1e9f;
            for (int i = 0; i < 25000; ++i) {                    // шаг 0.1 мс: при 500 м/с это 5 см, меньше радиуса головы 13 см
                const float t = (i + 1) * 0.0001f; p = p + v * 0.0001f; v.y -= g * 0.0001f;
                const V3 f2 = feet + tv * t, h2 = head + tv * t, ax = h2 - f2; V3 cpp, rpp; (void)rpp;
                const V3 A = f2 + ax * lo, B = f2 + ax * hi; const V3 vv = B - A; float tt = dot(p - A, vv) / dot(vv, vv); tt = tt < 0 ? 0 : (tt > 1 ? 1 : tt);
                const float dd = len(p - (A + vv * tt)); if (dd < best) best = dd;
            }
            ++cases;
            const float naturalMiss = pl.zoneMiss;
            if (pl.noop && naturalMiss > rad * 0.85f + 1e-4f) ++wrongNoop;
            if (!pl.noop && fabsf(pl.corr - (naturalMiss - rad * 0.55f)) > 1e-3f) ++wrongCorr;
            if (best > rad * 1.0f) { ++notHit; if (notHit <= 6) printf("   мимо: зона %d дист %.0f v %.0f угол %.0f off %.2f: пролёт %.3f (радиус %.2f) noop=%d corr=%.2f tof=%.3f\n", zone, dist, tvs, ang, off, best, rad, pl.noop, pl.corr, pl.tof); } else if (best > worstIn) worstIn = best;
        }
        printf("план выстрела: %d случаев (зоны 0-3, дистанции 12-180 м, цель 0-7 м/с, промах 0-3 м): мимо зоны %d, неверный noop %d, неверный сдвиг %d, худший проход %.3f м -> %s\n",
               cases, notHit, wrongNoop, wrongCorr, worstIn, (notHit == 0 && wrongNoop == 0 && wrongCorr == 0) ? "ok" : "ПЛОХО");
        if (notHit || wrongNoop || wrongCorr) ++bad;
        // (г) maxCorr и noop
        const V3 feet{ 0, 0, 40 }, head{ 0, 1.75f, 40 }, d0{ 0, 0, 1 };
        const Plan on = planShot(from, V3{ 0, (1.0f - 1.5f) / 40.f, 1 } * (1.f / sqrtf(1 + 0.000156f)), 500.f, 5.f, feet, head, V3{ 0, 0, 0 }, 0.32f, 2, true, 0.f, 5.f);
        const Plan far = planShot(from, V3{ 0.1f, 0, 1 } * (1.f / sqrtf(1.01f)), 500.f, 5.f, feet, head, V3{ 0, 0, 0 }, 0.32f, 2, true, 0.f, 0.5f);   // 0.1 рад на 40 м = 4 м вбок
        const bool ok = far.tooFar && !far.noop && far.corr > 3.f; (void)on; (void)d0;
        printf("отсечка maxCorr: сдвиг %.2f м при допуске 0.5 м -> tooFar=%d -> %s\n", far.corr, far.tooFar, ok ? "ok" : "ПЛОХО");
        if (!ok) ++bad;
    }
    // 7. Метод «Look direction»: направление считается от ГЛАЗА с упреждением по скорости и гравитации оружия, пуля стартует от СТВОЛА (смещён от глаза),
    //    план устаревает до 16 мс между кадрами, а поток записи экстраполирует глаз и цель по скоростям. Проверяем пролёт мимо оси груди (радиус 0.32 м).
    {
        int cases = 0, miss = 0; float worst = 0.f;
        for (float dist : { 10.f, 30.f, 70.f, 120.f, 200.f }) for (float tvs : { 0.f, 3.f, 6.f, 8.f }) for (float ang : { 0.f, 90.f, 180.f, 270.f })
        for (float mz : { 0.f, 0.3f }) for (float stale : { 0.f, 0.016f }) {
            const V3 eye{ 0, 1.6f, 0 }, ev{ 0, 0, 3.f };                     // игрок идёт вперёд 3 м/с
            const V3 muz = eye + V3{ 0.25f, -0.12f, 0.45f } * (mz > 0 ? 1.f : 0.f);
            const V3 feet0{ sinf(0.1f) * dist, 0.f, cosf(0.1f) * dist }; const float a = ang * 0.01745f; const V3 tv{ cosf(a) * tvs, 0, sinf(a) * tvs };
            const float spd = 500.f, g = 5.f;
            const V3 head0 = feet0 + V3{ 0, 1.75f, 0 };
            // план на момент кадра
            const V3 mid = feet0 + (head0 - feet0) * 0.575f; float tof; const V3 aim = leadPoint(eye, mid, tv, spd, g, 0.f, true, &tof);
            // поток записи в момент t=stale: экстраполяция
            const V3 eyeN = eye + ev * stale, ptN = aim + tv * stale; V3 d = ptN - eyeN; d = d * (1.f / len(d));
            // реальный выстрел в момент stale: пуля стартует от ствола, смещённого вместе с игроком
            V3 p = muz + ev * stale, v = d * spd; float best = 1e9f;
            for (int i = 0; i < 30000; ++i) {
                const float t = (i + 1) * 0.0001f; p = p + v * 0.0001f; v.y -= g * 0.0001f;
                const V3 f2 = feet0 + tv * (stale + t), h2 = head0 + tv * (stale + t), ax = h2 - f2; const V3 A = f2 + ax * 0.35f, B = f2 + ax * 0.80f, vv = B - A;
                float tt = dot(p - A, vv) / dot(vv, vv); tt = tt < 0 ? 0 : (tt > 1 ? 1 : tt); const float dd = len(p - (A + vv * tt)); if (dd < best) best = dd;
            }
            ++cases; if (best > 0.32f) ++miss; if (best > worst) worst = best;
        }
        printf("Look direction: %d случаев (10-200 м, цель до 8 м/с, смещение ствола, задержка кадра): мимо груди %d, худший пролёт %.3f м -> %s\n", cases, miss, worst, miss == 0 ? "ok" : "ПЛОХО");
        if (miss) ++bad;
    }
    printf(bad ? "FAILED %d\n" : "ALL OK\n", bad);
    return bad ? 1 : 0;
}
