// Хост-тест bones.h на поддельной памяти процесса: подбор раскладки Transform, карта костей и
// покадровое чтение движущейся модели. Запуск из корня репозитория:
//   g++ -O2 -std=c++17 -Isrc -Itools tools/test_bones.cpp -o /tmp/t2 && /tmp/t2
#include "bones.h"
#include "skel_testgen.h"
#include <cstdio>
#include <cstdlib>
#include <map>
using namespace oxskel; using namespace oxbone;
static int fails = 0;
#define CHECK(c, ...) do { if(!(c)) { ++fails; printf("FAIL: "); printf(__VA_ARGS__); printf("\n"); } } while(0)

struct FakeMem {
    std::map<uint64_t, std::vector<uint8_t>> reg;
    long reads = 0, multi = 0; bool garbage = false;
    uint8_t *at(uint64_t a, size_t n) { for (auto &kv : reg) if (a >= kv.first && a + n <= kv.first + kv.second.size()) return kv.second.data() + (a - kv.first); return nullptr; }
    void alloc(uint64_t a, size_t n) { reg[a].assign(n, 0); }
    bool rd(uint64_t a, void *b, size_t n) {
        ++reads;
        if (garbage) { for (size_t i = 0; i < n; ++i) ((uint8_t *)b)[i] = (uint8_t)rand(); return true; }
        uint8_t *p = at(a, n); if (!p) return false; memcpy(b, p, n); return true;
    }
    bool rdMulti(const uint64_t *a, int n, size_t each, void *out) { ++multi; for (int i = 0; i < n; ++i) { uint8_t *p = at(a[i], each); if (!p) return false; memcpy((uint8_t *)out + i * each, p, each); } return true; }
    bool isPtr(uint64_t p) { return p > 0x10000 && p < 0x0000800000000000ULL; }
    template <class T> void put(uint64_t a, T v) { uint8_t *p = at(a, sizeof(T)); if (p) memcpy(p, &v, sizeof(T)); }
};

struct Variant { const char *name; int hierOff, idxOff, localOff, parentOff; TrsFmt fmt; bool matrix = false; int stale = 0; };   // stale: 1 — кэш мира на кадр позади, 2 — кэш безнадёжно устарел

// Пишет иерархию (локальные TRS + родители) и заголовки нативных Transform в поддельную память.
struct World {
    FakeMem mem; Variant v;
    uint64_t managedBase = 0x7a00001000ULL, nativeBase = 0x7b00002000ULL, hierP = 0x7c00003000ULL;
    uint64_t localArr = 0x7d00004000ULL, parentArr = 0x7e00005000ULL;
    std::vector<uint64_t> nat;      // нативные Transform: голова, корпус, держатели
    int nodeOfNat[8]; int natN = 0;

    void writeStatic(const tg::SynRig &r) {
        mem.alloc(hierP, 0x100);
        mem.put<uint64_t>(hierP + 0x08, 0x7f0000a000ULL);                                         // посторонние указатели в заголовке
        mem.put<uint64_t>(hierP + 0x10, 0x7f0000b000ULL); mem.put<uint64_t>(hierP + 0x38, 0x7f0000c000ULL);
        mem.put<uint64_t>(hierP + v.localOff, localArr); mem.put<uint64_t>(hierP + v.parentOff, parentArr);
        nat.clear(); natN = 0;
        const int nodes[3] = { r.head, r.joint[J_CHEST], r.joint[J_HAND_R] };
        for (int k = 0; k < 3; ++k) {
            const uint64_t n = nativeBase + (uint64_t)k * 0x200;
            mem.alloc(n, 0x200);
            if (v.matrix) mem.put<uint64_t>(n + 0x28, localArr + (uint64_t)nodes[k] * v.fmt.stride);       // блок узла в массиве
            else { mem.alloc(0x7f0000d000ULL + k * 0x1000, 0x200); mem.put<uint64_t>(n + 0x28, 0x7f0000d000ULL + k * 0x1000);
                   for (int q = 0; q < 8; ++q) mem.put<float>(0x7f0000d000ULL + k * 0x1000 + 0x90 + q * 4, 3.0e7f * (q + 1)); }   // чужой блок с мусором
            mem.put<uint64_t>(n + v.hierOff, hierP); mem.put<int>(n + v.idxOff, nodes[k]);
            mem.put<int>(n + v.idxOff + 4, 0x7777 + k);                                            // рядом лежит чужое значение
            nat.push_back(n); nodeOfNat[natN++] = nodes[k];
        }
    }
    std::vector<V3> prevWorld; std::vector<Q4> prevRot;
    void writeArrays(const tg::SynRig &r, float yawRoot, unsigned seed, Q4 headRot, uint64_t la, uint64_t pa) {
        std::vector<TRS> loc; std::vector<Q4> wrot;
        tg::ToLocals(r, yawRoot, seed, headRot, loc, wrot);
        std::vector<V3> curWorld = r.world;
        const int stride = v.fmt.stride, n = r.size();
        if (!mem.at(la, (size_t)(1100) * stride)) { mem.reg.erase(localArr); mem.reg.erase(parentArr); mem.alloc(la, (size_t)1100 * stride); mem.alloc(pa, 1100 * 4); localArr = la; parentArr = pa; }
        for (int i = 0; i < n; ++i) {
            float f[16] = { 0 };
            f[v.fmt.posF] = loc[i].pos.x; f[v.fmt.posF + 1] = loc[i].pos.y; f[v.fmt.posF + 2] = loc[i].pos.z;
            f[v.fmt.rotF] = loc[i].rot.x; f[v.fmt.rotF + 1] = loc[i].rot.y; f[v.fmt.rotF + 2] = loc[i].rot.z; f[v.fmt.rotF + 3] = loc[i].rot.w;
            f[v.fmt.sclF] = loc[i].scl.x; f[v.fmt.sclF + 1] = loc[i].scl.y; f[v.fmt.sclF + 2] = loc[i].scl.z;
            memcpy(mem.at(la + (uint64_t)i * stride, stride), f, (size_t)stride);
            const int par = r.parent[i]; memcpy(mem.at(pa + (uint64_t)i * 4, 4), &par, 4);
            if (v.matrix && stride >= 0xC0) {                              // кэш мировой позиции движка в блоке узла
                const bool useOld = v.stale == 1 && (int)prevWorld.size() == n;
                V3 w = useOld ? prevWorld[i] : curWorld[i]; const Q4 wr = useOld ? prevRot[i] : wrot[i];
                if (v.stale == 2) w = w + V3{ 5.0f, 0.0f, 0.0f };
                float wf[12] = { w.x, w.y, w.z, 0, wr.x, wr.y, wr.z, wr.w, 1, 1, 1, 0 };
                memcpy(mem.at(la + (uint64_t)i * stride + 0x90, 48), wf, 48);
            }
        }
        prevWorld = curWorld; prevRot = wrot;
        mem.put<uint64_t>(hierP + v.localOff, la); mem.put<uint64_t>(hierP + v.parentOff, pa);
    }
};

static void runVariant(const Variant &var, bool shuffle) {
    const float S = 1.66f;
    World W; W.v = var;
    const V3 root{ 14, 3, -9 };
    const float yawModel = 0.9f, yawLook = 0.7f;
    V3 feet = root; V3 right{ cosf(yawLook), 0, -sinf(yawLook) }, fwd{ sinf(yawLook), 0, cosf(yawLook) };
    float phase = 0; Layout L; BoneState b; AxisCalib ax; CalibReport rep;
    int frames = 0, exact = 0, remaps = 0, edgesOk = 0; double worst = 0, worstFine = 0, faceErr = 0; bool calibrated = false;
    uint64_t la = W.localArr, pa = W.parentArr;
    for (int f = 0; f < 240; ++f) {
        const float speed = f < 80 ? 0.0f : (f < 160 ? 2.5f : 5.5f);
        phase += tg::GaitOmega(speed, S) / 30.0f;
        tg::GenIn gi; gi.feet = feet; gi.S = S; gi.speed = speed; gi.yaw = yawLook; gi.phase = phase; gi.time = f / 30.0f; gi.crouch = (f > 200) ? 0.7f : 0.0f; gi.aim = f > 120;
        Pose truth; tg::GenPose(gi, truth);
        tg::RigOpt ro; ro.shuffle = shuffle; ro.seed = 5; ro.weapon = f > 120;
        tg::SynRig rig; tg::BuildRig(truth, root, ro, rig);
        // на кадре 150 массивы переезжают (realloc): новые адреса, кости читаются заново
        if (f == 150) { la = 0x7d10008000ULL; pa = 0x7e10009000ULL; }
        if (f == 0) W.mem.alloc(W.localArr, 1100 * (size_t)var.fmt.stride), W.mem.alloc(W.parentArr, 1100 * 4);
        const Q4 headRot = qmul(tg::QuatY(yawLook), Q4{ 0, 0, 0, 1 });   // локальная +Z головы смотрит вперёд
        W.writeArrays(rig, yawModel, 10 + f, headRot, la, pa);
        W.writeStatic(rig);                                           // индексы узлов в заголовках Transform обновляются движком
        if (!calibrated) {
            calibrated = Calibrate(W.mem, L, W.nat.data(), (int)W.nat.size(), feet, &rep);
            if (!calibrated) continue;
            CHECK(L.truth == (var.matrix && var.stale != 2), "%s: truth flag %d, expected %d", var.name, (int)L.truth, (int)var.matrix);
            CHECK(L.hierOff == var.hierOff && L.idxOff == var.idxOff && L.localOff == var.localOff && L.parentOff == var.parentOff &&
                  L.fmt.stride == var.fmt.stride && L.fmt.posF == var.fmt.posF && L.fmt.rotF == var.fmt.rotF && L.fmt.sclF == var.fmt.sclF,
                  "%s: wrong layout picked (h%x i%x l%x p%x stride %x pos%d rot%d scl%d)", var.name, L.hierOff, L.idxOff, L.localOff, L.parentOff, L.fmt.stride, L.fmt.posF, L.fmt.rotF, L.fmt.sclF);
            b.internal = W.nat[0];
        }
        ++frames;
        if (!b.mapped) { if (Map(W.mem, L, b, S, right)) ++remaps; else continue; }
        Pose got;
        if (ReadPose(W.mem, L, b, feet, S, right, fwd, ax, got)) {
            double w = 0;
            for (int k = 0; k < J_COUNT; ++k) if (rig.joint[k] >= 0) w = fmax(w, len(got.j[k] - rig.world[rig.joint[k]]));
            worst = fmax(worst, w); if (w < 5e-3) ++exact;
            if (f > 200) faceErr = fmax(faceErr, len(got.face - fwd));
            // мелкие кости: каждое ребро — отрезок «родитель → узел» настоящей иерархии
            int found = 0;
            for (int fn : rig.fine) { const V3 pb = rig.world[fn], pa2 = rig.world[rig.parent[fn]];
                for (int e = 0; e < got.ne; ++e) if (len(got.e[e].b - pb) < 5e-3f && len(got.e[e].a - pa2) < 5e-3f) { ++found; break; } }
            if (found == (int)rig.fine.size()) ++edgesOk; else worstFine = fmax(worstFine, (double)rig.fine.size() - found);
        }
    }
    printf("%-26s %s frames %3d exact %3d fine-complete %3d remaps %d  worst joint err %.5f m  (reads in calibration %d)\n", var.name, shuffle ? "shuffled" : "ordered ", frames, exact, edgesOk, remaps, worst, rep.reads);
    CHECK(calibrated, "%s: layout not found (nat=%d hier=%d ptr=%d tried=%d parentOk=%d worldOk=%d)", var.name, rep.nNat, rep.nHier, rep.nPtr, rep.tried, rep.parentOk, rep.worldOk);
    CHECK(exact >= frames - 2, "%s: only %d/%d frames exact", var.name, exact, frames);
    CHECK(edgesOk >= frames - 2, "%s: fine bones incomplete in %d frames", var.name, frames - edgesOk);
    CHECK(remaps == 3, "%s: expected 3 maps (start, weapon taken, arrays realloc), got %d", var.name, remaps);
    CHECK(ax.Best() == 4, "%s: head forward axis %d (want local +Z = 4)", var.name, ax.Best());
    CHECK(faceErr < 0.05, "%s: face direction error %.3f", var.name, faceErr);
    CHECK(worst < 5e-3, "%s: joint error %.5f", var.name, worst);
}

int main() {
    static const Variant vars[] = {
        { "standard 38/40 18/20 pos-rot-scl", 0x38, 0x40, 0x18, 0x20, TrsFmt{ 0x30, 0, 4, 8 } },
        { "rot-first packed (repo guess)",    0x38, 0x40, 0x18, 0x20, TrsFmt{ 0x30, 4, 0, 7 } },
        { "shifted 30/38",                    0x30, 0x38, 0x18, 0x20, TrsFmt{ 0x30, 0, 4, 8 } },
        { "shifted 40/48 hdr 28/30",          0x40, 0x48, 0x28, 0x30, TrsFmt{ 0x30, 0, 4, 8 } },
        { "stride 0x40",                      0x38, 0x40, 0x18, 0x20, TrsFmt{ 0x40, 0, 4, 8 } },
        { "scale-first",                      0x38, 0x40, 0x18, 0x20, TrsFmt{ 0x30, 8, 4, 0 } },
        { "swapped array order",              0x38, 0x40, 0x20, 0x18, TrsFmt{ 0x30, 0, 4, 8 } },
        { "node 0xC0, rot-first, world@90",   0x38, 0x40, 0x18, 0x20, TrsFmt{ 0xC0, 4, 0, 7 }, true, 0 },
        { "node 0xC0, world cache one frame stale", 0x38, 0x40, 0x18, 0x20, TrsFmt{ 0xC0, 4, 0, 7 }, true, 1 },
        { "node 0x100, pos-first, world@90",  0x38, 0x40, 0x18, 0x20, TrsFmt{ 0x100, 0, 4, 8 }, true, 0 },
        { "node 0xD0, shifted 40/48",         0x40, 0x48, 0x28, 0x30, TrsFmt{ 0xD0, 0, 4, 8 }, true, 0 },
        { "node 0xC0, world cache hopelessly stale", 0x38, 0x40, 0x18, 0x20, TrsFmt{ 0xC0, 4, 0, 7 }, true, 2 },
    };
    for (const Variant &v : vars) { runVariant(v, false); runVariant(v, true); }
    // мусор вместо памяти: ничего не падает и ничего не калибруется
    { World W; W.v = vars[0]; W.mem.garbage = true; Layout L; uint64_t nat[3] = { 0x7a0000100ULL, 0x7a0000200ULL, 0x7a0000300ULL };
      bool c = Calibrate(W.mem, L, nat, 3, V3{}); CHECK(!c, "garbage memory calibrated"); printf("garbage memory: calibrate=%d (expected 0)\n", c); }
    { World W; W.v = vars[0]; Layout L; uint64_t nat[3] = { 0x7a0000100ULL, 0x7a0000200ULL, 0x7a0000300ULL };
      bool c = Calibrate(W.mem, L, nat, 3, V3{}); CHECK(!c, "unmapped memory calibrated"); printf("unmapped memory: calibrate=%d (expected 0)\n", c); }
    printf(fails ? "\n%d FAILED\n" : "\nALL PASSED\n", fails);
    return fails ? 1 : 0;
}
