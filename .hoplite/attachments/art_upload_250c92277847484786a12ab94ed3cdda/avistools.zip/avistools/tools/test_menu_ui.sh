#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
DIR=$(mktemp -d /tmp/avis_menu_ui.XXXXXX)
trap 'rm -rf "$DIR"' EXIT
python3 tools/preview/gen_stubs.py > "$DIR/stubs.cpp"
g++ -std=c++17 -O1 -w -DAVIS_PREVIEW -Iinclude -Iinclude/ImGui -Isrc -Isrc/trial \
 tools/test_menu_ui.cpp tools/preview/auth_stub.cpp "$DIR/stubs.cpp" \
 src/trial/trial_menu.cpp src/trial/trial_ui.cpp src/trial/trial_configs.cpp \
 src/trial/quick_actions.cpp src/trial/auto_heal.cpp src/trial/auth_screen.cpp src/trial/i18n.cpp src/auth/auth_sound.cpp \
 src/ImGui/imgui.cpp src/ImGui/imgui_draw.cpp src/ImGui/imgui_tables.cpp src/ImGui/imgui_widgets.cpp \
 -o "$DIR/test"
"$DIR/test"
