// Headless ImGui interaction test; no device, game, renderer, or network access.
#define AVIS_PREVIEW 1
#include "../src/trial/quick_actions.cpp"
#include <sys/stat.h>
#include <cstdlib>

Settings g_cfg{};
heal::Config g_autoHeal;
bool espdraw=false,espbox=false,esplines_enabled=false,skeleton=false,espname=false,espclan=false;
bool espweapon=false,espArmor=false,espdist=false,radarEnabled=false,oreEsp=false,animalEsp=false,baseEsp=false;
bool aimm=false,silentAim=false,noRecoil=false,noSpread=false,stretchOn=false;
bool boostDraw=false,boostGrass=false,boostTrees=false,boostNoLog=false;
ImTextureID GetTexture(int,ImVec2 *size){if(size)*size=ImVec2(0,0);return nullptr;}
namespace avis {static bool testActive=true;bool Active(){return testActive;}namespace snd {void Play(Sfx,int){}}}
static int fails=0;
#define CHECK(x) do{if(!(x)){++fails;printf("FAIL line %d: %s\n",__LINE__,#x);}}while(0)
static void FloatFrame(float x,float y,bool down){
 auto &io=ImGui::GetIO();io.MousePos=ImVec2(x,y);io.MouseDown[0]=down;io.DeltaTime=1.f/60.f;
 ImGui::NewFrame();bool menu=false;QuickActionsFrame(menu);ImGui::Render();
}
static void Tap(float x,float y){FloatFrame(x,y,false);FloatFrame(x,y,true);FloatFrame(x,y,false);}
static int comboValue=0;
static const char *items[]={"0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22"};
static void ComboFrame(float x,float y,bool down){
 auto &io=ImGui::GetIO();io.MousePos=ImVec2(x,y);io.MouseDown[0]=down;io.DeltaTime=1.f/60.f;ImGui::NewFrame();
 ImGui::SetNextWindowPos(ImVec2(50,50));ImGui::SetNextWindowSize(ImVec2(900,620));
 ImGui::Begin("qa_combo_test",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove);
 UI::O=ImVec2(100,100);UI::U=1.f;UI::DL=ImGui::GetWindowDrawList();UI::Block=UI::ComboOpen();
 UI::RowCombo("qa_test_combo","Function",&comboValue,items,23,180,508,300,170);
 UI::Block=false;UI::ComboPopup();ImGui::End();ImGui::Render();
}
static void ComboTap(float x,float y){ComboFrame(x,y,false);ComboFrame(x,y,true);ComboFrame(x,y,false);}
int main(){
 char dir[]="/tmp/avis_quick_ui_XXXXXX";CHECK(mkdtemp(dir)!=nullptr);
 ImGui::CreateContext();auto &io=ImGui::GetIO();io.IniFilename=nullptr;io.DisplaySize=ImVec2(1920,1080);
 ImFont *font=io.Fonts->AddFontDefault();unsigned char *px;int w,h;io.Fonts->GetTexDataAsRGBA32(&px,&w,&h);
 UI::FText=UI::FMed=UI::FTitle=font;g_cfg.rounding=12;g_cfg.anim=false;UI::U=1;
 QuickActionsInit(dir);g_config.enabled=true;
 float x=40.f+g_config.slots[0].x*1840.f,y=40.f+g_config.slots[0].y*1000.f;
 FloatFrame(0,0,false);Tap(x,y);CHECK(espdraw);
 FloatFrame(x,y,true);FloatFrame(x+120,y+60,true);FloatFrame(x+120,y+60,false);
 CHECK(espdraw);CHECK(g_config.slots[0].x>.92f && g_config.slots[0].y>.20f);
 x=40.f+g_config.slots[0].x*1840.f;y=40.f+g_config.slots[0].y*1000.f;
 Tap(x,y);CHECK(!espdraw);
 g_config.slots[0].action=quickcore::AutoHeal;Tap(x,y);CHECK(g_autoHeal.enabled);Tap(x,y);CHECK(!g_autoHeal.enabled);
 avis::testActive=false;Tap(x,y);CHECK(!espdraw);avis::testActive=true;
 for(int i=0;i<15;i++)QuickActionsSaveTick(.1f);
 std::string path=std::string(dir)+"/quick_actions.cfg";CHECK(access(path.c_str(),R_OK)==0);
 ComboFrame(0,0,false);ComboTap(500,400);CHECK(UI::ComboOpen());
 ComboTap(563,435);CHECK(UI::ComboOpen());ComboTap(563,435);CHECK(UI::ComboOpen());
 ComboTap(500,356);CHECK(comboValue==22 && !UI::ComboOpen());
 QuickActionsShutdown();unlink(path.c_str());rmdir(dir);ImGui::DestroyContext();
 puts(fails?"FAILED":"ALL OK");return fails!=0;
}
