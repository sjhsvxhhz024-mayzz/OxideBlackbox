// Хост-тест баллистики стрел: g++ -std=c++17 -O1 -Isrc tools/test_arrow_solver.cpp -o /tmp/t && /tmp/t
#include "silent_core.h"
#include <cstdio>
#include <initializer_list>
using namespace silentcore;
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { ++fails; printf("FAIL line %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

// Независимый интегратор (мелкий шаг, полная 3D-сцена): где окажется снаряд через t секунд, если выпущен по направлению d.
static V3 shoot(V3 from, V3 d, float v0, float g, float drag, float t) {
    const float l = len(d); V3 v = d * (v0 / l), p = from; const float dt = 0.001f, dec = expf(-drag * dt);
    for (float s = 0; s < t; s += dt) { p = p + v * dt; v.y -= g * dt; v = v * dec; }
    return p;
}
static float missDist(V3 from, const ArrowAim &a, V3 target, V3 tvel, float v0, float g, float drag) {
    const V3 hit = shoot(from, a.aim - from, v0, g, drag, a.tof);
    const V3 tp = target + tvel * a.tof;
    return len(hit - tp);
}

int main() {
    const V3 eye{ 0.f, 16.f, 0.f }, zero{ 0.f, 0.f, 0.f };
    {   // без гравитации и сопротивления: прямая линия на цель
        const V3 T{ 40.f, 18.f, 30.f };
        ArrowAim a = solveArrow(eye, T, zero, 80.f, 0.f, 0.f, false, 0.f);
        const V3 d = a.aim - eye, e = T - eye;
        const float c = dot(d, e) / (len(d) * len(e));
        CHECK(a.ok && c > 0.99999f, "straight line cos=%f", c);
        CHECK(fabsf(a.tof - len(e) / 80.f) < 0.01f, "tof %f vs %f", a.tof, len(e) / 80.f);
    }
    {   // аналитика: ровная земля, угол = 0.5·asin(gR/v²)
        const float v0 = 60.f, g = 9.81f, R = 50.f;
        ArrowAim a = solveArrow(eye, V3{ R, 16.f, 0.f }, zero, v0, g, 0.f, false, 0.f);
        const float want = 0.5f * asinf(g * R / (v0 * v0));
        CHECK(a.ok && fabsf(a.pitch - want) < 0.002f, "pitch %f want %f", a.pitch, want);
    }
    for (float drag : { 0.f, 0.15f, 0.6f })
        for (float v0 : { 45.f, 70.f, 110.f })
            for (float dist : { 15.f, 45.f, 90.f }) {
                const V3 T{ dist * 0.8f, 16.f + dist * 0.05f, dist * 0.6f };
                ArrowAim a = solveArrow(eye, T, zero, v0, 9.81f, drag, true, 0.f);
                if (!a.ok) { CHECK(dist >= 80.f || v0 < 60.f, "unexpected unreachable v0=%g dist=%g drag=%g", v0, dist, drag); continue; }
                const float m = missDist(eye, a, T, zero, v0, 9.81f, drag);
                CHECK(m < 0.25f, "static miss %.3f m (v0=%g dist=%g drag=%g)", m, v0, dist, drag);
            }
    {   // движущаяся цель: упреждение
        const V3 T{ 60.f, 16.f, 0.f }, V{ 0.f, 0.f, 6.f };
        ArrowAim a = solveArrow(eye, T, V, 70.f, 9.81f, 0.1f, true, 0.f);
        CHECK(a.ok, "moving target ok");
        const float m = missDist(eye, a, T, V, 70.f, 9.81f, 0.1f);
        CHECK(m < 0.35f, "moving miss %.3f m", m);
        ArrowAim b = solveArrow(eye, T, V, 70.f, 9.81f, 0.1f, false, 0.f);
        CHECK(missDist(eye, b, T, V, 70.f, 9.81f, 0.1f) > 1.5f, "without lead must miss a mover");
    }
    {   // цель выше глаз (снизу вверх) и ниже
        for (float dy : { 12.f, -20.f }) {
            const V3 T{ 40.f, 16.f + dy, 10.f };
            ArrowAim a = solveArrow(eye, T, zero, 70.f, 9.81f, 0.1f, false, 0.f);
            CHECK(a.ok && missDist(eye, a, T, zero, 70.f, 9.81f, 0.1f) < 0.25f, "dy=%g ok=%d", dy, (int)a.ok);
        }
    }
    {   // вне досягаемости: медленная стрела, большая дальность
        ArrowAim a = solveArrow(eye, V3{ 400.f, 16.f, 0.f }, zero, 30.f, 9.81f, 0.1f, false, 0.f);
        CHECK(!a.ok, "400 m at 30 m/s must be unreachable");
    }
    {   // вырожденные входы
        CHECK(!solveArrow(eye, V3{ 10.f, 16.f, 0.f }, zero, 0.f, 9.81f, 0.f, false, 0.f).ok, "v0=0");
        ArrowAim a = solveArrow(eye, V3{ 0.1f, 16.f, 0.1f }, zero, 60.f, 9.81f, 0.f, false, 0.f);
        CHECK(a.ok, "target above the eye at ~0 range");
        ArrowAim h = solveArrow(eye, V3{ 40.f, 16.f, 0.f }, zero, 60.f, -9.81f, 0.f, false, 0.f);
        CHECK(h.ok && h.pitch > 0.f, "negative gravity treated as magnitude");
    }
    printf(fails ? "FAILED: %d\n" : "ALL OK\n", fails);
    return fails ? 1 : 0;
}
