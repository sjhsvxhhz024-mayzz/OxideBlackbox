#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
g++ -std=c++17 -O1 -Wall -pthread -Isrc tools/test_auth_retry.cpp src/auth/auth_client.cpp -o /tmp/avis_test_auth_retry
/tmp/avis_test_auth_retry
