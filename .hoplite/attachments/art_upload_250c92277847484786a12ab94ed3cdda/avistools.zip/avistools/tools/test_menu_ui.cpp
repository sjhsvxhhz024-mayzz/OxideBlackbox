// Actual menu + auth-screen interaction, headless ImGui; no game/server/device.
#include "trial_config.h"
#include "trial_ui.h"
#include "auth/auth_client.h"
#include "trial_configs.h"
#include "imgui_internal.h"
#include <cassert>
#include <cstdio>
#include <cmath>
#include <sys/stat.h>
ImTextureID GetTexture(int,ImVec2 *s){if(s)*s=ImVec2();return nullptr;}
void TrialUploadTextures(){}
extern bool AuthScreenRender();
extern int AuthPreviewLength();
extern void AuthPreviewType(const char *);
extern void MenuPreviewSelect(int,int);
extern int MenuPreviewTab();
extern bool MenuPreviewOpen();
extern float MenuPreviewOpenFraction();
extern bool cupboardFinder, cupboardGuide;
extern float cupboardRadius;
namespace avis {void PreviewSet(const Snapshot&,bool);extern int previewSubmissions;extern std::string previewSubmittedKey;}
static void Frame(bool auth,float x=0,float y=0,bool down=false){
 auto &io=ImGui::GetIO();io.MousePos=ImVec2(x,y);io.MouseDown[0]=down;io.DeltaTime=1.f/60.f;
 ImGui::NewFrame();if(auth){if(!AuthScreenRender())Menu::Render();}else Menu::Render();ImGui::Render();
 auto *dd=ImGui::GetDrawData();
 for(int l=0;l<dd->CmdListsCount;++l)for(const auto &v:dd->CmdLists[l]->VtxBuffer){assert(std::isfinite(v.pos.x)&&std::isfinite(v.pos.y));}
}
static void Tap(float x,float y){Frame(true,x,y);Frame(true,x,y,true);Frame(true,x,y);}
int main(){
 char dir[]="/tmp/avis_menu_test_XXXXXX";assert(mkdtemp(dir));g_DataDir=dir;
 ImGui::CreateContext();auto &io=ImGui::GetIO();io.IniFilename=nullptr;io.DisplaySize=ImVec2(1600,900);
 auto *f=io.Fonts->AddFontDefault();unsigned char *p;int w,h;io.Fonts->GetTexDataAsRGBA32(&p,&w,&h);
 g_trialFontText=g_trialFontMed=g_trialFontTitle=f;Menu::Init(1600,900);g_cfg.anim=false;g_cfg.particles=false;
 avis::Snapshot snap;snap.phase=avis::Phase::NeedKey;avis::PreviewSet(snap,false);
 Frame(true);auto at=[](float x,float y){return UI::P(x,y);};
 auto c=at(103,279); // key '2': row 1, column 2
 Tap(c.x,c.y);assert(AuthPreviewLength()==1);
 auto invalid=at(44,279);Tap(invalid.x,invalid.y);assert(AuthPreviewLength()==1); // '1' excluded
 AuthPreviewType("7KQ2M9XPLR4T");Frame(true);auto enter=at(565,487);Tap(enter.x,enter.y);
 assert(avis::previewSubmissions==1 && avis::previewSubmittedKey=="AVIS-7KQ2-M9XP-LR4T");
 snap.phase=avis::Phase::Checking;avis::PreviewSet(snap,false);Frame(true);auto clear=at(59,435);Tap(clear.x,clear.y);assert(AuthPreviewLength()==12);
 snap.phase=avis::Phase::NeedKey;avis::PreviewSet(snap,false);Tap(clear.x,clear.y);assert(AuthPreviewLength()==0);
 snap.phase=avis::Phase::Checking;snap.retrying=true;snap.retryInSec=5;avis::PreviewSet(snap,false);Frame(true);
 auto cancel=at(320,472);Tap(cancel.x,cancel.y);assert(avis::Get().phase==avis::Phase::NeedKey);
 // Emulate an auth button still owning ImGui when an asynchronous response arrives.
 auto *authWindow=ImGui::FindWindowByName("##avis_key");assert(authWindow);
 ImGui::SetActiveID(authWindow->GetID("##paste"),authWindow);
 g_cfg.anim=true;
 snap.phase=avis::Phase::Active;snap.remainingSec=85000;avis::PreviewSet(snap,true);
 // Follow the real auth-success handoff instead of skipping directly to Menu.
 for(int i=0;i<160;++i)Frame(true);
 for(int i=0;i<10;++i){Frame(true);assert(MenuPreviewOpenFraction()==1.f);}
 auto aimTab=at(90,212);Tap(aimTab.x,aimTab.y);assert(MenuPreviewTab()==1);
 auto visualTab=at(90,146);Tap(visualTab.x,visualTab.y);assert(MenuPreviewTab()==0);
 for(int lang=0;lang<2;++lang){g_cfg.lang=lang;for(int t=0;t<6;++t){auto p=at(90,146+t*66);Tap(p.x,p.y);assert(MenuPreviewTab()==t);}}
 auto *pill=ImGui::FindWindowByName("##trial_enemies");assert(pill);
 auto center=pill->Pos+pill->Size*.5f;Tap(center.x,center.y);assert(!MenuPreviewOpen());
 for(int i=0;i<45;++i)Frame(true);
 Tap(center.x,center.y);assert(MenuPreviewOpen());for(int i=0;i<45;++i)Frame(true);
 auto again=at(90,212);Tap(again.x,again.y);assert(MenuPreviewTab()==1);
 g_cfg.anim=false;
 const int subs[]={8,1,2,5,1,3};
 for(int lang=0;lang<2;++lang){g_cfg.lang=lang;for(int t=0;t<6;++t)for(int s=0;s<subs[t];++s){MenuPreviewSelect(t,s);Frame(false);Frame(false);}}
 // Base card: six left rows, a separate cupboard mode and radius slider.
 g_cfg.lang=0;MenuPreviewSelect(0,4);Frame(false);Frame(false);
 cupboardFinder=false;
 auto toggle=at(430,391);Frame(false,toggle.x,toggle.y);Frame(false,toggle.x,toggle.y,true);Frame(false,toggle.x,toggle.y);
 assert(cupboardFinder);
 cupboardRadius=100;
 auto slider=at(400,453);Frame(false,slider.x,slider.y);Frame(false,slider.x,slider.y,true);Frame(false,slider.x,slider.y);
 assert(cupboardRadius>100 && cupboardRadius<=800);
 cupboardGuide=false;const float savedRadius=cupboardRadius;
 assert(Cfg_SaveSlot(0));cupboardFinder=false;cupboardGuide=true;cupboardRadius=5;
 assert(Cfg_LoadSlot(0));assert(cupboardFinder && !cupboardGuide && std::fabs(cupboardRadius-savedRadius)<.02f);
 assert(Cfg_DeleteSlot(0));rmdir((g_DataDir+"/configs").c_str());
 io.DisplaySize=ImVec2(900,450);g_cfg.uiScale=120;Frame(false);assert(UI::WinW*UI::U<=900*.94f+1);assert(UI::WinH*UI::U<=450*.92f+1);
 Menu::Shutdown();for(auto name:{"quick_actions.cfg","auto_heal.cfg","trial_settings.bin","settings.cfg"})unlink((g_DataDir+"/"+name).c_str());rmdir(g_DataDir.c_str());
 ImGui::DestroyContext();puts("ALL OK");
}
