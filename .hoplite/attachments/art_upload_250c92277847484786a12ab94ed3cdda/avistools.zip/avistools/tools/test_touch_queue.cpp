#include "touch_input_queue.h"
#include <cassert>
#include <thread>
#include <cstdio>
int main(){
 touchinput::Queue q;
 assert(!touchinput::ValidSlot(-1)&&!touchinput::ValidSlot(10)&&touchinput::ValidSlot(9));
 q.Push({10,20,true});q.Push({12,23,true});q.Push({0,0,false});
 auto events=q.Take();assert(events.size()==3&&events[0].x==10&&events[0].down&&events[1].x==12&&!events[2].down);
 assert(q.Take().empty());
 std::thread a([&]{for(int i=0;i<10000;++i)q.Push({float(i),float(i),bool(i%2)});});
 for(int i=0;i<10000;++i){auto e=q.Take();assert(e.size()<=256);}
 a.join();q.Clear();assert(q.Take().empty());puts("ALL OK");
}
