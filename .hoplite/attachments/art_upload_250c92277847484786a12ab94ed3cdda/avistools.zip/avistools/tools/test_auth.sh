#!/usr/bin/env bash
# Хост-тест клиента ключей против настоящего сервера (HTTP и HTTPS). Нужны: g++, gcc, python3 с aiohttp и cryptography.
#   PY=/path/to/python bash tools/test_auth.sh
set -euo pipefail
cd "$(dirname "$0")/.."
PY="${PY:-python3}"
export AVIS_TEST_IDENTITY="${AVIS_TEST_IDENTITY:-$("$PY" -c 'import secrets; print(secrets.token_hex(16))')}"
M=third_party/mbedtls
OBJ=/tmp/avis_mbedtls_host
mkdir -p "$OBJ"
if [ ! -f "$OBJ/libmbedtls.a" ]; then
    echo ">> собираю mbedtls для хоста (один раз)"
    ls $M/library/*.c | xargs -P"$(nproc)" -I{} sh -c "gcc -O2 -w -c -I$M/include -I$M/library {} -o $OBJ/\$(basename {} .c).o"
    ar rcs "$OBJ/libmbedtls.a" "$OBJ"/*.o
fi
g++ -std=c++17 -O1 -Wall -Wno-unused-result -Isrc -I$M/include tools/test_auth.cpp src/auth/auth_client.cpp src/auth/auth_clip.cpp src/auth/auth_net.cpp src/auth/auth_proto.cpp "$OBJ/libmbedtls.a" -lpthread -o /tmp/avis_test_auth

mkfifo /tmp/avis_srv_in 2>/dev/null || true
"$PY" server/tests/serve_for_client.py < <(tail -f /dev/null) > /tmp/avis_srv_out 2>/tmp/avis_srv_err &
SRV=$!
trap 'kill $SRV 2>/dev/null || true' EXIT
for _ in $(seq 1 50); do [ -s /tmp/avis_srv_out ] && break; sleep 0.1; done
HTTP=$("$PY" -c "import json;print(json.load(open('/tmp/avis_srv_out'))['http'])")
HTTPS=$("$PY" -c "import json;print(json.load(open('/tmp/avis_srv_out'))['https'])")
KEY=$("$PY" -c "import json;print(json.load(open('/tmp/avis_srv_out'))['key'])")
echo "== HTTP  $HTTP";  /tmp/avis_test_auth "$HTTP" "$KEY"
echo "== HTTPS $HTTPS"; /tmp/avis_test_auth "$HTTPS" "$KEY"
