// Хост-тест растяжения: g++ -std=c++17 -O1 -Wall -Isrc tools/test_stretch_core.cpp -o /tmp/t && /tmp/t
// Моделируется нативная камера Unity: матрицы, поле m_Aspect, флаги, пересчёт проекции движком раз в кадр.
#include "stretch_core.h"
#include <cstdio>
#include <vector>
using namespace stretch;
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { ++fails; printf("FAIL line %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

enum class Model { A_AspectOnly, B_NeedsFlag, C_NoReaction };

struct FakeCam {
    uint64_t base = 0x7000000000ULL;
    std::vector<uint8_t> mem = std::vector<uint8_t>(0x800, 0);
    int viewOff = 0x70, projOff = 0xB0, aspOff = 0x2A4, flagOff = 0x2A4 + 20, nearOff = 0x27C, farOff = 0x280;
    bool farReacts = true;   // как в Unity 4.3: флаги через 12 байт после m_Aspect
    Model model = Model::A_AspectOnly;
    float fov = 60.f, screen = 2400.f / 1080.f;
    int writes = 0; bool freeze = false;
    float getF(int o) const { float v; memcpy(&v, &mem[o], 4); return v; }
    void setF(int o, float v) { memcpy(&mem[o], &v, 4); }
    void init(float aspectField) {
        std::fill(mem.begin(), mem.end(), 0);
        setF(aspOff, aspectField); setF(nearOff, 0.3f); setF(farOff, 1000.f);
        mem[aspOff + 4] = 0; mem[aspOff + 12] = 1;               // DepthTextureMode-подобное значение
        mem[aspOff + 18] = 1;                                     // ImplicitWorldToCameraMatrix
        mem[aspOff + 19] = 1;                                     // ImplicitProjectionMatrix
        mem[flagOff] = 1;                                         // ImplicitAspect
        for (int i = 0; i < 16; ++i) { setF(viewOff + 4 * i, i % 5 == 0 ? 1.f : 0.f); }
        engineFrame();
    }
    // Кадр движка: LateUpdate игры пишет fov (-> проекция пересчитывается).
    void engineFrame() {
        if (freeze) return;
        float asp = getF(aspOff);
        if (model == Model::B_NeedsFlag && mem[flagOff] == 1) { asp = screen; setF(aspOff, screen); }   // неявный aspect переписывается каждый кадр
        if (model == Model::C_NoReaction) asp = screen;                                                   // aspect берётся не из этого поля
        if (mem[aspOff + 19] == 0 && model != Model::C_NoReaction) return;                                // явная матрица: движок не пересчитывает
        const float cot = 1.f / tanf(fov * 0.5f * 3.14159265f / 180.f);
        float P[16] = { 0 };
        const float n = getF(nearOff), f = farReacts ? getF(farOff) : 1000.f;
        P[0] = cot / asp; P[5] = cot; P[10] = -(f + n) / (f - n); P[11] = -1.f; P[14] = -2.f * f * n / (f - n);
        memcpy(&mem[projOff], P, 64);
    }
    void windowChanged() { if (model == Model::A_AspectOnly) setF(aspOff, screen); }     // смена размера окна при неявном aspect
    float eff() const { float P[16]; memcpy(P, &mem[projOff], 64); return P[5] / P[0]; }
    float farEff() const { float P[16]; memcpy(P, &mem[projOff], 64); float f = 0; farFromProj(P, f); return f; }
    bool rd(uint64_t a, void *b, size_t n) { if (a < base || a + n > base + mem.size()) return false; memcpy(b, &mem[a - base], n); return true; }
    bool wr(uint64_t a, const void *b, size_t n) { if (a < base || a + n > base + mem.size()) return false; memcpy(&mem[a - base], b, n); ++writes; return true; }
};

struct Run {
    Engine e; FakeCam c; double now = 100.0;
    explicit Run(Kind k = Kind::Aspect) : e(k) {}
    void tickN(int n, bool want, float target) { for (int i = 0; i < n; ++i) { c.engineFrame(); e.tick(c, c.base, c.projOff, c.viewOff, want, target, c.screen, now); now += 0.016; } }
};

int main() {
    {   // Пресеты и ограничения.
        CHECK(fabsf(presetAspect(3, 0) - 4.f / 3.f) < 1e-6f && fabsf(presetAspect(4, 0) - 1.25f) < 1e-6f && fabsf(presetAspect(5, 0) - 1.f) < 1e-6f, "presets");
        CHECK(fabsf(presetAspect(0, 0) - 16.f / 9.f) < 1e-6f && fabsf(presetAspect(1, 0) - 1.6f) < 1e-6f && fabsf(presetAspect(2, 0) - 1.5f) < 1e-6f, "presets 2");
        CHECK(fabsf(presetAspect(6, 1.9f) - 1.9f) < 1e-6f && presetAspect(6, 99.f) == 3.f && presetAspect(6, -1.f) == 0.5f && fabsf(presetAspect(6, NAN) - 4.f / 3.f) < 1e-6f, "custom clamp");
        float a; const float P1[16] = { 0.8f, 0, 0, 0, 0, 1.6f, 0, 0, 0, 0, -1, -1, 0, 0, -0.2f, 0 };
        CHECK(aspectFromProj(P1, a) && fabsf(a - 2.f) < 1e-6f, "aspectFromProj");
        float P2[16]; memcpy(P2, P1, 64); P2[11] = 0.f; CHECK(!aspectFromProj(P2, a), "orthographic rejected");
        memcpy(P2, P1, 64); P2[0] = NAN; CHECK(!aspectFromProj(P2, a), "nan rejected");
        CHECK(std::string(presetLabel(3)) == "4:3" && std::string(presetLabel(6)) == "Custom", "labels");
    }
    {   // Модель A: достаточно поля. Флаг не трогается, выключение возвращает значение.
        Run r; r.c.init(r.c.screen);
        const std::vector<uint8_t> before = r.c.mem;
        r.tickN(60, true, 4.f / 3.f);
        CHECK(r.e.state == State::Active, "A active (state %d)", (int)r.e.state);
        CHECK(fabsf(r.c.eff() - 4.f / 3.f) < 0.01f, "A eff %.4f", r.c.eff());
        CHECK(r.e.aspectOffset() == r.c.aspOff && r.e.flagOffset() == -1, "A offsets %x %d", r.e.aspectOffset(), r.e.flagOffset());
        CHECK(r.c.mem[r.c.flagOff] == 1 && r.c.mem[r.c.aspOff + 18] == 1 && r.c.mem[r.c.aspOff + 19] == 1, "A flags untouched");
        r.tickN(5, true, 1.25f); CHECK(fabsf(r.c.eff() - 1.25f) < 0.01f, "A retarget eff %.4f", r.c.eff());
        r.tickN(5, false, 1.25f);
        CHECK(r.e.state == State::Idle && fabsf(r.c.getF(r.c.aspOff) - r.c.screen) < 1e-5f, "A off restores field %.4f", r.c.getF(r.c.aspOff));
        r.tickN(3, false, 1.25f); CHECK(fabsf(r.c.eff() - r.c.screen) < 0.01f, "A off eff %.4f", r.c.eff());
        for (size_t i = 0; i < before.size(); ++i) if ((int)i < r.c.projOff || (int)i >= r.c.projOff + 64) CHECK(before[i] == r.c.mem[i], "A byte %zu changed after off", i);
        auto lg = r.e.drain(); bool conf = false; for (auto &s : lg) if (s.find("CONFIRMED") != std::string::npos) conf = true; CHECK(conf, "A confirmation logged");
    }
    {   // Модель B: aspect переписывается, пока ImplicitAspect=1 -> нужен флаг; ложные кандидаты откатываются.
        Run r; r.c.model = Model::B_NeedsFlag; r.c.init(r.c.screen);
        r.tickN(200, true, 1.5f);
        CHECK(r.e.state == State::Active, "B active (state %d) %s", (int)r.e.state, r.e.status.c_str());
        CHECK(r.e.flagOffset() == r.c.flagOff, "B flag at %x want %x", r.e.flagOffset(), r.c.flagOff);
        CHECK(r.c.mem[r.c.flagOff] == 0 && r.c.mem[r.c.aspOff + 18] == 1 && r.c.mem[r.c.aspOff + 19] == 1, "B decoy flags rolled back (%d %d) flag %d", r.c.mem[r.c.aspOff + 18], r.c.mem[r.c.aspOff + 19], r.c.mem[r.c.flagOff]);
        CHECK(fabsf(r.c.eff() - 1.5f) < 0.01f, "B eff %.4f", r.c.eff());
        r.tickN(5, false, 1.5f);
        CHECK(r.c.mem[r.c.flagOff] == 1 && r.c.mem[r.c.aspOff + 18] == 1 && r.c.mem[r.c.aspOff + 19] == 1, "B flags restored");
        CHECK(fabsf(r.c.getF(r.c.aspOff) - r.c.screen) < 1e-5f, "B field restored");
    }
    {   // Модель C: реакции нет -> откат побайтно, Failed, повтор не чаще раза в 20 с.
        Run r; r.c.model = Model::C_NoReaction; r.c.init(r.c.screen);
        const std::vector<uint8_t> before = r.c.mem;
        r.tickN(400, true, 4.f / 3.f);
        CHECK(r.e.state == State::Failed, "C failed (state %d)", (int)r.e.state);
        CHECK(r.c.mem == before, "C memory must be byte-identical after failure");
        const int w0 = r.c.writes; r.tickN(600, true, 4.f / 3.f);
        CHECK(r.c.writes - w0 < 60 && r.c.mem == before, "C retry throttled: %d extra writes", r.c.writes - w0);
        CHECK(r.e.status.find("did not react") != std::string::npos || r.e.status.find("retrying") != std::string::npos, "C status '%s'", r.e.status.c_str());
    }
    {   // Дрейф: движок сбросил aspect (смена окна) -> запись повторяется.
        Run r; r.c.init(r.c.screen); r.tickN(60, true, 4.f / 3.f);
        CHECK(r.e.state == State::Active, "drift setup");
        r.c.windowChanged(); r.tickN(8, true, 4.f / 3.f);
        CHECK(fabsf(r.c.eff() - 4.f / 3.f) < 0.01f && r.e.state == State::Active, "drift re-applied eff %.4f", r.c.eff());
    }
    {   // Смена объекта камеры (респавн): смещения известны -> быстрое применение без нового поиска.
        Run r; r.c.init(r.c.screen); r.tickN(60, true, 4.f / 3.f);
        const int scans = r.e.scans;
        FakeCam n2; n2.base = 0x7100000000ULL; n2.init(n2.screen);
        for (int i = 0; i < 40; ++i) { n2.engineFrame(); r.e.tick(n2, n2.base, n2.projOff, n2.viewOff, true, 4.f / 3.f, n2.screen, r.now); r.now += 0.016; }
        CHECK(r.e.state == State::Active && fabsf(n2.eff() - 4.f / 3.f) < 0.01f, "new camera eff %.4f state %d", n2.eff(), (int)r.e.state);
        CHECK(r.e.scans == scans, "no rescan on same layout: %d -> %d", scans, r.e.scans);
    }
    {   // Остаток прошлого запуска: поле уже растянуто; после выключения — родной экран, а не остаток.
        Run r; r.c.init(1.3333f);
        r.tickN(60, true, 1.25f);
        CHECK(r.e.state == State::Active, "leftover active (%d) %s", (int)r.e.state, r.e.status.c_str());
        r.tickN(5, false, 1.25f);
        CHECK(fabsf(r.c.getF(r.c.aspOff) - r.c.screen) < 1e-4f, "leftover restored to the screen, got %.4f", r.c.getF(r.c.aspOff));
    }
    {   // Нет поля, равного aspect.
        Run r; r.c.model = Model::C_NoReaction; r.c.init(r.c.screen); r.c.setF(r.c.aspOff, 7.7f);   // aspect матрицы берётся не из полей камеры
        const std::vector<uint8_t> before = r.c.mem;
        r.tickN(20, true, 4.f / 3.f);
        CHECK(r.e.state == State::Failed && r.c.writes == 0, "no candidate: state %d writes %d", (int)r.e.state, r.c.writes);
        CHECK(r.e.status.find("no float equal") != std::string::npos, "status '%s'", r.e.status.c_str());
        (void)before;
    }
    {   // Слишком много совпадений.
        Run r; r.c.init(r.c.screen);
        for (int k = 0; k < 8; ++k) r.c.setF(0x300 + 4 * k, r.c.screen);
        r.tickN(20, true, 4.f / 3.f);
        CHECK(r.e.state == State::Failed && r.c.writes == 0, "ambiguous: state %d writes %d", (int)r.e.state, r.c.writes);
    }
    {   // Выключено с самого начала: ни одной записи, даже при нечитаемой матрице.
        Run r; r.c.init(r.c.screen); r.tickN(100, false, 4.f / 3.f);
        CHECK(r.c.writes == 0 && r.e.state == State::Idle, "off from start writes %d", r.c.writes);
        r.c.freeze = true;
        r.c.mem[r.c.projOff + 44] = 0; r.c.mem[r.c.projOff + 45] = 0; r.c.mem[r.c.projOff + 46] = 0; r.c.mem[r.c.projOff + 47] = 0;   // m23 = 0 -> не перспектива
        r.tickN(20, true, 4.f / 3.f);
        CHECK(r.c.writes == 0, "no writes while the matrix is not a perspective (%d)", r.c.writes);
    }
    {   // Камера вне окна чтения: не падаем, не пишем.
        Run r; r.c.init(r.c.screen);
        for (int i = 0; i < 10; ++i) r.e.tick(r.c, 0x1234, r.c.projOff, r.c.viewOff, true, 1.3f, r.c.screen, r.now += 0.016);
        CHECK(r.c.writes == 0, "bad pointer writes %d", r.c.writes);
    }
    {   // Выключение в момент проверки возвращает всё.
        Run r; r.c.model = Model::B_NeedsFlag; r.c.init(r.c.screen);
        const std::vector<uint8_t> before = r.c.mem;
        r.tickN(70, true, 1.25f);                               // середина перебора вариантов
        r.tickN(3, false, 1.25f);
        for (size_t i = 0; i < before.size(); ++i) if ((int)i < r.c.projOff || (int)i >= r.c.projOff + 64) CHECK(before[i] == r.c.mem[i], "off mid-probe byte %zu differs (%d vs %d)", i, before[i], r.c.mem[i]);
    }
    {   // Дальность отрисовки: far берётся из матрицы, поле находится и подтверждается реакцией матрицы.
        float f = 0; const float P[16] = { 1, 0, 0, 0, 0, 1.7f, 0, 0, 0, 0, -(1000.f + 0.3f) / (1000.f - 0.3f), -1, 0, 0, -2.f * 1000.f * 0.3f / (1000.f - 0.3f), 0 };
        CHECK(farFromProj(P, f) && fabsf(f - 1000.f) < 3.f, "farFromProj %.2f", f);
        float Q[16]; memcpy(Q, P, 64); Q[11] = 0; CHECK(!farFromProj(Q, f), "ortho rejected");
        memcpy(Q, P, 64); Q[10] = -0.5f; CHECK(!farFromProj(Q, f), "bad m22 rejected");
        CHECK(clampFar(5.f) == 50.f && clampFar(99999.f) == 3000.f && clampFar(NAN) == 300.f, "clampFar");

        Run r(Kind::FarClip); r.c.init(r.c.screen);
        const std::vector<uint8_t> before = r.c.mem;
        r.tickN(60, true, 300.f);
        CHECK(r.e.state == State::Active, "far active (%d) %s", (int)r.e.state, r.e.status.c_str());
        CHECK(fabsf(r.c.farEff() - 300.f) < 6.f, "far effective %.1f", r.c.farEff());
        CHECK(r.e.aspectOffset() == r.c.farOff && r.e.flagOffset() == -1, "far offset %x flag %d", r.e.aspectOffset(), r.e.flagOffset());
        CHECK(fabsf(r.c.getF(r.c.nearOff) - 0.3f) < 1e-6f && fabsf(r.c.getF(r.c.aspOff) - r.c.screen) < 1e-6f, "near and aspect untouched");
        r.tickN(5, true, 150.f); CHECK(fabsf(r.c.farEff() - 150.f) < 4.f, "far retarget %.1f", r.c.farEff());
        r.tickN(5, false, 150.f);
        CHECK(r.e.state == State::Idle && fabsf(r.c.getF(r.c.farOff) - 1000.f) < 1e-3f, "far restored %.1f", r.c.getF(r.c.farOff));
        for (size_t i = 0; i < before.size(); ++i) if ((int)i < r.c.projOff || (int)i >= r.c.projOff + 64) CHECK(before[i] == r.c.mem[i], "far off: byte %zu changed", i);
    }
    {   // Обе подмены вместе на одной камере не мешают друг другу.
        Run a(Kind::Aspect), b(Kind::FarClip); a.c.init(a.c.screen); b.c = a.c;
        for (int i = 0; i < 120; ++i) {
            a.c.engineFrame();
            a.e.tick(a.c, a.c.base, a.c.projOff, a.c.viewOff, true, 4.f / 3.f, a.c.screen, a.now);
            b.c.mem = a.c.mem;
            b.e.tick(a.c, a.c.base, a.c.projOff, a.c.viewOff, true, 400.f, a.c.screen, a.now); a.now += 0.016;
        }
        CHECK(a.e.state == State::Active && b.e.state == State::Active, "both active %d %d", (int)a.e.state, (int)b.e.state);
        CHECK(fabsf(a.c.eff() - 4.f / 3.f) < 0.01f && fabsf(a.c.farEff() - 400.f) < 8.f, "both effective %.3f %.1f", a.c.eff(), a.c.farEff());
    }
    {   // Дальность: матрица не реагирует -> откат и отказ, без остатков.
        Run r(Kind::FarClip); r.c.farReacts = false; r.c.init(r.c.screen);
        const std::vector<uint8_t> before = r.c.mem;
        r.tickN(400, true, 300.f);
        CHECK(r.e.state == State::Failed && r.c.mem == before, "far no reaction: state %d, memory identical %d", (int)r.e.state, (int)(r.c.mem == before));
    }
    printf(fails ? "FAILED: %d\n" : "ALL OK\n", fails);
    return fails ? 1 : 0;
}
