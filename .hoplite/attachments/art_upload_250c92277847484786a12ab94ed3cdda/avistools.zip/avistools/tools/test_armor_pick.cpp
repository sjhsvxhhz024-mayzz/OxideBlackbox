#include <string>
#include <vector>
#include <cstdio>
#include <cctype>
static int ox_armorSlot(const std::string &name) {
    std::string l;
    for (char c : name) if (isalnum((unsigned char)c)) l.push_back((char)tolower((unsigned char)c));
    auto has = [&](const char *w) { return l.find(w) != std::string::npos; };
    if (has("hazmat") || has("militaryarmor") || has("fullsuit") || has("costume")) return 4;
    if (has("boot") || has("feet") || has("foot") || has("shoe") || has("sneaker") || has("sandal")) return 3;
    if (has("legging") || has("leggin") || has("legs") || has("leg") || has("pants") || has("trouser")) return 2;
    if (has("chest") || has("torso") || has("vest") || has("jacket") || has("body") || has("plate") || has("top") || has("coat") || has("shirt")) return 1;
    if (has("helmet") || has("mask") || has("head") || has("hat") || has("cap") || has("hood") || has("helm") || has("pumpkin") || has("crown")) return 0;
    return -1;
}

// Качество брони по названию: у игрока кроме брони бывает включена косметика и обычная одежда в тех же слотах, и побеждать должна
// настоящая броня высшего класса, а не запись с большим индексом. 0 — косметика (берётся, только если лучше ничего нет).
static int ox_armorRank(const std::string &name) {
    std::string l;
    for (char c : name) if (isalnum((unsigned char)c)) l.push_back((char)tolower((unsigned char)c));
    auto has = [&](const char *w) { return l.find(w) != std::string::npos; };
    if (has("pumpkin") || has("santa") || has("witch") || has("elfhat") || has("party") || has("cone") || has("christmas") || has("crown")) return 0;
    if (has("military") || has("mvk")) return 6;
    if (has("hazmat")) return 5;
    if (has("metal") || has("iron") || has("steel")) return 4;
    if (has("bone")) return 3;
    if (has("leather")) return 2;
    if (has("wood")) return 1;
    return 2;                                                   // неизвестный материал — считаем бронёй
}


static std::vector<std::string> pick(const std::vector<std::string>& names) {
    std::vector<std::string> out;
    std::string bySlot[5]; int bestRank[5] = { -1,-1,-1,-1,-1 }; std::vector<std::string> unslotted;
    for (auto &n : names) { int k = ox_armorSlot(n); if (k < 0) { if (ox_armorRank(n) > 0) unslotted.push_back(n); continue; } int r = ox_armorRank(n); if (r > bestRank[k]) { bestRank[k] = r; bySlot[k] = n; } }
    if (bySlot[4].empty()) { size_t u = 0; for (int k = 0; k < 4 && u < unslotted.size(); ++k) if (bySlot[k].empty()) { bySlot[k] = unslotted[u++]; bestRank[k] = ox_armorRank(bySlot[k]); } }
    if (!bySlot[4].empty() && bestRank[4] > 0) out.push_back(bySlot[4]); else for (int k = 0; k < 4; ++k) if (!bySlot[k].empty() && bestRank[k] > 0) out.push_back(bySlot[k]);
    return out;
}
int main() {
    int fails = 0;
    auto check = [&](const char *title, std::vector<std::string> in, std::vector<std::string> want) {
        auto got = pick(in); bool ok = got == want; if (!ok) ++fails;
        printf("%s %s ->", ok ? "OK  " : "FAIL", title); for (auto &g : got) printf(" [%s]", g.c_str()); printf("\n");
    };
    // полный MVK + кость и косметика в тех же слотах
    check("mvk full + bone + pumpkin", { "bone_chestplate", "bone_boots", "metal_mask_military", "metal_chestplate_military", "metal_leggins_military", "metal_boots_military", "pumpkin_hat" },
          { "metal_mask_military", "metal_chestplate_military", "metal_leggins_military", "metal_boots_military" });
    check("dotted ids", { "military.helmet", "military.chestplate", "military.leggings", "military.boots" }, { "military.helmet", "military.chestplate", "military.leggings", "military.boots" });
    check("nonstandard names", { "mvk_head", "mvk_vest", "mvk_pants", "mvk_shoes" }, { "mvk_head", "mvk_vest", "mvk_pants", "mvk_shoes" });
    check("unknown names fill the empty slots in index order", { "metal_mask_military", "xq_alpha", "metal_leggins_military", "xq_beta" }, { "metal_mask_military", "xq_alpha", "metal_leggins_military", "xq_beta" });
    check("metal beats bone beats leather", { "leather_chestplate", "bone_chestplate", "metal_chestplate" }, { "metal_chestplate" });
    check("cosmetic only when nothing better is absent", { "pumpkin_hat" }, { });
    check("hazmat suit replaces all", { "hazmat_suit", "bone_boots" }, { "hazmat_suit" });
    printf(fails ? "FAILED %d\n" : "ALL OK\n", fails);
}
