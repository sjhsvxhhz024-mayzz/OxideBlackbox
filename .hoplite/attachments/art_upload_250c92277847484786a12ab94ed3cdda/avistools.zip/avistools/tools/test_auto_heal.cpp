#include "auto_heal_core.h"
#include <cassert>
#include <cstdio>
#include <limits>
using namespace heal;
static Config Configured(){Config c;c.enabled=true;c.width=1600;c.height=900;c.rotation=1;c.delay=500;c.cooldown=2000;for(auto&p:c.points)p={.5f,.5f};return c;}
static Sample Ready(){Sample s;s.now=1;s.valid=s.allowed=true;s.owner=7;s.percent=20;s.selected=0;s.width=1600;s.height=900;s.rotation=1;s.items={10,11,12,13,14,15};s.medical=true;return s;}
static void Dose(Controller&t,Config&c,Sample&s){
 auto r=t.Tick(c,s);assert(r.action==Action::Select&&r.point==5);
 s.now+=.1;assert(t.Tick(c,s).action==Action::None);assert(t.State()==Phase::Selecting);
 t.Tick(c,s,1);assert(t.State()==Phase::WaitSelected);
 s.selected=5;s.now+=.1;t.Tick(c,s);assert(t.State()==Phase::Using);
 r=t.Tick(c,s);assert(r.action==Action::Use&&r.point==6);
 s.now+=.1;t.Tick(c,s,1);assert(t.Doses()==1&&t.State()==Phase::WaitEffect);
 s.now+=.6;t.Tick(c,s);assert(t.State()==Phase::Returning);
 r=t.Tick(c,s);assert(r.action==Action::Return&&r.point==0);
 s.now+=.1;t.Tick(c,s,1);assert(t.State()==Phase::Cooldown);s.selected=0;
}
int main(){
 Config c=Configured();Sample s=Ready();Controller t;Dose(t,c,s);
 s.now+=2.1;t.Tick(c,s);assert(t.State()==Phase::Blocked); // no endless consumption when HP does not rise
 s.percent=45;t.Tick(c,s);assert(t.State()==Phase::Idle&&t.Doses()==0);
 s.percent=20;assert(t.Tick(c,s).action==Action::Select);
 t.Reset();s=Ready();s.percent=70;assert(t.Tick(c,s).action==Action::None);
 for(int bad=0;bad<8;++bad){t.Reset();s=Ready();Config cc=c;
  if(bad==0)s.valid=false;if(bad==1)s.allowed=false;if(bad==2)s.percent=0;
  if(bad==3)s.percent=std::numeric_limits<float>::quiet_NaN();if(bad==4)s.medical=false;
  if(bad==5)s.rotation=3;if(bad==6)s.items[5]=0;if(bad==7)cc.points[6]=Point{};
  assert(t.Tick(cc,s).action==Action::None);
 }
 t.Reset();s=Ready();t.Tick(c,s);s.now+=4;t.Tick(c,s,1);assert(t.State()==Phase::Blocked);
 t.Reset();s=Ready();t.Tick(c,s);t.Tick(c,s,0);assert(t.State()==Phase::Blocked);
 t.Reset();s=Ready();t.Tick(c,s);s.owner=8;assert(t.Tick(c,s).action==Action::Select); // new owner starts with no old slot history
 t.Reset();s=Ready();t.Tick(c,s);s.allowed=false;t.Tick(c,s);assert(t.State()==Phase::Blocked);
 t.Reset();s=Ready();t.Tick(c,s);s.now+=.1;t.Tick(c,s,1);s.selected=1;t.Tick(c,s);assert(t.State()==Phase::Blocked);
 t.Reset();s=Ready();Dose(t,c,s);c.enabled=false;t.Tick(c,s);assert(t.State()==Phase::Idle&&t.Doses()==0);
 t.Reset();c=Configured();s=Ready();s.selected=5;assert(t.Tick(c,s).action==Action::Use);t.Tick(c,s,1);s.now+=.6;t.Tick(c,s);assert(t.State()==Phase::Cooldown); // already holding medicine: no bogus return
 t.Reset();c=Configured();s=Ready();t.Tick(c,s);t.Tick(c,s,1);s.selected=5;t.Tick(c,s);s.items[5]=99;assert(t.Tick(c,s).action==Action::None&&t.State()==Phase::Blocked);
 t.Reset();s=Ready();t.Tick(c,s);t.Tick(c,s,1);s.selected=5;t.Tick(c,s);t.Tick(c,s);t.Tick(c,s,1);s.items[0]=99;s.now+=.6;t.Tick(c,s);assert(t.State()==Phase::Cooldown); // never restore a different item
 Config broken;broken.threshold=INFINITY;broken.medicine=100;broken.attempts=99;broken.points[0]={NAN,0};broken.Normalize();assert(broken.threshold==35&&broken.medicine==5&&broken.attempts==3&&!broken.points[0].Ready());
 puts("AUTO HEAL CORE: ALL OK");
}
