#include "cupboard_finder_core.h"
#include <cassert>
#include <limits>
#include <cstdio>
int main() {
    using namespace cupboardfinder;
    float d=0,h=0;
    assert(Measure({0,0,0},{3,4,0},5,d,h) && d==5 && h==4);
    assert(!Measure({0,0,0},{3,4,1},5,d,h));
    assert(Measure({10,10,10},{10,7,10},5,d,h) && d==3 && h==-3);
    assert(Measure({0,0,0},{0,0,0},5,d,h) && d==0);
    assert(Radius(-100)==5 && Radius(1000)==800);
    const float nan=std::numeric_limits<float>::quiet_NaN();
    assert(Radius(nan)==100);
    assert(!Measure({nan,0,0},{0,0,0},100,d,h));
    assert(!Measure({0,0,0},{0,6000,0},800,d,h));
    assert(!Measure({0,0,0},{std::numeric_limits<float>::infinity(),0,0},800,d,h));
    puts("cupboard finder ALL OK");
}