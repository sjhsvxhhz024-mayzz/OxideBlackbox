#include "target_life.h"
#include <cassert>
#include <cstring>
#include <limits>
#include <unordered_map>
#include <cstdio>
struct Mem {
    std::unordered_map<uint64_t,unsigned char> b;
    template<class T> void put(uint64_t a,T v) {auto p=(unsigned char*)&v;for(size_t i=0;i<sizeof(v);++i)b[a+i]=p[i];}
    bool rd(uint64_t a,void *v,size_t n) {auto p=(unsigned char*)v;for(size_t i=0;i<n;++i){auto it=b.find(a+i);if(it==b.end())return false;p[i]=it->second;}return true;}
};
int main() {
    using namespace targetlife;
    Ticket t;t.pm=0x100;t.klass=0x500;t.identitySlot=0x110;t.identity=0x600;
    t.netIdSlot=0x620;t.netId=9;t.respawnSlot=0x180;t.sourceSlot=0x190;t.handler=0x700;
    t.ownerSlot=0x710;t.healthSlot=0x720;t.health=0x800;t.valuesSlot=0x810;
    Mem m;m.put(t.pm,t.klass);m.put(t.identitySlot,t.identity);m.put(t.netIdSlot,t.netId);
    m.put(t.respawnSlot,uint8_t(0));m.put(t.sourceSlot,t.handler);m.put(t.ownerSlot,t.pm);
    m.put(t.healthSlot,t.health);m.put(t.valuesSlot,100.f);m.put(t.valuesSlot+4,100.f);
    assert(Read(m,t)==State::Alive);
    // Snapshot was alive; worker recheck must see death without republication.
    m.put(t.valuesSlot,0.f);assert(Read(m,t)==State::Dead);
    m.put(t.valuesSlot,-1.f);assert(Read(m,t)==State::Unknown);
    m.put(t.valuesSlot,100.f);m.put(t.valuesSlot+4,0.f);t.current=1;
    assert(Read(m,t)==State::Dead);t.current=0;assert(Read(m,t)==State::Alive);
    m.put(t.respawnSlot,uint8_t(1));assert(Read(m,t)==State::Dead);
    m.put(t.respawnSlot,uint8_t(2));assert(Read(m,t)==State::Unknown);
    m.put(t.respawnSlot,uint8_t(0));m.put(t.netIdSlot,uint32_t(10));assert(Read(m,t)==State::Replaced);
    m.put(t.netIdSlot,t.netId);m.put(t.ownerSlot,uint64_t(0x999));assert(Read(m,t)==State::Replaced);
    m.put(t.ownerSlot,t.pm);m.put(t.healthSlot,uint64_t(0x999));assert(Read(m,t)==State::Replaced);
    m.put(t.healthSlot,t.health);m.put(t.valuesSlot,std::numeric_limits<float>::quiet_NaN());assert(Read(m,t)==State::Unknown);
    m.put(t.valuesSlot,100.f);m.b.erase(t.valuesSlot);assert(Read(m,t)==State::Unknown);
    m.put(t.valuesSlot,100.f);t.parentSlot=0x120;t.parent=0x900;m.put(t.parentSlot,t.parent);
    assert(Read(m,t)==State::Alive);m.put(t.parentSlot,uint64_t(0x999));assert(Read(m,t)==State::Replaced);
    Ticket roster;roster.pm=0x100;roster.klass=0x500;roster.identitySlot=0x110;
    roster.identity=0x600;roster.netIdSlot=0x620;roster.netId=9;
    roster.respawnSlot=0x180;roster.rosterListSlot=0x900;
    roster.rosterList=0xA00;roster.rosterItemsSlot=0xA10;
    roster.rosterItems=0xB00;roster.rosterSizeSlot=0xA18;
    roster.rosterIndex=1;roster.rosterEntrySlot=0xB28;
    m.put(roster.netIdSlot,roster.netId);m.put(roster.respawnSlot,uint8_t(0));
    m.put(roster.rosterListSlot,roster.rosterList);
    m.put(roster.rosterItemsSlot,roster.rosterItems);
    m.put(roster.rosterSizeSlot,int32_t(2));m.put(roster.rosterEntrySlot,roster.pm);
    assert(Read(m,roster)==State::Alive);
    m.put(roster.rosterSizeSlot,int32_t(1));assert(Read(m,roster)==State::Replaced);
    m.put(roster.rosterSizeSlot,int32_t(2));
    m.put(roster.rosterEntrySlot,uint64_t(0));assert(Read(m,roster)==State::Replaced);
    m.put(roster.rosterEntrySlot,roster.pm);
    m.put(roster.respawnSlot,uint8_t(1));assert(Read(m,roster)==State::Dead);
    m.put(roster.respawnSlot,uint8_t(0));
    m.put(roster.rosterListSlot,uint64_t(0));assert(Read(m,roster)==State::Replaced);
    puts("target life: health and active-roster scenarios passed");
}
