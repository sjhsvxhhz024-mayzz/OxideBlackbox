#include "silent_core.h"
#include <initializer_list>
#include <cassert>
#include <chrono>
#include <cstdio>
#include <limits>
using namespace silentcore;
// Independent RK4 integration of dv/dt=-k*v+(0,-g,0). This verifies
// mathematical consistency of the selected model, NOT native game physics.
static V3 integrate(V3 p,V3 v,float g,float k,float total) {
    double t=0;
    auto acc=[&](V3 w){return w*(-k)+V3{0,-g,0};};
    while(t<total) {
        const float h=(float)fmin(.001,total-t);
        const V3 a1=acc(v),v2=v+a1*(h*.5f),a2=acc(v2),v3=v+a2*(h*.5f),a3=acc(v3),v4=v+a3*h,a4=acc(v4);
        p=p+(v+v2*2+v3*2+v4)*(h/6);
        v=v+(a1+a2*2+a3*2+a4)*(h/6);t+=h;
    }
    return p;
}
int main() {
    int solved=0,rejected=0;float worst=0;
    for(float speed:{20.f,40.f,75.f}) for(float g:{0.f,5.f,9.81f})
    for(float drag:{0.f,.05f,.25f}) for(float distance:{3.f,20.f,60.f,100.f})
    for(float y:{-3.f,0.f,5.f}) {
        const V3 origin{2,2,-3},target{2+distance,2+y,-3},vel{2,0,3};
        const auto r=solveArrow(origin,target,vel,speed,g,drag,true,.04f);
        if(!r.ok){++rejected;continue;}
        const V3 end=integrate(origin,r.direction*speed,g,drag,r.tof);
        const float miss=len(end-(target+vel*(r.tof+.04f)));
        if(miss>worst)worst=miss;
        assert(miss<.03f);assert(r.tof>0&&r.tof<=8);++solved;
    }
    assert(solved>150);
    // Known no-drag stationary low arc.
    auto flat=solveArrow({}, {50,0,0},{},40,9.81f,0,true,0);
    const float pitch=.5f*asinf(9.81f*50/(40*40));assert(flat.ok&&fabsf(flat.pitch-pitch)<1e-5f);
    auto impossible=solveArrow({}, {200,0,0},{},20,9.81f,0,true,0);assert(!impossible.ok);
    auto longFlight=solveArrow({}, {75,0,0},{0,0,2},25,3,0,true,0);assert(longFlight.ok&&longFlight.tof>3);
    auto above=solveArrow({}, {0,4,0},{},15,9.81f,0,true,0);assert(above.ok);
    auto below=solveArrow({}, {0,-10,0},{},15,9.81f,0,true,0);assert(below.ok);
    auto close=solveArrow({}, {.15f,.05f,0},{},40,9.81f,.1f,true,0);assert(close.ok&&close.tof<.01f);
    auto noPrediction=solveArrow({}, {50,0,0},{10,0,0},40,9.81f,0,false,.2f);assert(noPrediction.ok&&fabsf(noPrediction.tof-flat.tof)<1e-5);
    assert(!solveArrow({}, {10,0,0},{},40,9.81f,-1,true,0).ok);
    assert(!solveArrow({}, {10,0,0},{},std::numeric_limits<float>::quiet_NaN(),9.81f,0,true,0).ok);
    // Zero-drag limit must remain numerically continuous.
    auto tiny=solveArrow({}, {50,0,0},{},40,9.81f,1e-8f,true,0);assert(tiny.ok&&fabsf(tiny.tof-flat.tof)<1e-5);
    MotionTrack m;m.update({},0);for(int i=1;i<=12;++i)m.update({i*.25f,0,0},i*.05);
    assert(m.vel.x>4.9f);m.update({2.75f,0,0},.65);assert(m.vel.x<0);
    m.update({2.75f,0,0},.80);assert(len(m.vel)==0);
    m.update({100,0,0},.85);assert(len(m.vel)==0); // teleport, not enormous lead
    const auto start=std::chrono::steady_clock::now();float total=0;
    for(int i=0;i<10000;++i) total+=solveArrow({}, {50+(i%9)*.1f,1,0},{3,0,2},50,9.81f,.1f,true,0).tof;
    const double us=std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-start).count()/10000;
    printf("Arrow model: %d solved, %d unreachable; independent RK4 worst miss %.5f m; host %.2f us/solve (checksum %.1f)\n",solved,rejected,worst,us,total);
}
