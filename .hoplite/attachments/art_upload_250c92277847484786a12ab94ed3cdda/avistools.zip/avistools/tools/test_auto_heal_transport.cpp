// Real subprocess transport and settings storage. No Android/game input invoked.
#include "auth/auth_sound.h"
#include "../src/trial/auto_heal.cpp"
#include <cassert>
#include <thread>
#include <chrono>
Settings g_cfg{};
ImTextureID GetTexture(int,ImVec2*s){if(s)*s=ImVec2();return nullptr;}
namespace avis {namespace snd {void Play(Sfx,int){}}}
static double Now(){return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();}
static void Finish(Command&c){double end=Now()+1;while(c.Busy()&&Now()<end){c.Poll(Now());std::this_thread::sleep_for(std::chrono::milliseconds(2));}assert(!c.Busy());}
int main(){
 assert(ParseFocus("mResumedActivity: ActivityRecord{a u0 com.game/.Main t2}","com.game"));
 assert(!ParseFocus("mResumedActivity: ActivityRecord{a u0 evil.com.game/.Main t2}","com.game"));
 assert(!ParseFocus("something com.game/.Main","com.game"));
 assert(!ParseFocus("topResumedActivity=ActivityRecord{u0 com.other/.Main}\nmResumedActivity: ActivityRecord{u0 com.game/.Main}","com.game"));
 Command c;char file[]="/bin/true";char*args[]={file,nullptr};assert(c.Start(file,args,Now(),false));Finish(c);assert(c.Result()==1);
 char fail[]="/bin/false";char*fargs[]={fail,nullptr};assert(c.Start(fail,fargs,Now(),false));Finish(c);assert(c.Result()==0);
 char echo[]="/bin/echo",msg[]="mResumedActivity: com.game/.Main";char*eargs[]={echo,msg,nullptr};assert(c.Start(echo,eargs,Now(),true));Finish(c);assert(c.Output().find("com.game/.Main")!=std::string::npos);
 char sleep[]="/bin/sleep",sec[]="10";char*sargs[]={sleep,sec,nullptr};assert(c.Start(sleep,sargs,Now(),false));c.Cancel();Finish(c);assert(c.Result()==0);
 assert(c.Start(sleep,sargs,Now(),false));c.Poll(Now()+3);Finish(c);assert(c.Result()==0);
 char dir[]="/tmp/avis_heal_test_XXXXXX";assert(mkdtemp(dir));AutoHealInit(dir);g_autoHeal.width=1600;g_autoHeal.height=900;g_autoHeal.rotation=1;g_autoHeal.points[0]={.2,.8};g_autoHeal.enabled=true;g_autoHeal.threshold=40;Save();AutoHealShutdown();AutoHealInit(dir);assert(!g_autoHeal.enabled&&g_autoHeal.threshold==40&&g_autoHeal.points[0].Ready());
 AutoHealShutdown();unlink((std::string(dir)+"/auto_heal.cfg").c_str());rmdir(dir);
 puts("AUTO HEAL TRANSPORT: ALL OK");
}
