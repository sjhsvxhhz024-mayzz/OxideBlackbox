#pragma once
// Генераторы для хост-тестов скелета: ходящая поза (двухзвенная IK) и синтетическая иерархия
// гуманоида с пальцами, носками, ключицами, оружием, рюкзаком и мусорными узлами.
// Только для тестов: в игре поза читается из настоящей иерархии костей.
#include "skeleton.h"
#include <string>
#include <vector>

namespace tg {
using namespace oxskel;

inline float GaitAmp(float speed, float sc) { return fminf(0.14f + 0.08f * speed, 0.46f) * sc; }
inline float GaitLift(float speed, float sc) { return fminf(0.03f + 0.012f * speed * speed, 0.28f) * sc; }
inline float GaitOmega(float speed, float S) { return speed / GaitAmp(speed, S / 1.66f); }

struct GenIn {
    V3 feet; float S = 1.66f; float crouch = 0; float speed = 0; float yaw = 0; float phase = 0; float time = 0;
    bool aim = false;        // руки вперёд, как с оружием
};

inline void GenPose(const GenIn &in, Pose &o) {
    o = Pose();
    const float S = in.S, sc = S / 1.66f;
    const float a = 0.245f * S, b = 0.245f * S, ah = 0.04f * S;
    const V3 up{ 0, 1, 0 };
    const V3 fwd{ sinf(in.yaw), 0, cosf(in.yaw) }, right{ cosf(in.yaw), 0, -sinf(in.yaw) };
    const float speed = in.speed;
    const float mv = clampf((speed - 0.1f) / 0.45f, 0.0f, 1.0f);
    const float A = GaitAmp(speed, sc) * mv, L = GaitLift(speed, sc) * mv;
    const float hipHalf = 0.054f * S;
    V3 ankleT[2];
    float xs[2], lifts[2];
    for (int i = 0; i < 2; ++i) {
        const float th = in.phase + (i == 0 ? 0.0f : 3.14159265f);
        xs[i] = A * sinf(th); lifts[i] = L * fmaxf(0.0f, cosf(th));
        const float sgn = i == 0 ? 1.0f : -1.0f;
        ankleT[i] = V3{ in.feet.x + right.x * hipHalf * sgn + fwd.x * xs[i], in.feet.y + ah + lifts[i], in.feet.z + right.z * hipHalf * sgn + fwd.z * xs[i] };
    }
    const float e0 = (a + b) * (1.0f - 0.32f * in.crouch);
    float Hp = ah + e0;
    for (int i = 0; i < 2; ++i) Hp = fminf(Hp, ah + lifts[i] + sqrtf(fmaxf(0.0f, 0.985f * (a + b) * 0.985f * (a + b) - xs[i] * xs[i])));
    const V3 pelvis{ in.feet.x, in.feet.y + Hp, in.feet.z };
    V3 hip[2], knee[2], ankle[2];
    for (int i = 0; i < 2; ++i) {
        const float sgn = i == 0 ? 1.0f : -1.0f;
        hip[i] = V3{ in.feet.x + right.x * hipHalf * sgn, pelvis.y, in.feet.z + right.z * hipHalf * sgn };
        knee[i] = IK2(hip[i], ankleT[i], a, b, fwd, &ankle[i]);
    }
    const float lean = 0.020f * speed + 0.30f * in.crouch;
    const V3 tdir = norm(up * cosf(lean) + fwd * sinf(lean), up);
    V3 chest = pelvis + tdir * (0.29f * S);
    chest.y += 0.004f * sinf(1.7f * in.time);
    const V3 neck = chest + tdir * (0.06f * S);
    const V3 headDir = norm(tdir * 0.5f + up * 0.5f, up);
    const V3 head = neck + headDir * (0.12f * S);
    const float armU = 0.16f * S, armF = 0.15f * S;
    V3 sh[2], el[2], hand[2];
    for (int i = 0; i < 2; ++i) {
        const float sgn = i == 0 ? 1.0f : -1.0f;
        const float th = in.phase + (i == 0 ? 3.14159265f : 0.0f);
        sh[i] = chest + right * (0.115f * S * sgn) - tdir * (0.015f * S);
        V3 tgt = sh[i] + right * (0.030f * S * sgn) + fwd * (0.75f * A * sinf(th)) + up * (-(armU + armF) * 0.94f);
        if (in.aim) tgt = sh[i] + fwd * (0.30f * S) + right * (-0.05f * S * sgn) + up * (-0.05f * S);
        const V3 pole = in.aim ? norm(up * -1.0f + right * (0.6f * sgn), V3{ 0, -1, 0 }) : norm(fwd * -1.0f + right * (0.5f * sgn), V3{ 0, 0, -1 });
        el[i] = IK2(sh[i], tgt, armU, armF, pole, &hand[i]);
    }
    o.j[J_HEAD] = head; o.j[J_NECK] = neck; o.j[J_CHEST] = chest;
    o.j[J_SPINE] = lerp(pelvis, chest, 0.5f); o.j[J_PELVIS] = pelvis;
    o.j[J_SH_R] = sh[0]; o.j[J_SH_L] = sh[1]; o.j[J_EL_R] = el[0]; o.j[J_EL_L] = el[1];
    o.j[J_HAND_R] = hand[0]; o.j[J_HAND_L] = hand[1];
    o.j[J_HIP_R] = hip[0]; o.j[J_HIP_L] = hip[1]; o.j[J_KNEE_R] = knee[0]; o.j[J_KNEE_L] = knee[1];
    o.j[J_FOOT_R] = ankle[0]; o.j[J_FOOT_L] = ankle[1];
    for (int i = 0; i < 2; ++i) {
        V3 t = ankle[i] + fwd * (0.09f * S);
        t.y = fmaxf(in.feet.y + 0.012f, ankle[i].y - 0.05f);
        o.j[i == 0 ? J_TOE_R : J_TOE_L] = t;
    }
    o.headR = 0.105f * sc; o.headC = head + headDir * (0.05f * sc); o.face = fwd; o.ok = true;
}

// ───────── синтетическая иерархия ─────────
struct RigOpt {
    bool clavicle = true, toes = true, fingers = true, weapon = true, backpack = true, twist = true, junk = true;
    bool shuffle = false;
    unsigned seed = 1;
};

struct SynRig {
    std::vector<int> parent;
    std::vector<V3> world;
    std::vector<std::string> name;
    int joint[J_COUNT];
    std::vector<int> fine;           // узлы, которые обязаны попасть в мелкие кости (пальцы, концы носков)
    std::vector<int> forbidden;      // узлы, которых в мелких костях быть не должно (оружие, рюкзак, волосы)
    int head = -1;
    int add(int par, V3 w, const char *nm) { parent.push_back(par); world.push_back(w); name.push_back(nm); return (int)parent.size() - 1; }
    int size() const { return (int)parent.size(); }
};

inline void BuildRig(const Pose &p, V3 rootPos, const RigOpt &o, SynRig &r) {
    r = SynRig();
    for (int &j : r.joint) j = -1;
    const V3 face = p.face;
    const int root = r.add(-1, rootPos, "root");
    int cam = -1;
    if (o.junk) { cam = r.add(root, rootPos + V3{ 0, 1.6f, 0 }, "cam"); r.add(cam, rootPos + V3{ 0.05f, 1.6f, 0.3f }, "camchild"); }
    const int model = r.add(root, rootPos, "model");
    const int hips = r.add(model, p.j[J_PELVIS], "hips");
    const int s1 = r.add(hips, p.j[J_SPINE], "spine");
    const int s2 = r.add(s1, p.j[J_CHEST], "chest");
    const int neck = r.add(s2, p.j[J_NECK], "neck");
    const int head = r.add(neck, p.j[J_HEAD], "head");
    r.head = head;
    r.joint[J_PELVIS] = hips; r.joint[J_SPINE] = s1; r.joint[J_CHEST] = s2; r.joint[J_NECK] = neck; r.joint[J_HEAD] = head;
    r.forbidden.push_back(r.add(head, p.headC + V3{ 0, 0.11f, 0 }, "hair"));
    r.forbidden.push_back(r.add(head, p.headC + face * 0.09f, "nose"));
    if (o.backpack) {
        const int bp = r.add(s2, p.j[J_CHEST] - face * 0.15f, "backpack");
        r.forbidden.push_back(bp);
        r.forbidden.push_back(r.add(bp, p.j[J_CHEST] - face * 0.20f + V3{ 0, -0.2f, 0 }, "backpackBottom"));
    }
    for (int side = 0; side < 2; ++side) {
        const bool R = side == 0;
        const V3 sh = p.j[R ? J_SH_R : J_SH_L], el = p.j[R ? J_EL_R : J_EL_L], hd = p.j[R ? J_HAND_R : J_HAND_L];
        int parentArm = s2;
        if (o.clavicle) parentArm = r.add(s2, lerp(p.j[J_CHEST], sh, 0.33f), R ? "clavR" : "clavL");
        const int ua = r.add(parentArm, sh, R ? "uarmR" : "uarmL");
        int fa;
        if (o.twist) { const int tw = r.add(ua, lerp(sh, el, 0.5f), "twistU"); fa = r.add(tw, el, R ? "farmR" : "farmL"); }
        else fa = r.add(ua, el, R ? "farmR" : "farmL");
        int h;
        if (o.twist) { const int tw = r.add(fa, lerp(el, hd, 0.5f), "twistF"); h = r.add(tw, hd, R ? "handR" : "handL"); }
        else h = r.add(fa, hd, R ? "handR" : "handL");
        r.joint[R ? J_SH_R : J_SH_L] = ua; r.joint[R ? J_EL_R : J_EL_L] = fa; r.joint[R ? J_HAND_R : J_HAND_L] = h;
        if (o.fingers) {
            const V3 dir = norm(hd - el, V3{ 0, -1, 0 });
            const V3 lat = norm(cross(dir, V3{ 0, 0, 1 }), V3{ 1, 0, 0 });
            for (int f = 0; f < 5; ++f) {
                const V3 off = lat * (0.012f * (f - 2));
                const int a = r.add(h, hd + dir * 0.075f + off, "f1");
                const int b = r.add(a, hd + dir * 0.125f + off, "f2");
                const int c = r.add(b, hd + dir * 0.168f + off, "f3");
                r.fine.push_back(a); r.fine.push_back(b); r.fine.push_back(c);
            }
        }
        if (o.weapon && R) {
            const int holder = r.add(h, hd + V3{ 0, -0.02f, 0 }, "weaponHolder");
            r.forbidden.push_back(holder);
            int prev = holder;
            for (int k = 1; k <= 6; ++k) prev = r.add(prev, hd + face * (0.13f * k), "weaponPart"), r.forbidden.push_back(prev);
        }
    }
    for (int side = 0; side < 2; ++side) {
        const bool R = side == 0;
        const V3 hp = p.j[R ? J_HIP_R : J_HIP_L], kn = p.j[R ? J_KNEE_R : J_KNEE_L], an = p.j[R ? J_FOOT_R : J_FOOT_L], to = p.j[R ? J_TOE_R : J_TOE_L];
        const int ul = r.add(hips, hp, R ? "ulegR" : "ulegL");
        int ll;
        if (o.twist) { const int tw = r.add(ul, lerp(hp, kn, 0.5f), "twistT"); ll = r.add(tw, kn, R ? "llegR" : "llegL"); }
        else ll = r.add(ul, kn, R ? "llegR" : "llegL");
        const int ft = r.add(ll, an, R ? "footR" : "footL");
        r.joint[R ? J_HIP_R : J_HIP_L] = ul; r.joint[R ? J_KNEE_R : J_KNEE_L] = ll; r.joint[R ? J_FOOT_R : J_FOOT_L] = ft;
        if (o.toes) {
            const int tz = r.add(ft, to, R ? "toesR" : "toesL");
            r.joint[R ? J_TOE_R : J_TOE_L] = tz;
            r.fine.push_back(r.add(tz, to + face * 0.055f, "toeEnd"));
        }
    }
    if (o.junk) for (int i = 0; i < 30; ++i) r.add(i % 2 ? root : cam, rootPos + V3{ 0.1f * (i % 7), 1.0f + 0.02f * i, 0.2f }, "misc");

    if (o.shuffle) {                                   // порядок узлов в массиве не обязан быть «родитель раньше потомка»
        const int n = r.size();
        std::vector<int> perm(n);
        for (int i = 0; i < n; ++i) perm[i] = i;
        unsigned s = o.seed * 2654435761u + 12345u;
        for (int i = n - 1; i > 0; --i) { s = s * 1664525u + 1013904223u; const int j = (int)((s >> 8) % (unsigned)(i + 1)); std::swap(perm[i], perm[j]); }
        // perm[old] = new
        SynRig q = r;
        for (int old = 0; old < n; ++old) {
            const int nw = perm[old];
            q.parent[nw] = r.parent[old] >= 0 ? perm[r.parent[old]] : -1;
            q.world[nw] = r.world[old]; q.name[nw] = r.name[old];
        }
        for (int &j : q.joint) if (j >= 0) j = perm[j];
        for (int &v : q.fine) v = perm[v];
        for (int &v : q.forbidden) v = perm[v];
        q.head = perm[r.head];
        r = q;
    }
}

inline Q4 QuatY(float a) { return { 0, sinf(a * 0.5f), 0, cosf(a * 0.5f) }; }
inline Q4 QInv(Q4 q) { return { -q.x, -q.y, -q.z, q.w }; }
inline Q4 RandQuat(unsigned &s) {
    auto rnd = [&]() { s = s * 1664525u + 1013904223u; return ((s >> 9) & 0x7FFFFF) / 8388607.0f; };
    Q4 q{ rnd() - 0.5f, rnd() - 0.5f, rnd() - 0.5f, rnd() - 0.5f + 0.6f };
    const float l = sqrtf(q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w);
    return { q.x / l, q.y / l, q.z / l, q.w / l };
}

// Локальные TRS из мировых позиций; у каждого узла случайный мировой поворот (кроме головы: её задаёт вызывающий).
inline void ToLocals(const SynRig &r, float yawRoot, unsigned seed, Q4 headWorldRot, std::vector<TRS> &loc, std::vector<Q4> &wrot) {
    const int n = r.size();
    loc.assign(n, TRS());
    wrot.assign(n, Q4());
    unsigned s = seed * 7919u + 17u;
    // порядок обработки: родители раньше детей
    std::vector<int> order; order.reserve(n);
    std::vector<char> done(n, 0);
    for (int pass = 0; pass < n && (int)order.size() < n; ++pass)
        for (int i = 0; i < n; ++i) if (!done[i] && (r.parent[i] < 0 || done[r.parent[i]])) { done[i] = 1; order.push_back(i); }
    for (int i : order) {
        if (r.parent[i] < 0) { wrot[i] = QuatY(yawRoot); loc[i].pos = r.world[i]; loc[i].rot = wrot[i]; continue; }
        wrot[i] = (i == r.head) ? headWorldRot : RandQuat(s);
        const int p = r.parent[i];
        loc[i].pos = rotate(QInv(wrot[p]), r.world[i] - r.world[p]);
        loc[i].rot = qmul(QInv(wrot[p]), wrot[i]);
        loc[i].scl = { 1, 1, 1 };
    }
}

} // namespace tg
