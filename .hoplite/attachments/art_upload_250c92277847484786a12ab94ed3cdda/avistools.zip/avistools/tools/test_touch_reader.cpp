// Real evdev parser and worker lifetime, using a local pipe instead of /dev/input.
#include "../src/Android_touch/TouchHelperA.cpp"
#include <cassert>
#include <chrono>
#include <thread>
static void Send(int fd,int slot,int tracking,int x=0,int y=0){
 input_event e[5]{};
 e[0].type=EV_ABS;e[0].code=ABS_MT_SLOT;e[0].value=slot;
 e[1].type=EV_ABS;e[1].code=ABS_MT_TRACKING_ID;e[1].value=tracking;
 e[2].type=EV_ABS;e[2].code=ABS_MT_POSITION_X;e[2].value=x;
 e[3].type=EV_ABS;e[3].code=ABS_MT_POSITION_Y;e[3].value=y;
 e[4].type=EV_SYN;e[4].code=SYN_REPORT;
 assert(write(fd,e,sizeof(e))==(ssize_t)sizeof(e));
 std::this_thread::sleep_for(std::chrono::milliseconds(20));
}
static void SendPointer(int fd, bool absolute, bool down) {
 input_event e[4]{};
 e[0].type=absolute?EV_ABS:EV_REL;e[0].code=absolute?ABS_X:REL_X;e[0].value=absolute?500:30;
 e[1].type=absolute?EV_ABS:EV_REL;e[1].code=absolute?ABS_Y:REL_Y;e[1].value=absolute?250:-20;
 e[2].type=EV_KEY;e[2].code=BTN_LEFT;e[2].value=down?1:0;
 e[3].type=EV_SYN;e[3].code=SYN_REPORT;
 assert(write(fd,e,sizeof(e))==(ssize_t)sizeof(e));
 std::this_thread::sleep_for(std::chrono::milliseconds(20));
}
static void SendVirtualTouch(int fd, bool down) {
 input_event e[4]{};
 e[0].type=EV_ABS;e[0].code=ABS_MT_POSITION_X;e[0].value=120;
 e[1].type=EV_ABS;e[1].code=ABS_MT_POSITION_Y;e[1].value=220;
 e[2].type=EV_KEY;e[2].code=BTN_TOUCH;e[2].value=down?1:0;
 e[3].type=EV_SYN;e[3].code=SYN_REPORT;
 assert(write(fd,e,sizeof(e))==(ssize_t)sizeof(e));
 std::this_thread::sleep_for(std::chrono::milliseconds(20));
}
static void SendLegacyTypeA(int fd, bool down) {
 input_event e[4]{};
 if (down) {
  e[0].type=EV_ABS;e[0].code=ABS_MT_POSITION_X;e[0].value=120;
  e[1].type=EV_ABS;e[1].code=ABS_MT_POSITION_Y;e[1].value=220;
  e[2].type=EV_SYN;e[2].code=SYN_MT_REPORT;
  e[3].type=EV_SYN;e[3].code=SYN_REPORT;
  assert(write(fd,e,sizeof(e))==(ssize_t)sizeof(e));
 } else {
  e[0].type=EV_SYN;e[0].code=SYN_MT_REPORT;
  e[1].type=EV_SYN;e[1].code=SYN_REPORT;
  assert(write(fd,e,sizeof(input_event)*2)==(ssize_t)sizeof(input_event)*2);
 }
 std::this_thread::sleep_for(std::chrono::milliseconds(20));
}
int main(){
 int fds[2];assert(pipe2(fds,O_NONBLOCK|O_CLOEXEC)==0);
 fdNum=1;origfd[0]=fds[0];Touch_readOnly=true;touchMaxX=640;touchMaxY=530;
 UpdateScreenData(640,530,0);mouseDevice=-1;primaryFinger[0]=-1;
 Touch_initialized=true;targF[0]={0,1,1};assert(pthread_create(&touchThreads[0],nullptr,TypeA,&targF[0])==0);threadStarted[0]=true;
 Send(fds[1],12,10,300,300);assert(mouseEvents.Take().empty()); // out-of-range slot
 Send(fds[1],0,1,100,200);auto e=mouseEvents.Take();assert(!e.empty()&&e.back().down&&e.back().x==100);
 Send(fds[1],1,2,400,400);e=mouseEvents.Take();assert(!e.empty()&&e.back().down&&e.back().x==100); // keep first finger
 Send(fds[1],1,-1);e=mouseEvents.Take();assert(!e.empty()&&e.back().down); // releasing secondary finger is not mouse-up
 Send(fds[1],1,3,400,400);mouseEvents.Take();
 Send(fds[1],0,-1);e=mouseEvents.Take();assert(!e.empty()&&!e.back().down);
 Send(fds[1],1,3,420,420);assert(mouseEvents.Take().empty()); // no gesture handoff
 Send(fds[1],1,-1);mouseEvents.Take();
 Send(fds[1],0,4,120,220);e=mouseEvents.Take();assert(!e.empty()&&e.back().down&&e.back().x==120);
 auto start=std::chrono::steady_clock::now();Touch_Close();
 assert(std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<.5);
 assert(!threadStarted[0]&&fdNum==0);close(fds[1]);
 // Virtual touchscreen with BTN_TOUCH but without ABS_MT_TRACKING_ID.
 {
  int p[2];assert(pipe2(p,O_NONBLOCK|O_CLOEXEC)==0);
  fdNum=1;origfd[0]=p[0];Touch_readOnly=true;touchMaxX=640;touchMaxY=530;
  UpdateScreenData(640,530,0);mouseDevice=-1;primaryFinger[0]=-1;
  Touch_initialized=true;targF[0]={0,1,1};
  assert(pthread_create(&touchThreads[0],nullptr,TypeA,&targF[0])==0);threadStarted[0]=true;
  SendVirtualTouch(p[1],true);
  auto press=mouseEvents.Take();assert(!press.empty()&&press.back().down&&press.back().x==120);
  SendVirtualTouch(p[1],false);
  auto release=mouseEvents.Take();assert(!release.empty()&&!release.back().down);
  Touch_Close();close(p[1]);
 }
 // Legacy type-A virtual touchscreen: frame positions mean press, empty
 // frame means release; neither tracking IDs nor BTN_TOUCH are provided.
 {
  int p[2];assert(pipe2(p,O_NONBLOCK|O_CLOEXEC)==0);
  fdNum=1;origfd[0]=p[0];Touch_readOnly=true;touchMaxX=640;touchMaxY=530;
  UpdateScreenData(640,530,0);mouseDevice=-1;primaryFinger[0]=-1;
  Touch_initialized=true;targF[0]={0,1,1};
  assert(pthread_create(&touchThreads[0],nullptr,TypeA,&targF[0])==0);threadStarted[0]=true;
  SendLegacyTypeA(p[1],true);
  auto press=mouseEvents.Take();assert(!press.empty()&&press.back().down&&press.back().x==120);
  SendLegacyTypeA(p[1],false);
  auto release=mouseEvents.Take();assert(!release.empty()&&!release.back().down);
  Touch_Close();close(p[1]);
 }
 // Emulator mouse: relative movement/click and absolute tablet coordinates.
 for (int mode=0;mode<2;++mode) {
  int p[2];assert(pipe2(p,O_NONBLOCK|O_CLOEXEC)==0);
  fdNum=1;origfd[0]=p[0];Touch_readOnly=true;
  UpdateScreenData(640,530,0);mouseDevice=-1;
  targF[0]={0,0,0,true,mode==0,true,false,0,1000,0,500};
  Touch_initialized=true;
  assert(pthread_create(&touchThreads[0],nullptr,TypePointer,&targF[0])==0);threadStarted[0]=true;
  SendPointer(p[1],mode==1,true);
  auto press=mouseEvents.Take();assert(!press.empty()&&press.back().down);
  assert(press.back().x==(mode==0?350:320)&&press.back().y==(mode==0?245:265));
  SendPointer(p[1],mode==1,false);
  auto release=mouseEvents.Take();assert(!release.empty()&&!release.back().down);
  Touch_Close();close(p[1]);
 }
 // Pump press/release on the main thread: release keeps the last pointer position.
 ImGui::CreateContext();auto &io=ImGui::GetIO();io.IniFilename=nullptr;io.DisplaySize={640,530};
 unsigned char *px;int w,h;io.Fonts->GetTexDataAsRGBA32(&px,&w,&h);
 mouseEvents.Push({100,100,true});mouseEvents.Push({-1,-1,false});Touch_PumpInput();
 for(int i=0;i<4;++i){io.DeltaTime=1.f/60;ImGui::NewFrame();ImGui::Render();}
 assert(io.MousePos.x==100&&io.MousePos.y==100&&!io.MouseDown[0]);ImGui::DestroyContext();
 puts("ALL OK");
}
