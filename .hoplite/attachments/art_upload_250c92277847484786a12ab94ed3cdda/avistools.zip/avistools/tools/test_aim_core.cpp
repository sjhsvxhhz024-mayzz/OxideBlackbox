// Хост-тест ядра наведения: g++ -std=c++17 -Isrc tools/test_aim_core.cpp -o /tmp/t && /tmp/t
#include "aim_core.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace aimcore;
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { ++fails; printf("FAIL %s:%d ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

// Unity: камера смотрит вдоль +Z локально; MouseLook: yaw вокруг Y, pitch>0 вниз. Строим VP (столбцы) = P * V.
static void buildVP(float yawDeg, float pitchDeg, const float eye[3], float out[16]) {
    const float y = yawDeg / kRadToDeg, p = pitchDeg / kRadToDeg;
    float f[3] = { cosf(p) * sinf(y), -sinf(p), cosf(p) * cosf(y) };
    float up0[3] = { 0, 1, 0 };
    float r[3] = { up0[1] * f[2] - up0[2] * f[1], up0[2] * f[0] - up0[0] * f[2], up0[0] * f[1] - up0[1] * f[0] };
    float rl = sqrtf(r[0] * r[0] + r[1] * r[1] + r[2] * r[2]); for (float &v : r) v /= rl;
    float u[3] = { f[1] * r[2] - f[2] * r[1], f[2] * r[0] - f[0] * r[2], f[0] * r[1] - f[1] * r[0] };
    // View (строки r,u,-f в Unity-стиле), затем перспектива с w = f·(p-eye)
    float V[4][4] = { { r[0], r[1], r[2], -(r[0]*eye[0]+r[1]*eye[1]+r[2]*eye[2]) },
                      { u[0], u[1], u[2], -(u[0]*eye[0]+u[1]*eye[1]+u[2]*eye[2]) },
                      { f[0], f[1], f[2], -(f[0]*eye[0]+f[1]*eye[1]+f[2]*eye[2]) },
                      { 0, 0, 0, 1 } };
    const float fx = 1.7f, fy = 3.0f, n = 0.1f, fa = 1000.f;
    float P[4][4] = { { fx, 0, 0, 0 }, { 0, fy, 0, 0 }, { 0, 0, (fa + n) / (fa - n), -2 * fa * n / (fa - n) }, { 0, 0, 1, 0 } };
    float M[4][4] = {};
    for (int i = 0; i < 4; ++i) for (int j = 0; j < 4; ++j) for (int k = 0; k < 4; ++k) M[i][j] += P[i][k] * V[k][j];
    for (int c = 0; c < 4; ++c) for (int rr = 0; rr < 4; ++rr) out[c * 4 + rr] = M[rr][c];   // column-major
}

int main() {
    // 1) углы из VP
    for (float yaw : { -170.f, -90.f, -10.f, 0.5f, 45.f, 135.f, 179.f })
        for (float pitch : { -70.f, -20.f, 0.f, 15.f, 60.f }) {
            float eye[3] = { 3, 1.7f, -8 }, m[16], ty, tp;
            buildVP(yaw, pitch, eye, m);
            CHECK(anglesFromVP(m, &ty, &tp), "vp invalid");
            CHECK(fabsf(wrapDeg(ty - yaw)) < 0.01f && fabsf(tp - pitch) < 0.01f, "angles yaw %.1f pitch %.1f -> %.3f %.3f", yaw, pitch, ty, tp);
        }

    // 2) самокалибровка: поля pitch/yaw среди шума, с отставанием на кадр и yaw в диапазоне 0..360
    srand(7);
    for (int trial = 0; trial < 200; ++trial) {
        const int pw = 4 + rand() % 100, yw = (pw + 1 + rand() % 20) % 120 + 2;
        if (pw == yw) continue;
        const bool yaw360 = rand() & 1;
        float w[AngleCalib::kWords];
        for (int i = 0; i < AngleCalib::kWords; ++i) w[i] = (i % 3 == 0) ? (float)(rand() % 200) * 0.37f - 20.f : (i % 3 == 1 ? 1.0f : (float)(rand() % 5));
        AngleCalib c; c.setHint(((trial & 1) ? pw : 7) * 4, ((trial & 1) ? yw : 9) * 4);
        float yaw = (float)(rand() % 360) - 180.f, pitch = 0;
        float prevY = yaw, prevP = 0;
        for (int step = 0; step < 400 && !c.done; ++step) {
            yaw = wrapDeg(yaw + 3.f + (rand() % 40) * 0.5f);
            pitch = 25.f * sinf(step * 0.31f) + 8.f;
            // поля отстают от матрицы на ~0.5°
            float fp = pitch - 0.5f, fy = yaw - 0.4f; (void)prevP; (void)prevY;
            w[pw] = fp; w[yw] = yaw360 ? (fy < 0 ? fy + 360.f : fy) : fy;
            c.feed(w, yaw, pitch);
        }
        int pb, yb;
        CHECK(c.ready(&pb, &yb) && pb == pw * 4 && yb == yw * 4, "calib trial %d want %x/%x got %d", trial, pw * 4, yw * 4, c.done);
    }
    // неподвижная камера и «мёртвые» нули не должны давать ложного результата
    { AngleCalib c; float w[AngleCalib::kWords] = {0}; for (int i = 0; i < 300; ++i) c.feed(w, 0.f, 0.f); CHECK(!c.done, "calib false positive"); }

    // 3) сглаживание
    { // монотонно, без перелёта
        float err = 30.f, total = 0; int n = 0;
        while (fabsf(err) > 0.05f && n < 2000) { const float s = approachStep(err, 1.f / 60.f, 6.f, 0.f, 0.f); CHECK(s >= 0 && s <= err + 1e-4f, "overshoot"); err -= s; total += s; ++n; }
        CHECK(n < 200, "too slow %d", n);
    }
    { // независимость от частоты кадров: за 0.25 с остаток должен совпадать
        float res[3]; int fpsv[3] = { 30, 60, 144 };
        for (int k = 0; k < 3; ++k) { float err = 40.f; const float dt = 1.f / fpsv[k]; for (float t = 0; t < 0.25f - 1e-6f; t += dt) err -= approachStep(err, dt, 6.f, 0.f, 0.f); res[k] = err; }
        CHECK(fabsf(res[0] - res[1]) < 0.6f && fabsf(res[1] - res[2]) < 0.6f, "fps dependent %.2f %.2f %.2f", res[0], res[1], res[2]);
    }
    CHECK(approachStep(10.f, 1.f / 60.f, 1.f, 0.f, 0.f) == 10.f, "smooth=1 must snap");
    CHECK(fabsf(approachStep(90.f, 1.f / 60.f, 1.f, 600.f, 0.f) - 10.f) < 1e-3f, "speed cap");
    CHECK(approachStep(0.02f, 1.f / 60.f, 6.f, 0.f, 0.05f) == 0.f, "deadzone");
    CHECK(approachStep(-8.f, 1.f / 60.f, 4.f, 0.f, 0.f) < 0.f, "sign");

    // 3b) доводка: с зоной settle прицел садится в точку за конечное число кадров, без неё — застревает в долях градуса
    { float e1 = 20.f, e2 = 20.f; int n1 = 0, n2 = 0;
      while (fabsf(e1) > 0.02f && n1 < 5000) { e1 -= approachStep(e1, 1.f / 60.f, 8.f, 0.f, 0.f, 0.8f); ++n1; }
      while (fabsf(e2) > 0.02f && n2 < 5000) { e2 -= approachStep(e2, 1.f / 60.f, 8.f, 0.f, 0.f, 0.f); ++n2; }
      CHECK(n1 < n2 && fabsf(e1) <= 0.02f, "settle must converge faster: %d vs %d", n1, n2);
      float e3 = 0.3f; const float st = approachStep(e3, 1.f / 60.f, 8.f, 0.f, 0.f, 0.8f);
      CHECK(st > 0.3f * 0.6f && st <= 0.3f, "settle zone step %.3f", st); }
    CHECK(fabsf(rampScale(0.f, 0.2f) - 0.35f) < 1e-5f && rampScale(1.f, 0.2f) == 1.f && rampScale(0.1f, 0.2f) > 0.6f && rampScale(0.1f, 0.2f) < 0.7f, "ramp");


    // 5) пружина: ступенька без перелёта и без отставания, независимость от fps, слежение за движущейся целью, ограничение скорости
    {
        auto run = [&](float fps, float smooth, float stepDeg, float tvelDeg, float simTime, float *maxOvershoot, float *tSettle, float *finalLag) {
            aimcore::Spring1D sp; const float dt = 1.f / fps; float cur = 0, target = stepDeg, over = 0; float settle = -1; float t = 0;
            for (; t < simTime; t += dt) {
                target += tvelDeg * dt;
                cur += sp.update(target, cur, dt, smooth, 1.0f, 0.0f, 0.0f, false);
                if (tvelDeg == 0.f && stepDeg > 0 && cur - target > over) over = cur - target;
                if (settle < 0 && fabsf(target - cur) < 0.02f * fabsf(stepDeg == 0 ? 1.f : stepDeg)) settle = t;
            }
            *maxOvershoot = over; *tSettle = settle; *finalLag = target + tvelDeg * dt - cur;   // update() целится на момент следующего кадра
        };
        float ov, ts, lag;
        run(60, 6, 30, 0, 2.0f, &ov, &ts, &lag);
        CHECK(ov < 0.05f, "spring overshoot %.3f deg", ov);
        CHECK(ts > 0.15f && ts < 0.75f, "spring settle %.3f s", ts);
        CHECK(fabsf(lag) < 0.01f, "spring final lag %.4f", lag);
        float ts30, ts144; run(30, 6, 30, 0, 2.0f, &ov, &ts30, &lag); run(144, 6, 30, 0, 2.0f, &ov, &ts144, &lag);
        CHECK(fabsf(ts30 - ts) < 0.05f && fabsf(ts144 - ts) < 0.05f, "fps dependence: 30=%.3f 60=%.3f 144=%.3f", ts30, ts, ts144);
        // движущаяся цель 80 град/с: установившееся отставание должно быть малым (меньше 1 град), у чистого экспоненциального сглаживания оно ~ v*tau
        float lagSpring; run(60, 6, 0, 80, 3.0f, &ov, &ts, &lagSpring);
        float curE = 0, tgt = 0; for (float t = 0; t < 3.0f; t += 1.f / 60.f) { tgt += 80.f / 60.f; curE += aimcore::approachStep(tgt - curE, 1.f / 60.f, 6.f, 0.f, 0.f); }
        CHECK(fabsf(lagSpring) < 1.0f, "spring lag on moving target %.3f deg", lagSpring);
        CHECK(fabsf(tgt - curE) > 3.0f * fabsf(lagSpring), "spring must beat exponential on moving target: spring %.3f vs exp %.3f", lagSpring, tgt - curE);
        // ограничение скорости и мёртвая зона
        { aimcore::Spring1D sp; float cur = 0, mx = 0; for (int i = 0; i < 120; ++i) { const float d = sp.update(90, cur, 1.f / 60.f, 3.f, 1.f, 200.f, 0.f, false); cur += d; if (fabsf(d) * 60.f > mx) mx = fabsf(d) * 60.f; }
          CHECK(mx <= 200.5f, "max speed respected: %.1f", mx); }
        { aimcore::Spring1D sp; float cur = 0; float moved = 0; for (int i = 0; i < 60; ++i) moved += fabsf(sp.update(0.03f, cur, 1.f / 60.f, 6.f, 1.f, 0.f, 0.05f, false)); CHECK(moved == 0.f, "deadzone must hold still, moved %.4f", moved); }
        // yaw через границу ±180: короткий путь
        { aimcore::Spring1D sp; float cur = 170, d = sp.update(-170, cur, 1.f / 60.f, 6.f, 1.f, 0.f, 0.f, true); CHECK(d > 0.f, "yaw wrap direction %.3f", d); }
        // плавность: ускорение в начале не скачком (первая скорость много меньше пиковой)
        { aimcore::Spring1D sp; float cur = 0, vmax = 0, v1 = 0; for (int i = 0; i < 90; ++i) { const float d = sp.update(40, cur, 1.f / 60.f, 6.f, 1.f, 0.f, 0.f, false); cur += d; const float vv = d * 60.f; if (i == 0) v1 = vv; if (vv > vmax) vmax = vv; }
          CHECK(v1 < 0.35f * vmax, "smooth start: first %.1f vs peak %.1f deg/s (экспоненциальное даёт 100%%)", v1, vmax); }
        // новая цель посреди движения: переход без перелёта и без разрыва скорости
        { aimcore::Spring1D sp; float cur = 0, target = 20; for (int i = 0; i < 20; ++i) cur += sp.update(target, cur, 1.f / 60.f, 6.f, 1.f, 0.f, 0.f, false);
          target = 5; float vPrev = sp.v, maxJump = 0; for (int i = 0; i < 60; ++i) { cur += sp.update(target, cur, 1.f / 60.f, 6.f, 1.f, 0.f, 0.f, false); maxJump = fmaxf(maxJump, fabsf(sp.v - vPrev)); vPrev = sp.v; }
          CHECK(maxJump < 60.f, "velocity jump on retarget %.1f deg/s per frame (разворот на 10 град при ω=15 — физический предел пружины)", maxJump); CHECK(fabsf(cur - 5.f) < 0.3f, "retarget final %.3f", cur); }
    }

    // 4) удержание цели
    CHECK(keepLocked(100.f, 90.f, 1.5f), "keep close");
    CHECK(!keepLocked(900.f, 90.f, 1.5f), "switch to much closer");
    CHECK(!keepLocked(-1.f, 90.f, 1.5f), "lost target");

    printf(fails ? "FAILED: %d\n" : "ALL PASSED\n", fails);
    return fails != 0;
}
