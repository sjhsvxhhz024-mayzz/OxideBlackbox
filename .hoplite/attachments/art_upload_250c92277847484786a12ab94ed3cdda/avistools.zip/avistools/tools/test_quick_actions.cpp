#include "trial/quick_actions_core.h"
#include <cstdio>
#include <limits>
using namespace quickcore;
static int fails = 0;
#define CHECK(x) do { if (!(x)) { ++fails; printf("FAIL line %d: %s\n", __LINE__, #x); } } while (0)
int main() {
    Config c;
    CHECK(!c.enabled && c.slots[0].enabled && c.menuKey == kInsert);
    c.enabled = true; c.slots[3].enabled = true;
    c.slots[3].action = HideTrees; c.slots[3].x = .123f; c.slots[3].y = .875f;
    c.slots[4].action=AutoHeal;
    Config round;
    CHECK(Load(Serialize(c), round));
    CHECK(Serialize(round) == Serialize(c));
    CHECK(!Load("AVIS_QUICK 999\n", round));
    CHECK(Bind(c, 2, 64) && c.slots[2].key == 64 && c.slots[0].key == 0);
    CHECK(!Bind(c, 1, kInsert));
    CHECK(!Bind(c, -2, 59) && !Bind(c, kSlots, 59) && !Bind(c, 0, -1));
    CHECK(Bind(c, -1, 65) && c.menuKey == 65 && c.slots[1].key == 0);
    c.size = std::numeric_limits<float>::quiet_NaN(); c.opacity = -5.f;
    c.slots[0].action = 999; c.slots[0].x = std::numeric_limits<float>::infinity();
    c.slots[0].y = -2.f; c.slots[0].key = 999999;
    Normalize(c);
    CHECK(c.size == 64.f && c.opacity == .35f && c.slots[0].action == Esp);
    CHECK(c.slots[0].x == .92f && c.slots[0].y == 0.f && !c.slots[0].key);
    CHECK(Load("AVIS_QUICK 1\nslot -1 1 5 64 1 1\nslot 0 1 999 999999 -4 8\nsize -4\nopacity 4\n", round));
    CHECK(round.size == 44.f && round.opacity == 1.f && round.slots[0].action == Esp);
    CHECK(round.slots[0].x == 0.f && round.slots[0].y == 1.f && !round.slots[0].key);
    KeyEdges edges;
    CHECK(edges.Feed(64, 1));
    CHECK(!edges.Feed(64, 1) && !edges.Feed(64, 2));
    CHECK(!edges.Feed(64, 0) && edges.Feed(64, 1));
    CHECK(!edges.Feed(-1, 1) && !edges.Feed(kKeyCount, 1));
    edges.Reset(); edges.down[64] = true;
    CHECK(!edges.Feed(64, 1)); // A key already held when the device is opened is not a press.
    Drag drag;
    drag.Begin(100, 100, 200, 200);
    CHECK(!drag.Move(103, 104, 8) && !drag.moved);
    CHECK(drag.Move(109, 100, 8) && drag.moved);
    CHECK(drag.Move(100, 100, 8)); // Returning to the start must not turn a drag into a click.
    drag.Begin(100, 100, 200, 200); CHECK(!drag.moved);
    Debounce d; d.observed = "a";
    CHECK(!d.Tick("b", .1f));
    CHECK(!d.Tick("b", .25f) && !d.Tick("b", .25f));
    CHECK(!d.Tick("c", .25f)); // A second edit restarts the timer.
    CHECK(!d.Tick("c", .25f) && !d.Tick("c", .25f) && !d.Tick("c", .25f));
    CHECK(d.Tick("c", .1f) && !d.Tick("c", .25f));
    puts(fails ? "FAILED" : "ALL OK"); return fails != 0;
}