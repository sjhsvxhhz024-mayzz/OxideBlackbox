// Хост-тест skeleton.h: опознание костей гуманоида на синтетических иерархиях.
// Запуск из корня репозитория: g++ -O2 -std=c++17 -Isrc -Itools tools/test_skeleton.cpp -o /tmp/t1 && /tmp/t1
#include "skeleton.h"
#include "skel_testgen.h"
#include <cstdio>
#include <cstdlib>
#include <set>
using namespace oxskel;
static int fails = 0;
#define CHECK(c, ...) do { if(!(c)) { ++fails; printf("FAIL: "); printf(__VA_ARGS__); printf("\n"); } } while(0)

static unsigned g_seed = 12345;
static float rnd01() { g_seed = g_seed * 1664525u + 1013904223u; return ((g_seed >> 9) & 0x7FFFFF) / 8388607.0f; }

int main() {
    const float speeds[4] = { 0.0f, 1.5f, 3.5f, 5.5f };
    int total = 0, perfect = 0, fineMissing = 0, forbiddenHit = 0, swapped = 0, identFail = 0, saneFail = 0;
    double worst = 0; int fineTotal = 0;
    for (int iter = 0; iter < 1200; ++iter) {
        tg::GenIn gi;
        gi.S = 1.66f * (0.9f + 0.2f * rnd01());
        gi.speed = speeds[iter % 4];
        gi.crouch = (iter % 7 == 0) ? 0.8f : 0.0f;
        gi.aim = (iter % 5 == 0);
        gi.yaw = rnd01() * 6.28318f;
        gi.phase = rnd01() * 6.28318f;
        gi.time = rnd01() * 10.0f;
        gi.feet = V3{ 100.0f * rnd01(), 5.0f * rnd01(), 100.0f * rnd01() };
        Pose truth; tg::GenPose(gi, truth);
        tg::RigOpt ro;
        ro.clavicle = iter % 3 != 0; ro.toes = iter % 4 != 1; ro.fingers = iter % 6 != 2; ro.weapon = iter % 2 == 0;
        ro.backpack = iter % 3 == 1; ro.twist = iter % 5 != 3; ro.junk = true; ro.shuffle = iter % 2 == 1; ro.seed = (unsigned)iter + 1;
        tg::SynRig rig; tg::BuildRig(truth, gi.feet, ro, rig);

        const int N = rig.size();
        std::vector<uint8_t> valid(N, 1);
        RigIn in; in.N = N; in.parent = rig.parent.data(); in.wpos = rig.world.data(); in.valid = valid.data();
        in.head = rig.head; in.ref = gi.S * (0.88f + 0.24f * rnd01());                 // масштаб порогов задан с ошибкой ±12 %
        in.right = V3{ cosf(gi.yaw), 0, -sinf(gi.yaw) };
        RigMap m; ++total;
        if (!IdentifyRig(in, m)) { ++identFail; if (identFail < 6) printf("  ident fail iter %d speed %.1f crouch %.1f aim %d opts clav%d toes%d fing%d weap%d bp%d twist%d shuf%d\n", iter, gi.speed, gi.crouch, gi.aim, ro.clavicle, ro.toes, ro.fingers, ro.weapon, ro.backpack, ro.twist, ro.shuffle); continue; }
        bool exact = true;
        for (int k = 0; k < J_COUNT; ++k) {
            if (rig.joint[k] < 0) { if (k != J_TOE_R && k != J_TOE_L) exact = false; continue; }
            if (m.j[k] != rig.joint[k]) { exact = false; if (identFail + swapped < 12) printf("    iter %d joint %d: got %d want %d (%s)\n", iter, k, m.j[k], rig.joint[k], rig.name[rig.joint[k]].c_str()); }
        }
        if (!exact) ++swapped; else ++perfect;
        // мелкие кости: все пальцы и концы носков есть, оружия/рюкзака/волос нет
        std::set<int> got(m.fineN, m.fineN + m.nf);
        for (int f : rig.fine) { ++fineTotal; if (!got.count(f)) ++fineMissing; }
        for (int f : rig.forbidden) if (got.count(f)) { ++forbiddenHit; if (forbiddenHit < 4) printf("    forbidden in fine: %s (iter %d)\n", rig.name[f].c_str(), iter); }
        // поза из карты
        std::vector<uint8_t> have(N, 1);
        Pose p; const V3 fwd{ sinf(gi.yaw), 0, cosf(gi.yaw) };
        if (!BuildPose(m, rig.world.data(), have.data(), gi.feet, gi.S, in.right, fwd, p)) { ++saneFail; continue; }
        for (int k = 0; k < J_COUNT; ++k) if (rig.joint[k] >= 0) worst = fmax(worst, len(p.j[k] - rig.world[rig.joint[k]]));
        if (!PoseSane(p, in.ref)) { ++saneFail; if (saneFail < 4) printf("    not sane iter %d\n", iter); }
        // ребро мелкой кости: от родителя к узлу
        CHECK(p.ne == m.nf || p.ne <= kMaxEdges, "edges count");
    }
    printf("IdentifyRig: %d rigs: exact joints %d, wrong %d, ident failures %d, pose-sane failures %d\n", total, perfect, swapped, identFail, saneFail);
    printf("  fine bones: %d expected, %d missing; forbidden (weapon/backpack/hair) leaked: %d; worst joint error %.5f m\n", fineTotal, fineMissing, forbiddenHit, worst);
    CHECK(identFail == 0, "identification failures");
    CHECK(swapped == 0, "wrong joints");
    CHECK(fineMissing == 0, "missing fine bones");
    CHECK(forbiddenHit == 0, "weapon/backpack leaked into fine bones");
    CHECK(saneFail == 0, "pose not sane");
    CHECK(worst < 1e-4, "joint position error");

    // стороны не зависят от угла взгляда: при неверном `right` пары могут поменяться местами, но набор тот же
    {
        int bad = 0, n = 0;
        for (int iter = 0; iter < 200; ++iter) {
            tg::GenIn gi; gi.speed = 3.5f; gi.phase = rnd01() * 6.28f; gi.yaw = rnd01() * 6.28f; gi.feet = V3{ 3, 0, 3 };
            Pose truth; tg::GenPose(gi, truth);
            tg::RigOpt ro; ro.seed = iter + 1; tg::SynRig rig; tg::BuildRig(truth, gi.feet, ro, rig);
            std::vector<uint8_t> valid(rig.size(), 1);
            RigIn in; in.N = rig.size(); in.parent = rig.parent.data(); in.wpos = rig.world.data(); in.valid = valid.data();
            in.head = rig.head; in.ref = gi.S; in.right = V3{ sinf(gi.yaw), 0, cosf(gi.yaw) };          // повёрнута на 90°
            RigMap m; ++n;
            if (!IdentifyRig(in, m)) { ++bad; continue; }
            auto pairOk = [&](Joint a, Joint b) { return (m.j[a] == rig.joint[a] && m.j[b] == rig.joint[b]) || (m.j[a] == rig.joint[b] && m.j[b] == rig.joint[a]); };
            if (!(pairOk(J_HAND_R, J_HAND_L) && pairOk(J_FOOT_R, J_FOOT_L) && pairOk(J_KNEE_R, J_KNEE_L) && pairOk(J_SH_R, J_SH_L))) ++bad;
        }
        printf("wrong body-axis hint: %d/%d rigs still identify every limb (sides may swap)\n", n - bad, n);
        CHECK(bad == 0, "limbs lost when side axis is wrong");
    }

    // AxisCalib: какая ось головной кости смотрит вперёд
    {
        for (int fixAxis = 0; fixAxis < 6; ++fixAxis) {
            AxisCalib ax; bool good = true;
            // модельный поворот: локальная ось fixAxis смотрит по горизонтальному вектору взгляда
            for (int i = 0; i < 400; ++i) {
                const float yaw = rnd01() * 6.28318f, pitch = (rnd01() - 0.5f) * 0.8f;
                Q4 qy = tg::QuatY(yaw);
                // базовый поворот «локальная ось fixAxis -> +Z»
                const V3 a = AxisCalib::Axis(fixAxis), z{ 0, 0, 1 };
                V3 c = cross(a, z); float d = dot(a, z);
                Q4 base{ 0, 0, 0, 1 };
                if (len(c) > 1e-5f) { const float s = sqrtf((1 + d) * 2); base = { c.x / s, c.y / s, c.z / s, s * 0.5f }; }
                else if (d < 0) base = { 0, 1, 0, 0 };
                Q4 qp{ sinf(pitch * 0.5f), 0, 0, cosf(pitch * 0.5f) };
                const Q4 q = qmul(qy, qmul(qp, base));
                ax.Feed(q, V3{ sinf(yaw), 0, cosf(yaw) });
            }
            const int best = ax.Best();
            if (best != fixAxis) good = false;
            // проверка итогового направления
            const float yaw = 1.1f; Q4 qy = tg::QuatY(yaw);
            const V3 a = AxisCalib::Axis(fixAxis), z{ 0, 0, 1 }; V3 c = cross(a, z); float d = dot(a, z);
            Q4 base{ 0, 0, 0, 1 }; if (len(c) > 1e-5f) { const float s = sqrtf((1 + d) * 2); base = { c.x / s, c.y / s, c.z / s, s * 0.5f }; } else if (d < 0) base = { 0, 1, 0, 0 };
            const V3 face = ax.Face(qmul(qy, base), V3{ 0, 0, 1 });
            if (len(face - V3{ sinf(yaw), 0, cosf(yaw) }) > 1e-3f) good = false;
            CHECK(good, "AxisCalib axis %d: best %d", fixAxis, best);
        }
        printf("AxisCalib: forward axis detected for all 6 local axes\n");
    }
    printf(fails ? "\n%d FAILED\n" : "\nALL PASSED\n", fails);
    return fails ? 1 : 0;
}
