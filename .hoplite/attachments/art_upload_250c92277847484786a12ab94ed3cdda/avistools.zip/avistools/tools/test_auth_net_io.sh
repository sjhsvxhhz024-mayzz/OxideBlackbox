#!/usr/bin/env bash
# Real sockets: HTTP/HTTPS delay >1s, fragments, keep-alive, truncation, 5s timeout.
# Requires a C++ compiler and Python cryptography (PY can select a virtualenv).
set -euo pipefail
cd "$(dirname "$0")/.."
PY="${PY:-python3}"
M=third_party/mbedtls
OBJ=/tmp/avis_mbedtls_host
mkdir -p "$OBJ"
if [ ! -f "$OBJ/libmbedtls.a" ]; then
    ls "$M"/library/*.c | xargs -P"$(nproc)" -I{} sh -c "gcc -O2 -w -c -I$M/include -I$M/library {} -o $OBJ/\$(basename {} .c).o"
    ar rcs "$OBJ/libmbedtls.a" "$OBJ"/*.o
fi
g++ -std=c++17 -O1 -Wall -Isrc -I"$M/include" tools/test_auth_net_io.cpp src/auth/auth_net.cpp \
    "$OBJ/libmbedtls.a" -pthread -o /tmp/avis_test_auth_net_io
"$PY" tools/test_auth_net_io.py /tmp/avis_test_auth_net_io