"""Генерирует определения глобальных переменных main.cpp, на которые ссылается меню (для превью без main.cpp)."""
import re
srcs = ["src/trial/trial_cfg_externs.inc", "src/trial/trial_menu.cpp", "src/trial/trial_configs.cpp", "src/trial/quick_actions.cpp", "src/trial/esp_style.h"]
TYPE = re.compile(r"^((?:const\s+)?(?:std::string|bool|int|float|double|uint\d+_t|size_t|unsigned))\s+(.*)$")
main = open("src/main.cpp", encoding="utf-8").read()
seen, out = set(), []
for p in srcs:
    for line in open(p, encoding="utf-8"):
        m = re.match(r"^extern\s+(?!\"C\")(.+);\s*(//.*)?$", line.strip())
        if not m or "(" in m.group(1):
            continue
        t = TYPE.match(m.group(1))
        if not t:
            continue
        for v in t.group(2).split(","):
            name = re.match(r"\s*(\w+)", v).group(1)
            if name not in seen:
                seen.add(name)
                initializer = ""
                m = re.search(r"\b" + re.escape(name) + r"\s*(?:\[[^]]*\])?\s*=\s*([^;]+);", main)
                if m:
                    value = m.group(1).strip()
                    tokens = value.strip("{}").split(",")
                    literal = all(re.fullmatch(r'(?:true|false|[-+]?(?:0x[0-9a-fA-F]+|(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][-+]?[0-9]+)?)[fFuUlL]*|espstyle::\w+(?:\[\d+\])?|"(?:[^"\\]|\\.)*")', x.strip()) for x in tokens)
                    if literal: initializer = " = " + value
                out.append(f"{t.group(1)} {v.strip()}{initializer};")
print('#include <string>\n#include <vector>\n#include <stdint.h>\n#include "trial/esp_style.h"')
print("\n".join(out))
