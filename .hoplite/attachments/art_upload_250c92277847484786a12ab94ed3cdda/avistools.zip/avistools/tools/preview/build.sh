#!/usr/bin/env bash
# Хост-превью меню: bash tools/preview/build.sh <сценарий> <выход.png> [время_сек] [ширина высота]
set -euo pipefail
cd "$(dirname "$0")/../.."
SYS=${SYSROOT:-/tmp/derh-sysroot}/inc
DEFINES=""
BIN=/tmp/avis_preview
if [ "${AVIS_PREVIEW_PC:-0}" = 1 ]; then DEFINES="-DAVIS_PREVIEW_PC"; BIN=/tmp/avis_preview_pc; fi
if [ ! -x "$BIN" ] || [ -n "$(find src tools/preview include assets -newer "$BIN" \( -name '*.cpp' -o -name '*.h' -o -name '*.jpg' -o -name '*.inc' -o -name '*.py' \) 2>/dev/null | head -1)" ]; then
    python3 tools/preview/gen_stubs.py > /tmp/avis_stubs_gen.cpp
    g++ -std=c++17 -O2 -w -DUSE_OPENGL -DAVIS_PREVIEW $DEFINES -Iinclude -Iinclude/ImGui -Isrc -Isrc/trial -Itools/preview -isystem "$SYS" \
        tools/preview/preview.cpp tools/preview/auth_stub.cpp /tmp/avis_stubs_gen.cpp \
        src/trial/trial_menu.cpp src/trial/trial_ui.cpp src/trial/trial_configs.cpp src/trial/quick_actions.cpp src/trial/auto_heal.cpp src/trial/auth_screen.cpp src/trial/i18n.cpp src/auth/auth_sound.cpp \
        src/ImGui/imgui.cpp src/ImGui/imgui_draw.cpp src/ImGui/imgui_tables.cpp src/ImGui/imgui_widgets.cpp -o "$BIN"
fi
PPM=$(mktemp --suffix=.ppm)
"$BIN" "$1" "$PPM" "${3:-2.0}" ${4:-2400} ${5:-1080}
ffmpeg -v error -y -i "$PPM" "$2" && rm -f "$PPM"
echo "ok: $2"
