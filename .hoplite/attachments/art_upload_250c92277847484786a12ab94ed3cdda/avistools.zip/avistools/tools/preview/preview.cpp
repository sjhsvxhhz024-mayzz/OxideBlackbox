// Хост-превью меню Trial и экрана ключа: настоящий код UI, ImGui -> программный растеризатор -> PPM.
//   bash tools/preview/build.sh <сценарий> <выход.ppm> [время_сек]
// Сценарии: menu:<вкладка>:<подвкладка> | key_empty | key_typed | key_hold | key_full | key_error | key_checking | key_offline | key_success | menu
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <string>

#include "trial_config.h"
#include "auth/auth_client.h"

struct PTex { int w = 0, h = 0; std::vector<uint8_t> px; };   // RGBA8
static PTex g_ptex[TEX_COUNT];
static PTex g_fontTex;

ImTextureID GetTexture(int slot, ImVec2 *size) {
    if (slot < 0 || slot >= TEX_COUNT || g_ptex[slot].w == 0) return (ImTextureID)0;
    if (size) *size = ImVec2((float)g_ptex[slot].w, (float)g_ptex[slot].h);
    return (ImTextureID)&g_ptex[slot];
}
void TrialUploadTextures() {}

extern void AuthPreviewType(const char *chars);           // auth_screen.cpp (AVIS_PREVIEW)
extern void AuthPreviewHold(char c);
extern void MenuPreviewSelect(int tab, int sub);          // trial_menu.cpp (AVIS_PREVIEW)                      // «зажать» клавишу: вдавленный вид и пузырь-превью
extern void MenuPreviewChamsDissolve(float phase);
namespace avis { void PreviewSet(const Snapshot &s, bool active); }

static void LoadTex(int slot, const char *path, bool gray) {
    int w, h, n;
    unsigned char *d = stbi_load(path, &w, &h, &n, 4);
    if (!d) { fprintf(stderr, "не удалось загрузить %s\n", path); return; }
    PTex &t = g_ptex[slot];
    t.w = w; t.h = h; t.px.assign(d, d + (size_t)w * h * 4);
    if (gray) for (size_t i = 0; i < (size_t)w * h; ++i) { t.px[i * 4 + 1] = t.px[i * 4]; t.px[i * 4 + 2] = t.px[i * 4]; t.px[i * 4 + 3] = 255; }
    stbi_image_free(d);
}

// ---------------------------------------------------------------- растеризатор
struct Fb { int w, h; std::vector<float> c; };   // RGB float

static void Sample(const PTex *t, float u, float v, float out[4]) {
    float x = u * t->w - 0.5f, y = v * t->h - 0.5f;
    int x0 = (int)floorf(x), y0 = (int)floorf(y);
    float fx = x - x0, fy = y - y0;
    auto at = [&](int xx, int yy, int k) {
        xx = xx < 0 ? 0 : xx >= t->w ? t->w - 1 : xx;
        yy = yy < 0 ? 0 : yy >= t->h ? t->h - 1 : yy;
        return t->px[((size_t)yy * t->w + xx) * 4 + k] / 255.0f;
    };
    for (int k = 0; k < 4; ++k)
        out[k] = (at(x0, y0, k) * (1 - fx) + at(x0 + 1, y0, k) * fx) * (1 - fy) + (at(x0, y0 + 1, k) * (1 - fx) + at(x0 + 1, y0 + 1, k) * fx) * fy;
}

static void Raster(Fb &fb, ImDrawData *dd) {
    for (int n = 0; n < dd->CmdListsCount; ++n) {
        const ImDrawList *dl = dd->CmdLists[n];
        for (const ImDrawCmd &cmd : dl->CmdBuffer) {
            if (cmd.UserCallback) continue;
            const PTex *tex = (const PTex *)cmd.GetTexID();
            const int cx0 = ImMax(0, (int)cmd.ClipRect.x), cy0 = ImMax(0, (int)cmd.ClipRect.y);
            const int cx1 = ImMin(fb.w, (int)ceilf(cmd.ClipRect.z)), cy1 = ImMin(fb.h, (int)ceilf(cmd.ClipRect.w));
            for (unsigned i = 0; i + 2 < cmd.ElemCount; i += 3) {
                const ImDrawVert &A = dl->VtxBuffer[dl->IdxBuffer[cmd.IdxOffset + i] + cmd.VtxOffset];
                const ImDrawVert &B = dl->VtxBuffer[dl->IdxBuffer[cmd.IdxOffset + i + 1] + cmd.VtxOffset];
                const ImDrawVert &C = dl->VtxBuffer[dl->IdxBuffer[cmd.IdxOffset + i + 2] + cmd.VtxOffset];
                struct Q { int64_t x,y; };
                auto q=[](ImVec2 p){return Q{(int64_t)llround(p.x*256),(int64_t)llround(p.y*256)};};
                const Q qa=q(A.pos), qb=q(B.pos), qc=q(C.pos);
                auto edge=[](Q a,Q b,Q p){return (b.x-a.x)*(p.y-a.y)-(b.y-a.y)*(p.x-a.x);};
                const int64_t signedArea=edge(qa,qb,qc);
                if (!signedArea) continue;
                const int sign=signedArea>0?1:-1;
                auto inclusive=[&](Q a,Q b){if(sign<0)std::swap(a,b);return b.y<a.y || (b.y==a.y && b.x>a.x);};
                const bool in0=inclusive(qb,qc),in1=inclusive(qc,qa),in2=inclusive(qa,qb);
                int minx = ImMax(cx0, (int)floorf(ImMin(A.pos.x, ImMin(B.pos.x, C.pos.x))));
                int maxx = ImMin(cx1 - 1, (int)ceilf(ImMax(A.pos.x, ImMax(B.pos.x, C.pos.x))));
                int miny = ImMax(cy0, (int)floorf(ImMin(A.pos.y, ImMin(B.pos.y, C.pos.y))));
                int maxy = ImMin(cy1 - 1, (int)ceilf(ImMax(A.pos.y, ImMax(B.pos.y, C.pos.y))));
                const double inv = 1.0 / (double)signedArea;
                float ca[4], cb[4], cc[4];
                for (int k = 0; k < 4; ++k) { ca[k] = ((A.col >> (8 * k)) & 0xFF) / 255.0f; cb[k] = ((B.col >> (8 * k)) & 0xFF) / 255.0f; cc[k] = ((C.col >> (8 * k)) & 0xFF) / 255.0f; }
                for (int y = miny; y <= maxy; ++y)
                    for (int x = minx; x <= maxx; ++x) {
                        const Q pixel{(int64_t)x*256+128,(int64_t)y*256+128};
                        const int64_t e0=edge(qb,qc,pixel),e1=edge(qc,qa,pixel),e2=edge(qa,qb,pixel);
                        if (e0*sign<0 || e1*sign<0 || e2*sign<0 ||
                            (!e0&&!in0) || (!e1&&!in1) || (!e2&&!in2)) continue;
                        const float w0=(float)(e0*inv),w1=(float)(e1*inv),w2=(float)(e2*inv);
                        float col[4];
                        for (int k = 0; k < 4; ++k) col[k] = ca[k] * w0 + cb[k] * w1 + cc[k] * w2;
                        if (tex && tex->w) {
                            float t[4];
                            Sample(tex, A.uv.x * w0 + B.uv.x * w1 + C.uv.x * w2, A.uv.y * w0 + B.uv.y * w1 + C.uv.y * w2, t);
                            for (int k = 0; k < 4; ++k) col[k] *= t[k];
                        }
                        float *d = &fb.c[((size_t)y * fb.w + x) * 3];
                        for (int k = 0; k < 3; ++k) d[k] = col[k] * col[3] + d[k] * (1.0f - col[3]);
                    }
            }
        }
    }
}

// ---------------------------------------------------------------- сценарии
static ImFont *LoadFont(const char *path, float px, const ImWchar *ranges) {
    ImFontConfig c;
    c.OversampleH = 2; c.OversampleV = 2;
    return ImGui::GetIO().Fonts->AddFontFromFileTTF(path, px, &c, ranges);
}

int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "usage: preview <scenario> <out.ppm> [time]\n"); return 2; }
    std::string sc = argv[1];
    int pvTab = 0, pvSub = 0;
    if (sc.rfind("menu:", 0) == 0) { sscanf(sc.c_str(), "menu:%d:%d", &pvTab, &pvSub); sc = "menu"; }
    const float tEnd = argc > 3 ? (float)atof(argv[3]) : 2.0f;
    const int W = argc > 4 ? atoi(argv[4]) : 2400, H = argc > 5 ? atoi(argv[5]) : 1080;

    ImGui::CreateContext();
    ImGuiIO &io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.DisplaySize = ImVec2((float)W, (float)H);
    static const ImWchar menuGlyphs[] = {0x20,0x17F,0x400,0x52F,0x2000,0x206F,0};
        const ImWchar *ru = menuGlyphs;
    static const ImWchar latin[] = { 0x20, 0x17F, 0 };
    const char *dir = getenv("AVIS_PREVIEW_FONTS");
    if (!dir) dir = "/usr/share/fonts/liberation-sans/";
    g_trialFontText  = LoadFont((std::string(dir) + "LiberationSans-Regular.ttf").c_str(), 28.0f, ru);
    g_trialFontMed   = LoadFont((std::string(dir) + "LiberationSans-Bold.ttf").c_str(), 32.0f, ru);
    g_trialFontTitle = LoadFont((std::string(dir) + "LiberationSans-Bold.ttf").c_str(), 62.0f, latin);
    unsigned char *fp; int fw, fh;
    io.Fonts->GetTexDataAsRGBA32(&fp, &fw, &fh);
    g_fontTex.w = fw; g_fontTex.h = fh; g_fontTex.px.assign(fp, fp + (size_t)fw * fh * 4);
    io.Fonts->SetTexID((ImTextureID)&g_fontTex);

    const char *as = "assets/trial/";
    LoadTex(TEX_STAR, (std::string(as) + "mark.png").c_str(), false);
    LoadTex(TEX_LOGO_ATLAS, (std::string(as) + "logo.png").c_str(), false);
    LoadTex(TEX_ESP_PERSON, (std::string(as) + "person.png").c_str(), false);
    LoadTex(TEX_PARTICLE_ATLAS, (std::string(as) + "atlas.png").c_str(), false);
    for (int i = 0; i < TEX_BANNER_COUNT; ++i) LoadTex(TEX_BANNER + i, (std::string(as) + "banner" + std::to_string(i) + ".jpg").c_str(), true);

    char previewDir[] = "/tmp/avis_preview_XXXXXX";
    if (!mkdtemp(previewDir)) return 3;
    g_DataDir = previewDir;

    avis::Snapshot s;
    s.infoReady = true; s.serverSet = true; s.bot = "AvisToolsBot"; s.channel = "AvisTools";
    bool active = false;
    const char *typed = "";
    if (sc == "key_typed") { typed = "7KQ2M9"; AuthPreviewHold('K'); }
    if (sc == "key_hold") { typed = "7KQ2M9XPL"; AuthPreviewHold('R'); }
    if (sc == "key_full") typed = "7KQ2M9XPLR4T";
    if (sc == "key_error") { typed = "7KQ2M9XPLR4T"; s.msg = avis::Msg::Invalid; }
    if (sc == "key_checking") { typed = "7KQ2M9XPLR4T"; s.phase = avis::Phase::Checking; }
    if (sc == "key_offline") { s.infoReady = false; s.infoFailed = true; s.msg = avis::Msg::Network; typed = "7KQ2M9XPLR4T"; }
    if (sc == "key_success" || sc == "menu") { active = true; s.phase = avis::Phase::Active; s.remainingSec = 85000; }
    avis::PreviewSet(s, active);
    g_cfg.lang = getenv("AVIS_PREVIEW_LANG") && strcmp(getenv("AVIS_PREVIEW_LANG"), "ru") == 0 ? 0 : 1;
    if (sc == "menu") MenuPreviewSelect(pvTab, pvSub);
    AuthPreviewType(typed);

    ImDrawData *dd = nullptr;
    const float dt = 0.1f;
    const int frames = (int)(tEnd / dt) + 1;
    for (int f = 0; f < frames; ++f) {
        io.DeltaTime = dt;
        ImGui::NewFrame();
        extern void OxDrawTrialMenu();
        if (f > 0) {
            g_cfg.lang = getenv("AVIS_PREVIEW_LANG") && strcmp(getenv("AVIS_PREVIEW_LANG"),"ru") == 0 ? 0 : 1;
            if (getenv("AVIS_PREVIEW_STILL")) g_cfg.anim = false;
        }
        if (sc=="menu" && pvTab==0 && pvSub==7 && getenv("AVIS_PREVIEW_DISSOLVE"))
            MenuPreviewChamsDissolve((float)atof(getenv("AVIS_PREVIEW_DISSOLVE")));
        OxDrawTrialMenu();
        ImGui::Render();
        dd = ImGui::GetDrawData();
        if (sc == "key_success" && f == (int)(0.5f / dt)) break;   // середина анимации успеха
        if (sc == "menu" && f == 0) { /* продолжаем до конца */ }
    }
    Fb fb;
    fb.w = W; fb.h = H; fb.c.resize((size_t)W * H * 3);
    for (int y = 0; y < H; ++y)       // фон «игры»: холодный градиент с лёгким шумом
        for (int x = 0; x < W; ++x) {
            float v = 0.10f + 0.18f * (1.0f - (float)y / H) + 0.03f * sinf(x * 0.013f) * sinf(y * 0.017f);
            float *d = &fb.c[((size_t)y * W + x) * 3];
            d[0] = v * 0.62f; d[1] = v * 0.80f; d[2] = v * 0.98f;
        }
    Raster(fb, dd);
    FILE *o = fopen(argv[2], "wb");
    fprintf(o, "P6\n%d %d\n255\n", W, H);
    for (size_t i = 0; i < (size_t)W * H * 3; ++i) { float v = fb.c[i]; fputc((int)(v < 0 ? 0 : v > 1 ? 255 : v * 255 + 0.5f), o); }
    fclose(o);
    Menu::Shutdown();
    for (const char *name : {"trial_settings.bin","quick_actions.cfg","auto_heal.cfg","settings.cfg"}) unlink((g_DataDir + "/" + name).c_str());
    rmdir(g_DataDir.c_str());
    ImGui::DestroyContext();
    return 0;
}
