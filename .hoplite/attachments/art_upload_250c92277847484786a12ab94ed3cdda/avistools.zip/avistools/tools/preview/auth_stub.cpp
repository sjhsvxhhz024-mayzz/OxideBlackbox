// Заглушка клиента ключей для превью: состояние задаётся из сценария, сети нет.
#include "auth/auth_client.h"

namespace avis {
static Snapshot g_s;
static bool g_active = false;
void PreviewSet(const Snapshot &s, bool active) { g_s = s; g_active = active; }
void Init(const char *) {}
void Shutdown() {}
Snapshot Get() { return g_s; }
bool Active() { return g_active; }
int64_t RemainingSec() { return g_active ? g_s.remainingSec : 0; }
int previewSubmissions = 0;
std::string previewSubmittedKey;
void Submit(const std::string &key) { ++previewSubmissions; previewSubmittedKey=key; }
void Logout() {}
void CancelCheck() { g_s.phase = Phase::NeedKey; g_s.retrying = false; }
void RetryServer() {}
void RequestPaste() {}
bool PasteBusy() { return false; }
bool TakePaste(PasteResult &) { return false; }
void OpenBot() {}
void OpenChannel() {}
}
