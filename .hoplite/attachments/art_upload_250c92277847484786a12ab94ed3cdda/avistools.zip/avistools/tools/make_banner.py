#!/usr/bin/env python3
"""Нарезает видео-фон экрана ключа в серые JPEG-атласы: assets/trial/banner0.jpg ... banner6.jpg

   python3 tools/make_banner.py путь/к/видео.mp4

Берутся ВСЕ кадры ролика в его родном темпе (без вспышек-замен, без перекраски): ролик чёрно-белый, белые кадры — часть монтажа.
Кадры 384x216, по 5x9 = 45 кадров в атласе 1920x1944 (меньше 2048: помещается в текстуру любого телефона с OpenGL ES 3).
Константы kFrames/kTiles/kFrameW/kFrameH/kCols/kRows в src/trial/auth_screen.cpp проверяются при запуске — разойдутся, скрипт упадёт.
"""
import glob, os, re, subprocess, sys

COLS, ROWS, W, H = 5, 9, 384, 216
root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
src = sys.argv[1]
fps_s = subprocess.check_output(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=nb_frames,r_frame_rate,duration",
                                 "-of", "default=nw=1", src]).decode()
kv = dict(l.split("=") for l in fps_s.split())
frames, dur = int(kv["nb_frames"]), float(kv["duration"])
tiles = -(-frames // (COLS * ROWS))

code = open(os.path.join(root, "src/trial/auth_screen.cpp"), encoding="utf-8").read()
want = {"kFrames": frames, "kTiles": tiles, "kFrameW": W, "kFrameH": H, "kCols": COLS, "kRows": ROWS}
for name, val in want.items():
    m = re.search(r"%s\s*=\s*([0-9.]+)" % name, code)
    if not m or int(float(m.group(1))) != val:
        sys.exit(f"{name} в auth_screen.cpp = {m.group(1) if m else '?'}, а должно быть {val}. Поправь константу и запусти снова.")

out = os.path.join(root, "assets", "trial")
for old in glob.glob(os.path.join(out, "banner*.jpg")):
    os.remove(old)
subprocess.check_call(["ffmpeg", "-v", "error", "-y", "-i", src, "-an", "-vf", f"scale={W}:{H}:flags=lanczos,format=gray,tile={COLS}x{ROWS}",
                       "-q:v", "4", "-pix_fmt", "yuvj420p", "-start_number", "0", os.path.join(out, "banner%d.jpg")])
files = sorted(glob.glob(os.path.join(out, "banner*.jpg")))
if len(files) != tiles:
    sys.exit(f"ожидалось {tiles} атласов, получилось {len(files)}")
total = sum(os.path.getsize(f) for f in files)
print(f"{frames} кадров за {dur:.3f} с ({frames / dur:.2f} к/с), {tiles} атласов, {total // 1024} КБ")
