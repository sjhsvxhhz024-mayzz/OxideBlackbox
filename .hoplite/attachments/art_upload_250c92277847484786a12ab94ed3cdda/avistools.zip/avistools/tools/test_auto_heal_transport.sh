#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
BIN=$(mktemp /tmp/avis_heal_transport.XXXXXX)
trap 'rm -f "$BIN"' EXIT
g++ -std=c++17 -O1 -pthread -Iinclude/ImGui -Iinclude -Isrc -Isrc/trial \
 tools/test_auto_heal_transport.cpp src/trial/trial_ui.cpp src/trial/i18n.cpp \
 src/ImGui/imgui.cpp src/ImGui/imgui_draw.cpp src/ImGui/imgui_tables.cpp src/ImGui/imgui_widgets.cpp -o "$BIN"
"$BIN"
