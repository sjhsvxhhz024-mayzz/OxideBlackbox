// Хост-тест таблиц архитектур: g++ -std=c++17 -O1 -Iinclude tools/test_arch.cpp -o /tmp/t && /tmp/t
#include "oxide_arch.h"
#include <cstdio>
#include <vector>
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { ++fails; printf("FAIL line %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)
using namespace oxarch;

static std::vector<uint64_t> slots(const Arch &a) {
    return { a.tiPlayerManager, a.tiGameController, a.tiNetworkClient, a.tiEquipRegistry, a.tiWeaponRegistry, a.tiWorldStreaming, a.tiBuildingPiece, a.tiPlayerVitals };
}

int main() {
    {   // Обе архитектуры 1.15.11966 проверяются по отдельным ScriptMetadata.
        const auto a = slots(kArm64), x = slots(kX86_64);
        const std::vector<uint64_t> expectedArm = {
            0xDEA09F8ULL, 0xDE9BCB0ULL, 0xDE9FC60ULL, 0xDEA65C0ULL,
            0xDE9ACA0ULL, 0xDEA5540ULL, 0xDE98CA8ULL, 0xDEA0A58ULL,
        };
        const std::vector<uint64_t> expectedPc = {
            0xDB6D178ULL, 0xDB68430ULL, 0xDB6C3E0ULL, 0xDB72D40ULL,
            0xDB67420ULL, 0xDB71CC0ULL, 0xDB65428ULL, 0xDB6D1D8ULL,
        };
        CHECK(a == expectedArm, "ARM64 slots differ from 1.15.11966 ScriptMetadata");
        CHECK(x == expectedPc, "x86_64 slots differ from 1.15.11966 ScriptMetadata");
        for (size_t i = 0; i < a.size(); ++i) for (size_t j = i + 1; j < a.size(); ++j) CHECK(a[i] != a[j] && x[i] != x[j], "duplicate slot %zu/%zu", i, j);
        for (size_t i = 0; i < a.size(); ++i) CHECK(a[i] % 8 == 0 && x[i] % 8 == 0, "slot %zu must be pointer-aligned", i);
    }
    {   // Диапазоны указателей: телефон — 39 бит, ПК — 47 бит; пары int и float в одном слове указателем не считаются.
        CHECK(isPtr(kArm64, 0x7b6fd15540ULL) && isPtr(kArm64, 0x7c28212ca0ULL), "arm64 heap pointers from the real logs");
        CHECK(!isPtr(kArm64, 0x7f1234567890ULL), "x86 address is not an arm64 pointer");
        CHECK(isPtr(kX86_64, 0x7f1234567890ULL) && isPtr(kX86_64, 0x7ffd12345678ULL) && isPtr(kX86_64, 0x558812345670ULL), "x86_64 typical addresses");
        CHECK(!isPtr(kX86_64, 0x7b6fd15540ULL), "arm64-style 39-bit value is below the x86_64 range");
        CHECK(!isPtr(kX86_64, 0x0000000000000064ULL) && !isPtr(kX86_64, 0x4120000041200000ULL) && !isPtr(kX86_64, 0xFFFFFFFFFFFFFFFFULL), "small ints / float pairs / -1");
        CHECK(!isPtr(kX86_64, 0x0000006400000064ULL) && !isPtr(kX86_64, 0x000007D000000000ULL), "two packed ints (100,100) and (2000,0) are not pointers");
        CHECK(!isPtr(kArm64, 0xFFFFFFFFFFFFFFFFULL) && !isPtr(kArm64, 0), "arm64 rejects -1 and 0");
    }
    {   // Системные вызовы process_vm_readv/writev.
        CHECK(kArm64.sysProcessVmReadv == 270 && kArm64.sysProcessVmWritev == 271, "arm64 syscalls");
        CHECK(kX86_64.sysProcessVmReadv == 310 && kX86_64.sysProcessVmWritev == 311, "x86_64 syscalls");
    }
    {   // Текущая архитектура хоста выбрана и согласована.
#if defined(OX_ARCH_FORCE_ARM64) || defined(__aarch64__)
        CHECK(&kCur == &kArm64, "kCur is arm64");
#else
        CHECK(&kCur == &kX86_64, "kCur is x86_64 on an x86_64 host");
#endif
    }
    printf(fails ? "FAILED: %d\n" : "ALL OK\n", fails);
    return fails ? 1 : 0;
}
