// Хост-тест правки конфигов оружия: g++ -std=c++17 -O1 -Isrc -Iinclude tools/test_weapon_patch.cpp -o /tmp/t && /tmp/t
#define OX_ARCH_FORCE_ARM64   // тест использует адреса телефона (до 0x8000000000)
#include "weapon_patch.h"
#include <cstdio>
#include <map>
using namespace wpatch;
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { ++fails; printf("FAIL line %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

struct FakeMem {
    std::vector<uint8_t> mem; uint64_t base = 0x7000000000ULL; std::map<uint64_t, std::string> names; int writes = 0;
    FakeMem() : mem(1 << 20, 0) {}
    bool rd(uint64_t a, void *b, size_t n) { if (a < base || a + n > base + mem.size()) return false; memcpy(b, &mem[a - base], n); return true; }
    bool wr(uint64_t a, const void *b, size_t n) { if (a < base || a + n > base + mem.size()) return false; memcpy(&mem[a - base], b, n); ++writes; return true; }
    std::string cls(uint64_t o) { auto it = names.find(o); return it == names.end() ? "" : it->second; }
    void p(uint64_t a, uint64_t v) { memcpy(&mem[a - base], &v, 8); }
    void f(uint64_t a, float v) { memcpy(&mem[a - base], &v, 4); }
    float rf(uint64_t a) { float v; memcpy(&v, &mem[a - base], 4); return v; }
};

struct World { FakeMem m; uint64_t weapon, cfg, disp, rec, calc; };
static World make(uint64_t cfgOff = 0x130, bool withCalc = true, uint64_t weaponAddr = 0x7000010000ULL) {
    World w; FakeMem &m = w.m;
    w.weapon = weaponAddr; w.cfg = 0x7000020000ULL; w.disp = 0x7000021000ULL; w.rec = 0x7000022000ULL; w.calc = 0x7000023000ULL;
    m.names[w.cfg] = "HitscanWeaponConfig"; m.names[w.disp] = "DispersionConfig"; m.names[w.rec] = "RecoilConfig";
    m.p(w.weapon + cfgOff, w.cfg); m.p(w.cfg + 0x68, w.disp); m.p(w.cfg + 0x70, w.rec);
    if (withCalc) { m.p(w.weapon + 0x1F8, w.calc); m.p(w.calc + 0x10, w.disp); m.p(w.calc + 0x18, w.cfg); m.f(w.calc + 0x20, 1.7f); }
    // значения: отдача, разброс
    const float rec[6] = { 0.5f, 1.0f, 1.5f, 2.5f, -0.4f, 0.4f }, dsp[6] = { 0.3f, 1.2f, 0.4f, 2.0f, 0.15f, 1.0f };
    for (int i = 0; i < 6; ++i) { m.f(w.rec + kRecoilFields[i], rec[i]); m.f(w.disp + kDispFields[i], dsp[i]); }
    m.f(w.disp + 0x2C, 4.0f); m.f(w.disp + 0x34, 0.6f); m.f(w.cfg + 0x3C, 0.8f); m.f(w.cfg + 0x18, 28.0f);   // не должны меняться: decrease rate, aim factor, damage
    return w;
}

int main() {
    // 1) обычный FPHitscan: нашли, правим, проверяем
    { World w = make(); Patcher<FakeMem> P; Ctx c;
      CHECK(P.resolve(w.m, w.weapon, c) && c.ok() && c.calc == w.calc, "resolve");
      CHECK(P.applyRecoil(w.m, c) == 6, "recoil fields"); CHECK(P.applySpread(w.m, c) == 7, "spread fields");
      for (int i = 0; i < 6; ++i) { CHECK(w.m.rf(w.rec + kRecoilFields[i]) == 0.f, "recoil[%d] not zero", i); CHECK(w.m.rf(w.disp + kDispFields[i]) == 0.f, "disp[%d] not zero", i); }
      CHECK(w.m.rf(w.cfg + 0x3C) == 0.f, "base dispersion");
      CHECK(w.m.rf(w.disp + 0x2C) == 4.0f && w.m.rf(w.disp + 0x34) == 0.6f && w.m.rf(w.cfg + 0x18) == 28.0f, "unrelated fields must stay");
      CHECK(P.zeroLiveSpread(w.m, c) && w.m.rf(w.calc + 0x20) == 0.f, "live spread");
      CHECK(!P.zeroLiveSpread(w.m, c), "no write when already zero"); }
    // 2) повторная правка не затирает оригиналы; восстановление возвращает их точно
    { World w = make(); Patcher<FakeMem> P; Ctx c; P.resolve(w.m, w.weapon, c);
      P.applyRecoil(w.m, c); P.applySpread(w.m, c); P.applyRecoil(w.m, c); P.applySpread(w.m, c);
      CHECK(P.saved.size() == 13, "saved %zu", P.saved.size());
      CHECK(P.restore(w.m, kRecoil) == 6, "restore recoil only");
      CHECK(w.m.rf(w.rec + 0x18) == 0.5f && w.m.rf(w.rec + 0x2C) == 0.4f, "recoil originals back"); CHECK(w.m.rf(w.disp + 0x18) == 0.f, "spread still patched");
      CHECK(P.restore(w.m) == 7, "restore rest"); CHECK(w.m.rf(w.disp + 0x28) == 0.15f && w.m.rf(w.cfg + 0x3C) == 0.8f && w.m.rf(w.disp + 0x30) == 1.0f, "spread originals back");
      CHECK(P.saved.empty() && P.keys.empty(), "state cleared");
      P.applyRecoil(w.m, c); CHECK(P.restore(w.m, kRecoil) == 6 && w.m.rf(w.rec + 0x20) == 1.5f, "patch again after restore keeps the new original"); }
    // 3) ракетомёт и арбалет: другие смещения config, без калькулятора
    for (uint64_t off : { 0x128ULL, 0x138ULL }) { World w = make(off, false); Patcher<FakeMem> P; Ctx c;
      CHECK(P.resolve(w.m, w.weapon, c) && c.cfgOff == off && c.calc == 0, "alt weapon off 0x%llx", (unsigned long long)off); CHECK(P.applyRecoil(w.m, c) == 6, "alt recoil"); }
    // 4) защита: неверное имя класса — ничего не пишется
    { World w = make(); w.m.names[w.rec] = "SomethingElse"; Patcher<FakeMem> P; Ctx c; CHECK(!P.resolve(w.m, w.weapon, c), "wrong class must be rejected"); CHECK(w.m.writes == 0, "no writes"); }
    { World w = make(); w.m.names[w.cfg] = "HitscanWeaponConfigX"; Patcher<FakeMem> P; Ctx c; CHECK(!P.resolve(w.m, w.weapon, c), "wrong cfg class"); }
    // 5) калькулятор с несовпадающими ссылками не принимается (не пишем в чужой объект)
    { World w = make(); w.m.p(w.calc + 0x10, 0x7000030000ULL); Patcher<FakeMem> P; Ctx c; CHECK(P.resolve(w.m, w.weapon, c) && c.calc == 0, "foreign calculator rejected"); CHECK(!P.zeroLiveSpread(w.m, c), "no live write"); }
    // 6) оружие без конфига (топор, факел), нулевой/мусорный указатель, недоступная память
    { World w = make(); Patcher<FakeMem> P; Ctx c; CHECK(!P.resolve(w.m, 0, c), "null"); CHECK(!P.resolve(w.m, 0x1234, c), "garbage ptr"); CHECK(!P.resolve(w.m, 0x7000090000ULL, c), "empty object"); CHECK(w.m.writes == 0, "no writes on junk"); }
    // 7) смена оружия: у второго другой набор конфигов, первый остаётся в списке для возврата
    { World a = make(0x130, true, 0x7000010000ULL); Patcher<FakeMem> P; Ctx c; P.resolve(a.m, a.weapon, c); P.applyRecoil(a.m, c);
      const uint64_t cfg2 = 0x7000040000ULL, disp2 = 0x7000041000ULL, rec2 = 0x7000042000ULL, weap2 = 0x7000050000ULL;
      a.m.names[cfg2] = "HitscanWeaponConfig"; a.m.names[disp2] = "DispersionConfig"; a.m.names[rec2] = "RecoilConfig";
      a.m.p(weap2 + 0x130, cfg2); a.m.p(cfg2 + 0x68, disp2); a.m.p(cfg2 + 0x70, rec2); a.m.f(rec2 + 0x18, 3.0f);
      Ctx c2; CHECK(P.resolve(a.m, weap2, c2) && c2.recoil == rec2, "second weapon"); P.applyRecoil(a.m, c2);
      CHECK(P.saved.size() == 12, "two weapons saved %zu", P.saved.size()); CHECK(P.restore(a.m) == 12 && a.m.rf(rec2 + 0x18) == 3.0f && a.m.rf(a.rec + 0x18) == 0.5f, "both restored"); }
    // 8) чтение/запись недоступны: не падаем и не считаем успехом
    { World w = make(); Patcher<FakeMem> P; Ctx c; P.resolve(w.m, w.weapon, c); c.recoil = 0x6000000000ULL; CHECK(P.applyRecoil(w.m, c) == 0, "unreadable target"); }
    printf(fails ? "FAILED: %d\n" : "ALL PASSED\n", fails);
    return fails != 0;
}
