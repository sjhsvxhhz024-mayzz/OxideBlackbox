@echo off
setlocal

rem Double-click this file to build one Android bundle with both ABIs.
rem From PowerShell or cmd: build.cmd -Target phone^|pc^|all [-NdkRoot "C:\path\to\ndk"] [-Jobs 8]

pushd "%~dp0"
if errorlevel 1 (
    echo Cannot open project directory: "%~dp0"
    set "result=1"
    goto :done
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1" %*
set "result=%errorlevel%"
popd

:done
if "%result%"=="0" (
    echo.
    if /I "%~1"=="-Help" (
        echo Usage displayed.
    ) else (
        echo Build completed. See dist\Avis_tools_v2.6.sh and SHA256SUMS.
    )
) else (
    echo.
    echo Build failed. See the error above. Exit code: %result%
)

rem Keep the window visible for Explorer double-click; set the environment
rem variable AVIS_BUILD_NO_PAUSE=1 for scripted calls.
if not defined AVIS_BUILD_NO_PAUSE pause
exit /b %result%
