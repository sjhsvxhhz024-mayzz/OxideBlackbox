"""Запуск: бот (long polling) и HTTP API в одном процессе.   python run.py"""
import asyncio
import logging
import signal
import sys

from aiohttp import web

from avisbot import config
from avisbot.api import build_app
from avisbot.bot import Bot
from avisbot.crypto import Signer
from avisbot.db import Database
from avisbot.service import Service
from avisbot.telegram import Telegram


async def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    cfg = config.from_env()
    if not cfg.bot_token:
        print("Не задан BOT_TOKEN (см. .env.example)", file=sys.stderr)
        return 2
    signer = Signer(cfg.signing_key_path)
    db = Database(cfg.db_path)
    tg = Telegram(cfg.bot_token, cfg.tg_api_base)
    await tg.start()
    svc = Service(cfg, db, tg)
    bot = Bot(svc, tg)

    runner = web.AppRunner(build_app(svc, signer, lambda: bot.username))
    await runner.setup()
    await web.TCPSite(runner, cfg.host, cfg.port).start()
    logging.info("API слушает %s:%d", cfg.host, cfg.port)

    task = asyncio.create_task(bot.run())

    async def janitor():
        while True:
            await asyncio.sleep(3600)
            db.cleanup(svc.now())

    jan = asyncio.create_task(janitor())
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for s in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(s, stop.set)
        except NotImplementedError:      # Windows
            pass
    await asyncio.wait({task, asyncio.create_task(stop.wait())}, return_when=asyncio.FIRST_COMPLETED)
    bot.stop(); task.cancel(); jan.cancel()
    await runner.cleanup()
    await tg.close()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(asyncio.run(main()))
    except KeyboardInterrupt:
        pass
