"""Сверяет значки из avisbot/emoji.py с настоящим набором DoodleIcons.   python check_emoji.py
Если набор изменили или удалили, бот не упадёт (покажет обычные эмодзи), но красота пропадёт — этот скрипт скажет об этом."""
import asyncio
import sys

from avisbot import config
from avisbot.emoji import ICONS, SET_NAME, SET_URL
from avisbot.telegram import Telegram, TelegramError


async def main() -> int:
    cfg = config.from_env()
    if not cfg.bot_token:
        print("Не задан BOT_TOKEN", file=sys.stderr)
        return 2
    tg = Telegram(cfg.bot_token, cfg.tg_api_base)
    await tg.start()
    try:
        s = await tg.call("getStickerSet", name=SET_NAME)
    except TelegramError as e:
        print(f"Набор {SET_URL} не получен: {e}")
        return 1
    finally:
        await tg.close()
    live = {st["custom_emoji_id"] for st in s["stickers"]}
    missing = [n for n, (cid, _) in ICONS.items() if cid not in live]
    print(f"набор «{s['title']}»: {len(live)} значков, бот использует {len(ICONS)}")
    if missing:
        print("ПРОПАЛИ:", ", ".join(missing))
        return 1
    print("все значки на месте")
    return 0


sys.exit(asyncio.run(main()))
