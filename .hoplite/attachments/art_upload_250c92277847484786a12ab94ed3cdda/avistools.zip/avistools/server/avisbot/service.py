"""Бизнес-логика: проверка подписки (с кэшем), выдача и проверка ключей."""
from __future__ import annotations

import asyncio
import logging
import re
import time
from dataclasses import dataclass
from typing import Callable, Dict, Optional, Tuple

from .config import Config
from .db import Database
from .telegram import Telegram, TelegramError

log = logging.getLogger("avisbot.service")

KEY_RE = re.compile(r"^AVIS-[A-HJ-NP-Z2-9]{4}-[A-HJ-NP-Z2-9]{4}-[A-HJ-NP-Z2-9]{4}$")
HWID_RE = re.compile(r"^[0-9a-f]{16,64}$")
NONCE_RE = re.compile(r"^[0-9a-f]{8,64}$")


class SubscriptionUnknown(Exception):
    """Не удалось спросить Telegram (бот не админ канала, сеть и т.п.)."""


@dataclass
class IssueResult:
    status: str                  # ok | banned | not_subscribed
    key: Optional[str] = None
    expires_at: int = 0
    reused: bool = False


class Service:
    def __init__(self, cfg: Config, db: Database, tg: Telegram, clock: Callable[[], float] = time.time):
        self.cfg, self.db, self.tg, self.clock = cfg, db, tg, clock
        self._sub_cache: Dict[int, Tuple[float, bool]] = {}
        self._issue_locks: Dict[int, asyncio.Lock] = {}

    def now(self) -> int:
        return int(self.clock())

    def is_owner(self, uid: int) -> bool:
        """Владелец: задан в ADMIN_IDS. Только владельцы назначают и снимают админов."""
        return uid in self.cfg.admin_ids

    def is_admin(self, uid: int) -> bool:
        """Любой админ (владелец или назначенный): команды управления и ключи без проверки подписки."""
        return self.is_owner(uid) or self.db.is_granted_admin(uid)

    async def is_subscribed(self, uid: int, use_cache: bool = True) -> bool:
        if use_cache:
            hit = self._sub_cache.get(uid)
            if hit and self.clock() - hit[0] < self.cfg.sub_cache_sec:
                return hit[1]
        try:
            ok = await self.tg.is_member(self.cfg.channel, uid)
        except TelegramError as e:
            log.error("getChatMember(%s, %s) не удался: %s (бот добавлен админом в канал?)", self.cfg.channel, uid, e)
            raise SubscriptionUnknown(str(e)) from e
        self._sub_cache[uid] = (self.clock(), ok)
        return ok

    async def issue(self, uid: int) -> IssueResult:
        # Проверка подписки — сетевой вызов; без замка две одновременные просьбы выдали бы два ключа.
        lock = self._issue_locks.setdefault(uid, asyncio.Lock())
        async with lock:
            return await self._issue(uid)

    async def _issue(self, uid: int) -> IssueResult:
        now = self.now()
        if self.db.is_banned(uid):
            return IssueResult("banned")
        if not self.is_admin(uid) and not await self.is_subscribed(uid, use_cache=False):
            return IssueResult("not_subscribed")
        cur = self.db.active_key(uid, now)
        if cur:
            return IssueResult("ok", cur["key"], cur["expires_at"], reused=True)
        key = self.db.issue_key(uid, now, self.cfg.key_ttl_sec)
        return IssueResult("ok", key, now + self.cfg.key_ttl_sec)

    async def verify(self, key: str, hwid: str) -> Tuple[str, int]:
        """Возвращает (status, expires_at). status: ok|invalid|revoked|banned|expired|hwid|unsub."""
        now = self.now()
        rec = self.db.get_key(key)
        if rec is None:
            return "invalid", 0
        if rec["revoked"]:
            return "revoked", 0
        if self.db.is_banned(rec["user_id"]):
            return "banned", 0
        if now >= rec["expires_at"]:
            return "expired", rec["expires_at"]
        if rec["hwid"] and rec["hwid"] != hwid:
            return "hwid", 0
        if not self.is_admin(rec["user_id"]):
            try:
                if not await self.is_subscribed(rec["user_id"]):
                    return "unsub", 0
            except SubscriptionUnknown:
                pass  # сбой Telegram не должен выкидывать всех пользователей
        self.db.bind_and_touch(key, hwid, now)
        return "ok", rec["expires_at"]
