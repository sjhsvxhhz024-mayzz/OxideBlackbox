"""Настройки из переменных окружения и (необязательно) файла .env рядом с run.py."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def load_env_file(path: Path) -> None:
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


@dataclass(frozen=True)
class Config:
    bot_token: str
    channel: str                 # "@AvisTools"
    admin_ids: frozenset
    key_ttl_sec: int
    db_path: str
    signing_key_path: str
    host: str
    port: int
    tg_api_base: str
    sub_cache_sec: int
    trust_proxy: bool
    custom_emoji: str            # auto — пробовать кастомные эмодзи, off — только обычные
    profile_sync: bool           # выставлять описание, команды и аватарку бота при запуске
    assets_dir: str

    @property
    def channel_name(self) -> str:
        return self.channel.lstrip("@")

    @property
    def channel_url(self) -> str:
        return f"https://t.me/{self.channel_name}"


def from_env() -> Config:
    base = Path(__file__).resolve().parent.parent
    load_env_file(base / ".env")
    token = os.environ.get("BOT_TOKEN", "").strip()
    channel = os.environ.get("CHANNEL", "@AvisTools").strip()
    if not channel.startswith("@"):
        channel = "@" + channel
    admins = frozenset(int(x) for x in os.environ.get("ADMIN_IDS", "").replace(";", ",").split(",") if x.strip().isdigit())
    return Config(
        bot_token=token,
        channel=channel,
        admin_ids=admins,
        key_ttl_sec=int(float(os.environ.get("KEY_TTL_HOURS", "24")) * 3600),
        db_path=os.environ.get("DB_PATH", str(base / "data" / "avis.db")),
        signing_key_path=os.environ.get("SIGNING_KEY", str(base / "signing_key.pem")),
        host=os.environ.get("HOST", "0.0.0.0"),
        port=int(os.environ.get("PORT", "8080")),
        tg_api_base=os.environ.get("TELEGRAM_API_BASE", "https://api.telegram.org").rstrip("/"),
        sub_cache_sec=int(os.environ.get("SUB_CACHE_SEC", "300")),
        trust_proxy=os.environ.get("TRUST_PROXY", "0") == "1",
        custom_emoji=os.environ.get("CUSTOM_EMOJI", "auto").strip().lower(),
        profile_sync=os.environ.get("PROFILE_SYNC", "1") == "1",
        assets_dir=os.environ.get("ASSETS_DIR", str(base / "assets")),
    )
