"""Бот: экраны, кнопки, выдача ключей. Каждый экран — обложка + подпись, которая правится на месте."""
from __future__ import annotations

import asyncio
import hashlib
import html
import logging
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, Optional, Tuple

from .emoji import Emoji
from .service import Service, SubscriptionUnknown
from .telegram import Telegram, TelegramError

log = logging.getLogger("avisbot.bot")

RICH_COOLDOWN = 3600        # сколько не пробуем кастомные эмодзи после отказа Telegram
ADMIN_ALERT_EVERY = 600     # как часто тревожить админов из-за сломанной проверки подписки

DESCRIPTION = (
    "Бесплатный ключ доступа к меню Avis tools на 24 часа.\n\n"
    "1. Подпишись на канал\n2. Нажми «Получить ключ»\n3. Вставь ключ в меню в игре\n\n"
    "Ключ обновляется раз в сутки — просто получи новый."
)
SHORT_DESCRIPTION = "Бесплатные ключи доступа Avis tools на 24 часа"
COMMANDS = [
    {"command": "start", "description": "Главное меню"},
    {"command": "key", "description": "Получить ключ на 24 часа"},
    {"command": "help", "description": "Как активировать ключ"},
]

Build = Callable[[Emoji], Tuple[str, dict]]

# Команды управления. Доступны админам; /addadmin, /deladmin и /admins — только владельцам (ADMIN_IDS).
ADMIN_CMDS = ("/admin", "/stats", "/ban", "/unban", "/revoke", "/gen", "/addadmin", "/deladmin", "/admins")
OWNER_ONLY = ("/addadmin", "/deladmin", "/admins")


def photo_error(e: TelegramError) -> bool:
    """Ошибка именно с картинкой (а не с подписью или кнопками): тогда есть смысл слать текстом или грузить заново."""
    d = e.description.lower()
    return e.code == 400 and any(w in d for w in ("file", "photo", "image", "dimension"))


def fmt_left(sec: int) -> str:
    sec = max(0, int(sec))
    h, m = sec // 3600, sec % 3600 // 60
    if h:
        return f"{h} ч {m:02d} мин"
    return f"{m} мин" if m else "меньше минуты"


def progress(left: int, total: int, cells: int = 10) -> str:
    filled = min(cells, max(0, math.ceil(left / total * cells))) if total > 0 else 0
    return "▰" * filled + "▱" * (cells - filled)


def icons_dropped(text: str, kb: dict, msg: dict) -> bool:
    """Telegram не ругается, когда у владельца бота нет Premium, а молча выкидывает кастомные эмодзи и значки кнопок.
    Узнаём это по сохранённому сообщению, которое он возвращает в ответ."""
    want_e = text.count("<tg-emoji")
    ents = msg.get("caption_entities") or msg.get("entities") or []
    if sum(1 for e in ents if e.get("type") == "custom_emoji") < want_e:
        return True
    want_i = sum(1 for row in kb["inline_keyboard"] for b in row if "icon_custom_emoji_id" in b)
    if want_i and "reply_markup" in msg:
        got_i = sum(1 for row in msg["reply_markup"].get("inline_keyboard", []) for b in row if "icon_custom_emoji_id" in b)
        return got_i < want_i
    return False


@dataclass
class Ctx:
    chat: int
    mid: Optional[int] = None       # сообщение, которое можно править (нажатие кнопки)
    was_photo: bool = False


class Bot:
    def __init__(self, svc: Service, tg: Telegram):
        self.svc, self.tg, self.cfg = svc, tg, svc.cfg
        self._last_press: Dict[int, float] = {}
        self.username = ""
        self._stop = asyncio.Event()
        self._rich_off_until = float("-inf")
        self._admin_alert_at = float("-inf")     # не 0: monotonic() на свежезагруженной машине бывает меньше интервала
        self._banner_id: Optional[str] = svc.db.kv_get("banner_file_id")
        self._banner_bytes: Optional[bytes] = None

    # ------------------------------------------------------------------ экраны
    def _chan(self) -> str:
        return f'<a href="{self.cfg.channel_url}">{html.escape(self.cfg.channel)}</a>'

    def _screen_start(self, uid: int) -> Build:
        cur = self.svc.db.active_key(uid, self.svc.now())
        left = (cur["expires_at"] - self.svc.now()) if cur else 0

        def build(e: Emoji):
            lines = [
                f"{e('rocket')} <b>Avis tools</b> — ключ доступа", "",
                "Бесплатный ключ на <b>24 часа</b> для меню Avis tools.", "",
                f"{e('megaphone')} Нужна подписка на {self._chan()}",
                f"{e('unlock')} Нажми «Получить ключ» и вставь его в меню в игре",
            ]
            if cur:
                lines += ["", f"{e('check')} <b>Ключ активен</b> — осталось {fmt_left(left)}"]
            kb = [
                [e.button("Показать ключ" if cur else "Получить ключ", "unlock", "primary", callback_data="getkey")],
                [e.button("Канал", "megaphone", url=self.cfg.channel_url), e.button("Как активировать", "info", callback_data="help")],
            ]
            return "\n".join(lines), {"inline_keyboard": kb}
        return build

    def _screen_key(self, key: str, exp: int, reused: bool) -> Build:
        left = exp - self.svc.now()

        def build(e: Emoji):
            text = (
                f"{e('check')} <b>{'Твой ключ' if reused else 'Ключ готов'}</b>\n\n"
                f"<code>{html.escape(key)}</code>\n\n"
                f"{e('clock')} Осталось: <b>{fmt_left(left)}</b>\n"
                f"<code>{progress(left, self.cfg.key_ttl_sec)}</code>\n\n"
                f"{e('device')} Привяжется к первому устройству, где его введут\n"
                f"{e('refresh')} Новый ключ — когда этот истечёт"
            )
            kb = [
                [e.button("Скопировать ключ", "copy", "primary", copy_text={"text": key})],
                [e.button("Обновить", "refresh", callback_data="getkey"), e.button("Как активировать", "info", callback_data="help")],
            ]
            return text, {"inline_keyboard": kb}
        return build

    def _screen_subscribe(self) -> Build:
        def build(e: Emoji):
            text = (
                f"{e('megaphone')} <b>Сначала подпишись на канал</b>\n\n"
                f"Ключи выдаются подписчикам {self._chan()}.\n"
                "Подпишись и нажми «Я подписался»."
            )
            kb = [
                [e.button("Открыть канал", "megaphone", url=self.cfg.channel_url)],
                [e.button("Я подписался", "check", "success", callback_data="getkey")],
            ]
            return text, {"inline_keyboard": kb}
        return build

    def _screen_help(self) -> Build:
        def build(e: Emoji):
            text = (
                f"{e('info')} <b>Как активировать ключ</b>\n\n"
                "<b>1.</b> Нажми «Получить ключ» и скопируй его\n"
                "<b>2.</b> Запусти Avis tools — сразу откроется окно ввода\n"
                "<b>3.</b> Нажми «Вставить» (или набери ключ) и «Войти»\n\n"
                f"<blockquote>{e('clock')} Ключ действует 24 часа\n"
                f"{e('device')} Привязывается к первому устройству\n"
                f"{e('megaphone')} Отпишешься от канала — ключ перестанет работать</blockquote>"
            )
            kb = [
                [e.button("Получить ключ", "unlock", "primary", callback_data="getkey")],
                [e.button("Назад", "back", callback_data="start")],
            ]
            return text, {"inline_keyboard": kb}
        return build

    def _screen_banned(self) -> Build:
        def build(e: Emoji):
            return (f"{e('ban')} <b>Доступ закрыт</b>\n\nЕсли это ошибка — напиши администратору канала {self._chan()}.",
                    {"inline_keyboard": [[e.button("Канал", "megaphone", url=self.cfg.channel_url)]]})
        return build

    def _screen_error(self) -> Build:
        def build(e: Emoji):
            return (f"{e('warn')} <b>Не получилось проверить подписку</b>\n\nTelegram сейчас не ответил. Попробуй ещё раз через минуту.",
                    {"inline_keyboard": [[e.button("Повторить", "refresh", "primary", callback_data="getkey")]]})
        return build

    # ------------------------------------------------------------------ показ
    def _rich_now(self) -> bool:
        return self.cfg.custom_emoji != "off" and time.monotonic() >= self._rich_off_until

    async def _show(self, ctx: Ctx, build: Build) -> None:
        """Показывает экран. Сначала с кастомными эмодзи; если Telegram их не принял (ошибка или молча выкинул —
        у владельца бота нет Premium), тут же переделывает этот экран обычными эмодзи и на час перестаёт пробовать."""
        modes = [True, False] if self._rich_now() else [False]
        failure: Optional[TelegramError] = None
        for rich in modes:
            text, kb = build(Emoji(rich))
            try:
                msg = await self._deliver(ctx, text, kb)
            except TelegramError as e:
                if rich and len(modes) == 2 and e.code == 400:
                    failure = e
                    continue
                raise
            if failure is not None:
                self._rich_off_until = time.monotonic() + RICH_COOLDOWN
                log.warning("Telegram отклонил кастомные эмодзи (%s). Показываю обычные, повторю попытку через час. "
                            "Чтобы не пробовать — CUSTOM_EMOJI=off.", failure)
            elif rich and msg is not None and icons_dropped(text, kb, msg):
                self._rich_off_until = time.monotonic() + RICH_COOLDOWN
                log.warning("Telegram молча убрал кастомные эмодзи: у владельца бота нет Telegram Premium. Показываю обычные, "
                            "повторю попытку через час (появится Premium — значки включатся сами).")
                text, kb = build(Emoji(False))
                await self._deliver(Ctx(ctx.chat, msg.get("message_id"), bool(msg.get("photo"))), text, kb)
            return

    async def _deliver(self, ctx: Ctx, text: str, kb: dict) -> Optional[dict]:
        """Правит сообщение на месте, а если нельзя — шлёт новое. Возвращает то, что сохранил Telegram."""
        if ctx.mid is not None:
            try:
                if ctx.was_photo:
                    msg = await self.tg.edit_caption(ctx.chat, ctx.mid, text, kb)
                else:
                    msg = await self.tg.edit(ctx.chat, ctx.mid, text, kb)
                return msg if isinstance(msg, dict) else None
            except TelegramError as e:
                if e.code != 400:
                    raise
                log.debug("не удалось отредактировать (%s) — отправляю новое сообщение", e)
        return await self._send_new(ctx.chat, text, kb)

    def _banner_upload(self) -> Optional[tuple]:
        if self._banner_bytes is None:
            p = Path(self.cfg.assets_dir) / "banner.jpg"
            self._banner_bytes = p.read_bytes() if p.is_file() else b""
        return ("banner.jpg", self._banner_bytes, "image/jpeg") if self._banner_bytes else None

    async def _send_photo(self, chat: int, src, text: str, kb: dict) -> dict:
        msg = await self.tg.send_photo(chat, src, text, kb)
        if not isinstance(src, str):        # первая загрузка: дальше шлём по file_id, без перезагрузки файла
            fid = (msg.get("photo") or [{}])[-1].get("file_id")
            if fid:
                self._banner_id = fid
                self.svc.db.kv_set("banner_file_id", fid)
        return msg

    async def _send_new(self, chat: int, text: str, kb: dict) -> dict:
        src = self._banner_id or self._banner_upload()
        if src:
            try:
                return await self._send_photo(chat, src, text, kb)
            except TelegramError as e:
                if not photo_error(e):      # проблема в подписи/кнопках — пусть решает вызывающий (_show)
                    raise
                if isinstance(src, str):    # file_id устарел (другой бот/токен) — грузим заново
                    self._banner_id = None
                    self.svc.db.kv_set("banner_file_id", None)
                    up = self._banner_upload()
                    if up:
                        try:
                            return await self._send_photo(chat, up, text, kb)
                        except TelegramError as e2:
                            if not photo_error(e2):
                                raise
                log.warning("обложка не отправилась (%s) — шлю текстом", e)
        return await self.tg.send(chat, text, kb)

    # ------------------------------------------------------------------ обработка
    async def on_update(self, u: dict) -> None:
        try:
            if "callback_query" in u:
                await self._on_callback(u["callback_query"])
            elif "message" in u:
                await self._on_message(u["message"])
        except Exception:
            log.exception("ошибка обработки апдейта")

    def _remember(self, user: dict) -> int:
        uid = int(user["id"])
        self.svc.db.upsert_user(uid, user.get("username"), user.get("first_name"), self.svc.now())
        return uid

    async def _on_message(self, m: dict) -> None:
        if m.get("chat", {}).get("type") != "private" or "from" not in m:
            return
        uid = self._remember(m["from"])
        ctx = Ctx(int(m["chat"]["id"]))
        text = (m.get("text") or "").strip()
        cmd, _, arg = text.partition(" ")
        cmd = cmd.split("@")[0].lower()
        if cmd in ("/key", "/getkey", "/mykey"):
            await self._give_key(ctx, uid, None)
        elif cmd == "/help":
            await self._show(ctx, self._screen_help())
        elif cmd in ADMIN_CMDS and self.svc.is_admin(uid):      # обычному пользователю команды не раскрываем
            await self._admin(ctx.chat, uid, cmd, arg.strip())
        else:       # /start, /menu и любой другой текст
            await self._show(ctx, self._screen_start(uid))

    async def _on_callback(self, cb: dict) -> None:
        uid = self._remember(cb["from"])
        msg = cb.get("message") or {}
        ctx = Ctx(int(msg.get("chat", {}).get("id", uid)), msg.get("message_id"), bool(msg.get("photo")))
        now = time.monotonic()
        if now - self._last_press.get(uid, float("-inf")) < 1.5:      # защита от спама кнопкой
            await self.tg.answer(cb["id"])
            return
        self._last_press[uid] = now
        data = cb.get("data")
        if data == "help":
            await self.tg.answer(cb["id"])
            await self._show(ctx, self._screen_help())
        elif data == "start":
            await self.tg.answer(cb["id"])
            await self._show(ctx, self._screen_start(uid))
        elif data == "getkey":
            await self._give_key(ctx, uid, cb["id"])
        else:
            await self.tg.answer(cb["id"])

    async def _give_key(self, ctx: Ctx, uid: int, cb_id: Optional[str]) -> None:
        async def toast(text: str, alert: bool = False) -> None:
            if cb_id:
                await self.tg.answer(cb_id, text, alert)

        try:
            res = await self.svc.issue(uid)
        except SubscriptionUnknown:
            await toast("Не удалось проверить подписку", True)
            await self._show(ctx, self._screen_error())
            await self._alert_admins()
            return
        if res.status == "banned":
            await toast("Доступ закрыт", True)
            await self._show(ctx, self._screen_banned())
        elif res.status == "not_subscribed":
            await toast("Сначала подпишись на канал", True)
            await self._show(ctx, self._screen_subscribe())
        else:
            await toast("Ключ ещё действует" if res.reused else "Ключ выдан")
            await self._show(ctx, self._screen_key(res.key, res.expires_at, res.reused))

    async def _alert_admins(self) -> None:
        if time.monotonic() - self._admin_alert_at < ADMIN_ALERT_EVERY:
            return
        self._admin_alert_at = time.monotonic()
        for a in self.cfg.admin_ids:
            try:
                await self.tg.send(a, f"⚠️ getChatMember не работает для {html.escape(self.cfg.channel)}. "
                                      "Добавь бота в канал администратором.")
            except TelegramError:
                pass

    def _who(self, uid: int) -> str:
        label = self.svc.db.user_label(uid)
        return f"<code>{uid}</code>" + (f" ({html.escape(label)})" if label else "")

    @staticmethod
    def _parse_id(arg: str) -> Optional[int]:
        a = arg.strip()
        return int(a) if a.isdigit() and 0 < int(a) < 2 ** 52 else None

    async def _admin(self, chat: int, uid: int, cmd: str, arg: str) -> None:
        svc, db, now = self.svc, self.svc.db, self.svc.now()
        owner = svc.is_owner(uid)
        if cmd in OWNER_ONLY and not owner:
            await self.tg.send(chat, "⛔ Назначать и снимать админов могут только владельцы.")
            return
        send = lambda t: self.tg.send(chat, t)

        if cmd == "/admin":
            lines = ["🛠 <b>Панель админа</b>", f"Твоя роль: <b>{'владелец' if owner else 'админ'}</b>", "",
                     "/stats — статистика", "/ban <code>ID</code> · /unban <code>ID</code> — бан и разбан (бан отзывает ключи)",
                     "/revoke <code>КЛЮЧ</code> — отозвать ключ", "/gen <code>[часы]</code> — ключ себе без проверки подписки"]
            if owner:
                lines += ["", "<b>Только владельцы:</b>", "/addadmin <code>ID</code> — назначить админа",
                          "/deladmin <code>ID</code> — снять админа", "/admins — список админов"]
            else:
                lines += ["", "Назначать админов может только владелец."]
            await send("\n".join(lines))
        elif cmd == "/stats":
            s = db.stats(now)
            names = {"users": "👥 Пользователей", "banned": "⛔ Забанено", "keys_total": "🔑 Ключей выдано",
                     "keys_active": "✅ Действуют сейчас", "online_10m": "🟢 В меню за 10 минут"}
            await send("📊 <b>Статистика</b>\n\n" + "\n".join(f"{names.get(k, k)}: <b>{v}</b>" for k, v in s.items()))
        elif cmd in ("/ban", "/unban"):
            target = self._parse_id(arg)
            if target is None:
                await send(f"Формат: {cmd} <code>ID</code> (числовой Telegram ID)")
            elif cmd == "/ban" and svc.is_admin(target):
                hint = " Сначала сними его: /deladmin." if owner and not svc.is_owner(target) else ""
                await send("⛔ Админа забанить нельзя." + hint)
            else:
                db.set_banned(target, cmd == "/ban", now)
                await send(f"{'⛔ забанен' if cmd == '/ban' else '✅ разбанен'}: {self._who(target)}")
        elif cmd == "/revoke":
            if not arg:
                await send("Формат: /revoke <code>AVIS-XXXX-XXXX-XXXX</code>")
            else:
                await send("🗑 ключ отозван" if db.revoke(arg.strip().upper()) else "Ключ не найден")
        elif cmd == "/gen":
            try:
                hours = float(arg.replace(",", ".")) if arg else self.cfg.key_ttl_sec / 3600
            except ValueError:
                hours = 0
            if not 0 < hours <= 24 * 365:
                await send("Формат: /gen <code>[часы]</code> — от 0.1 до 8760")
            else:
                key = db.issue_key(uid, now, int(hours * 3600))
                await send(f"🔑 <code>{key}</code> на {hours:g} ч")
        elif cmd == "/addadmin":
            target = self._parse_id(arg)
            if target is None:
                await send("Формат: /addadmin <code>ID</code> — числовой Telegram ID (узнать: @userinfobot)")
            elif svc.is_owner(target):
                await send(f"{self._who(target)} уже владелец.")
            elif not db.add_admin(target, uid, now):
                await send(f"{self._who(target)} уже админ.")
            else:
                db.set_banned(target, False, now)
                note = ""
                try:
                    await self.tg.send(target, "🛠 <b>Тебя назначили админом Avis tools.</b>\n\nКоманды — /admin. "
                                               "Назначать других админов можно только владельцам.")
                except TelegramError:
                    note = "\nℹ️ Сообщить ему не удалось: он ещё не писал боту. Пусть отправит /start."
                await send(f"✅ Админ назначен: {self._who(target)}{note}")
        elif cmd == "/deladmin":
            target = self._parse_id(arg)
            if target is None:
                await send("Формат: /deladmin <code>ID</code>")
            elif svc.is_owner(target):
                await send("⛔ Владельцев снять нельзя: они заданы в настройках сервера.")
            elif not db.remove_admin(target):
                await send(f"{self._who(target)} не админ.")
            else:
                await send(f"✅ Админ снят: {self._who(target)}")
        elif cmd == "/admins":
            granted = db.list_admins()
            lines = ["👑 <b>Владельцы</b>"] + [f"• {self._who(o)}" for o in sorted(self.cfg.admin_ids)]
            lines += ["", f"🛠 <b>Админы</b> ({len(granted)})"]
            lines += [f"• {self._who(g['id'])} — назначил <code>{g['granted_by']}</code>" for g in granted] or ["• пока нет"]
            await send("\n".join(lines))

    # ------------------------------------------------------------------ профиль бота
    def _bind_to_bot(self, bot_id: int) -> None:
        """file_id обложки и отметки «профиль уже выставлен» принадлежат конкретному боту. Сменили токен — забываем их,
        иначе новый бот остался бы без описания, команд и аватарки."""
        db = self.svc.db
        if db.kv_get("bot_id") != str(bot_id):
            for k in ("banner_file_id", "profile_hash", "avatar_done"):
                db.kv_set(k, None)
            db.kv_set("bot_id", str(bot_id))
            self._banner_id = None
            log.info("бот %d: профиль и обложка будут настроены заново", bot_id)

    async def sync_profile(self) -> None:
        """Описание, команды и аватарка бота. Повторно не выставляем, если ничего не изменилось."""
        if not self.cfg.profile_sync:
            return
        digest = hashlib.sha256(repr((DESCRIPTION, SHORT_DESCRIPTION, COMMANDS)).encode()).hexdigest()[:16]
        if self.svc.db.kv_get("profile_hash") != digest:
            try:
                await self.tg.set_commands(COMMANDS)
                await self.tg.set_description(DESCRIPTION)
                await self.tg.set_short_description(SHORT_DESCRIPTION)
                self.svc.db.kv_set("profile_hash", digest)
                log.info("профиль бота обновлён (описание, команды)")
            except TelegramError as e:
                log.warning("профиль бота не обновился: %s", e)
        avatar = Path(self.cfg.assets_dir) / "avatar.jpg"
        if avatar.is_file() and not self.svc.db.kv_get("avatar_done"):
            try:
                me = await self.tg.get_me()
                if await self.tg.profile_photo_count(int(me["id"])) == 0:     # чужую аватарку не трогаем
                    await self.tg.set_profile_photo("avatar.jpg", avatar.read_bytes())
                    log.info("аватарка бота выставлена")
                self.svc.db.kv_set("avatar_done", "1")
            except TelegramError as e:
                log.info("аватарка не выставлена: %s", e)

    # ------------------------------------------------------------------ цикл
    async def run(self) -> None:
        me = await self.tg.get_me()
        self.username = me.get("username", "")
        self._bind_to_bot(int(me["id"]))
        log.info("бот @%s запущен, канал %s, кастомные эмодзи: %s", self.username, self.cfg.channel,
                 "выкл" if self.cfg.custom_emoji == "off" else "авто")
        asyncio.create_task(self.sync_profile())
        offset, backoff = 0, 1.0
        while not self._stop.is_set():
            try:
                for u in await self.tg.get_updates(offset):
                    offset = max(offset, int(u["update_id"]) + 1)
                    asyncio.create_task(self.on_update(u))
                backoff = 1.0
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("getUpdates: %s (повтор через %.0f с)", e, backoff)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)

    def stop(self) -> None:
        self._stop.set()
