"""HTTP API для клиента. Ответ — две строки: payload и подпись (base64 DER ECDSA P-256/SHA-256).

payload:  AV1|<type>|<status>|<nonce>|<a>|<b>|<server_time>
  verify: a = hwid, b = expires_at (unix)
  info:   a = имя бота, b = имя канала
"""
from __future__ import annotations

import logging
import time
from collections import defaultdict, deque
from typing import Deque, Dict

from aiohttp import web

from .crypto import Signer
from .service import HWID_RE, KEY_RE, NONCE_RE, Service

log = logging.getLogger("avisbot.api")


class Limiter:
    """Скользящее окно: не больше `limit` запросов за `window` секунд с одного адреса."""

    def __init__(self, limit: int, window: float, clock=time.monotonic):
        self.limit, self.window, self.clock = limit, window, clock
        self._hits: Dict[str, Deque[float]] = defaultdict(deque)

    def allow(self, who: str) -> bool:
        now = self.clock()
        if len(self._hits) > 5000:          # не даём словарю расти бесконечно при переборе адресов
            for k in [k for k, v in self._hits.items() if not v or now - v[-1] > self.window]:
                del self._hits[k]
        q = self._hits[who]
        while q and now - q[0] > self.window:
            q.popleft()
        if len(q) >= self.limit:
            return False
        q.append(now)
        return True


def build_app(svc: Service, signer: Signer, bot_username_getter) -> web.Application:
    cfg = svc.cfg
    app = web.Application(client_max_size=4096)
    rate = Limiter(60, 60)          # любые запросы
    bad = Limiter(12, 600)          # неверные ключи за 10 минут

    def who(req: web.Request) -> str:
        if cfg.trust_proxy:
            xff = req.headers.get("X-Forwarded-For", "")
            if xff:
                return xff.split(",")[0].strip()
        return req.remote or "?"

    def reply(kind: str, status: str, nonce: str, a: str, b: str) -> web.Response:
        payload = f"AV1|{kind}|{status}|{nonce}|{a}|{b}|{svc.now()}"
        return web.Response(text=payload + "\n" + signer.sign(payload) + "\n", content_type="text/plain",
                            headers={"Cache-Control": "no-store"})

    async def verify(req: web.Request) -> web.Response:
        ip = who(req)
        if not rate.allow(ip):
            return web.Response(status=429, text="slow down")
        form = await req.post()
        key = str(form.get("key", "")).strip().upper()
        hwid = str(form.get("hwid", "")).strip().lower()
        nonce = str(form.get("nonce", "")).strip().lower()
        if not (KEY_RE.match(key) and HWID_RE.match(hwid) and NONCE_RE.match(nonce)):
            if not NONCE_RE.match(nonce):
                return web.Response(status=400, text="bad request")
            if not bad.allow(ip):
                return web.Response(status=429, text="slow down")
            return reply("verify", "invalid", nonce, "-", "0")
        status, exp = await svc.verify(key, hwid)
        if status == "invalid" and not bad.allow(ip):
            return web.Response(status=429, text="slow down")
        return reply("verify", status, nonce, hwid, str(exp))

    async def info(req: web.Request) -> web.Response:
        if not rate.allow(who(req)):
            return web.Response(status=429, text="slow down")
        nonce = req.query.get("nonce", "").strip().lower()
        if not NONCE_RE.match(nonce):
            return web.Response(status=400, text="bad request")
        return reply("info", "ok", nonce, bot_username_getter() or "-", cfg.channel_name)

    async def root(_: web.Request) -> web.Response:
        return web.Response(text="Avis tools API\n")

    app.add_routes([web.post("/api/v1/verify", verify), web.get("/api/v1/info", info),
                    web.get("/health", root), web.get("/", root)])
    return app
