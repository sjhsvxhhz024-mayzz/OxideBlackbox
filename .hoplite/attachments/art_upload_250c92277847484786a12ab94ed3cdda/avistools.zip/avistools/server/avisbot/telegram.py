"""Минимальный клиент Telegram Bot API поверх aiohttp (только то, что нужно боту)."""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Optional

import aiohttp

log = logging.getLogger("avisbot.tg")


class TelegramError(Exception):
    def __init__(self, method: str, code: int, description: str, retry_after: int = 0):
        super().__init__(f"{method}: {code} {description}")
        self.code, self.description, self.retry_after = code, description, retry_after


class Telegram:
    def __init__(self, token: str, api_base: str = "https://api.telegram.org"):
        self._url = f"{api_base}/bot{token}"
        self._session: Optional[aiohttp.ClientSession] = None

    async def start(self) -> None:
        self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=70))

    async def close(self) -> None:
        if self._session:
            await self._session.close()

    async def _post(self, method: str, params: dict, files: Optional[dict]) -> Any:
        """Один запрос. files={'поле': (имя, bytes, content_type)} — отправка multipart (загрузка файла)."""
        assert self._session, "Telegram.start() не вызван"
        if files:
            form = aiohttp.FormData()
            for k, v in params.items():
                form.add_field(k, v if isinstance(v, str) else json.dumps(v, ensure_ascii=False))
            for k, (name, data, ctype) in files.items():
                form.add_field(k, data, filename=name, content_type=ctype)
            ctx = self._session.post(f"{self._url}/{method}", data=form)
        else:
            ctx = self._session.post(f"{self._url}/{method}", json=params)
        async with ctx as r:
            data = await r.json(content_type=None)
        if not data.get("ok"):
            raise TelegramError(method, int(data.get("error_code", r.status)), str(data.get("description", "")),
                                int((data.get("parameters") or {}).get("retry_after", 0)))
        return data["result"]

    async def call(self, method: str, files: Optional[dict] = None, **params: Any) -> Any:
        for attempt in range(3):
            try:
                return await self._post(method, params, files)
            except TelegramError as e:
                # Лимит запросов: Telegram сам говорит, сколько ждать. Ждём (не дольше 10 с) и повторяем.
                if e.code == 429 and attempt < 2:
                    wait = min(max(e.retry_after, 1), 10)
                    log.warning("%s: лимит запросов, жду %d с", method, wait)
                    await asyncio.sleep(wait)
                    continue
                raise

    async def get_me(self):
        return await self.call("getMe")

    async def get_updates(self, offset: int, timeout: int = 50):
        return await self.call("getUpdates", offset=offset, timeout=timeout, allowed_updates=["message", "callback_query"])

    async def send(self, chat_id: int, text: str, markup: Optional[dict] = None):
        p: dict = dict(chat_id=chat_id, text=text, parse_mode="HTML", disable_web_page_preview=True)
        if markup:
            p["reply_markup"] = markup
        return await self.call("sendMessage", **p)

    async def send_photo(self, chat_id: int, photo: Any, caption: str, markup: Optional[dict] = None):
        """photo — file_id (str) или (имя, bytes, content_type) для загрузки. Возвращает сообщение целиком."""
        p: dict = dict(chat_id=chat_id, caption=caption, parse_mode="HTML")
        if markup:
            p["reply_markup"] = markup
        if isinstance(photo, str):
            return await self.call("sendPhoto", photo=photo, **p)
        return await self.call("sendPhoto", files={"photo": photo}, **p)

    async def edit(self, chat_id: int, message_id: int, text: str, markup: Optional[dict] = None):
        p: dict = dict(chat_id=chat_id, message_id=message_id, text=text, parse_mode="HTML", disable_web_page_preview=True)
        if markup:
            p["reply_markup"] = markup
        return await self._edit("editMessageText", p)

    async def edit_caption(self, chat_id: int, message_id: int, caption: str, markup: Optional[dict] = None):
        p: dict = dict(chat_id=chat_id, message_id=message_id, caption=caption, parse_mode="HTML")
        if markup:
            p["reply_markup"] = markup
        return await self._edit("editMessageCaption", p)

    async def _edit(self, method: str, p: dict):
        try:
            return await self.call(method, **p)
        except TelegramError as e:
            if "not modified" in e.description:     # то же содержимое — не ошибка
                return None
            raise

    async def answer(self, callback_id: str, text: str = "", alert: bool = False):
        try:
            await self.call("answerCallbackQuery", callback_query_id=callback_id, text=text, show_alert=alert)
        except TelegramError as e:
            log.debug("answerCallbackQuery: %s", e)

    async def is_member(self, channel: str, user_id: int) -> bool:
        """True, если пользователь состоит в канале. Бот должен быть администратором канала."""
        try:
            m = await self.call("getChatMember", chat_id=channel, user_id=user_id)
        except TelegramError as e:
            # Для несуществующих и «не участников» Telegram иногда отвечает ошибкой, а не status=left.
            if e.code == 400 and any(x in e.description for x in ("PARTICIPANT_ID_INVALID", "USER_NOT_PARTICIPANT", "user not found")):
                return False
            raise
        st = m.get("status")
        return st in ("creator", "administrator", "member") or (st == "restricted" and bool(m.get("is_member")))

    # ---------- оформление профиля бота ----------
    async def set_commands(self, commands: list) -> None:
        await self.call("setMyCommands", commands=commands)

    async def set_description(self, text: str) -> None:
        await self.call("setMyDescription", description=text)

    async def set_short_description(self, text: str) -> None:
        await self.call("setMyShortDescription", short_description=text)

    async def profile_photo_count(self, bot_id: int) -> int:
        r = await self.call("getUserProfilePhotos", user_id=bot_id, limit=1)
        return int(r.get("total_count", 0))

    async def set_profile_photo(self, name: str, data: bytes) -> None:
        await self.call("setMyProfilePhoto", files={"avatar": (name, data, "image/jpeg")},
                        photo={"type": "static", "photo": "attach://avatar"})
