"""Подпись ответов API (ECDSA P-256 + SHA-256, DER, base64). Клиент проверяет её вшитым публичным ключом."""
from __future__ import annotations

import base64
import os
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec


def generate_private_key(path: str) -> ec.EllipticCurvePrivateKey:
    key = ec.generate_private_key(ec.SECP256R1())
    pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(pem)
    return key


class Signer:
    def __init__(self, path: str, create: bool = False):
        p = Path(path)
        if p.is_file():
            self._key = serialization.load_pem_private_key(p.read_bytes(), password=None)
        elif create:
            self._key = generate_private_key(path)
        else:
            raise FileNotFoundError(f"Нет файла ключа подписи: {path}. Запусти: python gen_keys.py")

    def sign(self, payload: str) -> str:
        der = self._key.sign(payload.encode("utf-8"), ec.ECDSA(hashes.SHA256()))
        return base64.b64encode(der).decode("ascii")

    def public_pem(self) -> str:
        return self._key.public_key().public_bytes(
            serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode("ascii")
