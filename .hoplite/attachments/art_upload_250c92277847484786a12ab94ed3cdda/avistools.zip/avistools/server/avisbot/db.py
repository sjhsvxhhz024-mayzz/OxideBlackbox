"""SQLite: пользователи и ключи. Один процесс, поэтому достаточно одной блокировки."""
from __future__ import annotations

import secrets
import sqlite3
import threading
from pathlib import Path
from typing import Optional

# Без похожих символов (0/O, 1/I): ключ иногда вводят руками на экранной клавиатуре.
ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
PREFIX = "AVIS"

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, username TEXT, first_name TEXT,
  banned INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS keys(
  key TEXT PRIMARY KEY, user_id INTEGER NOT NULL, issued_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL, hwid TEXT, first_used_at INTEGER, last_used_at INTEGER,
  revoked INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS keys_user ON keys(user_id, issued_at);
CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY, granted_by INTEGER NOT NULL, created_at INTEGER NOT NULL);
"""


def new_key() -> str:
    groups = ["".join(secrets.choice(ALPHABET) for _ in range(4)) for _ in range(3)]
    return "-".join([PREFIX, *groups])


class Database:
    def __init__(self, path: str):
        if path != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        with self._lock:
            self._db.executescript(SCHEMA)
            self._db.commit()

    def _q(self, sql: str, args: tuple = ()):
        with self._lock:
            cur = self._db.execute(sql, args)
            self._db.commit()
            return cur

    def upsert_user(self, uid: int, username: Optional[str], first_name: Optional[str], now: int) -> None:
        self._q(
            "INSERT INTO users(id,username,first_name,created_at) VALUES(?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name",
            (uid, username, first_name, now),
        )

    def is_banned(self, uid: int) -> bool:
        r = self._q("SELECT banned FROM users WHERE id=?", (uid,)).fetchone()
        return bool(r and r["banned"])

    def set_banned(self, uid: int, banned: bool, now: int) -> None:
        self._q(
            "INSERT INTO users(id,banned,created_at) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET banned=excluded.banned",
            (uid, int(banned), now),
        )
        if banned:
            self._q("UPDATE keys SET revoked=1 WHERE user_id=?", (uid,))

    def active_key(self, uid: int, now: int):
        return self._q(
            "SELECT * FROM keys WHERE user_id=? AND revoked=0 AND expires_at>? ORDER BY issued_at DESC LIMIT 1",
            (uid, now),
        ).fetchone()

    def issue_key(self, uid: int, now: int, ttl: int) -> str:
        for _ in range(8):
            k = new_key()
            try:
                self._q("INSERT INTO keys(key,user_id,issued_at,expires_at) VALUES(?,?,?,?)", (k, uid, now, now + ttl))
                return k
            except sqlite3.IntegrityError:
                continue
        raise RuntimeError("не удалось сгенерировать уникальный ключ")

    def get_key(self, key: str):
        return self._q("SELECT * FROM keys WHERE key=?", (key,)).fetchone()

    def bind_and_touch(self, key: str, hwid: str, now: int) -> None:
        self._q(
            "UPDATE keys SET hwid=COALESCE(hwid,?), first_used_at=COALESCE(first_used_at,?), last_used_at=? WHERE key=?",
            (hwid, now, now, key),
        )

    def revoke(self, key: str) -> bool:
        return self._q("UPDATE keys SET revoked=1 WHERE key=?", (key,)).rowcount > 0

    def stats(self, now: int) -> dict:
        one = lambda sql, a=(): self._q(sql, a).fetchone()[0]
        return {
            "users": one("SELECT COUNT(*) FROM users"),
            "banned": one("SELECT COUNT(*) FROM users WHERE banned=1"),
            "keys_total": one("SELECT COUNT(*) FROM keys"),
            "keys_active": one("SELECT COUNT(*) FROM keys WHERE revoked=0 AND expires_at>?", (now,)),
            "online_10m": one("SELECT COUNT(*) FROM keys WHERE revoked=0 AND expires_at>? AND last_used_at>?", (now, now - 600)),
        }

    def is_granted_admin(self, uid: int) -> bool:
        return self._q("SELECT 1 FROM admins WHERE id=?", (uid,)).fetchone() is not None

    def add_admin(self, uid: int, granted_by: int, now: int) -> bool:
        """True, если админом стал впервые (повторное назначение ничего не меняет)."""
        return self._q("INSERT OR IGNORE INTO admins(id,granted_by,created_at) VALUES(?,?,?)", (uid, granted_by, now)).rowcount > 0

    def remove_admin(self, uid: int) -> bool:
        return self._q("DELETE FROM admins WHERE id=?", (uid,)).rowcount > 0

    def list_admins(self) -> list:
        return [dict(r) for r in self._q("SELECT a.id, a.granted_by, a.created_at, u.username, u.first_name FROM admins a "
                                          "LEFT JOIN users u ON u.id=a.id ORDER BY a.created_at").fetchall()]

    def user_label(self, uid: int) -> str:
        r = self._q("SELECT username, first_name FROM users WHERE id=?", (uid,)).fetchone()
        if r and r["username"]:
            return f"@{r['username']}"
        return (r["first_name"] if r and r["first_name"] else "") or ""

    def kv_get(self, k: str) -> Optional[str]:
        r = self._q("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
        return r["v"] if r else None

    def kv_set(self, k: str, v: Optional[str]) -> None:
        if v is None:
            self._q("DELETE FROM kv WHERE k=?", (k,))
        else:
            self._q("INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, v))

    def cleanup(self, now: int, keep_sec: int = 7 * 86400) -> None:
        self._q("DELETE FROM keys WHERE expires_at<?", (now - keep_sec,))
