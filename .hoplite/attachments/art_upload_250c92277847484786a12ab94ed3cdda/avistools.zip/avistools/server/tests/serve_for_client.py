"""Поднимает настоящий API (HTTP и HTTPS с самоподписанным сертификатом) для теста C++-клиента.
Печатает одну строку JSON и работает, пока не закроют stdin.   python serve_for_client.py"""
import asyncio
import datetime
import json
import os
import ssl
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

from aiohttp import web
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID

from avisbot.api import build_app
from avisbot.bot import Bot, Ctx
from avisbot.config import Config
from avisbot.crypto import Signer
from avisbot.db import Database
from avisbot.service import Service
from avisbot.telegram import Telegram
from fake_telegram import FakeTelegram


def selfsigned(tmp):
    key = ec.generate_private_key(ec.SECP256R1())
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "localhost")])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(1).not_valid_before(now - datetime.timedelta(days=1)).not_valid_after(now + datetime.timedelta(days=2))
            .sign(key, hashes.SHA256()))
    cp, kp = os.path.join(tmp, "c.pem"), os.path.join(tmp, "k.pem")
    open(cp, "wb").write(cert.public_bytes(serialization.Encoding.PEM))
    open(kp, "wb").write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(cp, kp)
    return ctx


async def main():
    signing = os.environ.get("SIGNING_KEY", os.path.join(os.path.dirname(__file__), "..", "signing_key.pem"))
    tmp = tempfile.mkdtemp()
    fake = FakeTelegram()
    await fake.start()
    cfg = Config("T", "@AvisTools", frozenset(), 24 * 3600, ":memory:", signing, "127.0.0.1", 0, fake.base, 300, False,
                 "auto", False, os.path.join(os.path.dirname(__file__), "..", "assets"))
    db, tg = Database(":memory:"), Telegram("T", fake.base)
    await tg.start()
    svc = Service(cfg, db, tg)
    bot = Bot(svc, tg)
    bot.username = "AvisToolsTestBot"
    fake.members.add(100)
    await bot._give_key(Ctx(100), 100, None)
    key = [t for t in fake.texts(100) if "AVIS-" in t][-1].split("<code>")[1].split("</code>")[0]
    app = build_app(svc, Signer(signing), lambda: bot.username)
    runner = web.AppRunner(app)
    await runner.setup()
    http = web.TCPSite(runner, "127.0.0.1", 0)
    https = web.TCPSite(runner, "127.0.0.1", 0, ssl_context=selfsigned(tmp))
    await http.start()
    await https.start()
    port = lambda s: s._server.sockets[0].getsockname()[1]
    print(json.dumps({"http": f"http://127.0.0.1:{port(http)}", "https": f"https://127.0.0.1:{port(https)}", "key": key}), flush=True)
    await asyncio.get_running_loop().run_in_executor(None, sys.stdin.read)
    await runner.cleanup()

asyncio.run(main())
