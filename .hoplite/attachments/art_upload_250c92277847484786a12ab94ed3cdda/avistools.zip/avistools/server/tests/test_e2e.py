import asyncio
import base64
import dataclasses
import json
import os
import re
import sys
import tempfile
import unittest

import aiohttp
from aiohttp import web
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

from avisbot.api import build_app          # noqa: E402
from avisbot.bot import Bot, Ctx, progress, fmt_left   # noqa: E402
from avisbot.emoji import Emoji, ICONS      # noqa: E402
from avisbot.config import Config          # noqa: E402
from avisbot.crypto import Signer          # noqa: E402
from avisbot.db import ALPHABET, Database  # noqa: E402
from avisbot.service import KEY_RE, Service  # noqa: E402
from avisbot.telegram import Telegram     # noqa: E402
from fake_telegram import FakeTelegram     # noqa: E402

HW = "a1" * 16
NONCE = "deadbeef01234567"


class Clock:
    def __init__(self):
        self.t = 1_800_000_000.0

    def __call__(self):
        return self.t


class E2E(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.fake = FakeTelegram()
        await self.fake.start()
        self.cfg = Config("TOKEN", "@AvisTools", frozenset({999}), 24 * 3600, ":memory:",
                          os.path.join(self.tmp.name, "k.pem"), "127.0.0.1", 0, self.fake.base, 300, False,
                          "auto", False, os.path.join(os.path.dirname(__file__), "..", "assets"))
        self.clock = Clock()
        self.signer = Signer(self.cfg.signing_key_path, create=True)
        self.db = Database(":memory:")
        self.tg = Telegram("TOKEN", self.fake.base)
        await self.tg.start()
        self.svc = Service(self.cfg, self.db, self.tg, self.clock)
        self.bot = Bot(self.svc, self.tg)
        self.bot.username = "AvisToolsTestBot"
        self.runner = web.AppRunner(build_app(self.svc, self.signer, lambda: self.bot.username))
        await self.runner.setup()
        site = web.TCPSite(self.runner, "127.0.0.1", 0)
        await site.start()
        self.api = f"http://127.0.0.1:{site._server.sockets[0].getsockname()[1]}"
        self.http = aiohttp.ClientSession()
        self.pub = serialization.load_pem_public_key(self.signer.public_pem().encode())

    async def asyncTearDown(self):
        await self.http.close()
        await self.runner.cleanup()
        await self.tg.close()
        await self.fake.stop()
        self.tmp.cleanup()

    # ---------- помощники ----------
    def press(self, uid, data="getkey", mid=7, photo=False):
        self.clock.t += 2  # антиспам кнопки считает по monotonic, поэтому сбросим его ниже
        self.bot._last_press.clear()
        return self.bot.on_update({"update_id": 1, "callback_query": {
            "id": "cb", "from": {"id": uid, "username": "u"}, "data": data,
            "message": {"message_id": mid, "chat": {"id": uid}, **({"photo": [{"file_id": "x"}]} if photo else {})}}})

    def msg(self, uid, text):
        return self.bot.on_update({"update_id": 2, "message": {
            "message_id": 1, "from": {"id": uid, "first_name": "N"}, "chat": {"id": uid, "type": "private"}, "text": text}})

    def last_key(self, uid):
        for t in reversed(self.fake.texts(uid)):
            m = re.search(r"AVIS-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}", t)
            if m:
                return m.group(0)
        return None

    async def verify(self, key, hwid=HW, nonce=NONCE):
        async with self.http.post(self.api + "/api/v1/verify", data={"key": key, "hwid": hwid, "nonce": nonce, "ver": "1"}) as r:
            body = await r.text()
            return r.status, body

    def check_sig(self, body):
        payload, sig = body.strip().split("\n")
        self.pub.verify(base64.b64decode(sig), payload.encode(), ec.ECDSA(hashes.SHA256()))
        return payload.split("|")

    # ---------- сценарии ----------
    async def test_not_subscribed_then_subscribed(self):
        await self.press(100)
        self.assertTrue(any("подпишись" in t for t in self.fake.texts(100)))
        self.assertIsNone(self.last_key(100))
        self.fake.members.add(100)
        await self.press(100)
        key = self.last_key(100)
        self.assertRegex(key, KEY_RE.pattern)
        self.assertTrue(all(c in ALPHABET for c in key.replace("AVIS-", "").replace("-", "")))

    async def test_same_key_within_24h_and_new_after(self):
        self.fake.members.add(100)
        await self.press(100)
        k1 = self.last_key(100)
        await self.press(100)
        self.assertEqual(k1, self.last_key(100))
        self.clock.t += 24 * 3600 + 5
        await self.press(100)
        self.assertNotEqual(k1, self.last_key(100))

    async def test_verify_ok_signature_and_binding(self):
        self.fake.members.add(100)
        await self.press(100)
        key = self.last_key(100)
        st, body = await self.verify(key)
        self.assertEqual(st, 200)
        f = self.check_sig(body)
        self.assertEqual(f[:4], ["AV1", "verify", "ok", NONCE])
        self.assertEqual(f[4], HW)
        self.assertEqual(int(f[5]), self.db.get_key(key)["expires_at"])
        self.assertEqual(int(f[6]), self.svc.now())
        # другой девайс
        _, body2 = await self.verify(key, hwid="b2" * 16)
        self.assertEqual(self.check_sig(body2)[2], "hwid")
        # тот же девайс — снова ок
        _, body3 = await self.verify(key)
        self.assertEqual(self.check_sig(body3)[2], "ok")

    async def test_invalid_expired_unsub_banned_revoked(self):
        self.fake.members.add(100)
        await self.press(100)
        key = self.last_key(100)
        _, b = await self.verify("AVIS-AAAA-BBBB-CCCC")
        self.assertEqual(self.check_sig(b)[2], "invalid")
        _, b = await self.verify("garbage")
        self.assertEqual(self.check_sig(b)[2], "invalid")
        # отписался -> unsub (кэш подписки 300 с)
        self.fake.members.discard(100)
        self.clock.t += 301
        _, b = await self.verify(key)
        self.assertEqual(self.check_sig(b)[2], "unsub")
        self.fake.members.add(100)
        self.clock.t += 301
        _, b = await self.verify(key)
        self.assertEqual(self.check_sig(b)[2], "ok")
        # истёк
        self.clock.t += 24 * 3600
        _, b = await self.verify(key)
        self.assertEqual(self.check_sig(b)[2], "expired")

    async def test_ban_and_revoke(self):
        self.fake.members.update({100, 101})
        await self.press(100)
        await self.press(101)
        k100, k101 = self.last_key(100), self.last_key(101)
        await self.msg(999, f"/ban 100")
        _, b = await self.verify(k100)
        self.assertEqual(self.check_sig(b)[2], "revoked")      # бан отзывает ключи
        await self.press(100)
        self.assertTrue(any("Доступ закрыт" in t for t in self.fake.texts(100)))
        await self.msg(999, f"/revoke {k101}")
        _, b = await self.verify(k101)
        self.assertEqual(self.check_sig(b)[2], "revoked")

    async def test_membership_api_down_is_fail_open_on_verify_but_not_on_issue(self):
        self.fake.members.add(100)
        await self.press(100)
        key = self.last_key(100)
        self.fake.broken_membership = True
        self.clock.t += 301
        _, b = await self.verify(key)
        self.assertEqual(self.check_sig(b)[2], "ok")           # сбой Telegram не выкидывает пользователей
        await self.press(101)
        self.assertIsNone(self.last_key(101))                   # а новый ключ без проверки подписки не выдаём
        self.assertTrue(any("getChatMember" in t for t in self.fake.texts(999)))   # админ предупреждён

    async def test_invalid_participant_counts_as_not_subscribed_without_alarm(self):
        await self.press(4040)
        self.assertIsNone(self.last_key(4040))
        self.assertTrue(any("подпишись" in t for t in self.fake.texts(4040)))
        self.assertFalse(any("getChatMember" in t for t in self.fake.texts(999)))   # админов не тревожим

    async def test_admin_gets_key_without_subscription_and_stats(self):
        await self.press(999)
        self.assertIsNotNone(self.last_key(999))
        await self.msg(999, "/stats")
        self.assertTrue(any("Статистика" in t for t in self.fake.texts(999)))
        await self.msg(123, "/stats")                           # не админ — игнор
        self.assertFalse(any("Статистика" in t for t in self.fake.texts(123)))

    async def test_info_and_bad_requests_and_rate_limit(self):
        async with self.http.get(self.api + "/api/v1/info", params={"nonce": NONCE}) as r:
            f = self.check_sig(await r.text())
        self.assertEqual(f[:6], ["AV1", "info", "ok", NONCE, "AvisToolsTestBot", "AvisTools"])
        async with self.http.get(self.api + "/api/v1/info", params={"nonce": "zz"}) as r:
            self.assertEqual(r.status, 400)
        # перебор неверных ключей упирается в лимит
        codes = []
        for i in range(20):
            st, _ = await self.verify(f"AVIS-AAAA-BBBB-{ALPHABET[i]*4}", nonce=NONCE)
            codes.append(st)
        self.assertIn(429, codes)

    async def test_polling_loop_end_to_end(self):
        self.fake.members.add(100)
        task = asyncio.create_task(self.bot.run())
        await self.fake.updates.put({"update_id": 10, "message": {"message_id": 1, "from": {"id": 100}, "chat": {"id": 100, "type": "private"}, "text": "/start"}})
        for _ in range(30):
            await asyncio.sleep(0.1)
            if self.fake.texts(100):
                break
        self.bot.stop(); task.cancel()
        self.assertTrue(any("AvisTools" in t for t in self.fake.texts(100)))

    # ---------- оформление ----------
    async def test_start_is_photo_with_custom_emoji_and_styled_buttons(self):
        await self.msg(100, "/start")
        photo = self.fake.calls("sendPhoto", 100)
        self.assertEqual(len(photo), 1)
        self.assertIn(f'<tg-emoji emoji-id="{ICONS["rocket"][0]}">🚀</tg-emoji>', photo[0]["caption"])
        first = photo[0]["reply_markup"]["inline_keyboard"][0][0]
        self.assertEqual((first["callback_data"], first["style"], first["icon_custom_emoji_id"]), ("getkey", "primary", ICONS["unlock"][0]))
        self.assertNotIn("🔓", first["text"])               # значок рисует Telegram, в тексте его нет
        row2 = photo[0]["reply_markup"]["inline_keyboard"][1]
        self.assertEqual(row2[0]["url"], "https://t.me/AvisTools")

    async def test_banner_uploaded_once_then_reused_by_file_id(self):
        await self.msg(100, "/start")
        await self.msg(101, "/start")
        a, b = self.fake.calls("sendPhoto", 100)[0], self.fake.calls("sendPhoto", 101)[0]
        self.assertTrue(a["photo"].startswith("<upload banner.jpg"))
        self.assertEqual(b["photo"], "BANNERFILEID")
        self.assertEqual(self.db.kv_get("banner_file_id"), "BANNERFILEID")

    async def test_stale_banner_file_id_is_reuploaded(self):
        self.db.kv_set("banner_file_id", "STALE")
        self.bot._banner_id = "STALE"
        await self.msg(100, "/start")
        photos = self.fake.calls("sendPhoto", 100)
        self.assertEqual([p["photo"] == "STALE" for p in photos], [True, False])
        self.assertTrue(photos[1]["photo"].startswith("<upload"))
        self.assertEqual(self.db.kv_get("banner_file_id"), "BANNERFILEID")

    async def test_button_on_photo_message_edits_caption_in_place(self):
        self.fake.members.add(100)
        await self.press(100, photo=True)
        self.assertEqual(len(self.fake.calls("editMessageCaption", 100)), 1)
        self.assertEqual(self.fake.calls("sendPhoto", 100), [])
        self.assertEqual(self.fake.calls("sendMessage", 100), [])

    async def test_button_on_old_text_message_edits_text(self):
        self.fake.members.add(100)
        await self.press(100, photo=False)
        self.assertEqual(len(self.fake.calls("editMessageText", 100)), 1)
        self.assertEqual(self.fake.calls("sendPhoto", 100), [])

    async def test_key_screen_has_copy_button_and_progress(self):
        self.fake.members.add(100)
        await self.press(100, photo=True)
        key = self.last_key(100)
        kb = self.fake.last_markup(100)["inline_keyboard"]
        copy = kb[0][0]
        self.assertEqual(copy["copy_text"], {"text": key})
        self.assertEqual(copy["style"], "primary")
        self.assertEqual([b["callback_data"] for b in kb[1]], ["getkey", "help"])
        self.assertIn("▰▰▰▰▰▰▰▰▰▰", self.fake.texts(100)[-1])
        self.assertIn("24 ч 00 мин", self.fake.texts(100)[-1])

    async def test_start_shows_active_key_status(self):
        self.fake.members.add(100)
        await self.press(100)
        self.clock.t += 5 * 3600
        await self.msg(100, "/start")
        cap = self.fake.calls("sendPhoto", 100)[-1]["caption"]
        self.assertIn("Ключ активен", cap)
        self.assertIn("19 ч 00 мин", cap)
        self.assertEqual(self.fake.calls("sendPhoto", 100)[-1]["reply_markup"]["inline_keyboard"][0][0]["text"], "Показать ключ")

    async def test_rich_rejected_falls_back_to_plain_and_remembers(self):
        self.fake.reject_rich = True
        await self.msg(100, "/start")
        self.assertEqual(self.fake.rejected, 1)                        # одна неудачная попытка, обычная версия дошла
        self.assertEqual(len(self.fake.calls("sendPhoto", 100)), 2)
        ok = self.fake.calls("sendPhoto", 100)[-1]
        self.assertNotIn("tg-emoji", ok["caption"])
        self.assertIn("🚀", ok["caption"])
        btn = ok["reply_markup"]["inline_keyboard"][0][0]
        self.assertEqual(btn["text"], "🔓 Получить ключ")
        self.assertNotIn("icon_custom_emoji_id", btn)
        self.assertEqual(btn["style"], "primary")                       # цвет кнопки Premium не нужен
        await self.msg(101, "/start")                                   # дальше не пробуем целый час
        self.assertEqual(len([1 for m, p in self.fake.sent if "tg-emoji" in json.dumps(p)]), 1)
        self.clock.t += 0  # монотонные часы бота: проверяем сам механизм
        self.bot._rich_off_until = 0.0
        self.fake.reject_rich = False
        await self.msg(102, "/start")
        self.assertIn("tg-emoji", self.fake.calls("sendPhoto", 102)[-1]["caption"])   # через час пробует снова

    async def test_silent_drop_without_premium_is_detected_and_screen_redone(self):
        self.fake.drop_rich = True          # Telegram не ругается, а молча убирает значки
        await self.msg(100, "/start")
        first = self.fake.calls("sendPhoto", 100)
        self.assertEqual(len(first), 1)
        self.assertIn("tg-emoji", first[0]["caption"])
        fix = self.fake.calls("editMessageCaption", 100)               # тот же экран тут же переделан обычными эмодзи
        self.assertEqual(len(fix), 1)
        self.assertNotIn("tg-emoji", fix[0]["caption"])
        btn = fix[0]["reply_markup"]["inline_keyboard"][0][0]
        self.assertEqual((btn["text"], btn["style"]), ("🔓 Получить ключ", "primary"))
        self.assertNotIn("icon_custom_emoji_id", btn)
        await self.msg(101, "/start")                                   # дальше сразу обычные, без лишней правки
        self.assertEqual(len(self.fake.calls("sendPhoto", 101)), 1)
        self.assertNotIn("tg-emoji", self.fake.calls("sendPhoto", 101)[0]["caption"])
        self.assertEqual(self.fake.calls("editMessageCaption", 101), [])

    async def test_custom_emoji_can_be_disabled(self):
        bot = Bot(Service(dataclasses.replace(self.cfg, custom_emoji="off"), self.db, self.tg, self.clock), self.tg)
        await bot.on_update({"update_id": 1, "message": {"message_id": 1, "from": {"id": 100}, "chat": {"id": 100, "type": "private"}, "text": "/start"}})
        p = self.fake.calls("sendPhoto", 100)[-1]
        self.assertNotIn("tg-emoji", p["caption"])
        self.assertNotIn("icon_custom_emoji_id", json.dumps(p["reply_markup"]))

    async def test_all_screens_fit_telegram_limits(self):
        key = "AVIS-ABCD-EFGH-JKLM"
        exp = self.svc.now() + 24 * 3600
        screens = [self.bot._screen_start(1), self.bot._screen_key(key, exp, False), self.bot._screen_key(key, exp, True),
                   self.bot._screen_subscribe(), self.bot._screen_help(), self.bot._screen_banned(), self.bot._screen_error()]
        for build in screens:
            for rich in (True, False):
                text, kb = build(Emoji(rich))
                self.assertLessEqual(len(text), 1024, text)                  # лимит подписи к фото
                self.assertEqual("<tg-emoji" in text, rich)
                for row in kb["inline_keyboard"]:
                    for b in row:
                        self.assertLessEqual(len(b["text"].encode()), 64)
                        self.assertEqual(sum(k in b for k in ("callback_data", "url", "copy_text")), 1)
                        if "icon_custom_emoji_id" in b:
                            self.assertTrue(rich)
                            self.assertIn(b["icon_custom_emoji_id"], [v[0] for v in ICONS.values()])
                        if "style" in b:
                            self.assertIn(b["style"], ("primary", "success", "danger"))
        for name, (cid, fb) in ICONS.items():
            self.assertTrue(cid.isdigit() and fb, name)

    async def test_concurrent_requests_issue_one_key(self):
        self.fake.members.add(100)
        res = await asyncio.gather(*[self.svc.issue(100) for _ in range(6)])
        self.assertEqual(len({r.key for r in res}), 1)
        self.assertEqual(sum(1 for r in res if not r.reused), 1)
        self.assertEqual(self.db.stats(self.svc.now())["keys_total"], 1)

    async def test_profile_synced_once_and_avatar_only_if_missing(self):
        bot = Bot(Service(dataclasses.replace(self.cfg, profile_sync=True), self.db, self.tg, self.clock), self.tg)
        await bot.sync_profile()
        await bot.sync_profile()
        self.assertEqual(len(self.fake.calls("setMyCommands")), 1)          # без изменений второй раз не трогаем
        self.assertEqual(len(self.fake.calls("setMyDescription")), 1)
        self.assertEqual(len(self.fake.calls("setMyProfilePhoto")), 1)
        cmds = [c["command"] for c in self.fake.calls("setMyCommands")[0]["commands"]]
        self.assertEqual(cmds, ["start", "key", "help"])
        # у бота уже есть аватарка — не перезаписываем
        db2 = Database(":memory:")
        self.fake.profile_photos = 1
        self.fake.sent.clear()
        bot2 = Bot(Service(dataclasses.replace(self.cfg, profile_sync=True), db2, self.tg, self.clock), self.tg)
        await bot2.sync_profile()
        self.assertEqual(self.fake.calls("setMyProfilePhoto"), [])

    def test_helpers(self):
        self.assertEqual(progress(86400, 86400), "▰▰▰▰▰▰▰▰▰▰")
        self.assertEqual(progress(43200, 86400), "▰▰▰▰▰▱▱▱▱▱")
        self.assertEqual(progress(1, 86400), "▰▱▱▱▱▱▱▱▱▱")
        self.assertEqual(progress(0, 86400), "▱▱▱▱▱▱▱▱▱▱")
        self.assertEqual((fmt_left(86399), fmt_left(3600), fmt_left(59 * 60), fmt_left(30)), ("23 ч 59 мин", "1 ч 00 мин", "59 мин", "меньше минуты"))

    async def test_rate_limit_429_is_retried(self):
        calls = {"n": 0}
        orig = self.tg._post

        async def flaky(method, params, files):
            if method == "sendMessage":
                calls["n"] += 1
                if calls["n"] == 1:
                    from avisbot.telegram import TelegramError
                    raise TelegramError(method, 429, "Too Many Requests: retry after 1", 1)
            return await orig(method, params, files)
        self.tg._post = flaky
        await self.tg.send(100, "hi")
        self.assertEqual(calls["n"], 2)

    # ---------- роли: владельцы и назначенные админы ----------
    async def test_owner_grants_admin_and_granted_admin_cannot_grant(self):
        await self.msg(999, "/addadmin 555")
        self.assertTrue(self.db.is_granted_admin(555))
        self.assertTrue(any("Админ назначен" in t for t in self.fake.texts(999)))
        self.assertTrue(any("назначили админом" in t for t in self.fake.texts(555)))       # новому админу пришло уведомление
        # назначенный админ: управление есть
        await self.msg(555, "/stats")
        self.assertTrue(any("Статистика" in t for t in self.fake.texts(555)))
        await self.msg(555, "/admin")
        self.assertTrue(any("Твоя роль: <b>админ</b>" in t for t in self.fake.texts(555)))
        # ...но раздавать админку нельзя
        for cmd in ("/addadmin 777", "/deladmin 999", "/deladmin 555", "/admins"):
            self.fake.sent.clear()
            await self.msg(555, cmd)
            self.assertTrue(any("только владельцы" in t for t in self.fake.texts(555)), cmd)
        self.assertFalse(self.db.is_granted_admin(777))
        self.assertTrue(self.db.is_granted_admin(555))                                        # и себя не снял
        # владельца это не затрагивает: он по-прежнему может
        await self.msg(999, "/addadmin 777")
        self.assertTrue(self.db.is_granted_admin(777))

    async def test_regular_user_gets_no_admin_surface(self):
        for cmd in ("/stats", "/admin", "/addadmin 5", "/ban 7", "/gen", "/admins"):
            self.fake.sent.clear()
            await self.msg(100, cmd)
            joined = " ".join(self.fake.texts(100))
            self.assertNotIn("Статистика", joined, cmd)
            self.assertNotIn("владельцы", joined.replace("Нужна подписка", ""), cmd)
            self.assertEqual(len(self.fake.calls("sendPhoto", 100)), 1, cmd)                 # просто главное меню
        self.assertFalse(self.db.is_granted_admin(5))

    async def test_delete_admin_and_list(self):
        await self.msg(999, "/addadmin 555")
        await self.msg(999, "/admins")
        listing = self.fake.texts(999)[-1]
        self.assertIn("999", listing)
        self.assertIn("555", listing)
        await self.msg(999, "/deladmin 555")
        self.assertFalse(self.db.is_granted_admin(555))
        self.fake.sent.clear()
        await self.msg(555, "/stats")                                                         # права пропали сразу
        self.assertFalse(any("Статистика" in t for t in self.fake.texts(555)))
        await self.msg(999, "/deladmin 999")                                                  # владельца снять нельзя
        self.assertTrue(any("Владельцев снять нельзя" in t for t in self.fake.texts(999)))

    async def test_admin_input_validation_and_idempotence(self):
        for bad in ("", "abc", "-5", "0", "1e3", "99999999999999999999999"):
            self.fake.sent.clear()
            await self.msg(999, f"/addadmin {bad}")
            self.assertTrue(any("Формат" in t for t in self.fake.texts(999)), bad)
        self.assertEqual(self.db.list_admins(), [])
        await self.msg(999, "/addadmin 555")
        self.fake.sent.clear()
        await self.msg(999, "/addadmin 555")
        self.assertTrue(any("уже админ" in t for t in self.fake.texts(999)))
        self.assertEqual(len(self.db.list_admins()), 1)
        self.assertEqual(self.fake.calls("sendMessage", 555), [])                             # повторно не уведомляем
        self.fake.sent.clear()
        await self.msg(999, "/addadmin 999")
        self.assertTrue(any("уже владелец" in t for t in self.fake.texts(999)))

    async def test_admins_cannot_be_banned_and_banned_user_can_become_admin(self):
        await self.msg(999, "/addadmin 555")
        for who, target in ((999, 555), (555, 999), (555, 555)):
            self.fake.sent.clear()
            await self.msg(who, f"/ban {target}")
            self.assertTrue(any("Админа забанить нельзя" in t for t in self.fake.texts(who)), (who, target))
            self.assertFalse(self.db.is_banned(target))
        await self.msg(999, "/ban 888")
        self.assertTrue(self.db.is_banned(888))
        await self.msg(999, "/addadmin 888")                                                  # назначение снимает бан
        self.assertFalse(self.db.is_banned(888))

    async def test_granted_admin_gets_key_without_subscription_and_loses_it_when_removed(self):
        await self.msg(999, "/addadmin 555")
        await self.press(555)
        key = self.last_key(555)
        self.assertIsNotNone(key)                                                             # не подписан, но ключ выдан
        _, b = await self.verify(key)
        self.assertEqual(self.check_sig(b)[2], "ok")
        await self.msg(999, "/deladmin 555")
        self.clock.t += 301
        _, b = await self.verify(key)
        self.assertEqual(self.check_sig(b)[2], "unsub")                                       # без админки действует проверка подписки

    async def test_admin_notify_failure_is_reported_not_fatal(self):
        self.fake.fail_chats.add(555)                                                         # бот ещё не может писать этому человеку
        await self.msg(999, "/addadmin 555")
        self.assertTrue(self.db.is_granted_admin(555))
        self.assertTrue(any("ещё не писал боту" in t for t in self.fake.texts(999)))

    async def test_switching_bot_token_reconfigures_profile_and_banner(self):
        self.db.kv_set("bot_id", "42")
        self.db.kv_set("banner_file_id", "old")
        self.db.kv_set("profile_hash", "x")
        self.db.kv_set("avatar_done", "1")
        bot = Bot(Service(dataclasses.replace(self.cfg, profile_sync=True), self.db, self.tg, self.clock), self.tg)
        self.assertEqual(bot._banner_id, "old")
        bot._bind_to_bot(1)                                                                   # fake-Telegram отвечает id=1
        self.assertIsNone(bot._banner_id)
        self.assertEqual([self.db.kv_get(k) for k in ("banner_file_id", "profile_hash", "avatar_done")], [None] * 3)
        self.assertEqual(self.db.kv_get("bot_id"), "1")
        await bot.sync_profile()
        self.assertEqual(len(self.fake.calls("setMyDescription")), 1)
        self.assertEqual(len(self.fake.calls("setMyProfilePhoto")), 1)
        bot._bind_to_bot(1)                                                                   # тот же бот — ничего не сбрасываем
        self.assertEqual(self.db.kv_get("profile_hash") is not None, True)


if __name__ == "__main__":
    unittest.main()
