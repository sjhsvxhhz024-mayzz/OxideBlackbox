"""Поддельный Telegram Bot API для тестов."""
import asyncio
import json

from aiohttp import web

RICH_MARKERS = ("icon_custom_emoji_id", "tg-emoji")      # цвет кнопки (style) Premium не требует


class FakeTelegram:
    def __init__(self):
        self.sent = []            # (method, params)
        self.members = set()      # id подписчиков
        self.broken_membership = False
        self.reject_rich = False  # Telegram отвечает ошибкой на кастомные эмодзи
        self.drop_rich = False    # Telegram молча выкидывает их (так и ведёт себя без Premium у владельца бота)
        self.rejected = 0         # сколько запросов отклонено из-за кастомных эмодзи
        self.fail_chats = set()   # чаты, куда бот «не может писать» (человек не запускал бота)
        self.profile_photos = 0
        self.updates = asyncio.Queue()
        self.runner = None
        self.port = 0

    async def start(self):
        app = web.Application(client_max_size=10 * 1024 * 1024)
        app.router.add_post("/bot{token}/{method}", self._handle)
        self.runner = web.AppRunner(app)
        await self.runner.setup()
        site = web.TCPSite(self.runner, "127.0.0.1", 0)
        await site.start()
        self.port = site._server.sockets[0].getsockname()[1]

    @property
    def base(self):
        return f"http://127.0.0.1:{self.port}"

    async def stop(self):
        await self.runner.cleanup()

    async def _params(self, req: web.Request) -> dict:
        if not req.content_type.startswith("multipart/"):
            return await req.json()
        p = {}
        async for part in await req.multipart():
            if part.filename:
                p[part.name] = f"<upload {part.filename} {len(await part.read())}>"
            else:
                p[part.name] = await part.text()
        for k in ("chat_id", "user_id", "message_id"):       # в multipart всё приходит строками
            if isinstance(p.get(k), str) and p[k].lstrip("-").isdigit():
                p[k] = int(p[k])
        for k in ("reply_markup", "photo"):
            if isinstance(p.get(k), str) and p[k][:1] in "{[":
                p[k] = json.loads(p[k])
        return p

    async def _handle(self, req: web.Request):
        method, p = req.match_info["method"], await self._params(req)
        self.sent.append((method, p))
        err = lambda code, d: web.json_response({"ok": False, "error_code": code, "description": d})
        if method == "getMe":
            return web.json_response({"ok": True, "result": {"id": 1, "username": "AvisToolsTestBot"}})
        if method == "getUpdates":
            try:
                u = await asyncio.wait_for(self.updates.get(), timeout=0.3)
                return web.json_response({"ok": True, "result": [u]})
            except asyncio.TimeoutError:
                return web.json_response({"ok": True, "result": []})
        if method == "getChatMember":
            if self.broken_membership:
                return err(400, "Bad Request: chat not found")
            if p["user_id"] == 4040:   # как Telegram отвечает на несуществующего участника
                return err(400, "Bad Request: PARTICIPANT_ID_INVALID")
            st = "member" if p["user_id"] in self.members else "left"
            return web.json_response({"ok": True, "result": {"status": st, "user": {"id": p["user_id"]}}})
        if method == "getUserProfilePhotos":
            return web.json_response({"ok": True, "result": {"total_count": self.profile_photos, "photos": []}})
        if method == "sendMessage" and p.get("chat_id") in self.fail_chats:
            return err(403, "Forbidden: bot can't initiate conversation with a user")
        if method in ("sendMessage", "sendPhoto", "editMessageText", "editMessageCaption"):
            blob = json.dumps(p, ensure_ascii=False)
            if self.reject_rich and any(m in blob for m in RICH_MARKERS):
                self.rejected += 1
                return err(400, "Bad Request: custom emoji are not allowed for this bot")
            if p.get("photo") == "STALE":
                return err(400, "Bad Request: wrong file identifier/HTTP URL specified")
            return web.json_response({"ok": True, "result": self._saved(method, p)})
        return web.json_response({"ok": True, "result": {"message_id": 100} if method.startswith(("send", "edit")) else True})

    def _saved(self, method: str, p: dict) -> dict:
        """То, что Telegram возвращает как сохранённое сообщение (с учётом отброшенных значков)."""
        text = p.get("text") or p.get("caption") or ""
        ents = [{"type": "bold", "offset": 0, "length": 1}]
        if not self.drop_rich:
            ents += [{"type": "custom_emoji", "offset": i * 2, "length": 2, "custom_emoji_id": "1"} for i in range(text.count("<tg-emoji"))]
        photo = method in ("sendPhoto", "editMessageCaption")
        msg = {"message_id": p.get("message_id", 100), "chat": {"id": p.get("chat_id")}, ("caption_entities" if photo else "entities"): ents}
        if photo:
            msg["photo"] = [{"file_id": "SMALL"}, {"file_id": "BANNERFILEID"}]
        rm = p.get("reply_markup")
        if rm:
            msg["reply_markup"] = {"inline_keyboard": [[{k: v for k, v in b.items() if not (self.drop_rich and k == "icon_custom_emoji_id")} for b in row]
                                                       for row in rm["inline_keyboard"]]}
        return msg

    # ---------- помощники для проверок ----------
    def texts(self, uid=None):
        return [p.get("text") or p.get("caption") or "" for m, p in self.sent
                if m in ("sendMessage", "editMessageText", "sendPhoto", "editMessageCaption") and (uid is None or p.get("chat_id") == uid)]

    def calls(self, method, uid=None):
        return [p for m, p in self.sent if m == method and (uid is None or p.get("chat_id") == uid)]

    def last_markup(self, uid):
        for m, p in reversed(self.sent):
            if m in ("sendMessage", "editMessageText", "sendPhoto", "editMessageCaption") and p.get("chat_id") == uid and "reply_markup" in p:
                return p["reply_markup"]
        return None
