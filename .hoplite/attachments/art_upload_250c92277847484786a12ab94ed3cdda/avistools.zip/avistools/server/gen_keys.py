"""Создаёт пару ключей подписи. Публичную часть нужно вшить в клиент (src/auth/auth_config.h).

   python gen_keys.py            — создать signing_key.pem, если его нет, и показать публичный ключ
   python gen_keys.py --force    — пересоздать (все старые клиенты перестанут принимать ответы сервера!)
"""
import sys

from avisbot import config
from avisbot.crypto import Signer, generate_private_key

cfg = config.from_env()
import os
if "--force" in sys.argv or not os.path.isfile(cfg.signing_key_path):
    generate_private_key(cfg.signing_key_path)
    print(f"Создан {cfg.signing_key_path} (НИКОМУ не показывай этот файл)\n")
print(Signer(cfg.signing_key_path).public_pem())
