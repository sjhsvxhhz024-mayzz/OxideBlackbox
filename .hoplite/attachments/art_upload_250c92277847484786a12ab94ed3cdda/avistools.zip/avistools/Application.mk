# Target: ARM64 Android, standalone executable (runs under root on device).
# Сборка для телефона (arm64-v8a) и Android x86_64 на ПК. Выбор через build.sh/build.ps1.
APP_ABI      := arm64-v8a x86_64
# android-29 gives us EGL, GLES3, ANativeWindow, dlfcn, system_properties.
APP_PLATFORM := android-29
# Static-link the C++ STL so the binary has no external libstdc++ dependency.
APP_STL      := c++_static
# -Wno-error: downgrade all -Werror back to warnings (oxorany + ImGui::TextColored
#   with non-literal format strings trigger -Wformat-security; the original build
#   was compiled with warnings, not errors).
# -Wno-format-security: silence the non-literal-format-string warning entirely.
# Логи: код логирования остаётся (-DOX_ENABLE_LOG), но выключен по умолчанию и стоит одно условие на вызов.
# Лог включён по умолчанию; выключить — пустой файл /sdcard/Download/AvisTools/debug.off.
# ДИАГНОСТИЧЕСКАЯ СБОРКА (по запросу erafox): логи ВКЛючены обратно.
#   OX_ENABLE_LOG  — пишет /sdcard/Download/AvisTools/avis_tools_<ts>.log
#   OX_VERBOSE_LOG — максимум деталей (chain/scan/HP/POS/W2S, первые 300 кадров)
#   Может слегка лагать (запись каждый кадр) — ок для диагностики, потом уберём.
APP_CPPFLAGS := -std=c++17 -fno-rtti -fexceptions -Wno-error -Wno-format-security -Wno-format -DOX_ENABLE_LOG
APP_CFLAGS   := -ffunction-sections -fdata-sections -Wno-error -Wno-format-security -Wno-format -DOX_ENABLE_LOG
# Release build, символы стрипаются.
APP_OPTIM    := release
APP_STRIP_MODE := --strip-all
