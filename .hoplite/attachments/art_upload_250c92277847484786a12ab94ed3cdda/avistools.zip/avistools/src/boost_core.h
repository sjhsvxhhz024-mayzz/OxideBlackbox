#pragma once
// Memory -> Boost: запись одного булева статического поля игры с возвратом исходного значения.
// Используется для WorldStreamingController.GrassEnabled / TreesEnabled (static_fields +0x18 / +0x19, дамп 1.14.11949): игра сама
// включает и выключает ими траву и деревья мира, поэтому запись «выключено» убирает их отрисовку, а возврат исходного значения
// восстанавливает то, что было до нашего вмешательства (если игра сама держала поле выключенным — оно таким и останется).
// Если игра перезаписывает поле (например, из настроек качества), запись повторяется, а счётчик перезаписей идёт в статус.
#include <stdint.h>
#include <string>

namespace boost {

enum class Result { Idle, Held, Waiting, Invalid };

class BoolPatch {
public:
    bool taken = false;
    uint8_t original = 1;
    int overwrites = 0, writes = 0;
    Result last = Result::Idle;

    // addr == 0 — поле недоступно (класс ещё не создан). Возвращает состояние для статуса.
    template <class Mem>
    Result tick(Mem &mem, uint64_t addr, bool hide, double now) {
        if (addr != addr_) {                                           // адрес сменился (перезапуск игры): прежний восстановить нельзя
            addr_ = addr; taken = false; wrote0_ = false; overwrites = 0;
        }
        if (!hide && !taken) { last = Result::Idle; return last; }
        if (!addr) { last = Result::Waiting; return last; }
        if (now < next_) return last;
        next_ = now + 0.25;
        uint8_t cur = 0;
        if (!mem.rd(addr, &cur, 1)) { last = Result::Waiting; return last; }
        if (cur > 1) { last = Result::Invalid; return last; }          // не bool: адрес неверен, ничего не пишем
        if (hide) {
            if (!taken) { original = cur; taken = true; wrote0_ = false; }
            if (cur != 0) {
                if (wrote0_) ++overwrites;                             // игра вернула значение после нашей записи
                const uint8_t z = 0;
                ++writes;
                if (mem.wr(addr, &z, 1)) wrote0_ = true;
            }
            last = Result::Held;
        } else {                                                       // выключение: вернуть исходное значение
            const uint8_t o = original;
            if (cur != o) { ++writes; mem.wr(addr, &o, 1); }
            taken = false; wrote0_ = false;
            last = Result::Idle;
        }
        return last;
    }

private:
    uint64_t addr_ = 0;
    bool wrote0_ = false;
    double next_ = 0.0;
};

// Ограничитель частоты кадров оверлея: сколько секунд спать перед началом следующего кадра. lastEnd — момент возврата из eglSwapBuffers (то есть
// vsync), cap — предел кадров/с (<= 0 — без ограничения). Кадр начинается за margin секунд до нужного vsync: отрисовка успевает, а
// swap дожидается vsync сам, поэтому частота не «проваливается» на следующую кратную обновлению экрана. Частота экрана не нужна.
inline double frameSleep(double lastEnd, double now, int cap, double margin = 0.003) {
    if (cap <= 0) return 0.0;
    const double period = 1.0 / (double)cap;
    double due = lastEnd + period - margin;
    if (due - now > period) due = now + period;                    // часы ушли назад или lastEnd устарел: не спим дольше периода
    return due > now ? due - now : 0.0;
}

}  // namespace boost
