#pragma once
// Скелет игрока: математика без чтения памяти (проверяется на хосте).
//
// Источник — настоящие кости модели. Иерархия нативных Transform плоская (массивы локальных
// TRS и индексов родителей), по ней считаются мировые позиции каждого узла. Кости опознаются
// по топологии гуманоида (бёдра, позвоночник, ноги, руки), без имён и без привязки к индексам.
// Пальцы и носки берутся прямо из иерархии: каждая кость рисуется своим ребром.
#include <math.h>
#include <stdint.h>
#include <string.h>
#include <memory>

namespace oxskel {

struct V3 { float x = 0, y = 0, z = 0; };
struct Q4 { float x = 0, y = 0, z = 0, w = 1; };

inline V3 operator+(V3 a, V3 b) { return { a.x + b.x, a.y + b.y, a.z + b.z }; }
inline V3 operator-(V3 a, V3 b) { return { a.x - b.x, a.y - b.y, a.z - b.z }; }
inline V3 operator*(V3 a, float s) { return { a.x * s, a.y * s, a.z * s }; }
inline float dot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline V3 cross(V3 a, V3 b) { return { a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x }; }
inline float len(V3 a) { return sqrtf(dot(a, a)); }
inline V3 lerp(V3 a, V3 b, float t) { return a + (b - a) * t; }
inline float hdist(V3 a, V3 b) { const float dx = a.x - b.x, dz = a.z - b.z; return sqrtf(dx * dx + dz * dz); }
inline bool finite3(V3 a) { return isfinite(a.x) && isfinite(a.y) && isfinite(a.z); }
inline V3 norm(V3 a, V3 fallback) { const float l = len(a); return l > 1e-5f ? a * (1.0f / l) : fallback; }
inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

inline V3 rotate(Q4 q, V3 v) {                       // q * v
    const V3 u{ q.x, q.y, q.z };
    const V3 t = cross(u, v) * 2.0f;
    return v + t * q.w + cross(u, t);
}
inline Q4 qmul(Q4 a, Q4 b) {                         // a * b
    return { a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
             a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
             a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
             a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z };
}

enum Joint {
    J_HEAD, J_NECK, J_CHEST, J_SPINE, J_PELVIS,
    J_SH_R, J_SH_L, J_EL_R, J_EL_L, J_HAND_R, J_HAND_L,
    J_HIP_R, J_HIP_L, J_KNEE_R, J_KNEE_L, J_FOOT_R, J_FOOT_L, J_TOE_R, J_TOE_L,
    J_COUNT
};

struct Edge { V3 a, b; };
constexpr int kMaxEdges = 48;

struct Pose {
    V3 j[J_COUNT];
    uint32_t real = 0;     // бит J: сустав найден в иерархии, а не достроен по пропорциям
    Edge e[kMaxEdges];     // мелкие кости: пальцы, носки и прочие листья
    int ne = 0;
    V3 face;               // единичный вектор, куда смотрит голова
    V3 headC;              // центр головы
    float headR = 0.105f;  // радиус головы, м
    bool ok = false;
};

// ════════════════════════════════════════════════════════════════════════════
//  Иерархия нативных Transform
// ════════════════════════════════════════════════════════════════════════════
struct TRS { V3 pos; Q4 rot; V3 scl{ 1, 1, 1 }; };

// Раскладка записи узла: смещения компонентов в float'ах и шаг записи в байтах. Локальный TRS лежит в
// первых 64 байтах записи; шаг может быть больше (запись узла содержит и другие поля, например мировой TRS).
struct TrsFmt { int stride = 0x30; int posF = 0, rotF = 4, sclF = 8; };

inline bool ParseTRS(const uint8_t *b, const TrsFmt &f, TRS &t) {
    float fl[16];
    const int n = f.stride < 64 ? f.stride : 64;
    memcpy(fl, b, (size_t)n);
    const int nf = n / 4;
    if (f.posF + 3 > nf || f.rotF + 4 > nf || f.sclF + 3 > nf) return false;
    t.rot = { fl[f.rotF], fl[f.rotF + 1], fl[f.rotF + 2], fl[f.rotF + 3] };
    t.pos = { fl[f.posF], fl[f.posF + 1], fl[f.posF + 2] };
    t.scl = { fl[f.sclF], fl[f.sclF + 1], fl[f.sclF + 2] };
    const float q2 = t.rot.x * t.rot.x + t.rot.y * t.rot.y + t.rot.z * t.rot.z + t.rot.w * t.rot.w;
    if (!isfinite(q2) || q2 < 0.81f || q2 > 1.21f) return false;
    if (!finite3(t.pos) || fabsf(t.pos.x) > 1e5f || fabsf(t.pos.y) > 1e5f || fabsf(t.pos.z) > 1e5f) return false;
    const float s[3] = { t.scl.x, t.scl.y, t.scl.z };
    for (float v : s) if (!isfinite(v) || fabsf(v) < 1e-4f || fabsf(v) > 1e3f) return false;
    return true;
}

struct Hier {
    int N = 0;
    const int *parent = nullptr;
    const TRS *loc = nullptr;
    const uint8_t *have = nullptr;
};

inline bool WorldPR(const Hier &h, int idx, V3 *pos, Q4 *rot) {
    if (idx < 0 || idx >= h.N || !h.have[idx]) return false;
    V3 p = h.loc[idx].pos;
    Q4 q = h.loc[idx].rot;
    int i = h.parent[idx], guard = 0;
    while (i >= 0) {
        if (i >= h.N || !h.have[i] || ++guard > 96) return false;
        const TRS &t = h.loc[i];
        p = rotate(t.rot, V3{ p.x * t.scl.x, p.y * t.scl.y, p.z * t.scl.z }) + t.pos;
        q = qmul(t.rot, q);
        i = h.parent[i];
    }
    if (pos) *pos = p;
    if (rot) *rot = q;
    return true;
}

// ════════════════════════════════════════════════════════════════════════════
//  Опознание костей гуманоида
// ════════════════════════════════════════════════════════════════════════════
constexpr int kMaxNodes = 2048;
constexpr int kMaxFine = 56;

struct RigMap {
    int j[J_COUNT];
    int fineN[kMaxFine], fineP[kMaxFine];   // мелкие кости: узел и его родитель
    int nf = 0;
    bool ok = false;
    RigMap() { for (int &v : j) v = -1; for (int k = 0; k < kMaxFine; ++k) fineN[k] = fineP[k] = -1; }
};

struct RigIn {
    int N = 0;
    const int *parent = nullptr;
    const V3 *wpos = nullptr;        // мировые позиции узлов
    const uint8_t *valid = nullptr;  // узел прочитан и мировая позиция посчитана
    int head = -1;                   // узел головы
    float ref = 1.66f;               // высота сустава головы над ногами стоя, м (масштаб порогов)
    V3 right{ 1, 0, 0 };             // горизонтальная боковая ось: только для имён «правый/левый»
};

namespace detail {

struct Tree {
    int first[kMaxNodes], next[kMaxNodes], order[kMaxNodes], lowNode[kMaxNodes];
    float minY[kMaxNodes];
    int cnt = 0;
};

inline bool OkParent(const RigIn &in, int i) { const int p = in.parent[i]; return p >= 0 && p < in.N && in.valid[p] && p != i; }

inline void BuildTree(const RigIn &in, Tree &t) {
    for (int i = 0; i < in.N; ++i) { t.first[i] = -1; t.next[i] = -1; t.lowNode[i] = i; t.minY[i] = in.valid[i] ? in.wpos[i].y : 1e9f; }
    for (int i = in.N - 1; i >= 0; --i) {
        if (!in.valid[i] || !OkParent(in, i)) continue;
        const int p = in.parent[i];
        t.next[i] = t.first[p];
        t.first[p] = i;
    }
    int stack[kMaxNodes], sp = 0;
    t.cnt = 0;
    for (int i = in.N - 1; i >= 0; --i) if (in.valid[i] && !OkParent(in, i)) stack[sp++] = i;
    while (sp > 0 && t.cnt < in.N) {
        const int n = stack[--sp];
        t.order[t.cnt++] = n;
        for (int c = t.first[n]; c >= 0 && sp < kMaxNodes - 1; c = t.next[c]) stack[sp++] = c;
    }
    for (int k = t.cnt - 1; k >= 0; --k) {
        const int n = t.order[k];
        if (!OkParent(in, n)) continue;
        const int p = in.parent[n];
        if (t.minY[n] < t.minY[p]) { t.minY[p] = t.minY[n]; t.lowNode[p] = t.lowNode[n]; }
    }
}

inline bool Ancestor(const RigIn &in, int node, int anc) {
    int g = 0;
    for (int i = node; i >= 0 && i < in.N && g < 96; i = in.parent[i], ++g) if (i == anc) return true;
    return false;
}

// Путь от вершины ветки `top` вниз до `leaf`. Возвращает длину (0 — leaf не под top).
inline int PathDown(const RigIn &in, int top, int leaf, int *out, int cap) {
    int tmp[96], n = 0;
    for (int i = leaf; i >= 0 && i < in.N && n < 96; i = in.parent[i]) { tmp[n++] = i; if (i == top) break; }
    if (n == 0 || tmp[n - 1] != top || n > cap) return 0;
    for (int k = 0; k < n; ++k) out[k] = tmp[n - 1 - k];
    return n;
}

inline int IndexOf(const int *path, int n, int node) { for (int k = 0; k < n; ++k) if (path[k] == node) return k; return -1; }

// Индекс узла пути, чья длина дуги от старта ближе всего к цели; не меньше minIdx.
inline int PickAtArc(const int *path, int n, const float *arc, float target, int minIdx) {
    int best = -1;
    float bd = 1e9f;
    for (int k = minIdx; k < n; ++k) { const float d = fabsf(arc[k] - target); if (d < bd) { bd = d; best = k; } }
    return best >= 0 ? path[best] : -1;
}

// Длина пути от `top` через ветку `c` до самого низкого узла её поддерева.
inline float BranchArc(const RigIn &in, const Tree &t, int top, int c) {
    float arc = len(in.wpos[c] - in.wpos[top]);
    int i = t.lowNode[c], g = 0;
    while (i != c && i >= 0 && i < in.N && g++ < 96) { const int p = in.parent[i]; arc += len(in.wpos[i] - in.wpos[p]); i = p; }
    return arc;
}

// Поддерево узла `root`: сколько узлов и насколько далеко оно уходит от точки `from`.
inline void SubtreeExtent(const RigIn &in, const Tree &t, int root, V3 from, float &extent, int &count) {
    int stk[kMaxNodes], sp = 0;
    extent = 0.0f; count = 0;
    stk[sp++] = root;
    while (sp > 0 && count < 400) {
        const int n = stk[--sp];
        ++count;
        extent = fmaxf(extent, len(in.wpos[n] - from));
        for (int c = t.first[n]; c >= 0 && sp < kMaxNodes - 1; c = t.next[c]) stk[sp++] = c;
    }
}

// Мелкие кости под суставом `root`: пальцы, носки. Берутся только небольшие ветки; оружие и снаряжение
// (большое поддерево) отбрасываются. Сами суставы (taken) не повторяются, но их потомки попадают в список.
inline void CollectFine(const RigIn &in, const Tree &t, int root, float maxExtent, uint8_t *taken, RigMap &out) {
    if (root < 0) return;
    for (int c = t.first[root]; c >= 0; c = t.next[c]) {
        float ext; int cnt;
        SubtreeExtent(in, t, c, in.wpos[root], ext, cnt);
        if (ext > maxExtent || cnt > 30) continue;
        int stk[kMaxNodes], sp = 0;
        stk[sp++] = c;
        while (sp > 0) {
            const int n = stk[--sp];
            if (!taken[n] && out.nf < kMaxFine && len(in.wpos[n] - in.wpos[in.parent[n]]) > 0.004f) {
                out.fineN[out.nf] = n; out.fineP[out.nf] = in.parent[n]; ++out.nf; taken[n] = 1;
            }
            for (int q = t.first[n]; q >= 0 && sp < kMaxNodes - 1; q = t.next[q]) stk[sp++] = q;
        }
    }
}

} // namespace detail

inline bool IdentifyRig(const RigIn &in, RigMap &out) {
    using namespace detail;
    out = RigMap();
    if (in.N < 12 || in.N > kMaxNodes || !in.valid || !in.wpos || !in.parent) return false;
    if (in.head < 0 || in.head >= in.N || !in.valid[in.head]) return false;
    const float ref = in.ref;
    const V3 headP = in.wpos[in.head];

    // Mapping runs only when the model changes. Keep its large scratch tree
    // local to this call so the Android x86_64 worker never retains a TLS
    // allocation across discovery jobs.
    std::unique_ptr<Tree> tree(new Tree{});
    Tree &t = *tree;
    BuildTree(in, t);

    // 1) бёдра: самый низкий предок головы на «высоте бёдер», у которого есть ≥ 2 ветки-ноги. Ногой считается
    //    ветка, чей путь вниз длиннее ~0.45 роста: у рук он короче. Критерий по длине, а не по вертикали,
    //    поэтому присед, бег и поднятая нога его не ломают.
    int hips = -1;
    {
        float bestY = 1e9f;
        int onPath = in.head, g = 0;
        for (int a = in.parent[in.head]; a >= 0 && a < in.N && in.valid[a] && g < 40; onPath = a, a = in.parent[a], ++g) {
            const float dh = headP.y - in.wpos[a].y;
            if (dh < 0.22f * ref || dh > 0.72f * ref) continue;
            int legs = 0;
            for (int c = t.first[a]; c >= 0; c = t.next[c])
                if (c != onPath && BranchArc(in, t, a, c) >= 0.45f * ref) ++legs;
            if (legs >= 2 && in.wpos[a].y < bestY) { bestY = in.wpos[a].y; hips = a; }
        }
    }
    if (hips < 0) return false;
    const V3 hipsP = in.wpos[hips];
    if (!(hipsP.y < headP.y - 0.15f * ref)) return false;

    // 2) позвоночник: путь бёдра -> голова
    int chain[64];
    const int cn = PathDown(in, hips, in.head, chain, 64);
    if (cn < 2) return false;
    float carc[64];
    carc[0] = 0.0f;
    for (int k = 1; k < cn; ++k) carc[k] = carc[k - 1] + len(in.wpos[chain[k]] - in.wpos[chain[k - 1]]);
    const float ctot = carc[cn - 1] > 1e-4f ? carc[cn - 1] : 1.0f;
    auto chainAt = [&](float frac, int lo, int hi) {
        int best = -1; float bd = 1e9f;
        for (int k = lo; k <= hi && k < cn; ++k) { const float d = fabsf(carc[k] / ctot - frac); if (d < bd) { bd = d; best = k; } }
        return best;
    };
    auto sideOf = [&](V3 p, V3 origin) { return dot(p - origin, in.right); };

    // 3) ноги: две самые низкие ветки-ноги от бёдер
    int legTop[2] = { -1, -1 };
    {
        float low[2] = { 1e9f, 1e9f };
        for (int c = t.first[hips]; c >= 0; c = t.next[c]) {
            if (c == chain[1] || BranchArc(in, t, hips, c) < 0.45f * ref) continue;
            const float my = t.minY[c];
            if (my < low[0]) { low[1] = low[0]; legTop[1] = legTop[0]; low[0] = my; legTop[0] = c; }
            else if (my < low[1]) { low[1] = my; legTop[1] = c; }
        }
    }
    if (legTop[0] < 0 || legTop[1] < 0) return false;

    // Колено и лодыжка выбираются по пропорциям звеньев, а не по абсолютным долям роста: бедро ≈ голень,
    // стопа заметно короче бедра. Так ошибка масштаба и скрутки (twist-кости) не сбивают выбор.
    struct LegJ { int hip = -1, knee = -1, ankle = -1, toe = -1; } legs[2];
    for (int s = 0; s < 2; ++s) {
        int path[96];
        const int n = PathDown(in, legTop[s], t.lowNode[legTop[s]], path, 96);
        if (n < 3) return false;
        float arc[96]; arc[0] = 0.0f;
        for (int k = 1; k < n; ++k) arc[k] = arc[k - 1] + len(in.wpos[path[k]] - in.wpos[path[k - 1]]);
        if (arc[n - 1] < 0.40f * ref) return false;
        int ki = -1, ai = -1;
        float bestS = -1e9f;
        for (int k = 1; k < n - 1; ++k) for (int a2 = k + 1; a2 < n; ++a2) {
            const float thigh = arc[k], shin = arc[a2] - arc[k], foot = arc[n - 1] - arc[a2];
            if (thigh < 0.08f * ref || shin < 0.08f * ref) continue;
            float sc = -fabsf(logf(thigh / shin)) - 0.6f * fabsf(logf((thigh + shin) / (0.49f * ref)));
            if (foot > 0.7f * thigh) sc -= 1.5f * (foot / thigh - 0.7f);
            if (t.first[path[a2]] >= 0) sc += 0.05f;                                  // у лодыжки есть носок
            if (sc > bestS) { bestS = sc; ki = k; ai = a2; }
        }
        if (ki < 1 || ai <= ki) return false;
        legs[s].hip = path[0]; legs[s].knee = path[ki]; legs[s].ankle = path[ai];
        legs[s].toe = ai + 1 < n ? path[ai + 1] : -1;
    }
    const int rIdx = sideOf(in.wpos[legs[1].hip], hipsP) > sideOf(in.wpos[legs[0].hip], hipsP) ? 1 : 0;
    const LegJ &LR = legs[rIdx], &LL = legs[1 - rIdx];

    // 4) руки. Боковая ось тела берётся по бёдрам (не зависит от входного `right`), поэтому поза с
    //    вытянутыми вперёд руками не путает стороны. Кандидат — ветка позвоночника с «вылетом» не меньше
    //    длины руки и плечом, заметно отнесённым вбок; на каждую сторону — самая длинная. Внутри руки
    //    плечо, локоть и кисть выбираются по пропорциям звеньев и по ветвлению кисти (пальцы, оружие).
    V3 lat = in.wpos[LR.hip] - in.wpos[LL.hip];
    lat.y = 0.0f;
    lat = norm(lat, in.right);
    struct ArmJ { int sh = -1, el = -1, hand = -1; } arms[2];            // [0] — правая, [1] — левая
    {
        struct ArmC { int top = -1, far = -1; float reach = 0, side = 0; } cand[16];
        int nc = 0;
        for (int k = 0; k < cn - 1 && nc < 16; ++k) {
            const int sp0 = chain[k];
            if (in.wpos[sp0].y < hipsP.y + 0.45f * (headP.y - hipsP.y)) continue;
            for (int c = t.first[sp0]; c >= 0 && nc < 16; c = t.next[c]) {
                if (c == chain[k + 1]) continue;
                int stk[kMaxNodes], sp = 0, far = c, visited = 0;
                float best = 0.0f;
                stk[sp++] = c;
                while (sp > 0 && visited++ < 400) {
                    const int n = stk[--sp];
                    const float d = len(in.wpos[n] - in.wpos[c]);
                    if (d > best) { best = d; far = n; }
                    for (int q = t.first[n]; q >= 0 && sp < kMaxNodes - 1; q = t.next[q]) stk[sp++] = q;
                }
                if (best < 0.22f * ref) continue;                    // рука от ключицы до пальцев ≥ ~0.4 м
                int path[96];
                const int n = PathDown(in, c, far, path, 96);
                if (n < 2) continue;
                const float s0 = dot(in.wpos[path[0]] - hipsP, lat), s1 = dot(in.wpos[path[1]] - hipsP, lat);
                const float side = fabsf(s1) > fabsf(s0) ? s1 : s0;
                if (fabsf(side) < 0.05f * ref) continue;             // рюкзак, оружие и прочее у оси — не рука
                cand[nc].top = c; cand[nc].far = far; cand[nc].reach = best; cand[nc].side = side;
                ++nc;
            }
        }
        int pk[2] = { -1, -1 };
        for (int k = 0; k < nc; ++k) {
            const int s = cand[k].side > 0.0f ? 0 : 1;
            if (pk[s] < 0 || cand[k].reach > cand[pk[s]].reach) pk[s] = k;
        }
        for (int s = 0; s < 2; ++s) {
            if (pk[s] < 0) continue;
            int path[96];
            const int n = PathDown(in, cand[pk[s]].top, cand[pk[s]].far, path, 96);
            if (n < 3) continue;
            float arc[96]; arc[0] = 0.0f;
            for (int k = 1; k < n; ++k) arc[k] = arc[k - 1] + len(in.wpos[path[k]] - in.wpos[path[k - 1]]);
            int bs = -1, be = -1, bh = -1;
            float bestS = -1e9f;
            for (int si = 0; si <= 2 && si < n - 2; ++si)
                for (int ei = si + 1; ei < n - 1; ++ei)
                    for (int hi = ei + 1; hi < n; ++hi) {
                        const float up = arc[ei] - arc[si], fo = arc[hi] - arc[ei];
                        if (up < 0.06f * ref || fo < 0.06f * ref) continue;
                        float sc = -fabsf(logf(up / fo / 1.07f)) - 0.6f * fabsf(logf((up + fo) / (0.31f * ref)));
                        int kids = 0;
                        for (int q = t.first[path[hi]]; q >= 0; q = t.next[q]) ++kids;
                        if (kids >= 3) sc += 0.6f;                   // у кисти расходятся пальцы / держатель оружия
                        if (sc > bestS) { bestS = sc; bs = si; be = ei; bh = hi; }
                    }
            if (bs < 0) continue;
            arms[s].sh = path[bs]; arms[s].el = path[be]; arms[s].hand = path[bh];
        }
    }

    // 5) итог
    out.j[J_HEAD] = in.head;
    out.j[J_PELVIS] = hips;
    const int ci = chainAt(0.66f, 1, cn - 2), si2 = chainAt(0.34f, 1, cn - 2);
    out.j[J_CHEST] = ci > 0 ? chain[ci] : -1;
    out.j[J_SPINE] = (si2 > 0 && si2 != ci) ? chain[si2] : -1;
    const int par = in.parent[in.head];
    out.j[J_NECK] = (par >= 0 && par != hips && par != out.j[J_CHEST]) ? par : -1;
    out.j[J_HIP_R] = LR.hip;    out.j[J_HIP_L] = LL.hip;
    out.j[J_KNEE_R] = LR.knee;  out.j[J_KNEE_L] = LL.knee;
    out.j[J_FOOT_R] = LR.ankle; out.j[J_FOOT_L] = LL.ankle;
    out.j[J_TOE_R] = LR.toe;    out.j[J_TOE_L] = LL.toe;
    out.j[J_SH_R] = arms[0].sh;     out.j[J_SH_L] = arms[1].sh;
    out.j[J_EL_R] = arms[0].el;     out.j[J_EL_L] = arms[1].el;
    out.j[J_HAND_R] = arms[0].hand; out.j[J_HAND_L] = arms[1].hand;

    // 6) мелкие кости: пальцы (под кистями) и носки (под стопами)
    uint8_t taken[kMaxNodes];
    memset(taken, 0, sizeof(taken));
    for (int k = 0; k < J_COUNT; ++k) if (out.j[k] >= 0) taken[out.j[k]] = 1;
    CollectFine(in, t, out.j[J_HAND_R], 0.135f * ref, taken, out);
    CollectFine(in, t, out.j[J_HAND_L], 0.135f * ref, taken, out);
    CollectFine(in, t, out.j[J_FOOT_R], 0.17f * ref, taken, out);
    CollectFine(in, t, out.j[J_FOOT_L], 0.17f * ref, taken, out);
    out.ok = true;
    return true;
}

// Собирает позу из мировых позиций узлов. Недостающие суставы достраивает по пропорциям.
// right/fwd — горизонтальные оси тела (из угла взгляда), feet — для носков и недостающих стоп.
inline bool BuildPose(const RigMap &m, const V3 *wp, const uint8_t *have, V3 feet, float ref, V3 right, V3 fwd, Pose &o) {
    o = Pose();
    auto get = [&](int jn, V3 &p) {
        const int n = m.j[jn];
        if (n < 0 || !have[n] || !finite3(wp[n])) return false;
        p = wp[n];
        o.real |= 1u << jn;
        return true;
    };
    V3 head, pelvis;
    if (!get(J_HEAD, head) || !get(J_PELVIS, pelvis)) return false;
    o.j[J_HEAD] = head; o.j[J_PELVIS] = pelvis;
    V3 p;
    o.j[J_CHEST] = get(J_CHEST, p) ? p : lerp(pelvis, head, 0.72f);
    o.j[J_SPINE] = get(J_SPINE, p) ? p : lerp(pelvis, o.j[J_CHEST], 0.5f);
    o.j[J_NECK] = get(J_NECK, p) ? p : lerp(head, o.j[J_CHEST], 0.40f);
    const V3 chest = o.j[J_CHEST];
    const float shHalf = 0.115f * ref, hipHalf = 0.054f * ref;
    o.j[J_HIP_R] = get(J_HIP_R, p) ? p : pelvis + right * hipHalf;
    o.j[J_HIP_L] = get(J_HIP_L, p) ? p : pelvis - right * hipHalf;
    o.j[J_KNEE_R] = get(J_KNEE_R, p) ? p : lerp(o.j[J_HIP_R], V3{ o.j[J_HIP_R].x, feet.y, o.j[J_HIP_R].z }, 0.5f);
    o.j[J_KNEE_L] = get(J_KNEE_L, p) ? p : lerp(o.j[J_HIP_L], V3{ o.j[J_HIP_L].x, feet.y, o.j[J_HIP_L].z }, 0.5f);
    o.j[J_FOOT_R] = get(J_FOOT_R, p) ? p : V3{ o.j[J_HIP_R].x, feet.y + 0.07f, o.j[J_HIP_R].z };
    o.j[J_FOOT_L] = get(J_FOOT_L, p) ? p : V3{ o.j[J_HIP_L].x, feet.y + 0.07f, o.j[J_HIP_L].z };
    auto toe = [&](V3 ankle) { V3 t = ankle + fwd * (0.09f * ref); t.y = fmaxf(feet.y + 0.01f, ankle.y - 0.04f); return t; };
    o.j[J_TOE_R] = get(J_TOE_R, p) ? p : toe(o.j[J_FOOT_R]);
    o.j[J_TOE_L] = get(J_TOE_L, p) ? p : toe(o.j[J_FOOT_L]);
    o.j[J_SH_R] = get(J_SH_R, p) ? p : chest + right * shHalf;
    o.j[J_SH_L] = get(J_SH_L, p) ? p : chest - right * shHalf;
    const V3 down{ 0, -1, 0 };
    o.j[J_EL_R] = get(J_EL_R, p) ? p : o.j[J_SH_R] + down * (0.16f * ref);
    o.j[J_EL_L] = get(J_EL_L, p) ? p : o.j[J_SH_L] + down * (0.16f * ref);
    o.j[J_HAND_R] = get(J_HAND_R, p) ? p : o.j[J_EL_R] + down * (0.145f * ref);
    o.j[J_HAND_L] = get(J_HAND_L, p) ? p : o.j[J_EL_L] + down * (0.145f * ref);
    o.headR = 0.105f * (ref / 1.66f);
    const V3 up = norm(head - o.j[J_NECK], V3{ 0, 1, 0 });
    o.headC = head + up * (0.05f * ref / 1.66f);
    o.face = fwd;
    for (int k = 0; k < m.nf && o.ne < kMaxEdges; ++k) {
        const int n = m.fineN[k], pr = m.fineP[k];
        if (n < 0 || pr < 0 || !have[n] || !have[pr] || !finite3(wp[n]) || !finite3(wp[pr])) continue;
        o.e[o.ne].a = wp[pr]; o.e[o.ne].b = wp[n]; ++o.ne;
    }
    o.ok = true;
    return true;
}

// Разумность позы: длины костей в допустимых пределах (защита от явного мусора; сдвиг узлов ловит контроль длин в bones.h).
inline bool PoseSane(const Pose &p, float ref) {
    auto seg = [&](Joint a, Joint b, float lo, float hi) { const float d = len(p.j[a] - p.j[b]); return d >= lo * ref && d <= hi * ref; };
    for (int k = 0; k < J_COUNT; ++k) if (!finite3(p.j[k])) return false;
    return seg(J_HIP_R, J_KNEE_R, 0.08f, 0.55f) && seg(J_HIP_L, J_KNEE_L, 0.08f, 0.55f) &&
           seg(J_KNEE_R, J_FOOT_R, 0.08f, 0.55f) && seg(J_KNEE_L, J_FOOT_L, 0.08f, 0.55f) &&
           seg(J_PELVIS, J_HEAD, 0.20f, 0.95f) &&
           seg(J_SH_R, J_EL_R, 0.04f, 0.45f) && seg(J_SH_L, J_EL_L, 0.04f, 0.45f) &&
           seg(J_EL_R, J_HAND_R, 0.04f, 0.45f) && seg(J_EL_L, J_HAND_L, 0.04f, 0.45f);
}

// Какая локальная ось головной кости смотрит «вперёд»: выясняется на лету сравнением с
// горизонтальным углом взгляда игрока. Модель у всех одна, поэтому калибровка общая.
struct AxisCalib {
    float sum[6] = { 0, 0, 0, 0, 0, 0 }, w[6] = { 0, 0, 0, 0, 0, 0 };
    static V3 Axis(int k) { static const V3 a[6] = { {1,0,0}, {-1,0,0}, {0,1,0}, {0,-1,0}, {0,0,1}, {0,0,-1} }; return a[k]; }
    void Feed(Q4 q, V3 fwdYaw) {
        for (int k = 0; k < 6; ++k) {
            const V3 d = rotate(q, Axis(k));
            const float hl = sqrtf(d.x * d.x + d.z * d.z);
            if (hl < 0.6f) continue;
            sum[k] += (d.x * fwdYaw.x + d.z * fwdYaw.z) / hl * hl;
            w[k] += hl;
        }
        if (w[0] + w[1] + w[4] + w[5] > 4000.0f) for (int k = 0; k < 6; ++k) { sum[k] *= 0.5f; w[k] *= 0.5f; }   // окно
    }
    int Best() const {
        int best = -1; float bv = 0.8f;
        for (int k = 0; k < 6; ++k) if (w[k] > 30.0f && sum[k] / w[k] > bv) { bv = sum[k] / w[k]; best = k; }
        return best;
    }
    V3 Face(Q4 q, V3 fallback) const {
        const int b = Best();
        if (b < 0) return fallback;
        return norm(rotate(q, Axis(b)), fallback);
    }
};


// ════════════════════════════════════════════════════════════════════════════
//  Позы без чтения костей
// ════════════════════════════════════════════════════════════════════════════

// Двухзвенная IK: сустав между root и концом; end — достижимая позиция конца.
inline V3 IK2(V3 root, V3 target, float a, float b, V3 pole, V3 *endOut) {
    V3 d = target - root;
    float D = len(d);
    if (D < 1e-4f) { d = V3{ 0, -1, 0 }; D = 1e-4f; }
    const V3 dir = d * (1.0f / D);
    const float Dc = clampf(D, fabsf(a - b) + 0.002f, a + b - 0.002f);
    const float x = (a * a - b * b + Dc * Dc) / (2.0f * Dc);
    const float h = sqrtf(fmaxf(0.0f, a * a - x * x));
    V3 perp = pole - dir * dot(pole, dir);
    float pl = len(perp);
    if (pl < 1e-4f) { perp = cross(dir, V3{ 1, 0, 0 }); pl = len(perp); }
    perp = perp * (1.0f / (pl > 1e-6f ? pl : 1.0f));
    if (endOut) *endOut = root + dir * Dc;
    return root + dir * x + perp * h;
}

inline void AddEdge(Pose &o, V3 a, V3 b) { if (o.ne < kMaxEdges) { o.e[o.ne].a = a; o.e[o.ne].b = b; ++o.ne; } }

// Статичная поза для превью в меню: стоит лицом к +Z, ноги на y = 0, голова на высоте S, руки чуть в стороны.
inline void StaticPose(float S, Pose &o) {
    o = Pose();
    const V3 up{ 0, 1, 0 }, fwd{ 0, 0, 1 }, right{ 1, 0, 0 };
    const float a = 0.245f * S, ah = 0.04f * S, hipHalf = 0.054f * S;
    const V3 pelvis{ 0, ah + 0.49f * S * 0.995f, 0 };
    const V3 chest = pelvis + up * (0.29f * S), neck = chest + up * (0.06f * S), head = neck + up * (0.12f * S);
    o.j[J_PELVIS] = pelvis; o.j[J_CHEST] = chest; o.j[J_NECK] = neck; o.j[J_HEAD] = head;
    o.j[J_SPINE] = lerp(pelvis, chest, 0.5f);
    for (int i = 0; i < 2; ++i) {
        const float sg = i == 0 ? 1.0f : -1.0f;
        const V3 hip = pelvis + right * (hipHalf * sg);
        const V3 an{ (hipHalf + 0.012f * S) * sg, ah, 0.0f };
        V3 ank;
        const V3 kn = IK2(hip, an, a, a, fwd, &ank);
        const V3 toe = ank + fwd * (0.09f * S) + up * (-(ah - 0.012f * S));
        const V3 sh = chest + right * (0.115f * S * sg) - up * (0.015f * S);
        const V3 dirU = norm(right * (0.62f * sg) - up, V3{ 0, -1, 0 }), dirF = norm(right * (0.50f * sg) - up, V3{ 0, -1, 0 });
        const V3 el = sh + dirU * (0.16f * S), hd = el + dirF * (0.15f * S);
        o.j[i == 0 ? J_HIP_R : J_HIP_L] = hip;   o.j[i == 0 ? J_KNEE_R : J_KNEE_L] = kn;
        o.j[i == 0 ? J_FOOT_R : J_FOOT_L] = ank; o.j[i == 0 ? J_TOE_R : J_TOE_L] = toe;
        o.j[i == 0 ? J_SH_R : J_SH_L] = sh;      o.j[i == 0 ? J_EL_R : J_EL_L] = el;
        o.j[i == 0 ? J_HAND_R : J_HAND_L] = hd;
        AddEdge(o, toe, toe + fwd * (0.04f * S));
        const V3 lat = cross(dirF, fwd);                          // поперёк кисти
        for (int f = 0; f < 5; ++f) {
            const float spread = (f - 2) * 0.016f * S, len1 = (f == 0 ? 0.030f : 0.040f) * S;
            V3 prev = hd;
            for (int seg = 0; seg < 3; ++seg) {
                const V3 nxt = prev + (dirF * (len1 * (seg == 0 ? 1.0f : 0.62f)) + lat * (spread * (seg == 0 ? 0.4f : 0.0f)));
                AddEdge(o, prev, nxt);
                prev = nxt;
            }
        }
    }
    o.headR = 0.105f * (S / 1.66f);
    o.headC = head + up * (0.05f * S / 1.66f);
    o.face = fwd;
    o.real = (1u << J_COUNT) - 1u;
    o.ok = true;
}

// Поза по настоящим опорным точкам, когда кости модели не читаются: голова, корпус и держатели оружия
// настоящие, остальное достроено по пропорциям, ноги стоят под тазом. Анимации здесь нет намеренно.
inline void AnchorPose(V3 head, V3 chestIn, bool haveChest, V3 rh, bool haveRH, V3 lh, bool haveLH,
                       V3 feet, float S, V3 fwd, V3 right, float crouch, Pose &o) {
    o = Pose();
    const V3 up{ 0, 1, 0 };
    const float a = 0.245f * S, ah = 0.04f * S, hipHalf = 0.054f * S;
    V3 chest = lerp(feet, head, 0.80f);
    if (haveChest && chestIn.y > feet.y + 0.40f * S && chestIn.y < head.y - 0.05f * S) chest = chestIn;
    const V3 pelvis{ head.x - (head.x - feet.x) * 0.3f, feet.y + ah + 0.49f * S * (1.0f - 0.32f * clampf(crouch, 0, 1)) * 0.995f, head.z - (head.z - feet.z) * 0.3f };
    o.j[J_HEAD] = head; o.j[J_CHEST] = chest; o.j[J_PELVIS] = pelvis;
    o.j[J_NECK] = lerp(head, chest, 0.45f); o.j[J_SPINE] = lerp(pelvis, chest, 0.5f);
    for (int i = 0; i < 2; ++i) {
        const float sg = i == 0 ? 1.0f : -1.0f;
        const V3 hip = pelvis + right * (hipHalf * sg);
        const V3 an{ feet.x + right.x * (hipHalf + 0.01f * S) * sg, feet.y + ah, feet.z + right.z * (hipHalf + 0.01f * S) * sg };
        V3 ank;
        const V3 kn = IK2(hip, an, a, a, fwd, &ank);
        const V3 toe = ank + fwd * (0.09f * S) + up * (-(ah - 0.012f * S));
        const V3 sh = chest + right * (0.115f * S * sg) - up * (0.015f * S);
        const bool have = i == 0 ? haveRH : haveLH;
        const V3 tgt = have ? (i == 0 ? rh : lh) : sh + up * (-0.30f * S) + right * (0.03f * S * sg);
        V3 hd;
        const V3 el = IK2(sh, tgt, 0.16f * S, 0.15f * S, norm(up * -1.0f + right * (0.5f * sg) - fwd * 0.3f, V3{ 0, -1, 0 }), &hd);
        o.j[i == 0 ? J_HIP_R : J_HIP_L] = hip;   o.j[i == 0 ? J_KNEE_R : J_KNEE_L] = kn;
        o.j[i == 0 ? J_FOOT_R : J_FOOT_L] = ank; o.j[i == 0 ? J_TOE_R : J_TOE_L] = toe;
        o.j[i == 0 ? J_SH_R : J_SH_L] = sh;      o.j[i == 0 ? J_EL_R : J_EL_L] = el;
        o.j[i == 0 ? J_HAND_R : J_HAND_L] = have ? tgt : hd;
    }
    o.headR = 0.105f * (S / 1.66f);
    o.headC = head + up * (0.05f * S / 1.66f);
    o.face = fwd;
    o.ok = true;
}

} // namespace oxskel
