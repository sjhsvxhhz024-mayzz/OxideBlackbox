#pragma once
#include <cstdint>
#include <cmath>

// Immutable resolved identity/health chain. Worker threads only read remote
// memory; they never touch render-thread HP maps, estimates or ImGui state.
namespace targetlife {
enum class State { Unknown, Alive, Dead, Replaced };
struct Ticket {
    uint64_t pm=0, klass=0, identitySlot=0, identity=0, netIdSlot=0;
    uint32_t netId=0;
    uint64_t respawnSlot=0, sourceSlot=0, handler=0, ownerSlot=0;
    uint64_t parentSlot=0, parent=0;
    uint64_t healthSlot=0, health=0, valuesSlot=0;
    int current=0;
    // Optional PC fallback when a remote player's health component is absent.
    // Each read revalidates membership in the live PlayerManager list.
    uint64_t rosterListSlot=0, rosterList=0, rosterItemsSlot=0, rosterItems=0;
    uint64_t rosterSizeSlot=0, rosterEntrySlot=0;
    int rosterIndex=-1;
};
template<class Reader> State Read(Reader &r,const Ticket &t) {
    if (!t.pm || !t.klass || !t.identity || !t.netId) return State::Unknown;
    uint64_t k=0,identity=0;uint32_t id=0;uint8_t respawn=0;
    if (!r.rd(t.pm,&k,8) || !r.rd(t.identitySlot,&identity,8)) return State::Unknown;
    if (k!=t.klass || identity!=t.identity) return State::Replaced;
    if (!r.rd(t.netIdSlot,&id,4)) return State::Unknown;
    if (id!=t.netId) return State::Replaced;
    if (!r.rd(t.respawnSlot,&respawn,1) || respawn>1) return State::Unknown;
    if (respawn==1) return State::Dead;
    if ((!t.handler || !t.health) && t.rosterEntrySlot && t.rosterIndex>=0) {
        uint64_t list=0,items=0,entry=0;int32_t size=0;
        if (!r.rd(t.rosterListSlot,&list,8) || !r.rd(t.rosterItemsSlot,&items,8) ||
            !r.rd(t.rosterSizeSlot,&size,4) || !r.rd(t.rosterEntrySlot,&entry,8))
            return State::Unknown;
        if (list!=t.rosterList || items!=t.rosterItems ||
            size<=t.rosterIndex || size>4096 || entry!=t.pm)
            return State::Replaced;
        return State::Alive;
    }
    if (!t.handler || !t.health || t.current<0 || t.current>1) return State::Unknown;
    uint64_t handler=0,owner=0,health=0;
    if(t.parentSlot) {uint64_t p=0;if(!r.rd(t.parentSlot,&p,8)) return State::Unknown;
        if(p!=t.parent) return State::Replaced;}
    if (!r.rd(t.sourceSlot,&handler,8) || !r.rd(t.ownerSlot,&owner,8) ||
        !r.rd(t.healthSlot,&health,8)) return State::Unknown;
    if (handler!=t.handler || owner!=t.pm || health!=t.health) return State::Replaced;
    float hp[2];
    if (!r.rd(t.valuesSlot,hp,sizeof(hp)) || !std::isfinite(hp[0]) ||
        !std::isfinite(hp[1]) || hp[0]<-1 || hp[1]<-1 || hp[0]>1e5f || hp[1]>1e5f)
        return State::Unknown;
    if(hp[t.current]<0) return State::Unknown; // loading/sentinel is not confirmed death
    return hp[t.current]==0 ? State::Dead : State::Alive;
}
} // namespace targetlife
