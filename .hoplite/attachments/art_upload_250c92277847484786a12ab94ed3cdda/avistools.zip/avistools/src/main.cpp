// NDK r27+ hardcodes -Werror=format-security at the end of the clang command
// line, after all user flags. oxorany() returns const char* (not a literal), so
// ImGui::TextColored(..., oxorany("...")) trips -Wformat-security. The original
// build was done with an older NDK that didn't force this. Pragma has priority
// over command-line -Werror, so we silence it here.
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wformat-nonliteral"
#pragma clang diagnostic ignored "-Wformat"

#include "main.h"
#include "auth/auth_client.h"
#include "auth/auth_config.h"
#include "auth/auth_sound.h"
#include "memory.h"
#include "utils.h"
#include "oxide_offsets.h"
#include "esp_style.h"
#include "skeleton.h"
#include "bones.h"
#include <unordered_map>
#include "oxlog.h"
#include "gear_names.h"
#include "stretch_core.h"
#include "oxide_arch.h"
#include "boost_core.h"
#include "aim_core.h"
#include "weapon_patch.h"
#include "silent_core.h"
#include "overlay_stability.h"
#include "overlay_jobs.h"
#include "trial/auto_heal.h"
#include "cupboard_finder_core.h"
#include "xray_core.h"
#include "chams_overlay.h"
#include "target_life.h"
#include "oxorany/oxorany.hpp"

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <sys/mman.h>
#include <sys/uio.h>
#include <malloc.h>
#include <math.h>
#include <thread>
#include <iostream>
#include <algorithm>
#include <sys/stat.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <iostream>
#include <locale>
#include <string>
#include <time.h>
#include <codecvt>
#include <dlfcn.h>
#include "Vector2.h"
#include "../include/Vector3.h"
#include "Quaternion.h"
#include <sstream>
#include <mutex>
#include <unordered_set>
#include <vector>
#include <atomic>
#include <chrono>

std::atomic<bool> main_thread_flag{true};

// ============================================================================
//  Startup pipeline (async).
//  Startup diagnostics + TypeInfo auto-resolve сканируют десятки/сотни МБ памяти
//  процесса игры и раньше вызывались синхронно в main() ДО входа в цикл рендера.
//  На защищённом билде Oxide это могло длиться минуты — meню за это время
//  вообще не открывалось (erafox видел зависший лог сразу после
//  "TypeInfo fallback из хедера: PM=... BP=... PV=...").
//  Новая схема: initGUI_draw() → touch → whileLoop СРАЗУ, а диагностика/резолв
//  идут в фоновом std::thread. UpdatePlayerCache/ox_getStatics пропускают
//  проход, пока фон не закончил, — меню отрисовывается с первого кадра, а
//  в углу видно строку статуса.
// ============================================================================
static std::atomic<bool> g_startupThreadStarted{false};
static std::atomic<bool> g_startupDone{false};
static std::atomic<bool> g_startupInProgress{false};
static std::mutex        g_startupStatusMutex;
static std::string       g_startupStatus = "\xd0\xbe\xd0\xb6\xd0\xb8\xd0\xb4\xd0\xb0\xd0\xbd\xd0\xb8\xd0\xb5"; // "ожидание"

static void ox_setStartupStatus(const std::string &s) {
    std::lock_guard<std::mutex> l(g_startupStatusMutex);
    g_startupStatus = s;
}
std::string ox_getStartupStatus() {
    std::lock_guard<std::mutex> l(g_startupStatusMutex);
    return g_startupStatus;
}

// Deadline для тяжёлых сканов памяти. Возвращает true если пора закруглиться.
// Проверяется вручную внутри цикла-сканера, чтобы не подвешивать UI.
static std::atomic<uint64_t> g_scanDeadlineMs{0};
static bool ox_scanTimedOut() {
    uint64_t d = g_scanDeadlineMs.load(std::memory_order_relaxed);
    if (!d) return false;
    uint64_t now = (uint64_t)std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
    return now >= d;
}
static void ox_setScanDeadline(uint64_t seconds) {
    uint64_t now = (uint64_t)std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
    g_scanDeadlineMs.store(now + seconds * 1000, std::memory_order_relaxed);
}
static void ox_clearScanDeadline() { g_scanDeadlineMs.store(0, std::memory_order_relaxed); }

int abs_ScreenX = 0;
int abs_ScreenY = 0;
int game_pid = -1;
uint64_t il2cpp_base = 0;

// ============================================================================
//  Startup-scan governance.
//
//  OX_TRUST_HEADER_TYPEINFO (default 1):
//    Верим значениям PLAYERMANAGER_TYPEINFO / BUILDINGPIECE_TYPEINFO /
//    PLAYERVITALS_TYPEINFO из oxide_offsets.h. При старте пробуем seed из
//    хедера (одна дереф + проверка имени класса) — если сходится, klass'ы
//    заполнены за миллисекунды, весь скан-путь пропускается: нет sweep-а
//    менеджеров, нет 45×20с retry, нет 200 MB/с memmem-прогрева. Если seed
//    не сходится (RVA протух, версия сменилась) — падаем на прежний
//    scan-based резолв через ox_autoResolveTypeInfos.
//
//  OX_DEEP_DIAG (default 0):
//    Полный sweep всех известных TypeInfo в конце startup-диагностики.
//    Нужен только когда обновляется libil2cpp.so и надо вытащить свежие
//    RVA для oxide_offsets.h — обычному пользователю это лаг без пользы.
// ============================================================================
#ifndef OX_TRUST_HEADER_TYPEINFO
#define OX_TRUST_HEADER_TYPEINFO 1
#endif
#ifndef OX_DEEP_DIAG
#define OX_DEEP_DIAG 0
#endif

// Типовые RVA из последнего dump.cs — fallback. Runtime resolver может заменить
// их на найденные в запущенной версии игры без пересборки после обновления.
static uint64_t g_playerManagerTypeInfoRVA = ox::PLAYERMANAGER_TYPEINFO;
static uint64_t g_buildingPieceTypeInfoRVA = ox::BUILDINGPIECE_TYPEINFO;
static bool g_typeInfoAutoResolved = false;
// Внешний чит НЕ может звать il2cpp_class_from_name (она в процессе игры).
// Поэтому кэшируем САМ указатель Il2CppClass, найденный сканом памяти по имени.
// Этого достаточно: klass + CLASS_STATIC_FIELDS -> static_fields напрямую,
// TypeInfo RVA (который на metadata v39 нестабилен) больше не нужен.
static uint64_t g_playerManagerKlass = 0;
static uint64_t g_buildingPieceKlass = 0;
// Mirror.NetworkClient (TDI 23916) — статический класс с реестром spawned.
// Нужен как резервный источник построек для LOS: saveList у клиента пустой.
static uint64_t g_networkClientKlass = 0;

// структура для кэширования данных игрока
struct PlayerCacheData {
    uint64_t address;
    uint32_t netId = 0;           // identity guard when reusing a cached name
    Vector3 position;
    ImVec2 w2sTop;
    ImVec2 w2sBottom;
    int health;
    int armor;
    int teamId;
    float distance;
    std::string name;
    bool nameFromRoster = false;   // ник взят из списка игроков матча (пришёл от сервера, а не из подписи над головой)
    std::string clan;          // тег клана (PM.clanTag)
    float hpNow = -1.f;        // живое HP (ox_readHpLive), -1 = не прочитано
    float hpMax = 0.f;         // максимум HP (GenericVitals.m_MaxHealth)
    std::string weapon;
    std::string weaponLabel;               // подпись оружия в руке: английское название
    // Расширенные данные читаются не каждый скан: имя и клан — раз в 2 с, оружие/броня/флаги — раз в 0.25 с (см. UpdatePlayerCache).
    double extStaticStamp = 0.0, extDynStamp = 0.0;
    int extMask = 0;
    std::vector<gear::Worn> armorWorn;     // надетая броня для подписей: название, слот, класс; порядок — голова, торс, ноги, ботинки, рюкзак
    std::string teamName;
    bool isVisibleTop;
    bool isVisibleBottom;
    // Якоря модели (KCC.head + Motor.LastInterpolatedPosition). Заполняются
    // когда espModelAnchor смог прочитать цепочку; тогда бокс/скелет/LOS
    // строятся по фактическим габаритам, а не по серверному тику + оффсет.
    bool    usedModelAnchor = false;
    Vector3 anchorFeet{0,0,0};
    Vector3 anchorHead{0,0,0};
    bool    anchorCrouching = false;  // цель сидит (капсула просела)
    Vector3 motorVelocity{0,0,0};     // скорость из Motor.BaseVelocity
    // Флаги состояния цели (PlayerManager.playerFlags + отдельные bool'ы).
    bool flagSleeping   = false;   // спит — обычно не атакуют
    bool flagSpectating = false;   // в режиме наблюдателя
    bool flagPrime      = false;   // прайм-аккаунт
    // LOS по BuildingPiece.saveList: true если путь от камеры до точки игрока
    // не перекрыт стеной. Пересчитывается каждый кадр в ESP-секции (дёшево на
    // кэше построек). aimbot при aimCheckWalls пропускает цели с losBlocked=true.
    bool losBlocked;
    bool losUnknown;   // нет данных для проверки (кэш построек пуст и цель не под лучом игры)
    uint64_t viewPtr;
    uint64_t bipedMap;
    bool hasSkeletonData;
    Vector3 velocity;
    Vector3 sampledPosition;
    double sampleTime;
    
    // ── Скелет: мировые позиции костей (заполняются ox_readSkeleton) ──────
    // Источник — PlayerModelInfo (head / body / rightWeaponHolder /
    // leftWeaponHolder) + Ragdoll.m_Pelvis. Остальные суставы достраиваются
    // интерполяцией между реальными точками, чтобы не читать по 15 трансформов
    // на игрока каждый кадр (дорого и лишний трафик к процессу игры).
    Vector3 headPos;      // голова (реальная кость)
    Vector3 neckPos;      // шея (интерполяция head<->chest)
    Vector3 spine1Pos;    // грудь
    Vector3 spine2Pos;    // таз (реальная кость: Ragdoll.m_Pelvis либо body)
    Vector3 rshoulderPos; // правое плечо
    Vector3 lshoulderPos; // левое плечо
    Vector3 ruparmPos;    // правый локоть
    Vector3 luparmPos;    // левый локоть
    Vector3 rlowarmPos;   // правая кисть (реальная кость: rightWeaponHolder)
    Vector3 llowarmPos;   // левая кисть  (реальная кость: leftWeaponHolder)
    Vector3 rhipPos, lhipPos;     // бёдра
    Vector3 rkneePos, lkneePos;   // колени
    Vector3 rfootPos, lfootPos;   // стопы
    // Живой скелет (ox_readSkeleton): дополнительные суставы и голова.
    Vector3 spineMidPos;          // середина позвоночника
    Vector3 rtoePos, ltoePos;     // носки
    Vector3 headCenter;           // центр головы
    Vector3 faceDir;              // куда смотрит голова (единичный вектор)
    float   headRadius = 0.105f;
    bool    skelLive = false;     // PC: настоящие кости; ARM: живые кости или опорные точки
    int     skelSrc = 0;          // 1 — кости модели, 2 — опорные точки (запасной путь)
    int     fineN = 0;            // мелкие кости: пальцы, носки (рёбра «родитель → узел»)
    Vector3 fineA[oxskel::kMaxEdges];
    Vector3 fineB[oxskel::kMaxEdges];
};

// глобальные переменные для кэширования
std::mutex player_data_mutex;
std::vector<PlayerCacheData> cached_players;
bool cache_needs_update = true;
int last_cache_frame = 0;
// Тяжёлый скан памяти (поиск игроков, HP, список) — раз в N кадров.
// Позиция КАЖДОГО игрока + камера пересчитываются КАЖДЫЙ кадр в отрисовке
// (ox_readPos по address), поэтому боксы держатся идеально на бегу и при
// повороте камеры без отставания — тяжёлый скан на это больше не влияет.
const int CACHE_UPDATE_INTERVAL = 3;
// Адрес локального игрока (для покадрового пересчёта камеры вне тяжёлого скана).
uint64_t g_localPlayer = 0;
std::string g_localTeamName;

int getProcessID(const char *packageName)
{
	DIR *dir = opendir("/proc");
	if (!dir) return -1;
	struct dirent *entry;
	while ((entry = readdir(dir)) != NULL)
	{
		int id = atoi(entry->d_name);
		if (id > 0)
		{
			char filename[64];
			snprintf(filename, sizeof(filename), "/proc/%d/cmdline", id);
			FILE *fp = fopen(filename, "r");
			if (fp)
			{
				char cmdline[256] = {0};
				size_t n = fread(cmdline, 1, sizeof(cmdline) - 1, fp);
				fclose(fp);
				if (n > 0 && strcmp(packageName, cmdline) == 0)
				{
					closedir(dir);
					return id;
				}
			}
		}
	}
	closedir(dir);
	return -1;
}

// Проверяет, есть ли в /proc/<pid>/maps строка с подстроко�� module.
static bool pidHasModule(int pid, const char *module) {
	char path[64]; sprintf(path, "/proc/%d/maps", pid);
	FILE* f = fopen(path, "rt");
	if (!f) return false;
	char line[1024];
	bool found = false;
	while (fgets(line, sizeof(line), f)) {
		if (strstr(line, module)) { found = true; break; }
	}
	fclose(f);
	return found;
}

// cmdline процесса начинается с packageName? (обрезает \0-разделённые аргументы).
static bool pidCmdlineMatches(int pid, const char *packageName) {
	char path[64]; sprintf(path, "/proc/%d/cmdline", pid);
	FILE* f = fopen(path, "r");
	if (!f) return false;
	char cmd[128] = {0};
	size_t n = fread(cmd, 1, sizeof(cmd) - 1, f);
	fclose(f);
	if (n == 0) return false;
	cmd[n] = 0;
	// главный процесс: cmdline РОВНО == packageName (сервисы имеют суффикс ":name")
	return strcmp(cmd, packageName) == 0;
}

// Находит ГЛАВНЫЙ процесс игры: среди всех с совпадающим cmdline выбирает тот,
// у которого реально замаплен module (рендер-процесс), иначе — любой совпавший.
// preferModule=nullptr → вернуть первый совпавший (как раньше).
int getGameProcessID(const char *packageName, const char *preferModule) {
	DIR *dir = opendir("/proc");
	if (!dir) return -1;
	struct dirent *entry;
	int firstMatch = -1;
	int best = -1;
	while ((entry = readdir(dir)) != NULL) {
		int id = atoi(entry->d_name);
		if (id <= 0) continue;
		if (!pidCmdlineMatches(id, packageName)) continue;
		if (firstMatch < 0) firstMatch = id;
		if (preferModule && pidHasModule(id, preferModule)) { best = id; break; }
	}
	closedir(dir);
	if (best > 0) return best;
	return firstMatch;
}

uint64_t get_module_base(const char *module_name, int mod) {
	uint64_t returned = 0;
	char path[32];
	sprintf(path, "/proc/%d/maps\0", game_pid);
	char line[1024];
	FILE* maps = fopen(path, "rt");
	if (!maps) return 0;
	while(fgets(line, 1024, maps)) {
		if(strstr(line, module_name) && strstr(line, (mod == 1 ? "r--p" : "r-xp"))) {
			uint64_t start,end;
			sscanf(line, "%lx-%lx",&start,&end);
			returned = start;
			break;
		}
  }
  fclose(maps);
  return returned;
}

// Возвращает АДРЕС САМОГО НИЗКОГО маппинга модуля (простой fallback).
uint64_t get_module_lowest(const char *module_name) {
	uint64_t lowest = 0;
	char path[64];
	sprintf(path, "/proc/%d/maps", game_pid);
	FILE* maps = fopen(path, "rt");
	if (!maps) return 0;
	char line[1024];
	while (fgets(line, sizeof(line), maps)) {
		if (!strstr(line, module_name)) continue;
		uint64_t start = 0, end = 0;
		if (sscanf(line, "%lx-%lx", &start, &end) == 2 && start) {
			if (!lowest || start < lowest) lowest = start;
		}
	}
	fclose(maps);
	return lowest;
}

// ИСТИННАЯ база ELF для RVA. В maps модуль может иметь несколько несвязанных
// кластеров (стороннее mmap файла + реальная загрузка линкером). Реальный —
// тот, где есть исполняемый r-xp сегмент. Берём его файловый offset, вычисляем
// candidate = xp_start - xp_offset, и выбираем offset-0 маппинг того же кластера
// (ближайший к candidate). Так отсекаем «левый» read-only mmap того же файла.
uint64_t get_module_base_real(const char *module_name) {
	char path[64];
	sprintf(path, "/proc/%d/maps", game_pid);
	FILE* maps = fopen(path, "rt");
	if (!maps) return 0;
	char line[1024];

	uint64_t xpStart = 0, xpOff = 0;
	// первый проход: найти исполняемый сегмент модуля
	while (fgets(line, sizeof(line), maps)) {
		if (!strstr(line, module_name)) continue;
		if (!strstr(line, "r-xp")) continue;
		uint64_t s = 0, e = 0, off = 0;
		if (sscanf(line, "%lx-%lx %*s %lx", &s, &e, &off) >= 2) { xpStart = s; xpOff = off; break; }
	}

	if (!xpStart) { // нет исполняемого — падаем на низший
		fclose(maps);
		return get_module_lowest(module_name);
	}

	uint64_t candidate = xpStart - xpOff; // ожидаемая база кластера
	rewind(maps);

	// второй проход: offset-0 маппинг, ближайший к candidate
	uint64_t best = 0, bestDiff = ~0ULL;
	while (fgets(line, sizeof(line), maps)) {
		if (!strstr(line, module_name)) continue;
		uint64_t s = 0, e = 0, off = 0;
		if (sscanf(line, "%lx-%lx %*s %lx", &s, &e, &off) < 2) continue;
		if (off != 0) continue;
		uint64_t diff = (s > candidate) ? (s - candidate) : (candidate - s);
		if (diff < bestDiff) { bestDiff = diff; best = s; }
	}
	fclose(maps);

	// если offset-0 не нашёлся или далеко (>16MB) — используем candidate.
	if (!best || bestDiff > 0x1000000ULL) return candidate;
	return best;
}

// Диагностика: выводит все строки maps, содержащие подстроку.
static void dump_maps_matching(const char *needle, int maxLines) {
	char path[64];
	sprintf(path, "/proc/%d/maps", game_pid);
	FILE* maps = fopen(path, "rt");
	if (!maps) { OXLOGW("maps не открылся для '%s'", needle); return; }
	char line[1024];
	int n = 0;
	while (fgets(line, sizeof(line), maps) && n < maxLines) {
		if (strstr(line, needle)) {
			size_t l = strlen(line);
			if (l && line[l-1] == '\n') line[l-1] = 0;
			OXLOGT("  maps: %s", line);
			n++;
		}
	}
	if (n == 0) OXLOGW("  в maps нет строк с '%s'", needle);
	fclose(maps);
}

// Диапазон маппингов модуля [low, high) и число сегментов.
static void get_module_span(const char *module_name, uint64_t &low, uint64_t &high, int &segs) {
	low = 0; high = 0; segs = 0;
	char path[64]; sprintf(path, "/proc/%d/maps", game_pid);
	FILE* maps = fopen(path, "rt");
	if (!maps) return;
	char line[1024];
	while (fgets(line, sizeof(line), maps)) {
		if (!strstr(line, module_name)) continue;
		uint64_t s = 0, e = 0;
		if (sscanf(line, "%lx-%lx", &s, &e) == 2 && s) {
			if (!low || s < low) low = s;
			if (e > high) high = e;
			segs++;
		}
	}
	fclose(maps);
}

// Форвар��-объявления (определены ниже, в секции чтения списка игроков).
static inline bool ox_isPtr(uint64_t p);
static void ox_className(uint64_t klass, char *out, int outlen);

// Инфо об одном модуле: диапазон, размер, ELF-хедер. Возвращает базу (low).
static uint64_t ox_dumpModule(const char *name) {
	uint64_t low, high; int segs;
	get_module_span(name, low, high, segs);
	uint64_t size = (high > low) ? (high - low) : 0;
	if (!low) { OXLOGW("Модуль '%s' НЕ найден в maps", name); return 0; }
	OXLOGI("%s: base=0x%llx end=0x%llx size=%llu MB (0x%llx) segs=%d",
	       name, (unsigned long long)low, (unsigned long long)high,
	       (unsigned long long)(size >> 20), (unsigned long long)size, segs);
	uint8_t elf[16] = {0};
	if (vm_readv(low, elf, sizeof(elf)))
		OXLOGI("  ELF magic: %02x %02x %02x %02x %s", elf[0], elf[1], elf[2], elf[3],
		       (elf[0]==0x7f && elf[1]=='E' && elf[2]=='L' && elf[3]=='F') ? "OK ELF" : "НЕ ELF!");
	else
		OXLOGW("  ELF-хедер не читается на 0x%llx", (unsigned long long)low);
	dump_maps_matching(name, 12);
	return low;
}

// Разовая диагностика ОБЕИ�� схем доступа за один запуск.
static void ox_moduleInfo() {
	oxlog::section("MODULE INFO — все .so игры");
	dump_maps_matching(".so", 60); // общий обзор: увидеть реальные имена либ

	// ---------- Схема A: il2cpp (реальная база по r-xp кластеру) ----------
	oxlog::section("SCHEME A: il2cpp (libil2cpp.so)");
	ox_dumpModule(ox::MODULE); // общий обзор всех маппингов
	uint64_t baseA = get_module_base_real(ox::MODULE);
	OXLOGI("Истинная база (r-xp кластер) = 0x%llx", (unsigned long long)baseA);
	if (baseA) {
        uint64_t rva = g_playerManagerTypeInfoRVA;
		uint64_t at = baseA + rva;
		uint64_t klass = rpm<uint64_t>(at);
		OXLOGI("[base+RVA(0x%llx)]=0x%llx -> klass=0x%llx",
		       (unsigned long long)rva, (unsigned long long)at, (unsigned long long)klass);
		uint8_t buf[0x40];
		if (vm_readv(at, buf, sizeof(buf)))
			oxlog::hexdump("вокруг base+RVA", at, buf, sizeof(buf));
		if (ox_isPtr(klass)) {
			char cn[96]; ox_className(klass, cn, sizeof(cn));
			OXLOGI("  klass name='%s' %s", cn,
			       (cn[0]) ? "" : "(пусто — RVA неверный для этой версии)");
			// дамп самого klass — увидеть name/namespace/static_fields
			if (vm_readv(klass, buf, sizeof(buf)))
				oxlog::hexdump("Il2CppClass head", klass, buf, sizeof(buf));
		} else {
			OXLOGW("  klass не похож на указатель — RVA либо база неверны");
		}
	}
}

// Ленивый резолв базы libil2cpp.so. Возвращает true если база готова.
static bool ox_ensureBase(bool full) {
	if (il2cpp_base) {
		// Периодически проверяем, что процесс жив и модуль на месте (раз в ~120 кадров).
		static int liveCheck = 0;
		if (++liveCheck >= 120) {
			liveCheck = 0;
			if (!pidHasModule(game_pid, ox::MODULE)) {
				OXLOGW("[base] pid=%d потерял %s — сброс, пере-резолв", game_pid, ox::MODULE);
				il2cpp_base = 0;
				// падаем ниже на пере-резолв PID/базы
			}
		}
		if (il2cpp_base) {
			static bool infoOnce = false;
			if (!infoOnce && full) { infoOnce = true; ox_moduleInfo(); }
			return true;
		}
	}

	// Проверяем, жив ли текущий PID и есть ли у него нужный модуль.
	// Если maps не читается ИЛИ модуля нет — пере-резолвим PID, выбирая ГЛАВНЫЙ
	// проце������с игры (тот, где реально замаплен libil2cpp.so). Игра могла
	// перезапуститься (новый PID) или мы поймали сервисный процесс.
	bool needRePid = (game_pid <= 0) || !pidHasModule(game_pid, ox::MODULE);
	if (needRePid) {
		int np = getGameProcessID(ox::PACKAGE, ox::MODULE);
		if (np > 0 && np != game_pid) {
			OXLOGI("[pid] переключа��сь на процесс с %s: %d -> %d",
			       ox::MODULE, game_pid, np);
			game_pid = np;
		} else if (np <= 0) {
			if (full) OXLOGW("[pid] процесс игры с %s пока не найден (game_pid=%d)",
			                 ox::MODULE, game_pid);
		}
	}

	uint64_t low = get_module_base_real(ox::MODULE);
	if (low) {
		il2cpp_base = low;
		OXLOGI("[base] %s найден: 0x%llx (pid=%d, r-xp кластер)", ox::MODULE,
		       (unsigned long long)il2cpp_base, game_pid);
		return true;
	}

	if (full) {
		OXLOGW("[base] %s ещё не в maps (pid=%d). Диагностика:", ox::MODULE, game_pid);
		dump_maps_matching("il2cpp", 12);
		dump_maps_matching(".so", 4);
	}
	return false;
}

bool aimm;
bool aimvisible = true;
int aimcurbone = 0;
float aimFovPixels = 220.0f;
float aimSmooth = 6.0f;
float aimMaxDistance = 350.0f;
bool aimDrawFov = true;
bool aimPrediction = true;
float aimProjectileSpeed = 250.0f;
float aimLatencyMs = 50.0f;
float aimMaxLeadTime = 0.35f;
// UPDATE 2026/07/31 v20: продвинутое упреждение.
// aimProjectileGravity — падение пули (м/с²). 0 = hitscan (нет дуги). Для
// баллистики (лук/дробовик с дропом) выставить ~9.81..20. Аим поднимает точку
// на величину дропа за время полёта.
float aimProjectileGravity = 0.0f;
// Итеративное схождение упреждения: цель успевает сместиться пока летит пуля,
// а это меняет дистанцию и время полёта. Пара итераций сходится к точке встречи.
float aimPredictIters = 3.0f;
// bug #4 (crouch): у внешнего чита НЕТ надёжного per-player флага «присел»
// (crouch-state живёт в обфусцированных ECM-компонентах, не reachable от
// PlayerManager, а animator-bool требует вызова метода В процессе). Поэтому
// авто-детект невозможен. Вместо ложного авто-детекта — ручной тумблер:
// когда враги приседают, включаешь его и aim-точка опускается на crouch-дельту.
bool  aimCrouchSafe = false;   // опускать aim-точку (враги присели)
float aimCrouchDrop = 0.45f;   // на сколько метров опустить (стоя ~1.8, сидя ~1.35)

// LOS-чек (аим через стены): если ON — аимбот не наводится на цель, перекрытую
// building piece'ом по ходу луча. ESP при этом рисует цель СИНИМ (невидим) и
// ЗЕЛЁНЫМ (видим) — отдельно от команды/инга.
bool aimCheckWalls = false;  // снят из меню: см. espColorByVisibility
bool aimIgnoreTeammates = false;  // см. espHideTeammates — источник команды пуст
// Валл-чек убран из меню: BuildingPiece.saveList наполняется только на СЕРВЕРЕ
// (OnStartServer), у клиента он пустой by design. Резерв через
// NetworkClient.spawned находит единицы объектов (matched=1..2 из ~50) —
// этого мало для честной проверки стен, поэтому окраска по видимости
// выключена, а не показывает ложную картину.
bool espColorByVisibility = false;
// --- Новый пакет фич (всё на чтении) ---
// Unity Matrix4x4 в памяти лежит column-major: m00 m10 m20 m30 m01 m11 ...
struct OxMat4 { float m[16]; };
// Сила подсветки стекла. Управляет ореолом вокруг панели, цветной дымкой
// внутри неё и яркостью кромок разом — один ползунок на весь материал.
float glowIntensity = 1.0f;
bool espModelAnchor = true; // ESP по трансформам модели вместо серверного тика
// Матричный W2S: берём worldToCameraMatrix/projectionMatrix прямо из нативной
// камеры вместо реконструкции базиса из углов. Смещения ищутся по подписи один
// раз за сессию; если не нашлись — тихо работаем по старому пути.
bool espMatrixW2S  = true;
static OxMat4 g_camVP;          // VP этого кадра
static OxMat4 g_camView;        // сырая view-матрица (для позиции камеры)
static bool   g_camVPValid = false;
static Vector3 g_camPosFromMatrix{0,0,0};
static bool    g_camPosValid = false;

// Доля радиуса капсулы, занятая видимым телом. Меньше — бокс уже, больше — шире.
static constexpr float OX_BOX_FIT = 0.80f;
float espBoxYOffset = -1.84f;
// espBoxYOffset (-1.84) калибровался под УГЛОВУЮ проекцию, которая сама вносила
// вертикальный сдвиг. Матричная проекция геометрически верна, поэтому тот же
// оффсет становится чистым смещением бокса на 1.84 м ВНИЗ — ровно симптом
// «игрок выше чем ESP». При активной матрице привязку берём нулевую:
// lastTickPosition — это позиция НОГ, значит низ бокса = pos, верх = pos+1.85.
static inline float ox_boxYOffset() {
#if defined(__x86_64__)
    // The live model origin observed on PC is at the feet. The old -1.84 m
    // correction put the whole ESP (and its fallback aim point) below players.
    return 0.0f;
#else
    return g_camVPValid ? 0.0f : espBoxYOffset;
#endif
}

bool espDistColor  = false; // цвет бокса по дистанции: близко=красный, далеко=синий
bool espFlags      = false; // метки Sleeping / Spectating / Prime
bool espHpNumber   = true;  // HP цифрой всегда (а не только когда !=100)
bool radarEnabled  = false; // радар-миникарта 360°
float radarRange   = 150.f; // радиус охвата радара в метрах
float radarSize    = 190.f; // диаметр виджета в пикселях
float radarPos[2]  = {40.f, 320.f}; // позиция левого верхнего угла
float radarAlpha   = 0.55f; // прозрачность подложки

// bug #5: аимбот работает ТОЛЬКО когда игрок целится (ADS/scope). ADS-состояние
// определяем по падению живого FOV ниже базового (FPManager.kYl < _kSQ*ratio) —
// проверяемо offline, не требует icall'ов. По умолчанию ВКЛ (запрос пользователя).
bool aimOnlyADS = true;   // legacy-флаг; теперь производный от aimTriggerMode

// UPDATE 2026/07/31 v22: РЕЖИМ активации аима.
//   0 = Always     — как только цель в FOV
//   1 = ADS/Scope  — только в прицеле (падение живого FOV)
//   2 = On fire    — только когда стреляем (детект по состоянию оружия)
//   3 = ADS + Fire — в прицеле ИЛИ при стрельбе
bool aimSticky = true;          // удержание цели (не прыгать между соседними)
float aimMaxSpeed = 900.0f;     // потолок скорости поворота, град/с
float aimDeadzone = 0.05f;      // не двигаем прицел, если ошибка меньше, град
float aimSwitchMargin = 1.5f;   // во сколько раз новая цель должна быть ближе к прицелу, чтобы сменить удерживаемую
float aimFireHold = 0.25f;      // сколько секунд после выстрела наводка остаётся активной (режимы On fire / ADS+Fire)
bool aimHoriz = true, aimVert = true;       // по каким осям наводить
bool aimSkipSleeping = true, aimSkipSpectating = true;
bool aimDrawTarget = true;      // линия от центра экрана до цели
float aimSettleDeg = 0.8f;      // зона доводки: ближе неё прицел садится ровно в точку
float aimRampMs = 120.0f;       // плавный разгон после захвата новой цели, мс
bool aimRecoilComp = true;      // учитывать разницу между полем углов и реальной камерой (отдача, покачивание)
bool noRecoil = false, noSpread = false;      // вкладка Memory
// Memory -> Stretch: подмена соотношения сторон нативной камеры (stretch_core.h). stretchMode: 0 16:9, 1 16:10, 2 3:2, 3 4:3, 4 5:4, 5 1:1, 6 Custom.
bool stretchOn = false;
int stretchMode = 3;
float stretchCustom = 1.5f;
std::string g_stretchStatus = "Stretch: off";
bool xrayOn = false;
float xrayDistance = 5.0f;
std::string g_xrayStatus = "X-ray: off";
// Memory -> Boost: дальность отрисовки (дальняя плоскость камеры), трава и деревья мира, частота кадров оверлея, логи.
bool boostDraw = false;
float boostDrawDist = 400.f;
bool boostGrass = false, boostTrees = false;
int boostFpsMode = 2;                // 0 Auto, 1 90, 2 60, 3 45, 4 30 (по умолчанию 60: оверлей не нужен чаще, чем рисует игра)
bool boostNoLog = false;
std::string g_boostStatus[5] = { "Draw distance: off", "World: grass and trees are drawn", "Overlay: auto", "Logs: on", "Load: measuring..." };
std::string g_memStatus = "No Recoil / No Spread: off";
bool aimSmoothConst = false;    // false — экспоненциальное сглаживание, true — постоянная скорость
static bool g_aimHasTarget = false; static ImVec2 g_aimTargetScreen;
int aimTriggerMode = 1;   // по умолчанию ADS (как раньше aimOnlyADS=true)

const char* aimbones[] = { "head","neck","body" };

bool check(uint64_t addr) {
	return addr != 0 && addr < 0xffffffffff;
}

std::string utf16le_to_utf8(const std::u16string &u16str) {    
    if (u16str.empty()) {
        return std::string();
    }

    const char16_t *p = u16str.data();   
    std::u16string::size_type len = u16str.length();  
    if (p[0] == 0xFEFF) {      
        p += 1;      
        len -= 1;   
    } 

    std::string u8str;   
    u8str.reserve(len * 3);    
    char16_t u16char;  
    for (std::u16string::size_type i = 0; i < len; ++i) {       
        u16char = p[i];        
        if (u16char < 0x0080) {          
            u8str.push_back((char) (u16char & 0x00FF));          
            continue;       
        }      
        if (u16char >= 0x0080 && u16char <= 0x07FF) {          
            u8str.push_back((char) (((u16char >> 6) & 0x1F) | 0xC0));        
            u8str.push_back((char) ((u16char & 0x3F) | 0x80));          
            continue;       
        }      
        if (u16char >= 0xD800 && u16char <= 0xDBFF) {           
            uint32_t highSur = u16char;          
            uint32_t lowSur = p[++i];          
            uint32_t codePoint = highSur - 0xD800;    
            codePoint <<= 10;        
            codePoint |= lowSur - 0xDC00;      
            codePoint += 0x10000;           
            u8str.push_back((char) ((codePoint >> 18) | 0xF0));     
            u8str.push_back((char) (((codePoint >> 12) & 0x3F) | 0x80));         
            u8str.push_back((char) (((codePoint >> 06) & 0x3F) | 0x80));            
            u8str.push_back((char) ((codePoint & 0x3F) | 0x80));        
            continue;       
        } { 
        u8str.push_back((char) (((u16char >> 12) & 0x0F) | 0xE0));          
        u8str.push_back((char) (((u16char >> 6) & 0x3F) | 0x80));      
        u8str.push_back((char) ((u16char & 0x3F) | 0x80));         
        continue;      
        }    
    }   
    return u8str;
}

[[maybe_unused]] int example() { return 0; }

bool espbox = true;
float espfillp = 0.22f;
float espstroke = 0.85f;  // < 1 = тот же 1 px, но слабее (ImGui не рисует тоньше пикселя)
bool espCornerBox = false;
float espCornerLength = 0.28f;
// Вертикальная привязка бокса. ox_readPos отдаёт PM.lastTickPosition, но у
// какого именно уровня контроллера там pivot (ноги / центр капсулы / голова)
// статически не определить. Наблюдение с устройства: бокс встаёт ВЫШЕ цели,
// значит pivot не на ногах — компенсируем сдвигом вниз. Слайдер в меню
// ESP -> BOX -> Vertical offset, чтобы подобрать вживую без пересборки.

bool espen;
bool esphpgradient;
bool espweapon;
bool espArmor;          // надетая броня подписями под боксом
bool esptracer;
bool espfill;
bool espgradient;
bool esphpoutline = true;
bool espdist = false;
bool esparm;

// Максимальная дальность отрисовки ESP (метры). По умолчанию огромная —
// показываем игроков хоть через всю карту. 0 = без ограничения вообще.
float espMaxDistance = 5000.0f;

// --- ESP Lines / Tracers ---
bool esplines_enabled = true;
float esplines_thickness = 0.75f;  // < 1 = тот же 1 px, но слабее
float esplines_color[3] = {1.0f, 1.0f, 1.0f};
int   esplines_position = 0; // 0=bottom center, 1=crosshair

// --- Настройки камеры для W2S (тюнятся в меню на устройстве) ---
float camFov = 98.607f;     // ГОРИЗОНТАЛЬНЫЙ FOV (град) — откалибровано под игру
bool  camInvertPitch = false;// инвертировать вертикальную ось проекции
bool  camInvertYaw = false;  // инвертировать горизонтальную ось проекции
// FIX bug #3: базис камеры теперь ВСЕГДА из мирового кватерниона m_LookRoot
// (полный yaw+pitch). Legacy-тумблеры pitch-fallback/swap удалены — они
// приводили к двойному применению pitch («боксы уезжают вверх»).

// --- Состояние кастомного меню ---
bool  g_menuOpen  = true;    // открыто ли большое меню (счётчик врагов тумблит)
int   g_activeTab = 0;       // 0=ESP 1=Aim 2=Camera 3=Settings
int   g_accentTheme = 1;     // индекс акцент-темы GLASS UI (0..4); 1 = Violet (магента-родной)

// --- Фильтры и производительность ---
int   g_enemyCount  = 0;     // сколько игроков сейчас в кэше (для счётчика)
int   g_cacheInterval = 10;  // heavy list/HP scan; positions are refreshed separately
int   g_positionInterval = 1;  // рефреш позиций каждый кадр — минимальный drift ESP
// Скрытие тимейтов снято из меню: ни один из трёх источников состава команды
// не заполнен в этом билде (nWc.team=0, TeammateStates пуст, UI-панель тоже).
// Оставлено выключенным, чтобы не тратить чтения на заведомо пустые цепочки.
bool  espHideTeammates = false;
bool espname;
bool vischeck;
bool esphat;
bool skeleton = true;    // скелет по настоящим костям модели (см. docs/ARCHITECTURE.md). Тумблер в меню Visual.
bool chamsOn = false;
bool chamsAnimated = true;
bool chamsDissolve = true;
int chamsStyle = 0;
float chamsOpacity = .58f;
float chamsGlow = .65f;
float chamsSpeed = 1.0f;
float chamsDuration = 1.4f;
float chamsRange = 180.0f;
bool outoffov;
bool oofvis;
bool ESP3D;
bool esp3dcorners;
bool visible;
bool visibleskeleton;

float cornered;
float espround;
float esp3dcornerstroke = 0.6f;   // v27: толщина 3D-бокса
float esphpsize = 3;
float width3d = 1.0f;
float oulinewidth3d = 0.5f;
float hatalpha = 0.200f;
float hatradius = 0.50f;
float hatsegments = 10.f;
float esphptextsize = 0;
bool espdraw = true;
bool espline;
float espboxcolor[3] = {1.0f, 1.0f, 1.0f};   // v27: белый по умолчанию
// v27: отдельный стиль на каждую функцию — своя толщина и цвет.
float skeleton_stroke = espstyle::kSkelStroke;   // множитель толщины
float skeleton_color[3] = {0.72f, 0.74f, 0.78f};   // серый
float esp3dcolor[3] = {1.0f, 1.0f, 1.0f};
// Имя / клан / HP: тумблеры и стиль (вкладка Visual -> Style). Значения по умолчанию — в espstyle::.
bool  espclan;
float espnamecolor[3] = {espstyle::kNameColor[0], espstyle::kNameColor[1], espstyle::kNameColor[2]};
float espclancolor[3] = {espstyle::kClanColor[0], espstyle::kClanColor[1], espstyle::kClanColor[2]};
float espnamesize = espstyle::kTextSize;   // множитель базового размера текста
float espclansize = espstyle::kTextSize;
int   esphpstyle  = espstyle::kHpStyle;    // 0 слева, 1 справа, 2 снизу
float esphpwidth  = espstyle::kHpWidth;    // толщина полосы HP, px
float esphpdamage = espstyle::kHpDamage;   // урон одного попадания для оценки HP; < 1 = авто (оружие в руках)
float esphpcrit   = espstyle::kHpCrit;     // множитель попадания в голову

ImDrawList* getDrawList() {
	return ImGui::GetBackgroundDrawList();
}

struct Vector4 {
	float x,y,z,w;
};

struct TMatrix {
    Vector4 position;
    Quaternion rotation;
    Vector4 scale;
};

static Vector3 getPosition(uint64_t transObj2) {
 uint64_t transObj = rpm<uint64_t>(transObj2 + 0x10);
 
    uint64_t matrix = rpm<uint64_t>(transObj + 0x38);
    uint64_t index = rpm<uint64_t>(transObj + 0x40);
 
    uint64_t matrix_list = rpm<uint64_t>(matrix + 0x18);
    uint64_t matrix_indices = rpm<uint64_t>(matrix + 0x20);
 
    Vector3 result = rpm<Vector3>(matrix_list + sizeof(TMatrix) * index);
    int transformIndex = rpm<int>(matrix_indices + sizeof(int) * index);
 
    while(transformIndex >= 0) {
        TMatrix tMatrix = rpm<TMatrix>(matrix_list + sizeof(TMatrix) * transformIndex);
 
        float rotX = tMatrix.rotation.x;
        float rotY = tMatrix.rotation.y;
        float rotZ = tMatrix.rotation.z;
        float rotW = tMatrix.rotation.w;
 
        float scaleX = result.x * tMatrix.scale.x;
        float scaleY = result.y * tMatrix.scale.y;
        float scaleZ = result.z * tMatrix.scale.z;
 
        result.x = tMatrix.position.x + scaleX +
                    (scaleX * ((rotY * rotY * -2.0) - (rotZ * rotZ * 2.0))) +
                    (scaleY * ((rotW * rotZ * -2.0) - (rotY * rotX * -2.0))) +
                    (scaleZ * ((rotZ * rotX * 2.0) - (rotW * rotY * -2.0)));
        result.y = tMatrix.position.y + scaleY +
                    (scaleX * ((rotX * rotY * 2.0) - (rotW * rotZ * -2.0))) +
                    (scaleY * ((rotZ * rotZ * -2.0) - (rotX * rotX * 2.0))) +
                    (scaleZ * ((rotW * rotX * -2.0) - (rotZ * rotY * -2.0)));
        result.z = tMatrix.position.z + scaleZ +
                    (scaleX * ((rotW * rotY * -2.0) - (rotX * rotZ * -2.0))) +
                    (scaleY * ((rotY * rotZ * 2.0) - (rotW * rotX * -2.0))) +
                    (scaleZ * ((rotX * rotX * -2.0) - (rotY * rotY * 2.0)));
 
        transformIndex = rpm<int>(matrix_indices + sizeof(int) * transformIndex);
    }
 
    return result;
}


// ============================================================================
//  OXIDE: чтение списка игроков через il2cpp static chain (с авто-детектом)
// ============================================================================

// Похоже ли значение на валидный heap/mmap указатель (выровнен, в диапазоне).
static inline bool ox_isPtr(uint64_t p) {
    return oxarch::isPtr(p) && (p & 0x3) == 0;
}

// Число занятых слотов Dictionary: _count лежит по 0x20, _freeCount по 0x28 (дамп 1.13.946, порядок полей .NET). Берём большее из двух:
// лишние слоты безвредны — свободные записи отсекаются по hashCode<0 и пустому значению.
static inline int ox_dictCount(uint64_t dict) {
    const int a = rpm<int>(dict + 0x20), b = rpm<int>(dict + 0x28);
    return a > b ? a : b;
}

// Мягкая проверка указателя (для строк/полей БЕЗ требования выравнивания по 4).
static inline bool ox_isPtrLoose(uint64_t p) {
    return oxarch::isPtr(p);
}

// TypeInfo and managed-list headers are live mutable state. Reading these
// through the frame cache can retain a class name or static pointer from an
// earlier initialization phase; use an exact process read for this chain.
template<typename T> static T ox_readDirect(uint64_t addr) {
    T value{};
    if (addr >= 0x1000) pvm(reinterpret_cast<void *>(addr), &value, sizeof(value), false);
    return value;
}

// Читает C-строку имени из Il2CppClass* (klass + CLASS_NAME -> const char*).
static void ox_className(uint64_t klass, char *out, int outlen) {
    out[0] = 0;
    if (!ox_isPtr(klass)) return;
    uint64_t namePtr = rpm<uint64_t>(klass + ox::CLASS_NAME);
    if (!ox_isPtrLoose(namePtr)) return; // строковый указатель может быть невыровнен
    char buf[96] = {0};
    if (!vm_readv(namePtr, buf, sizeof(buf) - 1)) return;
    int i = 0;
    for (; i < outlen - 1 && i < (int)sizeof(buf) - 1; i++) {
        char c = buf[i];
        if (c < 0x20 || (unsigned char)c > 0x7e) break; // только печатные ASCII
        out[i] = c;
    }
    out[i] = 0;
}

struct OxMapRange {
    uint64_t start;
    uint64_t end;
    char perms[5];
    char path[512];
};

// Snapshot /proc/<pid>/maps. Called only by the manual runtime resolver.
static void ox_collectMaps(std::vector<OxMapRange> &out, const char *pathFilter,
                           bool writableOnly, size_t maxBytes, bool anonOnly = false) {
    out.clear();
    char procPath[64]; snprintf(procPath, sizeof(procPath), "/proc/%d/maps", game_pid);
    FILE *maps = fopen(procPath, "rt");
    if (!maps) return;
    size_t total = 0;
    char line[1024];
    while (fgets(line, sizeof(line), maps)) {
        OxMapRange map{};
        unsigned long long start = 0, end = 0;
        char path[512] = {};
        int parsed = sscanf(line, "%llx-%llx %4s %*llx %*s %*s %511[^\n]",
                            &start, &end, map.perms, path);
        if (parsed < 3 || end <= start || map.perms[0] != 'r') continue;
        if (writableOnly && map.perms[1] != 'w') continue;
        if (pathFilter && *pathFilter && !strstr(path, pathFilter)) continue;
        if (anonOnly) {
            // Только анонимные регионы: расшифрованные метаданные/строки живут тут.
            if (path[0] != 0 && path[0] != '[') continue;
            // Пропускаем гигантские регионы (GC-куча) — имён классов там нет.
            if ((unsigned long long)(end - start) > 128ULL * 1024 * 1024) continue;
        }
        size_t size = (size_t)(end - start);
        if (size > maxBytes || total > maxBytes - size) continue;
        map.start = start;
        map.end = end;
        snprintf(map.path, sizeof(map.path), "%s", path);
        out.push_back(map);
        total += size;
    }
    fclose(maps);
}

// UPDATE 2026/07/31 v7: находит РЕАЛЬНЫЙ base адрес global-metadata.dat в памяти игры
// через /proc/<pid>/maps. Игра mmap'ит файл в свой процесс, mapping попадает в maps с
// path типа "/data/app/.../assets/bin/Data/Managed/Metadata/global-metadata.dat".
// Возвращает start_address первого такого mapping. 0 если не нашли (metadata ещё не
// подгружен либо игра сама расшифровала файл в анон-память — второе редкость для v39).
//
// Этот путь ЗАМЕНЯЕТ старую fast-seed цепочку OX_META_BASE_PTR_RVA (которая в новой
// сборке 2026-07-31 указывает не на metadata_base, а на какую-то внутреннюю таблицу
// libil2cpp — см. v5-лог: nameVa @ 0x6e9af44360 содержит ARM64-инструкции, не строку).
static uint64_t ox_findMetadataMmapBase() {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", game_pid);
    FILE *maps = fopen(path, "rt");
    if (!maps) return 0;
    char line[2048];
    uint64_t first_base = 0;
    while (fgets(line, sizeof(line), maps)) {
        // Ищем строки заканчивающиеся на "/global-metadata.dat" (mmap file mapping)
        if (!strstr(line, "global-metadata.dat")) continue;
        // Формат /proc/*/maps: "START-END perms offset dev inode  /path"
        // Берём только r-- mappings (metadata mmap'ится PROT_READ).
        unsigned long long s = 0, e = 0;
        char perms[8] = {0};
        if (sscanf(line, "%llx-%llx %7s", &s, &e, perms) < 3) continue;
        if (perms[0] != 'r') continue;
        // Хотим первый mmap (offset=0), проверяем что offset==0
        unsigned long long off = 0;
        if (sscanf(line, "%llx-%llx %*s %llx", &s, &e, &off) < 3) continue;
        if (off == 0) {
            first_base = s;
            break;
        }
        // fallback: если offset != 0 (какая-то фрагментация), берём первый попавшийся
        if (first_base == 0) first_base = s - off;
    }
    fclose(maps);
    return first_base;
}

static bool ox_asciiEquals(uint64_t address, const char *expected) {
    if (!ox_isPtrLoose(address) || !expected) return false;
    size_t length = strlen(expected);
    if (!length || length > 120) return false;
    char value[128] = {};
    return pvm(reinterpret_cast<void *>(address), value, length + 1, false) &&
           memcmp(value, expected, length) == 0 && value[length] == 0;
}

// Searches mapped memory for an ASCII literal (with NUL) and returns addresses.
static void ox_findAscii(const std::vector<OxMapRange> &maps, const char *needle,
                         std::vector<uint64_t> &matches, size_t maxMatches) {
    matches.clear();
    const size_t needleLen = strlen(needle) + 1;
    if (needleLen < 2) return;
    // Больший чанк (4 MB) + memmem() glibc — SIMD-оптимизирован под ARM64,
    // на порядок быстрее ручного memcmp-по-байту в цикле (лог 2026-07-24
    // показал 8 MB/сек на прошлом slot-переборе; memmem даёт 200+ MB/сек).
    const size_t chunkSize = 4 * 1024 * 1024;
    std::vector<uint8_t> buffer(chunkSize + needleLen);
    for (const OxMapRange &map : maps) {
        size_t carry = 0;
        for (uint64_t at = map.start; at < map.end && matches.size() < maxMatches;) {
            if (ox_scanTimedOut()) return;
            size_t want = (size_t)std::min<uint64_t>(chunkSize, map.end - at);
            if (!vm_readv(at, buffer.data() + carry, want)) { carry = 0; at += want; continue; }
            size_t total = carry + want;
            // memmem — сплошной sub-string поиск glibc. Возвращает первое
            // вхождение или NULL; сдвигаем указатель на +1 и ищем следующее.
            const uint8_t *base = buffer.data();
            const uint8_t *cursor = base;
            size_t remaining = total;
            while (matches.size() < maxMatches) {
                void *hit = memmem(cursor, remaining, needle, needleLen);
                if (!hit) break;
                size_t off = (const uint8_t*)hit - base;
                matches.push_back(at - carry + off);
                cursor = (const uint8_t*)hit + 1;
                if (cursor >= base + total) break;
                remaining = total - (cursor - base);
            }
            carry = std::min(needleLen - 1, total);
            memmove(buffer.data(), buffer.data() + total - carry, carry);
            at += want;
        }
    }
}

// Finds Il2CppClass by its name/namespace: class+0x10 points to name, class+0x18
// points to namespace. Class objects are in writable managed runtime mappings.
static uint64_t ox_findClassByName(uint64_t nameAddress, const char *className,
                                   const char *nameSpace, const std::vector<OxMapRange> &rwMaps) {
    const size_t chunkSize = 1024 * 1024;
    std::vector<uint8_t> buffer(chunkSize);
    for (const OxMapRange &map : rwMaps) {
        for (uint64_t at = map.start; at < map.end;) {
            if (ox_scanTimedOut()) return 0;
            size_t want = (size_t)std::min<uint64_t>(chunkSize, map.end - at);
            if (!vm_readv(at, buffer.data(), want)) { at += want; continue; }
            for (size_t i = 0; i + sizeof(uint64_t) <= want; i += sizeof(uint64_t)) {
                uint64_t value = 0;
                memcpy(&value, buffer.data() + i, sizeof(value));
                if (value != nameAddress || at + i < ox::CLASS_NAME) continue;
                uint64_t klass = at + i - ox::CLASS_NAME;
                uint64_t namespaceAddress = rpm<uint64_t>(klass + ox::CLASS_NAMESPACE);
                bool nsOk = (nameSpace == nullptr) || ox_asciiEquals(namespaceAddress, nameSpace);
                if (nsOk && ox_asciiEquals(rpm<uint64_t>(klass + ox::CLASS_NAME), className))
                    return klass;
            }
            at += want;
        }
    }
    return 0;
}

// НАДЁЖНЫЙ поиск Il2CppClass: перебираем 8-байтовые слоты, трактуя значение как
// name-указатель. Если оно ведёт в пул строк и strcmp совпал — это klass+0x10.
// Не зависит от того, какую именно копию имени держит класс (каноничную из
// блоба метадаты), поэтому чинит прошлый "класс не найден" при найденных литералах.
//
// Кооперативный deadline: если ox_setScanDeadline(N) выставлен, скан свернётся
// после его истечения и вернёт 0 — исключает подвисание фона на десятки минут
// при сканировании многогигабайтной кучи Unity.
// Слоты Il2CppClass* в libil2cpp (ScriptMetadata дампа 1.14.11949): класс читается прямо, без поиска по памяти.
// Слот заполняет сама игра при первом обращении к классу; пока он пуст, просто повторяем чтение на следующем тике.
static constexpr uint64_t OX_TI_PLAYERMANAGER = oxarch::kCur.tiPlayerManager;
static constexpr uint64_t OX_TI_GAMECONTROLLER = oxarch::kCur.tiGameController;
static constexpr uint64_t OX_TI_NETWORKCLIENT = oxarch::kCur.tiNetworkClient;
static constexpr uint64_t OX_TI_EQUIP_REGISTRY = oxarch::kCur.tiEquipRegistry;   // kU: Dictionary<int,string> номер -> id брони
static constexpr uint64_t OX_TI_WEAPON_REGISTRY = oxarch::kCur.tiWeaponRegistry;  // kD: Dictionary<int,string> номер -> id оружия

static uint64_t ox_klassFromSlot(uint64_t rva, const char *name) {
    if (!il2cpp_base) return 0;
    const uint64_t k = ox_readDirect<uint64_t>(il2cpp_base + rva);
    if (!ox_isPtr(k)) return 0;
    if (name && !ox_asciiEquals(ox_readDirect<uint64_t>(k + ox::CLASS_NAME), name)) return 0;
    return k;
}

static uint64_t ox_scanClassByName(const char *, const char *, const std::vector<OxMapRange> &, uint64_t, uint64_t) { return 0; }

// Finds the writable libil2cpp TypeInfo slot containing klass and converts its
// runtime address to an RVA from il2cpp_base. Уважает deadline из
// ox_setScanDeadline().
static uint64_t ox_findTypeInfoRVA(uint64_t klass, const std::vector<OxMapRange> &libRwMaps) {
    const size_t chunkSize = 1024 * 1024;
    std::vector<uint8_t> buffer(chunkSize);
    for (const OxMapRange &map : libRwMaps) {
        for (uint64_t at = map.start; at < map.end;) {
            if (ox_scanTimedOut()) return 0;
            size_t want = (size_t)std::min<uint64_t>(chunkSize, map.end - at);
            if (!vm_readv(at, buffer.data(), want)) { at += want; continue; }
            for (size_t i = 0; i + sizeof(uint64_t) <= want; i += sizeof(uint64_t)) {
                uint64_t value = 0;
                memcpy(&value, buffer.data() + i, sizeof(value));
                if (value == klass && at + i >= il2cpp_base)
                    return at + i - il2cpp_base;
            }
            at += want;
        }
    }
    return 0;
}

// Forward-decl: sweep вызывает auto-resolve, а тот определён ниже.
static bool ox_autoResolveTypeInfo(const char *className, const char *nameSpace,
                                   uint64_t &outRVA, uint64_t &outKlass, bool full);

// Runtime-скан ВСЕХ известных TypeInfo (по именам + namespace), с записью
// найденного RVA в лог. Служит источником свежих RVA для oxide_offsets.h после
// обновления игры — erafox прочитает Download-лог и обновит хардкод.
static void ox_sweepAllTypeInfos(bool full) {
    struct Known { const char *ns; const char *name; };
    static const Known kKnown[] = {
        {"Oxide",           "PlayerManager"},
        {"Oxide.Building",  "BuildingPiece"},
        {"Oxide",           "PlayerVitals"},
        {"Oxide",           "GenericVitals"},
        {"Oxide",           "EntityVitals"},
        {"Oxide",           "MouseLook"},
        {"Oxide",           "RaycastManager"},
        {"Oxide.Weapons",   "WeaponRecoil"},
        {"Oxide.Weapons",   "FPHitscan"},
        {"UnityEngine",     "Camera"},
        {"UnityEngine",     "Transform"},
    };
    oxlog::section("TYPEINFO SWEEP (runtime)");
    for (const Known &k : kKnown) {
        if (ox_scanTimedOut()) { OXLOGW("[sweep] deadline, дальше не сканируем"); break; }
        uint64_t rva = 0, klass = 0;
        bool ok = ox_autoResolveTypeInfo(k.name, k.ns, rva, klass, full);
        OXLOGI("[sweep] %-24s ns=%-16s -> klass=0x%llx  TypeInfoRVA=0x%llx  %s",
               k.name, k.ns, (unsigned long long)klass, (unsigned long long)rva,
               ok ? "OK" : "MISS");
    }
    OXLOGI("[sweep] завершён. Скопируй RVA в include/oxide_offsets.h если правишь fallback.");
}

// On-demand recovery of TypeInfo RVAs after a game update. First finds the
// literal in libil2cpp mappings, then Il2CppClass in writable runtime memory,
// and finally the TypeInfo pointer slot in libil2cpp's writable data segment.
static bool ox_autoResolveTypeInfo(const char *className, const char *, uint64_t &outRVA, uint64_t &outKlass, bool) {
    uint64_t rva = 0;
    if (!strcmp(className, "PlayerManager")) rva = OX_TI_PLAYERMANAGER;
    else return false;
    outRVA = rva;
    outKlass = ox_klassFromSlot(rva, className);
    return outKlass != 0;
}

// Offline-baked class name offsets в global-metadata.dat (из decrypted split-zip
// metadata, декодировано Nov/typeinfo_offline.py + string table @0xdc0ec).
// В рантайме: expected_name_va = metadata_base + оффсет ниже.
// UPDATE 2026/07/24: name-offsets = STR_OFF(0xDBE2C) + nameIndex. Класс-имя в
// строковой таблице (metadata_base + offset). Пересчитано под NEW metadata.
// UPDATE 2026/07/31: metadata пересобрана, strings-таблица сдвинута.
// Verified via `grep -abo "PlayerManager\x00" global-metadata.dat` — берём позицию, где сразу
// перед и после ASCII \x00 (packed nul-terminated table).
static constexpr uint64_t OX_META_NAME_OFF_PLAYERMANAGER = 0x17e504;  // "PlayerManager" (was 0x171ebc)
static constexpr uint64_t OX_META_NAME_OFF_BUILDINGPIECE = 0x11713e;  // "BuildingPiece" (was 0x10c433)
static constexpr uint64_t OX_META_NAME_OFF_PLAYERVITALS  = 0x1770dc;  // "PlayerVitals"  (was 0x16aebf)

// Резолвит Il2CppClass* через ПОИСК ССЫЛКИ на имя класса в libil2cpp writable.
// Не сканирует анон-память игры (что убивает игру через watchdog CatsBit'а).
// Bulk-read libRw одним vm_readv, локальный поиск слота содержащего known name-VA.
// Найденный слот - 0x10 = Il2CppClass* (CLASS_NAME field lives at klass+0x10).
static uint64_t ox_findKlassByNameVa(uint64_t nameVa,
                                     const std::vector<OxMapRange> &libRwMaps) {
    // UPDATE 2026/07/31 v9: БЫЛ БАГ — `if (sz > 16MB) continue` пропускал большие
    // регионы. Il2CppClass-структуры живут в class-heap, который БОЛЬШЕ 16 MB, поэтому
    // сканер их никогда не видел (v8-лог: "строка есть, но pointer не нашёл").
    // Теперь читаем чанками по 8 MB, большие регионы НЕ пропускаем.
    const size_t CHUNK = 8ULL * 1024 * 1024;
    std::vector<uint8_t> buf(CHUNK);
    for (const OxMapRange &m : libRwMaps) {
        if (m.end <= m.start) continue;
        for (uint64_t at = m.start; at < m.end; ) {
            if (ox_scanTimedOut()) return 0;
            size_t want = (size_t)std::min<uint64_t>(CHUNK, m.end - at);
            if (!vm_readv(at, buf.data(), want)) { at += want; continue; }
            for (size_t off = 0; off + 8 <= want; off += 8) {
                uint64_t v;
                memcpy(&v, buf.data() + off, 8);
                if (v == nameVa) {
                    uint64_t slot_va = at + off;
                    uint64_t klass = slot_va - ox::CLASS_NAME;  // slot = klass->name field
                    if (ox_isPtr(klass)) return klass;
                }
            }
            // Перекрытие на 8 байт чтобы не пропустить pointer на границе чанка.
            at += (want >= 8) ? (want - 8 + 8) : want;
            if (want < CHUNK) break;
        }
    }
    return 0;
}

// UPDATE 2026/07/31 v9: надёжный резолвер класса. Не полагается ни на s_TypeInfoTable,
// ни на конкретную копию metadata. Находит ВСЕ копии "className\0" во всех readable
// регионах, для каждой ищет указатель (chunked, без cap по размеру региона), верифицирует
// Il2CppClass layout: klass+0x10=name(className), klass+0x18=namespace(wantNs).
// Поиск класса по куче убран: он нагружал телефон и мог срабатывать как сигнал античита. Классы берутся из слотов TypeInfo.
static uint64_t ox_resolveKlassRobust(const char *, const char *) { return 0; }

// Fast-seed через offline MetadataCache chain (10 read'ов total, БЕЗ сканов).
//
// Оффлайн-разбор libil2cpp.so через capstone нашёл цепочку резолва TDI → klass,
// которую собственный код игры использует (функция @0x4d777f0 в libil2cpp,
// сравнимо с MetadataCache::GetTypeInfoFromTypeDefinitionIndex):
//
//   1) metadata_base = *(base + 0xbf81008)         ; загруженный global-metadata
//   2) header_ptr    = *(base + 0xbf81010)         ; Il2CppGlobalMetadataHeader
//   3) stride        = *(base + 0xbf8101c)         ; 1/2/4 байта на индекс
//   4) types_off_raw = *(header_ptr + 0xec)        ; XOR-encrypted оффсет
//   5) types_off     = types_off_raw ^ 0xA5C3F19D  ; decrypt (per README)
//   6) mc            = *(base + 0xbf80ff8)         ; MetadataCache*
//   7) s_TypeInfoTable = *(mc + 0x38)              ; Il2CppClass**
//   Один раз на всё, кэшируется. Дальше на класс:
//   8) ext_idx = *(metadata_base + types_off + TDI*stride)   ; u8/u16/u32
//   9) klass   = *(s_TypeInfoTable + ext_idx * 8)
//   10) validate: ox_className(klass) == expected_name
//
// UPDATE 2026/07/24: слоты сместились. Найдены offline-дизасмом NEW libil2cpp
// GetTypeInfoFromTypeDefinitionIndex (@0x4DFF360) + MetadataCache::Initialize
// (@0x4DFF4F8). XOR-ключ хедера 0xA5C3F19D — НЕ изменился (тот же movz/movk в коде).
//   OLD -> NEW: MC 0xbe3bb10->0xbf80ff8, base 0xbe3bb20->0xbf81008,
//   header 0xbe3bb28->0xbf81010, stride 0xbe3bb34->0xbf8101c,
//   s_TypeInfoTable 0xbe3bb58->0xbf80ff0. Все в .bss (RW, null в файле).
//
// Watchdog CatsBit'а срабатывает на ОБЪЁМ vm_readv (сравнение старой vs новой
// версии cheat'а: старая ~400 read'ов на резолв, новая — ~200 МБ scan). Здесь
// суммарно ~13 read'ов на 2 класса — не должен видеть.
static constexpr uint64_t OX_META_MC_RVA         = 0xbf613f8;  // was 0xbf80ff8
static constexpr uint64_t OX_META_BASE_PTR_RVA   = 0xbf61408;  // was 0xbf81008
static constexpr uint64_t OX_META_HEADER_PTR_RVA = 0xbf61410;  // was 0xbf81010
static constexpr uint64_t OX_META_STRIDE_RVA     = 0xbf6141c;  // was 0xbf8101c
static constexpr uint32_t OX_META_HEADER_TYPES_FIELD = 0xec;
static constexpr uint32_t OX_META_XOR_KEY        = 0xA5C3F19D;
static constexpr uint64_t OX_MC_TYPEINFOTABLE_OFF = 0x38;

// Кэш стартап-констант (заполняется один раз, читается на каждый резолв).
static uint64_t g_metadataBase   = 0;
static uint64_t g_typesTableAddr = 0;
static uint32_t g_typeStride     = 0;
static uint64_t g_sTypeInfoTable = 0;

static bool ox_cacheMetadataChain() {
    if (!il2cpp_base) return false;
    if (g_metadataBase && g_typesTableAddr && g_typeStride && g_sTypeInfoTable) return true;

    uint64_t meta   = rpm<uint64_t>(il2cpp_base + OX_META_BASE_PTR_RVA);
    uint64_t hdr    = rpm<uint64_t>(il2cpp_base + OX_META_HEADER_PTR_RVA);
    uint32_t stride = rpm<uint32_t>(il2cpp_base + OX_META_STRIDE_RVA);
    if (!ox_isPtr(meta) || !ox_isPtr(hdr) || stride == 0 || stride > 4) {
        OXLOGW("[chain] MetadataCache pointers ещё не установлены (meta=0x%llx hdr=0x%llx stride=%u)",
               (unsigned long long)meta, (unsigned long long)hdr, stride);
        return false;
    }

    uint32_t off_raw = rpm<uint32_t>(hdr + OX_META_HEADER_TYPES_FIELD);
    uint32_t off_dec = off_raw ^ OX_META_XOR_KEY;

    uint64_t mc = rpm<uint64_t>(il2cpp_base + OX_META_MC_RVA);
    if (!ox_isPtr(mc)) {
        OXLOGW("[chain] MetadataCache pointer ещё null (mc=0x%llx)", (unsigned long long)mc);
        return false;
    }

    // === DIAGNOSTIC: пробуем ВСЕ MC offsets в диапазоне, где может лежать
    // s_TypeInfoTable. Для каждого читаем ext_idx для PM (TDI 8357, UPDATE 2026/07/24),
    // берём klass, дампим 64 байта. По логу видно какой offset реально даёт
    // Il2CppClass с валидным именем. (OX_TDI_PLAYERMANAGER объявлен ниже — тут литерал.)
    static bool s_diagLogged = false;
    if (!s_diagLogged) {
        s_diagLogged = true;
        uint64_t enc_addr_pm = meta + off_dec + 8357ULL * stride;
        uint32_t ext_idx_pm = (stride == 4 ? rpm<uint32_t>(enc_addr_pm) :
                              stride == 2 ? (uint32_t)rpm<uint16_t>(enc_addr_pm) :
                                            (uint32_t)rpm<uint8_t>(enc_addr_pm));
        OXLOGI("[chain-diag] meta=0x%llx hdr=0x%llx mc=0x%llx types_off=0x%x stride=%u ext_idx_pm(TDI=8357)=%u",
               (unsigned long long)meta, (unsigned long long)hdr,
               (unsigned long long)mc, off_dec, stride, ext_idx_pm);
        for (uint64_t mc_off : {0x18ULL, 0x20ULL, 0x28ULL, 0x30ULL, 0x38ULL, 0x40ULL, 0x48ULL, 0x50ULL, 0x58ULL, 0x60ULL}) {
            uint64_t table = rpm<uint64_t>(mc + mc_off);
            if (!ox_isPtr(table)) {
                OXLOGD("[chain-diag] MC+0x%llx = 0x%llx (не указатель)", mc_off, (unsigned long long)table);
                continue;
            }
            uint64_t klass_pm = rpm<uint64_t>(table + (uint64_t)ext_idx_pm * 8);
            char nm[64] = {0};
            if (ox_isPtr(klass_pm)) ox_className(klass_pm, nm, sizeof(nm));
            OXLOGI("[chain-diag] MC+0x%02llx=0x%llx  table[%u]=0x%llx  name='%s'",
                   mc_off, (unsigned long long)table, ext_idx_pm,
                   (unsigned long long)klass_pm, nm);
            if (ox_isPtr(klass_pm)) {
                uint8_t buf[64] = {0};
                if (vm_readv(klass_pm, buf, sizeof(buf))) {
                    char label[64];
                    snprintf(label, sizeof(label), "klass @ MC+0x%llx table[%u]", mc_off, ext_idx_pm);
                    oxlog::hexdump(label, klass_pm, buf, sizeof(buf));
                }
            }
        }
    }

    uint64_t tit = rpm<uint64_t>(mc + OX_MC_TYPEINFOTABLE_OFF);
    if (!ox_isPtr(tit)) {
        OXLOGW("[chain] s_TypeInfoTable ещё не выделен (mc=0x%llx tit=0x%llx)",
               (unsigned long long)mc, (unsigned long long)tit);
        return false;
    }

    g_metadataBase   = meta;
    g_typesTableAddr = meta + off_dec;
    g_typeStride     = stride;
    g_sTypeInfoTable = tit;
    OXLOGI("[chain] cached: meta=0x%llx types_off=0x%x stride=%u tit=0x%llx",
           (unsigned long long)meta, off_dec, stride,
           (unsigned long long)tit);
    return true;
}

static uint64_t ox_klassFromTDI(uint32_t tdi, const char *expectedName) {
    if (!ox_cacheMetadataChain()) return 0;
    uint64_t enc_addr = g_typesTableAddr + (uint64_t)tdi * g_typeStride;
    uint32_t ext_idx = 0;
    switch (g_typeStride) {
        case 1: ext_idx = rpm<uint8_t>(enc_addr);  if (ext_idx == 0xff)    return 0; break;
        case 2: ext_idx = rpm<uint16_t>(enc_addr); if (ext_idx == 0xffff)  return 0; break;
        case 4: ext_idx = rpm<uint32_t>(enc_addr); if (ext_idx == 0xffffffff) return 0; break;
        default: return 0;
    }
    uint64_t klass = rpm<uint64_t>(g_sTypeInfoTable + (uint64_t)ext_idx * 8);
    if (!ox_isPtr(klass)) return 0;
    char cn[96] = {0};
    ox_className(klass, cn, sizeof(cn));
    if (cn[0] == 0 || strcmp(cn, expectedName) != 0) {
        // Диагностика один раз на класс — дамп первых 32 байт klass чтобы
        // понять валиден ли указатель (Class::Init не прогнан VS указатель мусор).
        static std::atomic<uint64_t> s_dumpedFor{0};
        uint64_t marker = ((uint64_t)tdi << 40) | (klass & 0xffffffffffULL);
        if (s_dumpedFor.exchange(marker) != marker) {
            uint8_t buf[32] = {0};
            if (vm_readv(klass, buf, sizeof(buf))) {
                oxlog::hexdump("klass head (Class::Init pending?)", klass, buf, sizeof(buf));
            }
        }
        OXLOGD("[chain] TDI=%u ext=%u klass=0x%llx имя='%s' ожидали '%s'",
               tdi, ext_idx, (unsigned long long)klass, cn, expectedName);
        return 0;
    }
    return klass;
}

// Offline-baked byvalTypeIndex (external index в types[]) для каждого класса.
// Достаётся из decrypted global-metadata.dat: TypeDef record @ (0x1523780 + TDI*82) + 8.
// UPDATE 2026/07/24: пересчитано под NEW metadata. Проверено offline: 60998/46457/61062.
static constexpr int32_t OX_BYVAL_IDX_PLAYERMANAGER = 60998;  // was 60939
static constexpr int32_t OX_BYVAL_IDX_BUILDINGPIECE = 46457;  // was 46390
static constexpr int32_t OX_BYVAL_IDX_PLAYERVITALS  = 61062;  // was 61003

// Метадата диапазон для проверки: находится ли pointer в метадате (Il2CppTypeDefinition*)
// или в куче (Il2CppClass* пост-Class::Init). Метадата ~26 МБ, начинается с magic.
static bool ox_isInMetadata(uint64_t addr, uint64_t metaBase, size_t metaSize = 32ULL << 20) {
    return addr >= metaBase && addr < metaBase + metaSize;
}

// Bulk-search heap region for slot equal to nameVa (klass's name field).
// Klass в куче рядом с MC struct — Il2CppClass structs аллоцируются тем же
// аллокатором. Одна vm_readv-считка большого куска памяти игры, локальный поиск.
// Если найдено → klass = slot - CLASS_NAME (0x10).
static uint64_t ox_findKlassInHeap(uint64_t nameVa, uint64_t regionStart, size_t regionSize) {
    if (regionSize > 32ULL * 1024 * 1024) return 0;  // cap 32 MB per bulk read
    std::vector<uint8_t> buf(regionSize);
    if (!vm_readv(regionStart, buf.data(), regionSize)) return 0;
    for (size_t off = 0; off + 8 <= regionSize; off += 8) {
        uint64_t v;
        memcpy(&v, buf.data() + off, 8);
        if (v == nameVa) {
            uint64_t slot = regionStart + off;
            uint64_t klass = slot - ox::CLASS_NAME;
            // Sanity: klass должен быть в той же куче
            if (klass >= regionStart && klass < regionStart + regionSize) return klass;
        }
    }
    return 0;
}

// РЕЗОЛВ ЧЕРЕЗ s_TypeInfoTable — offline-найденный через ARM64 disasm.
//
// Offline-дизасм libil2cpp.so нашёл `MetadataCache::Initialize` +
// `GetTypeInfoFromTypeDefinitionIndex`. Оттуда — cached lazy accessor:
//   NEW 0x4DFF370: ldr x21, [x8, #0xff0]       ; x21 = *(0xBF80FF0) = s_TypeInfoTable
//   NEW 0x4DFF374: ldr x20, [x21, w0, sxtw #3] ; klass = s_TypeInfoTable[TDI]
//   (OLD было 0x4D77404 ldr x22,[x8,#0xb58] -> 0xBE3BB58; store в Init @0x4DFF63C)
//
// s_TypeInfoTable — Il2CppClass** массив (TYPEDEF_COUNT записей), индексируется по TDI.
// UPDATE 2026/07/24: slot @ RVA 0xBF80FF0 (было 0xBE3BB58) — .bss (writable),
// NULL в файле, malloc'ится MetadataCache::Initialize через Calloc.
//
// Lazy: s_TypeInfoTable[TDI] == NULL пока класс не заресолвен игрой (metadata usage
// init при входе в матч). После первого захода — s_TypeInfoTable[8357] = klass.
// ВАЖНО (фикс 2026/07/25): 0xBF80FF0 — это s_MethodInfoDefinitionTable
// (226854 слотов, индекс = method index), НЕ таблица классов. Обе функции —
// GetMethodInfoFromMethodDefinitionIndex @0x4dff360 и Class::FromTypeDefinition
// @0x4e0030c — имеют одинаковую форму (XOR-ключ + sdiv + cache-write), поэтому
// pattern-скан сел на неправильную.
//
// Доказательство из MetadataCache::Initialize @0x4dff4f8:
//   0x4dff5f8: ldr w8,[header,#0xe8]; eor KEY   -> 29486  (typeDefinitionsCount)
//   0x4dff618: str x0, [0xBF81040]              -> s_TypeInfoDefinitionTable
//   0x4dff61c: ldr w8,[header,#0xd0]; eor KEY   -> 226854 (methodsCount)
//   0x4dff63c: str x0, [0xBF80FF0]              -> s_MethodInfoDefinitionTable
//
// Class::FromTypeDefinition @0x4e0030c читает именно 0xBF81040:
//   0x4e00334: ldr x22, [x8, #0x40]           ; x22 = *(0xBF81040)
//   0x4e00338: ldr x20, [x22, w0, sxtw #3]    ; klass = table[TDI]
//   0x4e00604: str x20, [x22, w19, sxtw #3]   ; cache-write
//
// Старый билд: 0xBE3BB58. Все metadata-глобалы сдвинулись на +0x1454E8,
// 0xBE3BB58 + 0x1454E8 = 0xBF81040. Мнемоника на будущее:
//   s_TypeInfoDefinitionTable = <ctx global> + 0x48  (0xBF80FF8 + 0x48).
// UPDATE 2026/07/25: подтверждено дизасмом Initialize @0x4df3948 —
//   alloc(header[0xe8]^KEY = 29486) -> str x0,[0xBF61440]   классы
//   alloc(header[0xd0]^KEY = 226242) -> str x0,[0xBF613F0]  методы
// Все шесть metadata-глобалов сдвинулись ровно на -0x1FC00.
// Мнемоника снова сходится: ctx(0xBF613F8) + 0x48 = 0xBF61440.
static constexpr uint64_t OX_S_TYPEINFO_TABLE_RVA = 0xBF61440ULL;  // was 0xBF81040
// UPDATE 2026/10/08 (билд 1.13.946, дамп arm64.1.13.946): TDI обновлены
// (grep "class X :" в dump.cs). TYPEDEF_COUNT: header метадаты зашифрован
// целиком, поэтому взят как max(TypeDefIndex)+1 из дампа. Рабочий резолв —
// robust name-scan, эти TDI нужны только резервному fast-seed пути.
// ARM64/x86_64 1.15.11966: TypeDefIndex совпадают в обоих dump.cs.
// count = max(TypeDefIndex)+1.
static constexpr uint32_t OX_TDI_NETWORKCLIENT    = 25797;
static constexpr uint32_t OX_TDI_PLAYERMANAGER    = 9814;
static constexpr uint32_t OX_TDI_BUILDINGPIECE    = 9938;
static constexpr uint32_t OX_TDI_PLAYERVITALS     = 9449;
static constexpr uint32_t OX_TYPEDEF_COUNT        = 31895;

// Fast-seed через s_TypeInfoTable[TDI]. Детерминированный, 3 vm_readv на класс.
static bool ox_ensureBase(bool full);
static bool ox_fastSeedTypeInfoFromHeader() {
    if (!il2cpp_base) {
        static double s_lastTry = -10.0;
        const double now = (double)time(nullptr);
        if (now - s_lastTry < 1.0) return false;           // чтение /proc/<pid>/maps — не чаще раза в секунду
        s_lastTry = now;
        if (!ox_ensureBase(false)) return false;
    }
    if (!g_playerManagerKlass) {
        g_playerManagerKlass = ox_klassFromSlot(OX_TI_PLAYERMANAGER, "PlayerManager");
        if (g_playerManagerKlass) OXLOGI("[klass] PlayerManager=0x%llx (слот +0x%llx)", (unsigned long long)g_playerManagerKlass, (unsigned long long)OX_TI_PLAYERMANAGER);
        else {
            static double s_lastDiag = 0.0;
            const double now = (double)time(nullptr);
            if (now - s_lastDiag > 10.0) {
                s_lastDiag = now;
                const uint64_t raw = rpm<uint64_t>(il2cpp_base + OX_TI_PLAYERMANAGER);
                char nm[40] = {0};
                if (ox_isPtr(raw)) { const uint64_t np = rpm<uint64_t>(raw + ox::CLASS_NAME); if (ox_isPtr(np)) vm_readv((unsigned long)np, nm, 32); }
                for (char &c : nm) if ((unsigned char)c < 0x20 || (unsigned char)c > 0x7E) c = '?';
                OXLOGW("[klass] слот PlayerManager (base+0x%llx) = 0x%llx, имя класса '%s' — %s", (unsigned long long)OX_TI_PLAYERMANAGER,
                       (unsigned long long)raw, nm, raw ? "имя не совпало (другая версия игры?)" : "слот ещё пуст (класс не инициализирован)");
            }
        }
    }
    return g_playerManagerKlass != 0;
}

static bool ox_autoResolveTypeInfos(bool full) {
    uint64_t rva = 0, k = 0;
    if (!g_playerManagerKlass && ox_autoResolveTypeInfo("PlayerManager", "Oxide", rva, k, full)) {
        g_playerManagerKlass = k;
        g_playerManagerTypeInfoRVA = rva;
    }
    return g_playerManagerKlass != 0;
}

// Runtime metadata extractor -------------------------------------------------
// Il2CppGlobalMetadataHeader всегда начинается с 0xFAB11BAF уже ПОСЛЕ
// расшифровки. Ищем этот заголовок в native writable mappings, валидируем
// version и таблицы offset/size, затем копируем весь blob в Download.
static constexpr uint32_t IL2CPP_METADATA_MAGIC = 0xFAB11BAFU;
[[maybe_unused]] static std::string g_metadataDumpStatus = "No metadata dump yet";

static void ox_collectMetadataMaps(std::vector<OxMapRange> &out, size_t maxBytes) {
    out.clear();
    char procPath[64]; snprintf(procPath, sizeof(procPath), "/proc/%d/maps", game_pid);
    FILE *maps = fopen(procPath, "rt");
    if (!maps) return;
    size_t total = 0;
    char line[1024];
    while (fgets(line, sizeof(line), maps)) {
        // Decrypted IL2CPP metadata normally lives in malloc/anonymous native
        // memory. Dalvik heaps, per-thread stacks and device mappings are huge
        // and cannot contain it, so skip them before reading process memory.
        if (strstr(line, "dalvik") || strstr(line, "stack_and_tls") ||
            strstr(line, "/dev/") || strstr(line, "jit-"))
            continue;
        OxMapRange map{};
        unsigned long long start = 0, end = 0;
        char path[512] = {};
        int parsed = sscanf(line, "%llx-%llx %4s %*llx %*s %*s %511[^\n]",
                            &start, &end, map.perms, path);
        if (parsed < 3 || end <= start || map.perms[0] != 'r') continue;
        // Some loaders decrypt metadata and immediately mprotect it read-only.
        // Include writable native allocations as before plus anonymous read-only
        // memory and libil2cpp's own read-only mappings; skip unrelated system
        // libraries with file-backed r-- pages.
        bool isWritable = map.perms[1] == 'w';
        bool isIl2Cpp = strstr(path, "libil2cpp.so") != nullptr;
        bool isAnonymous = path[0] == 0 || strstr(path, "[anon:") != nullptr ||
                           strstr(path, "[heap]") != nullptr;
        if (!isWritable && !isIl2Cpp && !isAnonymous) continue;
        size_t size = (size_t)(end - start);
        if (size > maxBytes || total > maxBytes - size) continue;
        map.start = start;
        map.end = end;
        snprintf(map.path, sizeof(map.path), "%s", path);
        out.push_back(map);
        total += size;
    }
    fclose(maps);
}

static bool ox_validateMetadataHeader(uint64_t address, uint64_t mappingEnd,
                                      size_t &dumpSize, uint32_t &version) {
    // The header is a sequence of offset/size fields. Read enough for every
    // current Unity metadata version, but accept only table ends inside the map.
    uint32_t words[128] = {};
    if (!vm_readv(address, words, sizeof(words))) return false;
    if (words[0] != IL2CPP_METADATA_MAGIC) return false;
    version = words[1];
    if (version < 20 || version > 40) return false;

    uint64_t available = mappingEnd - address;
    uint64_t maxEnd = 0;
    int validTables = 0;
    for (size_t i = 2; i + 1 < IM_ARRAYSIZE(words); i += 2) {
        uint64_t offset = words[i];
        uint64_t size = words[i + 1];
        if (offset < 8 || size == 0) continue;
        if (offset >= available || size > available - offset) continue;
        uint64_t tableEnd = offset + size;
        if (tableEnd > maxEnd) maxEnd = tableEnd;
        ++validTables;
    }
    // A real header has many tables and is larger than a minimal header.
    if (validTables < 8 || maxEnd < 0x1000 || maxEnd > 512ULL * 1024 * 1024) return false;
    dumpSize = (size_t)maxEnd;
    return true;
}

static bool ox_copyRemoteFile(uint64_t remote, size_t size, const char *path) {
    FILE *out = fopen(path, "wb");
    if (!out) return false;
    const size_t chunkSize = 1024 * 1024;
    std::vector<uint8_t> buffer(chunkSize);
    bool ok = true;
    for (size_t offset = 0; offset < size;) {
        size_t count = std::min(chunkSize, size - offset);
        if (!vm_readv(remote + offset, buffer.data(), count) ||
            fwrite(buffer.data(), 1, count, out) != count) {
            ok = false;
            break;
        }
        offset += count;
    }
    fclose(out);
    if (!ok) remove(path);
    return ok;
}

[[maybe_unused]] static void ox_dumpDecryptedMetadata() {
    oxlog::section("DECRYPTED METADATA DUMP");
    if (game_pid <= 0) {
        g_metadataDumpStatus = "Dump failed: game process unavailable";
        OXLOGE("[META] %s", g_metadataDumpStatus.c_str());
        return;
    }

    std::vector<OxMapRange> maps;
    ox_collectMetadataMaps(maps, 1024ULL * 1024 * 1024);
    OXLOGI("[META] scanning %zu native readable/anonymous mappings", maps.size());

    const size_t chunkSize = 1024 * 1024;
    std::vector<uint8_t> buffer(chunkSize + 4);
    uint64_t metadataAddress = 0;
    uint64_t metadataEnd = 0;
    size_t metadataSize = 0;
    uint32_t metadataVersion = 0;

    for (const OxMapRange &map : maps) {
        size_t carry = 0;
        for (uint64_t at = map.start; at < map.end && !metadataAddress;) {
            size_t want = (size_t)std::min<uint64_t>(chunkSize, map.end - at);
            if (!vm_readv(at, buffer.data() + carry, want)) { carry = 0; at += want; continue; }
            size_t total = carry + want;
            for (size_t i = 0; i + sizeof(uint32_t) <= total; i += sizeof(uint32_t)) {
                uint32_t magic = 0;
                memcpy(&magic, buffer.data() + i, sizeof(magic));
                if (magic != IL2CPP_METADATA_MAGIC) continue;
                uint64_t candidate = at - carry + i;
                if (ox_validateMetadataHeader(candidate, map.end, metadataSize, metadataVersion)) {
                    metadataAddress = candidate;
                    metadataEnd = map.end;
                    break;
                }
            }
            carry = std::min(sizeof(uint32_t) - 1, total);
            memmove(buffer.data(), buffer.data() + total - carry, carry);
            at += want;
        }
        if (metadataAddress) break;
    }

    if (!metadataAddress) {
        g_metadataDumpStatus = "Metadata header not found in native writable memory";
        OXLOGE("[META] %s", g_metadataDumpStatus.c_str());
        return;
    }

    char outputPath[256];
    time_t now = time(nullptr);
    struct tm tmv{};
    localtime_r(&now, &tmv);
    const char *dir = oxlog::activeDir();
    if (!dir || !dir[0]) dir = "/sdcard/Download/AvisTools";
    snprintf(outputPath, sizeof(outputPath),
             "%s/global-metadata_%04d%02d%02d_%02d%02d%02d.dat",
             dir,
             tmv.tm_year + 1900, tmv.tm_mon + 1, tmv.tm_mday,
             tmv.tm_hour, tmv.tm_min, tmv.tm_sec);

    OXLOGI("[META] header=0x%llx mappingEnd=0x%llx version=%u size=%zu",
           (unsigned long long)metadataAddress, (unsigned long long)metadataEnd,
           metadataVersion, metadataSize);
    if (!ox_copyRemoteFile(metadataAddress, metadataSize, outputPath)) {
        g_metadataDumpStatus = "Metadata copy failed: check root/storage permission";
        OXLOGE("[META] %s", g_metadataDumpStatus.c_str());
        return;
    }

    g_metadataDumpStatus = "Metadata saved: " + std::string(outputPath);
    OXLOGI("[META] COMPLETE: %s", g_metadataDumpStatus.c_str());
}

// Имя класса объекта: obj+0x0 -> klass -> name.
static void ox_objClassName(uint64_t obj, char *out, int outlen) {
    out[0] = 0;
    if (!ox_isPtr(obj)) return;
    ox_className(rpm<uint64_t>(obj), out, outlen);
}

// Найденный список игроков.
struct PlayerListView {
    uint64_t elems;   // адрес первого элемента (items + ARRAY_DATA)
    int      count;   // число элементов
    uint64_t container; // сам объект-контейнер (для лога)
    uint64_t statOff; // оффсет в static_fields
    bool     ok;
};

// Резолвит static_fields класса PlayerManager. Возвращает 0 при ошибке.
static uint64_t ox_getStatics(bool) {
    if (!il2cpp_base) return 0;
    if (!ox_isPtr(g_playerManagerKlass)) { ox_fastSeedTypeInfoFromHeader(); if (!ox_isPtr(g_playerManagerKlass)) return 0; }
    const uint64_t st = ox_readDirect<uint64_t>(g_playerManagerKlass + ox::CLASS_STATIC_FIELDS);
    return ox_isPtr(st) ? st : 0;
}

// Оценивает объект-контейнер как список: возвращает count и elems, 0 если не список.
static bool ox_evalContainer(uint64_t c, uint64_t &elems, int &count,
                             char *clsOut, int clsLen, int &homo, int &checked) {
    elems = 0; count = 0; homo = 0; checked = 0; if (clsOut) clsOut[0] = 0;
    if (!ox_isPtr(c)) return false;
    uint64_t items = ox_readDirect<uint64_t>(c + ox::LIST_ITEMS);
    if (!ox_isPtr(items)) return false;

    int listSize   = ox_readDirect<int>(c + ox::LIST_SIZE);            // List._size (int)
    uint64_t arrLen = ox_readDirect<uint64_t>(items + ox::ARRAY_COUNT); // Il2CppArray.max_length

    if (listSize > 0 && listSize <= ox::LIST_COUNT_MAX) count = listSize;
    else if (arrLen > 0 && arrLen <= (uint64_t)ox::LIST_COUNT_MAX) count = (int)arrLen;
    else return false;

    elems = items + ox::ARRAY_DATA;
    // A List<T> may temporarily contain a null first slot while players are
    // joining or leaving. Use the first populated slot as the class sample.
    uint64_t k0 = 0;
    for (int i = 0; i < count && i < 8; i++) {
        uint64_t e = ox_readDirect<uint64_t>(elems + i * 8);
        if (!ox_isPtr(e)) continue;
        const uint64_t klass = ox_readDirect<uint64_t>(e);
        if (!ox_isPtr(klass)) continue;
        if (!k0) k0 = klass;
        checked++;
        if (klass == k0) homo++;
    }
    if (checked == 0) return false;
    if (clsOut) {
        for (int i = 0; i < count && i < 8; i++) {
            uint64_t e = ox_readDirect<uint64_t>(elems + i * 8);
            if (ox_isPtr(e) && ox_readDirect<uint64_t>(e) == k0) {
                ox_objClassName(e, clsOut, clsLen);
                break;
            }
        }
    }
    return homo > 0;
}

// Сканирует static_fields и ищет список игроков (однородный массив объектов,
// имя класса содержит "Player"). full=true → логирует каждый кандидат.
static PlayerListView ox_scanForPlayerList(uint64_t statics, bool) {
    // PlayerManager.clientPlayerList (List<PlayerManager>) лежит в static_fields по фиксированному смещению.
    PlayerListView r; r.ok = false; r.elems = 0; r.count = 0; r.container = 0; r.statOff = ox::STATIC_PLAYER_LIST;
    const uint64_t c = ox_readDirect<uint64_t>(statics + ox::STATIC_PLAYER_LIST);
    int cnt, homo, checked; uint64_t elems; char cls[96];
    if (ox_evalContainer(c, elems, cnt, cls, sizeof(cls), homo, checked) && homo >= 1) {
        r.ok = true; r.elems = elems; r.count = cnt; r.container = c;
    }
    return r;
}

// Дампит объект-игрока целиком и ищет плавающие HP-кандидаты и позицию.
static void ox_dumpPlayer(int idx, uint64_t player) {
    char cls[96]; ox_objClassName(player, cls, sizeof(cls));
    OXLOGI("=== ИГРОК[%d] = 0x%llx  class='%s' ===", idx, (unsigned long long)player, cls);

    uint8_t buf[0x220];
    if (!vm_readv(player, buf, sizeof(buf))) { OXLOGW("  чтение объекта не удалось"); return; }
    oxlog::hexdump("player +0x00", player, buf, sizeof(buf));

    // Скан float-полей самого игрока: HP (1..200) и триплеты позиции.
    for (uint64_t o = 0x10; o + 4 <= sizeof(buf); o += 4) {
        float f; memcpy(&f, buf + o, 4);
        if (f >= 1.0f && f <= 200.0f && f == (float)(int)f)
            OXLOGT("  [HP?] player+0x%llx = %.1f", (unsigned long long)o, f);
    }
    for (uint64_t o = 0x10; o + 12 <= sizeof(buf); o += 4) {
        float x, y, z;
        memcpy(&x, buf + o, 4); memcpy(&y, buf + o + 4, 4); memcpy(&z, buf + o + 8, 4);
        bool ok = fabsf(x) > 0.01f && fabsf(x) < 100000.f &&
                  fabsf(y) > 0.01f && fabsf(y) < 100000.f &&
                  fabsf(z) > 0.01f && fabsf(z) < 100000.f;
        if (ok)
            OXLOGT("  [POS?] player+0x%llx = (%.2f, %.2f, %.2f)", (unsigned long long)o, x, y, z);
    }

    // Под-объекты игрока (NetworkIdentity, MouseLook, PlayerMap, vitals, transform...)
    // — HP и п���зиция обычно ЗДЕСЬ, а не в теле игрока. Рекурсивн�� сканируем каждый.
    for (uint64_t o = 0x8; o + 8 <= 0x120; o += 8) {
        uint64_t p; memcpy(&p, buf + o, 8);
        if (!ox_isPtr(p)) continue;
        char sub[96]; ox_objClassName(p, sub, sizeof(sub));
        OXLOGT("  [PTR] player+0x%llx -> 0x%llx class='%s'",
               (unsigned long long)o, (unsigned long long)p, sub);

        uint8_t sb[0x140];
        if (!vm_readv(p, sb, sizeof(sb))) continue;
        // HP-кандидаты в под-объекте.
        for (uint64_t so = 0x8; so + 4 <= sizeof(sb); so += 4) {
            float f; memcpy(&f, sb + so, 4);
            if (f >= 1.0f && f <= 200.0f && f == (float)(int)f)
                OXLOGT("      [HP?] %s+0x%llx = %.1f", sub[0]?sub:"?",
                       (unsigned long long)so, f);
        }
        // Триплеты позиции в под-объекте.
        for (uint64_t so = 0x8; so + 12 <= sizeof(sb); so += 4) {
            float x, y, z;
            memcpy(&x, sb + so, 4); memcpy(&y, sb + so + 4, 4); memcpy(&z, sb + so + 8, 4);
            bool ok = fabsf(x) > 0.5f && fabsf(x) < 100000.f &&
                      fabsf(y) > 0.5f && fabsf(y) < 100000.f &&
                      fabsf(z) > 0.5f && fabsf(z) < 100000.f;
            if (ok)
                OXLOGT("      [POS?] %s+0x%llx = (%.2f, %.2f, %.2f)", sub[0]?sub:"?",
                       (unsigned long long)so, x, y, z);
        }
    }
}

// HP ����грока: player+0xC8 -> PlayerVitals; vitals+0x88 -> float health.
static float ox_readHP(uint64_t player, bool full) {
    uint64_t vitals = 0;
    if (!vm_readv(player + ox::PM_VITALS,&vitals,sizeof(vitals))) return -1.f;
    if (full) oxlog::ptrstep("player + VITALS(0xC8)", player + ox::PM_VITALS, vitals);
    if (!ox_isPtr(vitals)) return -1.f;
    float hp = -1.f;
    if (!vm_readv(vitals + ox::VITALS_HEALTH,&hp,sizeof(hp)) || !isfinite(hp)) return -1.f;
    if (full) OXLOGT("  vitals + 0x88 -> HP = %.3f", hp);
    return hp;
}

static std::string ox_readManagedString(uint64_t stringObject) {
    if (!ox_isPtr(stringObject)) return "";
    String value = rpm<String>(stringObject);
    if (value.length <= 0 || value.length > 128) return "";
    return value.Get();
}

// FIX bug #2: читает managed string как СЫРЫЕ UTF-16 байты (hex-строкой).
// String::Get() выкидывает всё >= 0x80 -> кириллические/эмодзи имена команд
// схлопывались в "" ИЛИ в неразличимые огрызки, из-за чего сравнение
// сокомандников молча ломалось. Здесь сравниваем по полному содержимому.
// Возвращает "" если строка пустая/невалидная.
static std::string ox_readStringKey(uint64_t stringObject) {
    if (!ox_isPtr(stringObject)) return "";
    int len = rpm<int>(stringObject + 0x10); // _stringLength
    if (len <= 0 || len > 128) return "";
    // читаем len*2 байт UTF-16 начиная с _firstChar (0x14)
    std::vector<uint8_t> raw((size_t)len * 2);
    if (!vm_readv(stringObject + 0x14, raw.data(), raw.size())) return "";
    static const char* HEX = "0123456789abcdef";
    std::string out; out.reserve(raw.size() * 2);
    for (uint8_t b : raw) { out.push_back(HEX[b >> 4]); out.push_back(HEX[b & 0xf]); }
    return out;
}

// FIX bug #2: строит СТАБИЛЬНЫЙ ключ команды игрока для сравнения сокомандников.
// Приоритет источников:
//   1) teamName (SyncVar @0x280) — реплицируется на всех клиентов для всех игроков.
//   2) team(WNn @0x120) -> pf(@0x90) -> mYs(teamId string @0x10) — corroborating.
// Возвращает "" если игрок ВНЕ команды (тогда его нельзя считать сокомандником).
static std::string ox_teamKey(uint64_t player) {
    if (!ox_isPtr(player)) return "";
    // 1) teamName (raw UTF-16). Ключ с префиксом источника, чтобы не путать.
    std::string tn = ox_readStringKey(rpm<uint64_t>(player + ox::PM_TEAM_NAME));
    if (!tn.empty()) return "N:" + tn;
    // 2) team -> pf -> mYs (teamId).
    // ВАЖНО: pf-объект РАЗДЕЛЯЕТСЯ между всеми членами команды (WNn per-player,
    // pf shared). Каждая PM имеет свою WNn, но их WNn.team_data указывают на
    // ОДИН И ТОТ ЖЕ pf. Поэтому pf-pointer — стабильный team-identity.
    uint64_t wnn = rpm<uint64_t>(player + ox::PM_TEAM);
    if (ox_isPtr(wnn)) {
        uint64_t pf = rpm<uint64_t>(wnn + ox::WNN_TEAM_DATA);
        if (ox_isPtr(pf)) {
            std::string id = ox_readStringKey(rpm<uint64_t>(pf + ox::PF_TEAM_ID_STR));
            if (!id.empty()) return "I:" + id;
            // 3) Fallback: сам pf-указатель как team-id. Все тимейты имеют
            // одинаковый pf pointer, разные — разные pf (или null для соло).
            char buf[32];
            snprintf(buf, sizeof(buf), "P:%llx", (unsigned long long)pf);
            return std::string(buf);
        }
    }
    return "";
}

// ── Прямая проверка сокомандника по составу команды ────────────────────────
// Строковые team-поля в этом билде часто пусты у обоих игроков, из-за чего
// сравнение ключей молча ничего не скрывало. Здесь идём по РЕАЛЬНОМУ составу:
//   local.PM + PM_TEAM(0x120) -> WNn
//   WNn + 0x90                -> pf (общий объект команды)
//   pf  + 0x20                -> List<TeamMember>
//   TeamMember + 0x10         -> string id  == PM.userID цели (0x278)
// Возвращает true если target числится в команде локального игрока.
// Обходит Dictionary<string,V> и отдаёт КЛЮЧИ (managed-строки) в колбэк.
// Нужен для nWc.TeammateStates, где ключ — userID сокомандника.
template <typename CB>
static int ox_forEachDictStringKeys(uint64_t dictObj, CB&& cb) {
    if (!ox_isPtr(dictObj)) return -1;
    uint64_t entries = rpm<uint64_t>(dictObj + ox::DICT_ENTRIES);
    if (!ox_isPtr(entries)) return -1;
    int count = ox_dictCount(dictObj);
    if (count <= 0 || count > 64) return -1;          // команда не бывает большой
    uint64_t arrLen = rpm<uint64_t>(entries + ox::ARRAY_COUNT);
    if (arrLen == 0 || arrLen > 256) return -1;
    if ((uint64_t)count > arrLen) count = (int)arrLen;

    uint64_t dataBase = entries + ox::ARRAY_DATA;
    size_t bytes = (size_t)count * (size_t)ox::DICT_SENTRY_STRIDE;
    std::vector<uint8_t> buf(bytes);
    if (!vm_readv(dataBase, buf.data(), bytes)) return -1;

    int seen = 0;
    for (int i = 0; i < count; ++i) {
        const uint8_t* e = buf.data() + (size_t)i * ox::DICT_SENTRY_STRIDE;
        int32_t hashCode; memcpy(&hashCode, e + ox::DICT_SENTRY_HASHCODE, 4);
        if (hashCode < 0) continue;
        uint64_t keyPtr; memcpy(&keyPtr, e + ox::DICT_SENTRY_KEY, 8);
        if (!ox_isPtr(keyPtr)) continue;
        cb(keyPtr);
        ++seen;
    }
    return seen;
}

// Разовая диагностика цепочки команды (раз в 3 сек), чтобы видеть где рвётся:
// PM.team(0x120) -> nWc.team(0x90) -> Cc.dCI(0x20) -> List<TeamMember>.
[[maybe_unused]] static void ox_logTeamChain(uint64_t localPm, uint64_t targetPm) {
    static double s_last = 0.0;
    double now = (double)ImGui::GetTime();
    if (now - s_last < 3.0) return;
    s_last = now;

    uint64_t lw  = rpm<uint64_t>(localPm  + ox::PM_TEAM);
    uint64_t tw  = rpm<uint64_t>(targetPm + ox::PM_TEAM);
    uint64_t lpf = ox_isPtr(lw) ? rpm<uint64_t>(lw + ox::WNN_TEAM_DATA) : 0;
    uint64_t tpf = ox_isPtr(tw) ? rpm<uint64_t>(tw + ox::WNN_TEAM_DATA) : 0;
    int size = -1;
    if (ox_isPtr(lpf)) {
        uint64_t list = rpm<uint64_t>(lpf + ox::PF_TEAM_MEMBERS);
        if (ox_isPtr(list)) size = rpm<int>(list + ox::LIST_SIZE);
    }
    std::string tid = ox_readStringKey(rpm<uint64_t>(targetPm + ox::PM_USER_ID));
    // Состояние словаря сокомандников — теперь основной источник.
    uint64_t states = ox_isPtr(lw) ? rpm<uint64_t>(lw + ox::NWC_TEAMMATE_STATES) : 0;
    int stCount = ox_isPtr(states) ? ox_dictCount(states) : -1;
    int online  = ox_isPtr(lw) ? rpm<int>(lw + ox::NWC_ONLINE) : -1;

    OXLOGI("[team] lw=0x%llx lpf=0x%llx roster=%d | states=0x%llx cnt=%d online=%d | tid='%s'",
           (unsigned long long)lw, (unsigned long long)lpf, size,
           (unsigned long long)states, stCount, online, tid.c_str());

    // Печатаем сами ключи словаря — по ним видно, совпадает ли формат с
    // PM.userID цели (оба должны быть одинаковыми hex-строками).
    if (ox_isPtr(states) && stCount > 0) {
        int shown = 0;
        ox_forEachDictStringKeys(states, [&](uint64_t k) {
            if (shown >= 3) return;
            std::string ks = ox_readStringKey(k);
            OXLOGI("[team]   mate[%d]='%s'", shown, ks.c_str());
            shown++;
        });
    }
}

static bool ox_isTeammate(uint64_t localPm, uint64_t targetPm) {
    if (!ox_isPtr(localPm) || !ox_isPtr(targetPm) || localPm == targetPm) return false;
#ifdef OX_ENABLE_LOG
    if (espHideTeammates || aimIgnoreTeammates) ox_logTeamChain(localPm, targetPm);
#endif

    // ── ПУТЬ 0 (v21, самый надёжный): teamName SyncVar (PM+0x280). ───────────
    // Реплицируется Mirror'ом на ВСЕ клиенты для КАЖДОГО игрока (доказано
    // наличием _Mirror_SyncVarHookDelegate_teamName). Непустая строка, равная
    // нашей — это сокомандник. Не зависит от серверных team-компонентов, которые
    // в этом билде пусты на неведущем клиенте.
    {
        std::string myTeam = ox_readStringKey(rpm<uint64_t>(localPm  + ox::PM_TEAM_NAME));
        std::string tgTeam = ox_readStringKey(rpm<uint64_t>(targetPm + ox::PM_TEAM_NAME));
        if (!myTeam.empty() && !tgTeam.empty() && myTeam == tgTeam) return true;
    }

    // ── ПУТЬ 0b (v21): готовый флаг игры nicklabel.isTeammate (PM+0x130 → +0x91).
    // Игра сама вычисляет «свой» для nick-label; читаем её вердикт напрямую.
    {
        uint64_t wd = rpm<uint64_t>(targetPm + ox::PM_NICKLABEL);
        if (ox_isPtr(wd)) {
            uint8_t isMate = rpm<uint8_t>(wd + ox::NICKLABEL_IS_TEAMMATE);
            if (isMate == 1) return true;
        }
    }

    // ── ГЛАВНЫЙ ПУТЬ (legacy): nWc.TeammateStates ──────────────────────────
    // В этом билде nWc.team(0x90) приходит нулём даже когда игрок в команде,
    // поэтому старая цепочка через pf молча ничего не скрывала. А словарь
    // состояний заполнен, и его ключи — это userID сокомандников.
    {
        uint64_t lw = rpm<uint64_t>(localPm + ox::PM_TEAM);
        if (ox_isPtr(lw)) {
            uint64_t states = rpm<uint64_t>(lw + ox::NWC_TEAMMATE_STATES);
            if (ox_isPtr(states)) {
                std::string tid = ox_readStringKey(rpm<uint64_t>(targetPm + ox::PM_USER_ID));
                if (!tid.empty()) {
                    bool found = false;
                    ox_forEachDictStringKeys(states, [&](uint64_t keyStr) {
                        if (found) return;
                        std::string k = ox_readStringKey(keyStr);
                        if (!k.empty() && k == tid) found = true;
                    });
                    if (found) return true;
                }
            }
        }
    }

    // Быстрый путь: одинаковый pf-объект = одна команда.
    uint64_t lw = rpm<uint64_t>(localPm  + ox::PM_TEAM);
    uint64_t tw = rpm<uint64_t>(targetPm + ox::PM_TEAM);
    uint64_t lpf = ox_isPtr(lw) ? rpm<uint64_t>(lw + ox::WNN_TEAM_DATA) : 0;
    uint64_t tpf = ox_isPtr(tw) ? rpm<uint64_t>(tw + ox::WNN_TEAM_DATA) : 0;
    if (ox_isPtr(lpf) && lpf == tpf) return true;

    // Резерв: у nWc есть ВТОРОЙ путь к данным команды — поле team(0x90) типа Cc
    // (тот же объект, что pf). Если WNN_TEAM_DATA указывает не туда после
    // обновления, сверяем по нему; совпадение указателей = одна команда.
    if (!ox_isPtr(lpf) || lpf != tpf) {
        uint64_t lcc = ox_isPtr(lw) ? rpm<uint64_t>(lw + ox::NWC_TEAM_DATA) : 0;
        uint64_t tcc = ox_isPtr(tw) ? rpm<uint64_t>(tw + ox::NWC_TEAM_DATA) : 0;
        if (ox_isPtr(lcc) && lcc == tcc) return true;
        // И берём его как источник ростера, если основной пуст.
        if (!ox_isPtr(lpf) && ox_isPtr(lcc)) lpf = lcc;
    }

    if (!ox_isPtr(lpf)) return false;   // мы не в команде — скрывать некого

    // Медленный, но железный путь: сверяем userID по списку участников.
    // Берём ID ЦЕЛИ и ищем его в НАШЕМ ростере — так проверка не зависит от
    // того, заполнены ли строковые поля у нас самих.
    std::string targetId = ox_readStringKey(rpm<uint64_t>(targetPm + ox::PM_USER_ID));
    if (targetId.empty()) return false;

    uint64_t list = rpm<uint64_t>(lpf + ox::PF_TEAM_MEMBERS);
    if (!ox_isPtr(list)) return false;
    uint64_t items = rpm<uint64_t>(list + ox::LIST_ITEMS);
    int      size  = rpm<int>(list + ox::LIST_SIZE);
    if (!ox_isPtr(items) || size <= 0 || size > 32) return false;

    uint64_t elems = items + ox::ARRAY_DATA;
    for (int i = 0; i < size; ++i) {
        uint64_t tm = rpm<uint64_t>(elems + i * 8);
        if (!ox_isPtr(tm)) continue;
        std::string id = ox_readStringKey(rpm<uint64_t>(tm + ox::TEAMMEMBER_ID));
        if (!id.empty() && id == targetId) return true;
    }
    return false;
}

// ============================================================================
//  Расширенные данные игрока: ник, оружие, броня, флаги состояния.
//  Всё только на ЧТЕНИЕ, цепочки короткие (2-5 vm_readv на поле), берутся
//  раз в тяжёлый скан (не каждый кадр) — на watchdog не влияет.
// ============================================================================

// ── Ник, клан, HP и урон: begin ────────────────────────────────────────────

// UTF-16LE -> UTF-8 с суррогатными парами. String::Get() выбрасывает всё >= 0x80, из-за чего русские ники
// пропадали целиком. Управляющие и невидимые символы отбрасываются, края обрезаются.
static std::string ox_readStringUtf8(uint64_t stringObject, int maxChars = 64) {
    if (!ox_isPtr(stringObject)) return "";
    const int len = rpm<int>(stringObject + 0x10);
    if (len <= 0 || len > 1024) return "";
    const int n = len < maxChars ? len : maxChars;
    char16_t buf[256];
    if (n > 256 || !vm_readv((unsigned long)(stringObject + 0x14), buf, (size_t)n * 2)) return "";
    std::string out;
    out.reserve((size_t)n * 2);
    for (int i = 0; i < n; ++i) {
        uint32_t c = buf[i];
        if (c >= 0xD800 && c <= 0xDBFF) {
            if (i + 1 < n && buf[i + 1] >= 0xDC00 && buf[i + 1] <= 0xDFFF) { c = 0x10000 + ((c - 0xD800) << 10) + (buf[i + 1] - 0xDC00); ++i; }
            else continue;
        } else if (c >= 0xDC00 && c <= 0xDFFF) continue;
        if (c < 0x20 || c == 0x7F) continue;
        if ((c >= 0x200B && c <= 0x200F) || (c >= 0x2028 && c <= 0x202E) || (c >= 0x2060 && c <= 0x2064) || c == 0xFEFF) continue;
        if (c == 0xA0) c = ' ';
        if (c < 0x80) out.push_back((char)c);
        else if (c < 0x800) { out.push_back((char)(0xC0 | (c >> 6))); out.push_back((char)(0x80 | (c & 0x3F))); }
        else if (c < 0x10000) { out.push_back((char)(0xE0 | (c >> 12))); out.push_back((char)(0x80 | ((c >> 6) & 0x3F))); out.push_back((char)(0x80 | (c & 0x3F))); }
        else { out.push_back((char)(0xF0 | (c >> 18))); out.push_back((char)(0x80 | ((c >> 12) & 0x3F))); out.push_back((char)(0x80 | ((c >> 6) & 0x3F))); out.push_back((char)(0x80 | (c & 0x3F))); }
    }
    size_t a = 0, b = out.size();
    while (a < b && out[a] == ' ') ++a;
    while (b > a && out[b - 1] == ' ') --b;
    return out.substr(a, b - a);
}

// Заготовки текста из префаба и пустышки — это не ник: «Nickname», «Nickname 2», «Player», «Никнейм», хэш-ID.
static bool ox_nickValid(const std::string &s) {
    if (s.empty()) return false;
    std::string l;
    for (char c : s) l.push_back((char)tolower((unsigned char)c));
    static const char *const bad[] = { "nickname", "nick", "name", "player", "text", "new text", "unnamed", "unknown", "loading",
                                       "none", "null", "user", "username", "player name", "playername", "enter nickname",
                                       "your nickname", "text (tmp)", "label",
                                       "Никнейм", "Ник", "Имя", "Игрок", "никнейм", "ник", "имя", "игрок", "Ваш ник", "Введите ник" };
    for (const char *b : bad) if (l == b || s == b) return false;
    if (l.compare(0, 8, "nickname") == 0) {
        bool rest = true;
        for (size_t i = 8; i < l.size(); ++i) {
            const unsigned char c = (unsigned char)l[i];
            if (!(isdigit(c) || c == ' ' || c == '(' || c == ')' || c == '_' || c == '-')) { rest = false; break; }
        }
        if (rest) return false;
    }
    if (s.size() >= 12) {                                    // длинная hex-строка — это идентификатор, а не ник
        bool hex = true;
        for (unsigned char c : s) if (!isxdigit(c) && c != '-') { hex = false; break; }
        if (hex) return false;
    }
    for (unsigned char c : s) if (c >= 0x80 || isalnum(c)) return true;
    return false;
}

// Подпись над головой: PM -> nicklabel(dM) -> nickname(UI.Text) -> m_Text. У чужих игроков часто остаётся
// заготовка «Nickname», поэтому это последний по приоритету источник.
static std::string ox_readNickname(uint64_t pm) {
    if (!ox_isPtr(pm)) return "";
    const uint64_t nl = rpm<uint64_t>(pm + ox::PM_NICKLABEL);
    if (!ox_isPtr(nl)) return "";
    const uint64_t txt = rpm<uint64_t>(nl + ox::NICKLABEL_NICKNAME);
    if (!ox_isPtr(txt)) return "";
    return ox_readStringUtf8(rpm<uint64_t>(txt + ox::UITEXT_M_TEXT), 48);
}

static uint32_t ox_netIdOf(uint64_t pm) {
    const uint64_t ni = rpm<uint64_t>(pm + ox::NB_NET_IDENTITY);
    return ox_isPtr(ni) ? rpm<uint32_t>(ni + ox::NI_NET_ID) : 0u;
}

// ── Контроллер игры: синглтон GameControllerBase ──────────────────────────────
// klass находит фоновый поток (по имени, тем же резолвером, что PlayerManager); здесь — чтение статики и полей.
// Через экземпляр достижимы реестр игроков матча (RBK) и менеджер пуль (Qe).
static std::atomic<uint64_t> g_gcKlass{0};
static uint64_t g_gcInst = 0, g_gcRbk = 0, g_gcQe = 0;
static double   g_gcNext = 0.0;
static int      g_gcStage = 0;               // 0 нет klass, 1 нет static_fields, 2 нет экземпляра, 4 ок

// Объект похож на RBK (список игроков): числа игроков в разумных пределах, массив PlayerModel[] читается.
static bool ox_looksLikeRbk(uint64_t rbk) {
    if (!ox_isPtr(rbk)) return false;
    uint8_t b[0x30];
    if (!vm_readv((unsigned long)(rbk + 0x88), b, sizeof(b))) return false;       // 0x88..0xB8
    int maxP, cnt;
    uint64_t models;
    memcpy(&maxP, b + 0x10, 4);                                                    // maxPlayers @0x98
    memcpy(&cnt, b + 0x14, 4);                                                     // playersCount @0x9C
    memcpy(&models, b + 0x28, 8);                                                  // playerModels @0xB0
    if (maxP < 1 || maxP > 4000 || cnt < 0 || cnt > 4000 || !ox_isPtr(models)) return false;
    return rpm<uint64_t>(models + ox::ARRAY_COUNT) <= 8192;
}

static void ox_gcTick(double now) {
    if (now < g_gcNext) return;
    g_gcNext = now + 1.0;
    uint64_t k = g_gcKlass.load(std::memory_order_relaxed);
    if (!k) { k = ox_klassFromSlot(OX_TI_GAMECONTROLLER, "GameControllerBase"); if (k) g_gcKlass.store(k); }
    if (!k) { g_gcStage = 0; return; }
    const uint64_t st = rpm<uint64_t>(k + ox::CLASS_STATIC_FIELDS);
    if (!ox_isPtr(st)) { g_gcStage = 1; return; }
    auto okInst = [&](uint64_t p) { return ox_isPtr(p) && ox_looksLikeRbk(rpm<uint64_t>(p + ox::GC_PLAYERS_LIST)); };
    uint64_t inst = rpm<uint64_t>(st + ox::GC_STATIC_INSTANCE);
    if (!okInst(inst)) {                                                           // смещение статики могло съехать — ищем рядом
        inst = 0;
        for (uint64_t off = 0; off <= 0x80 && !inst; off += 8) { const uint64_t p = rpm<uint64_t>(st + off); if (okInst(p)) inst = p; }
    }
    if (!inst) { g_gcStage = 2; return; }
    const uint64_t rbk = rpm<uint64_t>(inst + ox::GC_PLAYERS_LIST);
    uint64_t qe = rpm<uint64_t>(inst + ox::GC_BALLISTIC_SHOTS);
    if (!ox_isPtr(qe) || !ox_isPtr(rpm<uint64_t>(qe + ox::QE_BULLETS))) qe = 0;
    if (inst != g_gcInst || rbk != g_gcRbk || qe != g_gcQe)
        OXLOGI("[gc] контроллер игры: экземпляр=0x%llx список игроков=0x%llx менеджер пуль=0x%llx", (unsigned long long)inst,
               (unsigned long long)rbk, (unsigned long long)qe);
    g_gcStage = 4;
    g_gcInst = inst; g_gcRbk = rbk; g_gcQe = qe;
}

// ── Реестр игроков матча (настоящие ники) ─────────────────────────────────────
struct OxRosterEntry { std::string nick, clan; int level = 0; };
static uint64_t g_rbk = 0;
static std::unordered_map<std::string, OxRosterEntry> g_roster;
static double g_rosterNextResolve = 0.0, g_rosterNextRead = 0.0, g_rosterNextLog = 0.0;
static int g_rosterStage = 0;                 // до какого звена цепочки дошли (для лога)
static int g_rosterFails = 0;                 // подряд неудачных перечитываний списка
static const char *g_rosterSrc = "";
std::string g_selfNick, g_selfClan;           // ник и клан локального игрока: показываются в превью меню

static void ox_rosterAdd(std::unordered_map<std::string, OxRosterEntry> &out, uint64_t idP, uint64_t nickP, uint64_t clanP, int level) {
    const std::string id = ox_readStringUtf8(idP, 64);
    if (id.empty() || out.count(id)) return;
    OxRosterEntry en;
    en.nick = ox_readStringUtf8(nickP, 48);
    if (ox_isPtr(clanP)) en.clan = ox_readStringUtf8(clanP, 16);
    en.level = level;
    out[id] = std::move(en);
}

// PlayerModel[]: массив структур {id, nick, clanId, clanTag, premium, level, prime}, шаг 0x30.
static int ox_rosterReadArray(uint64_t rbk, std::unordered_map<std::string, OxRosterEntry> *out) {
    const uint64_t arr = rpm<uint64_t>(rbk + ox::RBK_PLAYER_MODELS);
    if (!ox_isPtr(arr)) return 0;
    const uint64_t len = rpm<uint64_t>(arr + ox::ARRAY_COUNT);
    if (len == 0 || len > 4096) return 0;
    const int n = (int)(len < 256 ? len : 256);
    std::vector<uint8_t> buf((size_t)n * ox::PLAYERMODEL_STRIDE);
    if (!vm_readv((unsigned long)(arr + ox::ARRAY_DATA), buf.data(), buf.size())) return 0;
    int valid = 0;
    for (int i = 0; i < n; ++i) {
        const uint8_t *e = buf.data() + (size_t)i * ox::PLAYERMODEL_STRIDE;
        uint64_t idP, nickP, clanP;
        int level;
        memcpy(&idP, e + ox::PLAYERMODEL_ID, 8);
        memcpy(&nickP, e + ox::PLAYERMODEL_NICK, 8);
        memcpy(&clanP, e + ox::PLAYERMODEL_CLAN_TAG, 8);
        memcpy(&level, e + ox::PLAYERMODEL_LEVEL, 4);
        if (!ox_isPtr(idP) || !ox_isPtr(nickP)) continue;
        ++valid;
        if (out) ox_rosterAdd(*out, idP, nickP, clanP, level);
    }
    return valid;
}

// Dictionary<string, PlayerModel>: размер записи и смещение ключа определяются по самим данным (ключ == PlayerModel.id).
struct OxDictLayout { int stride = 0, keyOff = 0; };
static OxDictLayout g_dictLayout;

static int ox_rosterReadDict(uint64_t rbk, std::unordered_map<std::string, OxRosterEntry> *out) {
    const uint64_t dict = rpm<uint64_t>(rbk + ox::RBK_PLAYER_DICT);
    if (!ox_isPtr(dict)) return 0;
    const uint64_t entries = rpm<uint64_t>(dict + ox::DICT_ENTRIES);
    int count = ox_dictCount(dict);
    if (!ox_isPtr(entries) || count <= 0 || count > 4096) return 0;
    const uint64_t alen = rpm<uint64_t>(entries + ox::ARRAY_COUNT);
    if (alen == 0 || alen > 16384) return 0;
    if ((uint64_t)count > alen) count = (int)alen;

    auto matches = [&](const uint8_t *e, const OxDictLayout &L) {                  // 1 — запись подходит, 0 — нет, -1 — свободная
        int32_t hash;
        memcpy(&hash, e, 4);
        if (hash < 0) return -1;
        uint64_t keyP, idP, nickP;
        memcpy(&keyP, e + L.keyOff, 8); memcpy(&idP, e + L.keyOff + 8, 8); memcpy(&nickP, e + L.keyOff + 16, 8);
        if (!ox_isPtr(keyP) || !ox_isPtr(idP) || !ox_isPtr(nickP)) return 0;
        const std::string k = ox_readStringUtf8(keyP, 64);
        return (!k.empty() && k == ox_readStringUtf8(idP, 64)) ? 1 : 0;
    };
    if (g_dictLayout.stride == 0) {
        static const OxDictLayout cands[] = { {0x40, 8}, {0x48, 0x10}, {0x50, 0x10}, {0x38, 8}, {0x58, 0x10}, {0x48, 8}, {0x30, 8} };
        const int probe = count < 8 ? count : 8;
        int bestScore = 0;
        OxDictLayout best;
        for (const OxDictLayout &L : cands) {
            std::vector<uint8_t> buf((size_t)probe * L.stride);
            if (!vm_readv((unsigned long)(entries + ox::ARRAY_DATA), buf.data(), buf.size())) continue;
            int score = 0;
            for (int i = 0; i < probe; ++i) if (matches(buf.data() + (size_t)i * L.stride, L) == 1) ++score;
            if (score > bestScore) { bestScore = score; best = L; }
        }
        if (bestScore < 1) return 0;
        g_dictLayout = best;
        OXLOGI("[nick] словарь игроков: шаг записи 0x%x, ключ +0x%x (подошло %d из %d проверенных)", best.stride, best.keyOff, bestScore, probe);
    }
    const OxDictLayout L = g_dictLayout;
    int valid = 0;
    for (int base = 0; base < count; base += 64) {
        const int n = (count - base) < 64 ? (count - base) : 64;
        std::vector<uint8_t> buf((size_t)n * L.stride);
        if (!vm_readv((unsigned long)(entries + ox::ARRAY_DATA + (uint64_t)base * L.stride), buf.data(), buf.size())) { g_dictLayout = OxDictLayout(); break; }
        for (int i = 0; i < n; ++i) {
            const uint8_t *e = buf.data() + (size_t)i * L.stride;
            if (matches(e, L) != 1) continue;
            ++valid;
            if (!out) continue;
            uint64_t idP, nickP, clanP;
            int level;
            memcpy(&idP, e + L.keyOff + ox::PLAYERMODEL_ID, 8);
            memcpy(&nickP, e + L.keyOff + ox::PLAYERMODEL_NICK, 8);
            memcpy(&clanP, e + L.keyOff + ox::PLAYERMODEL_CLAN_TAG, 8);
            memcpy(&level, e + L.keyOff + ox::PLAYERMODEL_LEVEL, 4);
            ox_rosterAdd(*out, idP, nickP, clanP, level);
        }
    }
    return valid;
}

// Читает список игроков: и массив, и словарь (в одном из них данные точно есть); возвращает число валидных записей.
static int ox_rosterRead(uint64_t rbk, std::unordered_map<std::string, OxRosterEntry> *out) {
    const int a = ox_rosterReadArray(rbk, out);
    const int d = ox_rosterReadDict(rbk, out);
    return a > d ? a : d;
}

// Где искать список игроков: 1) синглтон контроллера игры; 2) PM.team (RBY) -> rUk (iZ) -> playersList;
// 3) любой указатель в RBY, у которого по смещению playersList лежит правдоподобный RBK.
static bool ox_rosterResolve(uint64_t pm) {
    if (g_gcRbk && ox_looksLikeRbk(g_gcRbk) && ox_rosterRead(g_gcRbk, nullptr) >= 1) {
        g_rbk = g_gcRbk; g_rosterSrc = "контроллер игры"; g_rosterStage = 6;
        return true;
    }
    const uint64_t rby = rpm<uint64_t>(pm + ox::PM_TEAM);
    if (!ox_isPtr(rby)) { g_rosterStage = 1; return false; }
    uint64_t iz = rpm<uint64_t>(rby + ox::RBY_TEAM_MANAGER);
    auto rbkOf = [&](uint64_t z) { return ox_isPtr(z) ? rpm<uint64_t>(z + ox::IZ_PLAYERS_LIST) : 0; };
    uint64_t rbk = rbkOf(iz);
    if (!ox_looksLikeRbk(rbk)) {
        rbk = 0;
        uint64_t blk[0x40 / 8 + 8];
        if (vm_readv((unsigned long)(rby + 0x68), blk, sizeof(blk)))
            for (size_t i = 0; i < sizeof(blk) / 8 && !rbk; ++i) { const uint64_t c = rbkOf(blk[i]); if (ox_looksLikeRbk(c)) rbk = c; }
    }
    if (!rbk) { g_rosterStage = ox_isPtr(iz) ? 3 : 2; return false; }
    if (ox_rosterRead(rbk, nullptr) < 1) { g_rosterStage = 5; return false; }
    g_rbk = rbk; g_rosterSrc = "PM.team"; g_rosterStage = 6;
    return true;
}

// Раз в ~1.5 с перечитывает список; пока реестр не найден — раз в 2 с пробует найти.
static void ox_rosterTick(uint64_t anyPm, double now) {
    ox_gcTick(now);
    if (!g_rbk) {
        if (now < g_rosterNextResolve) return;
        g_rosterNextResolve = now + 2.0;
        bool ok = false;
        if (ox_isPtr(g_localPlayer)) ok = ox_rosterResolve(g_localPlayer);
        if (!ok && ox_isPtr(anyPm)) ok = ox_rosterResolve(anyPm);
        if (!ok) {
            if (now >= g_rosterNextLog) {
                g_rosterNextLog = now + 10.0;
                OXLOGW("[nick] список игроков матча не найден (этап %d: 1 PM.team, 2 RBY.rUk, 3 iZ.playersList, 5 пустой список; контроллер игры: этап %d)",
                       g_rosterStage, g_gcStage);
            }
            return;
        }
        OXLOGI("[nick] список игроков матча найден (%s): RBK=0x%llx", g_rosterSrc, (unsigned long long)g_rbk);
        g_rosterNextRead = 0.0;
    }
    if (now < g_rosterNextRead) return;
    g_rosterNextRead = now + 1.5;
    std::unordered_map<std::string, OxRosterEntry> fresh;
    if (ox_rosterRead(g_rbk, &fresh) < 1) {            // единичный сбой переживаем; три подряд — матч сменился, ищем заново
        if (++g_rosterFails >= 3) { g_rbk = 0; g_roster.clear(); g_rosterFails = 0; g_dictLayout = OxDictLayout(); }
        return;
    }
    g_rosterFails = 0;
    g_roster.swap(fresh);
    if (ox_isPtr(g_localPlayer)) {
        const std::string lid = ox_readStringUtf8(rpm<uint64_t>(g_localPlayer + ox::PM_USER_ID), 64);
        auto it = g_roster.find(lid);
        if (it != g_roster.end()) { g_selfNick = it->second.nick; g_selfClan = it->second.clan; }
    }
    if (now >= g_rosterNextLog) {
        g_rosterNextLog = now + 30.0;
        OXLOGI("[nick] в списке игроков записей: %d, ваш ник: '%s'", (int)g_roster.size(), g_selfNick.c_str());
    }
}

// Запись игрока в списке по его userID; nullptr, если игрока там пока нет.
static const OxRosterEntry *ox_rosterEntry(uint64_t pm, double now) {
    ox_rosterTick(pm, now);
    if (!g_rbk) return nullptr;
    const std::string id = ox_readStringUtf8(rpm<uint64_t>(pm + ox::PM_USER_ID), 64);
    if (id.empty()) return nullptr;
    auto it = g_roster.find(id);
    if (it == g_roster.end()) {                       // новый игрок: список перечитаем скорее
        if (g_rosterNextRead > now + 0.3) g_rosterNextRead = now + 0.3;
        return nullptr;
    }
    return &it->second;
}

// Ник: список игроков матча -> Ryk.DisplayName -> подпись над головой. Заготовки («Nickname») отбрасываются.
static std::string ox_playerNick(uint64_t pm, bool *fromRoster = nullptr) {
    if (fromRoster) *fromRoster = false;
    const double now = (double)ImGui::GetTime();
    std::string nick, regNick, disp, label;
    const char *src = "нет";
    if (const OxRosterEntry *e = ox_rosterEntry(pm, now)) regNick = e->nick;
    if (ox_nickValid(regNick)) { nick = regNick; src = "список игроков"; if (fromRoster) *fromRoster = true; }
    const uint64_t rys = rpm<uint64_t>(pm + ox::PM_EVENT_HANDLER);
    if (nick.empty() && ox_isPtr(rys) && rpm<uint64_t>(rys + ox::RYS_MANAGER) == pm) {
        disp = ox_readStringUtf8(rpm<uint64_t>(rys + ox::RYK_DISPLAY_NAME), 48);
        if (ox_nickValid(disp)) { nick = disp; src = "Ryk.DisplayName"; }
    }
    if (nick.empty()) {
        label = ox_readNickname(pm);
        if (ox_nickValid(label)) { nick = label; src = "подпись"; }
    }
    static std::unordered_map<uint64_t, std::string> s_last;
    static int s_lines = 0;
    std::string key = nick + "|" + src;
    auto it = s_last.find(pm);
    if (it == s_last.end() || it->second != key) {
        if (s_last.size() > 512) s_last.clear();
        s_last[pm] = key;
        if (s_lines++ < 60)
            OXLOGI("[nick] pm=0x%llx -> '%s' (%s); список='%s' DisplayName='%s' подпись='%s'", (unsigned long long)pm, nick.c_str(), src,
                   regNick.c_str(), disp.c_str(), label.c_str());
    }
    return nick;
}

// Ник только из символов, которые есть в шрифте: иначе ImGui рисует вместо них «?». Литеральные «?» тоже выкидываем.
static std::string ox_cleanNick(ImFont *font, const std::string &in) {
    std::string out;
    const char *p = in.c_str(), *end = p + in.size();
    while (p < end) {
        unsigned int c = 0;
        const int n = ImTextCharFromUtf8(&c, p, end);
        if (n <= 0) break;
        if (c && c != '?' && c <= 0xFFFF && font->FindGlyphNoFallback((ImWchar)c)) out.append(p, (size_t)n);
        p += n;
    }
    size_t a = out.find_first_not_of(' '), b = out.find_last_not_of(' ');
    return a == std::string::npos ? std::string() : out.substr(a, b - a + 1);
}

// Клан: PM.clanTag (SyncVar), если пусто — из списка игроков матча.
static std::string ox_playerClan(uint64_t pm) {
    std::string c = ox_readStringUtf8(rpm<uint64_t>(pm + ox::PM_CLAN_TAG), 16);
    if (c.empty()) if (const OxRosterEntry *e = ox_rosterEntry(pm, (double)ImGui::GetTime())) c = e->clan;
    return c;
}

// Одинаковая подпись у двух и более разных игроков — заготовка, а не ник (у настоящих ников она своя).
// Имена из списка игроков матча приходят от сервера и не трогаются.
static void ox_dropDuplicateNicks(std::vector<PlayerCacheData> &v) {
    auto lower = [](const std::string &s) { std::string l; for (char c : s) l.push_back((char)tolower((unsigned char)c)); return l; };
    std::unordered_map<std::string, int> cnt;
    for (const PlayerCacheData &p : v) if (!p.name.empty() && !p.nameFromRoster) ++cnt[lower(p.name)];
    for (PlayerCacheData &p : v) if (!p.name.empty() && !p.nameFromRoster && cnt[lower(p.name)] >= 2) p.name.clear();
}

// ── Оценка HP по попаданиям ───────────────────────────────────────────────────
// Игра не сообщает клиенту HP чужих игроков: до смерти там остаётся максимум, при смерти — 0. Поэтому каждое
// замеченное попадание (ваше или чужой выстрел из менеджера пуль) вычитается из оценки; настоящее значение игры
// имеет приоритет (смерть, воскрешение, меньшее HP).
struct OxHpEst {
    float  hp = -1.f;            // оценка; < 0 — по этому игроку попаданий не было
    double lastSeen = 0.0, lastHit = 0.0, lastTick = 0.0;
    int    hits = 0;
    bool   dead = false;
};
static std::unordered_map<uint64_t, OxHpEst> g_hpEst;

// Живое HP. GenericVitals.m_MaxHealth — максимум, текущее значение хранит Ryk.Health (реактивное значение с
// двумя float). Цепочка: PM -> Rys (playerEventHandler | vitals.PlayerEvent | vitals.Entity) -> Health -> float.
// Rys проверяется обратной ссылкой manager == PM. Какой из двух float текущий, определяется по голосованию:
// при изменении «текущий» принимает новое значение, а второй — старое текущее.
struct OxHpState {
    uint64_t rys = 0, hobj = 0;
    double   nextResolve = 0.0, nextCheck = 0.0, lastSeen = 0.0, nextLog = 0.0;
    float    a = 0.f, b = 0.f, maxHp = 100.f;
    bool     have = false;
};
static std::unordered_map<uint64_t, OxHpState> g_hpStates;
static int g_hpVoteA = 0, g_hpVoteB = 0;
static const char *g_hpPathName = "";

static bool ox_hpResolve(uint64_t pm, OxHpState &st) {
    const uint64_t vitals = rpm<uint64_t>(pm + ox::PM_VITALS);
    uint64_t cand[3] = { rpm<uint64_t>(pm + ox::PM_EVENT_HANDLER), 0, 0 };
    if (ox_isPtr(vitals)) {
        cand[1] = rpm<uint64_t>(vitals + ox::VITALS_PLAYER_EVENT);
        cand[2] = rpm<uint64_t>(vitals + ox::VITALS_ENTITY);
    }
    static const char *names[3] = { "PM.playerEventHandler", "vitals.PlayerEvent", "vitals.Entity" };
    for (int i = 0; i < 3; ++i) {
        if (!ox_isPtr(cand[i]) || rpm<uint64_t>(cand[i] + ox::RYS_MANAGER) != pm) continue;
        const uint64_t h = rpm<uint64_t>(cand[i] + ox::RYK_HEALTH);
        if (!ox_isPtr(h)) continue;
        const float a = rpm<float>(h + ox::REASONED_VALUE_A), b = rpm<float>(h + ox::REASONED_VALUE_B);
        if (!isfinite(a) || !isfinite(b) || a < -1.f || a > 1e5f || b < -1.f || b > 1e5f) continue;
        st.rys = cand[i]; st.hobj = h; st.have = false;
        if (g_hpPathName != names[i]) { g_hpPathName = names[i]; OXLOGI("[hp] цепочка HP: %s -> Ryk.Health -> float (a=%.1f b=%.1f)", names[i], a, b); }
        return true;
    }
    return false;
}

// Максимум здоровья игрока (из GenericVitals.m_MaxHealth, по умолчанию 100).
static float ox_hpMaxOf(uint64_t pm) {
    auto it = g_hpStates.find(pm);
    return (it != g_hpStates.end() && it->second.maxHp > 1.f) ? it->second.maxHp : 100.f;
}

// Списывает урон с оценки HP игрока.
static void ox_applyDamage(uint64_t pm, float dmg, double now) {
    OxHpEst &e = g_hpEst[pm];
    if (e.dead) return;
    const float maxHp = ox_hpMaxOf(pm);
    if (e.hp < 0.f) e.hp = maxHp;
    e.hp -= dmg;
    if (e.hp < 0.f) e.hp = 0.f;
    e.lastSeen = e.lastHit = e.lastTick = now;
    ++e.hits;
}

// Накладывает оценку по попаданиям на значение игры (out.hpNow — значение игры до вызова).
static void ox_hpEstApply(uint64_t pm, double now, PlayerCacheData &out) {
    auto it = g_hpEst.find(pm);
    if (it == g_hpEst.end()) return;
    OxHpEst &e = it->second;
    e.lastSeen = now;
    const float real = out.hpNow;
    if (real <= 0.f) { e.dead = true; e.hp = 0.f; return; }                  // смерть игра сообщает сама
    if (e.dead) { e = OxHpEst(); e.lastSeen = now; return; }                // воскрес — оценка с нуля
    if (e.hp < 0.f) return;                                                  // по этому игроку попаданий не было
    const float maxHp = out.hpMax > 1.f ? out.hpMax : 100.f;
    float dtR = (float)(now - e.lastTick);
    e.lastTick = now;
    if (dtR > 1.f) dtR = 1.f;
    if (dtR > 0.f && now - e.lastHit > 20.0 && e.hp < maxHp) {              // долго без урона — медленная регенерация
        e.hp += 0.5f * dtR;
        if (e.hp > maxHp) e.hp = maxHp;
    }
    if (real < e.hp) e.hp = real;                                            // игра показала меньше — верим игре
    const float floorHp = 0.03f * maxHp;                                     // жив, пока игра не сказала обратное
    out.hpNow = e.hp > floorHp ? e.hp : floorHp;
}

// Заполняет out.hpNow / out.hpMax. false — значение не получено.
static bool ox_readHpLive(uint64_t pm, PlayerCacheData &out, bool estimate = true) {
    if (!ox_isPtr(pm)) return false;
    const double now = (double)ImGui::GetTime();
    OxHpState &st = g_hpStates[pm];
    st.lastSeen = now;
    static double s_prune = 0.0;
    if (now > s_prune) {
        s_prune = now + 3.0;
        for (auto it = g_hpStates.begin(); it != g_hpStates.end();)
            it = (now - it->second.lastSeen > 4.0) ? g_hpStates.erase(it) : std::next(it);
        for (auto it = g_hpEst.begin(); it != g_hpEst.end();)
            it = (now - it->second.lastSeen > 120.0) ? g_hpEst.erase(it) : std::next(it);
    }
    if (!st.hobj) {
        if (now < st.nextResolve) return false;
        if (!ox_hpResolve(pm, st)) {
            st.nextResolve = now + 1.0;
            if (now >= st.nextLog) { st.nextLog = now + 10.0; OXLOGW("[hp] pm=0x%llx: цепочка до Ryk.Health не найдена", (unsigned long long)pm); }
            return false;
        }
    }
    if (now >= st.nextCheck) {                     // раз в секунду: объект на месте и принадлежит этому игроку
        st.nextCheck = now + 1.0;
        const uint64_t vitals = rpm<uint64_t>(pm + ox::PM_VITALS);
        const float mx = ox_isPtr(vitals) ? rpm<float>(vitals + ox::VITALS_HEALTH) : 0.f;
        st.maxHp = (isfinite(mx) && mx > 1.f && mx < 1e5f) ? mx : 100.f;
        if (rpm<uint64_t>(st.rys + ox::RYS_MANAGER) != pm || rpm<uint64_t>(st.rys + ox::RYK_HEALTH) != st.hobj) {
            st.hobj = 0; st.rys = 0; st.nextResolve = now + 0.2;
            return false;
        }
    }
    if (!estimate && (rpm<uint64_t>(st.rys + ox::RYS_MANAGER) != pm || rpm<uint64_t>(st.rys + ox::RYK_HEALTH) != st.hobj)) return false;
    float v[2];
    if (!vm_readv((unsigned long)(st.hobj + ox::REASONED_VALUE_A), v, sizeof(v)) ||
        !isfinite(v[0]) || !isfinite(v[1]) || v[0] < -1.f || v[0] > 1e5f || v[1] < -1.f || v[1] > 1e5f) {
        st.hobj = 0; st.nextResolve = now + 0.5;
        return false;
    }
    if (st.have && (v[0] != st.a || v[1] != st.b)) {
        const bool vA = (v[1] == st.a && v[0] != st.a);    // первое поле новое, второе приняло старое значение первого
        const bool vB = (v[0] == st.b && v[1] != st.b);
        if (vA && !vB) ++g_hpVoteA; else if (vB && !vA) ++g_hpVoteB;
    }
    st.a = v[0]; st.b = v[1]; st.have = true;
    const float cur = (g_hpVoteB > g_hpVoteA) ? v[1] : v[0];
    out.hpNow = cur < 0.f ? 0.f : cur;
    out.hpMax = st.maxHp;
    if (estimate) ox_hpEstApply(pm, now, out);
    if (now >= st.nextLog) {
        st.nextLog = now + 8.0;
        OXLOGI("[hp] pm=0x%llx: rgf=%.1f rgL=%.1f max=%.0f -> %.1f  (голоса: первое=%d второе=%d)", (unsigned long long)pm, v[0], v[1], st.maxHp, out.hpNow, g_hpVoteA, g_hpVoteB);
    }
    return true;
}

// Fresh authoritative life gate, shared by aim, silent and death effects.
// GenericVitals.m_MaxHealth is NOT current HP. Never use hit estimates here.
struct OxLifeMem { bool rd(uint64_t a,void *b,size_t n) {return vm_readv((unsigned long)a,b,n);} };
static void ox_chamsDeath(const targetlife::Ticket &ticket,double now);
struct OxDeathNotice { targetlife::Ticket ticket; double at; };
static std::mutex g_deathMutex;
static std::vector<OxDeathNotice> g_deathNotices;
static double ox_lifeClock() {
    return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
}
static targetlife::State ox_lifeRead(const targetlife::Ticket &ticket,bool worker=false) {
    OxLifeMem mem;const auto state=targetlife::Read(mem,ticket);
    if (state==targetlife::State::Dead && worker) {
        std::lock_guard<std::mutex> lk(g_deathMutex);
        bool have=false;
        for(const auto &n:g_deathNotices)
            if(n.ticket.pm==ticket.pm && n.ticket.klass==ticket.klass && n.ticket.netId==ticket.netId) {have=true;break;}
        if(!have && g_deathNotices.size()<64) g_deathNotices.push_back({ticket,ox_lifeClock()});
    }
    return state;
}
// Render thread only: resolves the HP chain and publishes immutable tickets.
static targetlife::State ox_lifeSnapshot(uint64_t pm,targetlife::Ticket &t) {
    t={};if(!ox_isPtr(pm)) return targetlife::State::Unknown;
    OxLifeMem mem;
    t.pm=pm;t.identitySlot=pm+ox::NB_NET_IDENTITY;t.respawnSlot=pm+ox::PM_RESPAWNING;
    if(!mem.rd(pm,&t.klass,8) || !mem.rd(t.identitySlot,&t.identity,8) || !ox_isPtr(t.identity))
        return targetlife::State::Unknown;
    t.netIdSlot=t.identity+ox::NI_NET_ID;
    if(!mem.rd(t.netIdSlot,&t.netId,4)) return targetlife::State::Unknown;
    uint8_t respawn=0;
    if(!mem.rd(t.respawnSlot,&respawn,1) || respawn>1) return targetlife::State::Unknown;
    if(respawn==1) {
        const auto st=ox_lifeRead(t);if(st==targetlife::State::Dead) ox_chamsDeath(t,ImGui::GetTime());return st;
    }
    PlayerCacheData hp{};
    if(!ox_readHpLive(pm,hp,false)) {
#if defined(__x86_64__)
        // Some PC remote players have no readable health component. Accept
        // them only while the current class/identity remains in the active
        // client list. The worker rechecks that list before using a ticket.
        if(t.klass!=g_playerManagerKlass || !t.netId) return targetlife::State::Unknown;
        const uint64_t statics=ox_getStatics(false);
        const uint64_t listSlot=statics+ox::STATIC_PLAYER_LIST;
        const uint64_t list=ox_isPtr(statics) ? ox_readDirect<uint64_t>(listSlot) : 0;
        const uint64_t items=ox_isPtr(list) ? ox_readDirect<uint64_t>(list+ox::LIST_ITEMS) : 0;
        const int size=ox_isPtr(list) ? ox_readDirect<int>(list+ox::LIST_SIZE) : 0;
        if(!ox_isPtr(items) || size<=0 || size>256) return targetlife::State::Unknown;
        std::vector<uint64_t> roster((size_t)size);
        if(!pvm((void*)(items+ox::ARRAY_DATA),roster.data(),roster.size()*8,false))
            for(int i=0;i<size;++i) {
                uint64_t value=0;
                if(pvm((void*)(items+ox::ARRAY_DATA+(uint64_t)i*8),&value,8,false))
                    roster[(size_t)i]=value;
                else roster[(size_t)i]=0;
            }
        for(int i=0;i<size;++i) if(roster[(size_t)i]==pm) {
            t.rosterListSlot=listSlot;t.rosterList=list;
            t.rosterItemsSlot=list+ox::LIST_ITEMS;t.rosterItems=items;
            t.rosterSizeSlot=list+ox::LIST_SIZE;t.rosterIndex=i;
            t.rosterEntrySlot=items+ox::ARRAY_DATA+(uint64_t)i*8;
            return ox_lifeRead(t);
        }
#endif
        return targetlife::State::Unknown;
    }
    const auto it=g_hpStates.find(pm);if(it==g_hpStates.end()) return targetlife::State::Unknown;
    t.handler=it->second.rys;t.health=it->second.hobj;
    // Preserve the actual resolved path (PM handler OR a validated vitals path).
    uint64_t slots[3]={pm+ox::PM_EVENT_HANDLER,0,0};
    uint64_t vitals=0;
    if(mem.rd(pm+ox::PM_VITALS,&vitals,8) && ox_isPtr(vitals)) {
        slots[1]=vitals+ox::VITALS_PLAYER_EVENT;slots[2]=vitals+ox::VITALS_ENTITY;
    }
    for(uint64_t slot:slots) {uint64_t h=0;if(slot && mem.rd(slot,&h,8) && h==t.handler) {t.sourceSlot=slot;if(slot!=slots[0]) {t.parentSlot=pm+ox::PM_VITALS;t.parent=vitals;}break;}}
    if(!t.sourceSlot) return targetlife::State::Unknown;
    t.ownerSlot=t.handler+ox::RYS_MANAGER;t.healthSlot=t.handler+ox::RYK_HEALTH;
    t.valuesSlot=t.health+ox::REASONED_VALUE_A;t.current=g_hpVoteB>g_hpVoteA ? 1 : 0;
    const auto state=ox_lifeRead(t);
    if(state==targetlife::State::Dead) ox_chamsDeath(t,ImGui::GetTime());
    return state;
}

// ── Урон оружия ───────────────────────────────────────────────────────────────
// HitscanWeaponConfig.damage. Конфиг лежит по разным смещениям у FPHitscan / FPCrossbow / FPRocketLauncher;
// подходящее выбирается по правдоподобию соседних полей (урон, дальность, скорострельность, число снарядов).
static float ox_cfgDamage(uint64_t weaponObj) {
    static const uint64_t offs[3] = { ox::FPHITSCAN_CONFIG, ox::FPCROSSBOW_CONFIG, ox::FPROCKET_CONFIG };
    for (uint64_t o : offs) {
        const uint64_t cfg = rpm<uint64_t>(weaponObj + o);
        if (!ox_isPtr(cfg)) continue;
        uint8_t raw[0x28];
        if (!vm_readv((unsigned long)(cfg + ox::HSCFG_DAMAGE), raw, sizeof(raw))) continue;
        float damage, maxDist, fireRate;
        int pellets;
        memcpy(&damage, raw, 4);
        memcpy(&maxDist, raw + (ox::HSCFG_MAX_DISTANCE - ox::HSCFG_DAMAGE), 4);
        memcpy(&fireRate, raw + (ox::HSCFG_FIRE_RATE - ox::HSCFG_DAMAGE), 4);
        memcpy(&pellets, raw + (ox::HSCFG_PELLETS - ox::HSCFG_DAMAGE), 4);
        if (isfinite(damage) && damage >= 1.f && damage <= 1000.f && isfinite(maxDist) && maxDist >= 3.f && maxDist <= 3000.f &&
            isfinite(fireRate) && fireRate > 0.f && fireRate <= 300.f && pellets >= 1 && pellets <= 64)
            return damage;
    }
    return 0.f;
}

// Какое FP-оружие сейчас в руках у локального игрока: PM.weaponReference (обёртка или сам объект) должно оказаться
// в PM.weapons[]; запасной путь — предмет в руках (Rys.EquippedItem) совпадает с FPObject.Item. 0 — не определили.
static float ox_weaponDamage(uint64_t pm, double now) {
    static uint64_t s_pm = 0;
    static float s_dmg = 0.f;
    static double s_next = 0.0;
    static float s_logged = -1.f;
    if (s_pm == pm && now < s_next && now >= s_next - 0.5) return s_dmg;   // кэш на 0.4 с; время назад (новый запуск) его сбрасывает
    s_pm = pm; s_next = now + 0.4; s_dmg = 0.f;
    const uint64_t arr = rpm<uint64_t>(pm + ox::PM_WEAPONS);
    if (!ox_isPtr(arr)) return 0.f;
    const uint64_t cnt = rpm<uint64_t>(arr + ox::ARRAY_COUNT);
    if (cnt == 0 || cnt > 128) return 0.f;
    uint64_t w[128];
    if (!vm_readv((unsigned long)(arr + ox::ARRAY_DATA), w, (size_t)cnt * 8)) return 0.f;
    auto inArray = [&](uint64_t p) { for (uint64_t i = 0; i < cnt; ++i) if (w[i] == p) return true; return false; };
    uint64_t active = 0;
    const char *how = "";
    const uint64_t wr = rpm<uint64_t>(pm + ox::PM_WEAPON_REF);
    if (ox_isPtr(wr)) {
        if (inArray(wr)) { active = wr; how = "weaponReference"; }
        else {
            uint64_t blk[10];
            if (vm_readv((unsigned long)wr, blk, sizeof(blk)))
                for (int k = 0; k < 10 && !active; ++k) if (ox_isPtr(blk[k]) && inArray(blk[k])) { active = blk[k]; how = "weaponReference(обёртка)"; }
        }
    }
    if (!active) {
        const uint64_t rys = rpm<uint64_t>(pm + ox::PM_EVENT_HANDLER);
        const uint64_t ro = ox_isPtr(rys) ? rpm<uint64_t>(rys + ox::RYS_EQUIPPED_ITEM) : 0;
        if (ox_isPtr(ro)) {
            const uint64_t items[2] = { rpm<uint64_t>(ro + ox::RYR_VALUE_A), rpm<uint64_t>(ro + ox::RYR_VALUE_B_REF) };
            for (uint64_t i = 0; i < cnt && !active; ++i) {
                if (!ox_isPtr(w[i])) continue;
                const uint64_t it = rpm<uint64_t>(w[i] + ox::FPOBJECT_ITEM);
                if (ox_isPtr(it) && (it == items[0] || it == items[1])) { active = w[i]; how = "EquippedItem"; }
            }
        }
    }
    if (!active || rpm<uint64_t>(active + ox::FPOBJECT_PLAYER) != pm) return 0.f;
    s_dmg = ox_cfgDamage(active);
    if (s_dmg > 0.f && s_dmg != s_logged) { s_logged = s_dmg; OXLOGI("[hit] оружие в руках (%s): урон конфига %.1f", how, s_dmg); }
    return s_dmg;
}

// ── Геометрия ─────────────────────────────────────────────────────────────────
static void ox_playerSegment(const PlayerCacheData &pl, float feet[3], float head[3]) {
    if (pl.usedModelAnchor) {
        feet[0] = pl.anchorFeet.x; feet[1] = pl.anchorFeet.y; feet[2] = pl.anchorFeet.z;
        head[0] = pl.anchorHead.x; head[1] = pl.anchorHead.y; head[2] = pl.anchorHead.z;
    } else {
        const float y0 = pl.position.y + ox_boxYOffset();
        feet[0] = head[0] = pl.position.x; feet[2] = head[2] = pl.position.z;
        feet[1] = y0 - ox::BOX_FOOT; head[1] = y0 + ox::BOX_HEAD;
    }
}

static float ox_distToSegment(const float p[3], const float a[3], const float b[3]) {
    const float ab[3] = { b[0] - a[0], b[1] - a[1], b[2] - a[2] };
    const float ap[3] = { p[0] - a[0], p[1] - a[1], p[2] - a[2] };
    const float l2 = ab[0] * ab[0] + ab[1] * ab[1] + ab[2] * ab[2];
    float t = l2 > 1e-6f ? (ap[0] * ab[0] + ap[1] * ab[1] + ap[2] * ab[2]) / l2 : 0.f;
    t = t < 0.f ? 0.f : (t > 1.f ? 1.f : t);
    const float c[3] = { a[0] + ab[0] * t - p[0], a[1] + ab[1] * t - p[1], a[2] + ab[2] * t - p[2] };
    return sqrtf(c[0] * c[0] + c[1] * c[1] + c[2] * c[2]);
}

// Ближайшие точки двух отрезков (p1,q1) и (p2,q2); возвращает расстояние, s и t — доли вдоль каждого.
static float ox_segSegDist(const float p1[3], const float q1[3], const float p2[3], const float q2[3], float *sOut, float *tOut) {
    auto clamp01 = [](float v) { return v < 0.f ? 0.f : (v > 1.f ? 1.f : v); };
    const float d1[3] = { q1[0] - p1[0], q1[1] - p1[1], q1[2] - p1[2] };
    const float d2[3] = { q2[0] - p2[0], q2[1] - p2[1], q2[2] - p2[2] };
    const float r[3] = { p1[0] - p2[0], p1[1] - p2[1], p1[2] - p2[2] };
    auto dot = [](const float *a, const float *b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; };
    const float a = dot(d1, d1), e = dot(d2, d2), f = dot(d2, r);
    float s = 0.f, t = 0.f;
    const float EPS = 1e-6f;
    if (a <= EPS && e <= EPS) { s = t = 0.f; }
    else if (a <= EPS) { s = 0.f; t = clamp01(f / e); }
    else {
        const float c = dot(d1, r);
        if (e <= EPS) { t = 0.f; s = clamp01(-c / a); }
        else {
            const float b = dot(d1, d2), denom = a * e - b * b;
            s = denom > EPS ? clamp01((b * f - c * e) / denom) : 0.f;
            t = (b * s + f) / e;
            if (t < 0.f) { t = 0.f; s = clamp01(-c / a); }
            else if (t > 1.f) { t = 1.f; s = clamp01((b - c) / a); }
        }
    }
    float dx = 0.f, dy = 0.f, dz = 0.f;
    dx = (p1[0] + d1[0] * s) - (p2[0] + d2[0] * t);
    dy = (p1[1] + d1[1] * s) - (p2[1] + d2[1] * t);
    dz = (p1[2] + d1[2] * s) - (p2[2] + d2[2] * t);
    if (sOut) *sOut = s;
    if (tOut) *tOut = t;
    return sqrtf(dx * dx + dy * dy + dz * dz);
}

// ── Слежение за попаданиями локального игрока ────────────────────────────────
struct OxHitWatch {
    uint64_t pm = 0, rys = 0, timeObj = 0, pointObj = 0, aimObj = 0;
    bool   have = false;
    float  t[2] = { 0.f, 0.f };
    float  p[6] = { 0, 0, 0, 0, 0, 0 };
    double nextResolve = 0.0;
    int    events = 0, misses = 0;
};
static OxHitWatch g_hit;

// Раз в кадр: ловит новое попадание и списывает урон с оценки HP цели.
static void ox_hitUpdate(std::vector<PlayerCacheData> &players, double now) {
    OxHitWatch &h = g_hit;
    const uint64_t lp = g_localPlayer;
    if (!ox_isPtr(lp) || players.empty()) return;
    if (h.pm != lp) { h = OxHitWatch(); h.pm = lp; }
    if (!h.timeObj) {
        if (now < h.nextResolve) return;
        h.nextResolve = now + 1.0;
        const uint64_t rys = rpm<uint64_t>(lp + ox::PM_EVENT_HANDLER);
        if (!ox_isPtr(rys) || rpm<uint64_t>(rys + ox::RYS_MANAGER) != lp) return;
        const uint64_t tobj = rpm<uint64_t>(rys + ox::RYS_LAST_HIT_TIME);
        const uint64_t pobj = rpm<uint64_t>(rys + ox::RYS_LAST_HIT_POINT);
        const uint64_t aobj = rpm<uint64_t>(rys + ox::RYS_AIM_RAYCAST);
        if (!ox_isPtr(tobj)) return;
        h.rys = rys; h.timeObj = tobj; h.pointObj = ox_isPtr(pobj) ? pobj : 0; h.aimObj = ox_isPtr(aobj) ? aobj : 0; h.have = false;
        OXLOGI("[hit] слежение за попаданиями включено: Rys=0x%llx время=0x%llx точка=0x%llx прицел=0x%llx", (unsigned long long)rys,
               (unsigned long long)tobj, (unsigned long long)h.pointObj, (unsigned long long)h.aimObj);
    }
    float t[2];
    if (!vm_readv((unsigned long)(h.timeObj + ox::RYR_VALUE_A), t, sizeof(t))) { h.timeObj = 0; return; }
    if (!isfinite(t[0]) || !isfinite(t[1])) return;
    float pp[6] = { 0, 0, 0, 0, 0, 0 };
    const bool havePts = h.pointObj && vm_readv((unsigned long)(h.pointObj + ox::RYR_VALUE_A), pp, sizeof(pp));   // rgC и rgE подряд
    if (!h.have) {
        h.t[0] = t[0]; h.t[1] = t[1]; memcpy(h.p, pp, sizeof(pp)); h.have = true;
        return;
    }
    const float prevFresh = fmaxf(h.t[0], h.t[1]), fresh = fmaxf(t[0], t[1]);
    const bool changed = (t[0] != h.t[0] || t[1] != h.t[1]);
    const float oldP[6] = { h.p[0], h.p[1], h.p[2], h.p[3], h.p[4], h.p[5] };
    h.t[0] = t[0]; h.t[1] = t[1];
    if (havePts) memcpy(h.p, pp, sizeof(pp));
    if (!changed) return;
    if (fresh < prevFresh - 5.f) return;                   // время сбросилось (новая сцена)
    if (!(fresh > prevFresh + 1e-4f)) return;

    // Точка попадания: слот, значение которого не совпало ни с одним из прежних (второй слот может хранить предыдущее).
    float P[3] = { 0, 0, 0 };
    bool haveP = false;
    if (havePts) {
        auto same = [](const float *a, const float *b) { return a[0] == b[0] && a[1] == b[1] && a[2] == b[2]; };
        const bool aFresh = !same(pp, oldP) && !same(pp, oldP + 3);
        const float *src = aFresh ? pp : (same(pp + 3, oldP) || same(pp + 3, oldP + 3) ? pp : pp + 3);
        P[0] = src[0]; P[1] = src[1]; P[2] = src[2];
        haveP = isfinite(P[0]) && isfinite(P[1]) && isfinite(P[2]) && fabsf(P[0]) < 1e5f && fabsf(P[1]) < 1e5f && fabsf(P[2]) < 1e5f &&
                (P[0] != 0.f || P[1] != 0.f || P[2] != 0.f);
    }
    ++h.events;

    // Игрок под прицелом (Rys.AimRaycast -> RyT.PlayerManager).
    uint64_t aimed = 0;
    if (h.aimObj) {
        const uint64_t slots[2] = { ox::RYR_VALUE_A, ox::RYR_VALUE_B_REF };
        for (uint64_t so : slots) {
            const uint64_t ryt = rpm<uint64_t>(h.aimObj + so);
            if (!ox_isPtr(ryt)) continue;
            const uint64_t apm = rpm<uint64_t>(ryt + ox::RYT_PLAYER);
            if (!ox_isPtr(apm)) continue;
            for (const PlayerCacheData &pl : players) if (pl.address == apm) { aimed = apm; break; }
            if (aimed) break;
        }
    }

    // Цель: игрок под прицелом, если точка не противоречит; иначе ближайший к точке попадания (не дальше 1 м).
    const PlayerCacheData *target = nullptr;
    float bestD = 1e9f, tFeet[3] = { 0, 0, 0 }, tHead[3] = { 0, 0, 0 };
    for (const PlayerCacheData &pl : players) {
        float f[3], hd[3];
        ox_playerSegment(pl, f, hd);
        const float d = haveP ? ox_distToSegment(P, f, hd) : 0.f;
        const bool isAimed = (pl.address == aimed);
        if (isAimed && (!haveP || d <= 4.0f)) { target = &pl; bestD = d; memcpy(tFeet, f, 12); memcpy(tHead, hd, 12); break; }
        if (haveP && d < bestD && d <= 1.0f) { target = &pl; bestD = d; memcpy(tFeet, f, 12); memcpy(tHead, hd, 12); }
    }
    if (!target) {
        ++h.misses;
        if (h.misses <= 8) OXLOGI("[hit] #%d попадание не по игроку: точка=(%.1f %.1f %.1f) игроков в кэше=%d", h.events, P[0], P[1], P[2], (int)players.size());
        return;
    }

    const bool crit = haveP && P[1] >= tHead[1] - 0.32f;
    float base = esphpdamage >= 1.f ? esphpdamage : ox_weaponDamage(lp, now);
    const bool autoDmg = base > 0.f && esphpdamage < 1.f;
    if (base <= 0.f) base = 30.f;                                          // оружие не определили — типичный урон
    const float dmg = base * (crit ? (esphpcrit > 1.f ? esphpcrit : 1.f) : 1.f);

    if (g_hpEst[target->address].dead) return;
    ox_applyDamage(target->address, dmg, now);
    const OxHpEst &e = g_hpEst[target->address];
    OXLOGI("[hit] #%d цель=0x%llx расстояние до точки %.2f м, голова=%d, урон %.0f (%s) -> оценка HP %.0f/%.0f (попаданий: %d)", h.events,
           (unsigned long long)target->address, bestD, (int)crit, dmg, autoDmg ? "оружие" : (esphpdamage >= 1.f ? "ручной" : "по умолчанию"),
           e.hp, ox_hpMaxOf(target->address), e.hits);
}

// ── Выстрелы всех игроков: менеджер пуль (Qe) ────────────────────────────────
// Qe.Quj — список живых пуль. Каждая пуль (Qr) хранит владельца (netId), состояние (позиция, скорость) и оружие-стрелка (QV).
// Пока пуля летит, запоминаем начало её пути и последнюю позицию; когда она исчезает из списка (попала или вышла
// из дальности), проверяем по геометрии, прошёл ли путь через капсулу игрока раньше точки, где пуля пропала.
// Попадание списывает урон оружия стрелка (HitscanWeaponConfig.damage) с оценки HP цели.
struct OxBullet {
    uint64_t ptr = 0, ownerObj = 0;
    uint32_t owner = 0;
    int      shot = 0, kind = 0;
    float    p0[3] = { 0, 0, 0 }, v0[3] = { 0, 0, 0 }, pLast[3] = { 0, 0, 0 };
    double   t0 = 0.0, tLast = 0.0;
    bool     seen = false;
};
static std::unordered_map<uint64_t, OxBullet> g_bullets;
static int g_shotsSeen = 0, g_shotHits = 0, g_bulletBad = 0, g_bulletLogged = 0;
static const char *g_bulletState = "нет данных";
static std::unordered_map<uint32_t, uint64_t> g_netToPm;
static double g_netToPmNext = 0.0;

// Урон оружия-стрелка с кэшем на 5 с (чтение конфига — несколько обращений к памяти).
static float ox_ownerDamage(uint64_t ownerObj, double now) {
    struct Ent { double until; float dmg; };
    static std::unordered_map<uint64_t, Ent> s_cache;
    auto it = s_cache.find(ownerObj);
    if (it != s_cache.end() && now < it->second.until && now >= it->second.until - 5.5) return it->second.dmg;
    if (s_cache.size() > 256) s_cache.clear();
    const float d = ox_isPtr(ownerObj) ? ox_cfgDamage(ownerObj) : 0.f;
    s_cache[ownerObj] = { now + 5.0, d };
    return d;
}

static void ox_bulletFinish(const OxBullet &b, std::vector<PlayerCacheData> &players, double now, float dt) {
    // стрелок: по netId владельца, иначе по оружию (FPObject.Player)
    uint64_t shooter = 0;
    auto it = g_netToPm.find(b.owner);
    if (it != g_netToPm.end()) shooter = it->second;
    if (!shooter && ox_isPtr(b.ownerObj)) {
        const uint64_t pm = rpm<uint64_t>(b.ownerObj + ox::FPOBJECT_PLAYER);
        if (ox_isPtr(pm)) shooter = pm;
    }
    if (!shooter) return;
    if (shooter == g_localPlayer && g_hit.timeObj != 0) return;            // свои попадания считает отдельный детектор

    const float speed = sqrtf(b.v0[0] * b.v0[0] + b.v0[1] * b.v0[1] + b.v0[2] * b.v0[2]);
    const float dir[3] = { b.v0[0] / speed, b.v0[1] / speed, b.v0[2] / speed };
    const float step = speed * (dt > 0.f ? dt : 0.017f);
    const float dx = b.pLast[0] - b.p0[0], dy = b.pLast[1] - b.p0[1], dz = b.pLast[2] - b.p0[2];
    const float flown = sqrtf(dx * dx + dy * dy + dz * dz);
    const float back = step * 1.2f;                                         // пуля могла пролететь кадр до того, как мы её увидели
    const float reach = flown + step * 1.1f + 0.5f;                         // не дальше точки, где пуля пропала
    const float A[3] = { b.p0[0] - dir[0] * back, b.p0[1] - dir[1] * back, b.p0[2] - dir[2] * back };
    const float B[3] = { b.p0[0] + dir[0] * reach, b.p0[1] + dir[1] * reach, b.p0[2] + dir[2] * reach };
    const float segLen = back + reach;

    const PlayerCacheData *target = nullptr;
    float bestAlong = 1e9f, hitY = 0.f, tHeadY = 0.f;
    for (const PlayerCacheData &pl : players) {
        if (pl.address == shooter) continue;
        auto est = g_hpEst.find(pl.address);
        if (est != g_hpEst.end() && est->second.dead) continue;
        float f[3], hd[3];
        ox_playerSegment(pl, f, hd);
        const float axA[3] = { f[0], f[1] + 0.25f, f[2] }, axB[3] = { hd[0], hd[1] - 0.10f, hd[2] };
        float s = 0.f, t = 0.f;
        const float d = ox_segSegDist(A, B, axA, axB, &s, &t);
        const float vx = pl.velocity.x, vy = pl.velocity.y, vz = pl.velocity.z;
        const float R = 0.40f + fminf(0.5f, sqrtf(vx * vx + vy * vy + vz * vz) * 0.08f);   // запас на смещение цели из-за задержки сети
        if (d > R) continue;
        const float along = s * segLen - back;
        if (along < bestAlong) { bestAlong = along; target = &pl; hitY = A[1] + (B[1] - A[1]) * s; tHeadY = hd[1]; }
    }
    if (!target) return;

    const bool crit = hitY >= tHeadY - 0.30f;
    float base = esphpdamage >= 1.f ? esphpdamage : ox_ownerDamage(b.ownerObj, now);
    if (base <= 0.f) base = 30.f;
    const float dmg = base * (crit ? (esphpcrit > 1.f ? esphpcrit : 1.f) : 1.f);
    ox_applyDamage(target->address, dmg, now);
    ++g_shotHits;
    const OxHpEst &e = g_hpEst[target->address];
    if (g_shotHits <= 40)
        OXLOGI("[shot] стрелок=0x%llx -> цель=0x%llx расстояние %.0f м, голова=%d, урон %.0f -> оценка HP %.0f/%.0f", (unsigned long long)shooter,
               (unsigned long long)target->address, bestAlong, (int)crit, dmg, e.hp, ox_hpMaxOf(target->address));
}

static void ox_bulletRead(uint64_t ptr, std::vector<PlayerCacheData> &players, double now, float dt) {
    uint8_t raw[ox::QR_SIZE];
    if (!ox_isPtr(ptr) || !vm_readv((unsigned long)ptr, raw, sizeof(raw))) return;
    float pos[3], vel[3];
    uint32_t owner;
    int shot, kind;
    uint64_t ownerObj;
    memcpy(pos, raw + ox::QR_STATE_POS, 12); memcpy(vel, raw + ox::QR_STATE_VEL, 12);
    memcpy(&owner, raw + ox::QR_OWNER_ID, 4); memcpy(&shot, raw + ox::QR_SHOT_ID, 4);
    memcpy(&kind, raw + ox::QR_KIND, 4);      memcpy(&ownerObj, raw + ox::QR_OWNER_OBJ, 8);
    const float sp = sqrtf(vel[0] * vel[0] + vel[1] * vel[1] + vel[2] * vel[2]);
    const bool ok = isfinite(pos[0]) && isfinite(pos[1]) && isfinite(pos[2]) && isfinite(sp) &&
                    fabsf(pos[0]) < 1e5f && fabsf(pos[1]) < 1e5f && fabsf(pos[2]) < 1e5f && sp >= 15.f && sp <= 5000.f;
    if (!ok) {
        ++g_bulletBad;
        if (g_bulletLogged < 6) {
            ++g_bulletLogged;
            uint64_t q[8];
            memcpy(q, raw + 0x38, sizeof(q));
            OXLOGW("[shot] пуля 0x%llx не похожа на пулю: поз=(%.1f %.1f %.1f) скорость=%.1f; qword[0x38..0x78]=%llx %llx %llx %llx %llx %llx %llx %llx",
                   (unsigned long long)ptr, pos[0], pos[1], pos[2], sp, (unsigned long long)q[0], (unsigned long long)q[1], (unsigned long long)q[2],
                   (unsigned long long)q[3], (unsigned long long)q[4], (unsigned long long)q[5], (unsigned long long)q[6], (unsigned long long)q[7]);
        }
        return;
    }
    auto it = g_bullets.find(ptr);
    if (it != g_bullets.end() && it->second.owner == owner && it->second.shot == shot) {
        memcpy(it->second.pLast, pos, 12);
        it->second.tLast = now;
        it->second.seen = true;
        return;
    }
    if (it != g_bullets.end()) { ox_bulletFinish(it->second, players, now, dt); g_bullets.erase(it); }    // объект из пула взят под новую пулю
    OxBullet b;
    b.ptr = ptr; b.ownerObj = ownerObj; b.owner = owner; b.shot = shot; b.kind = kind;
    memcpy(b.p0, pos, 12); memcpy(b.pLast, pos, 12); memcpy(b.v0, vel, 12);
    b.t0 = b.tLast = now; b.seen = true;
    g_bullets[ptr] = b;
    ++g_shotsSeen;
    if (g_shotsSeen <= 8) {
        const auto sh = g_netToPm.find(owner);
        OXLOGI("[shot] #%d пуля: владелец=%u выстрел=%d тип=%d поз=(%.1f %.1f %.1f) скорость=%.0f оружие=0x%llx стрелок=%s", g_shotsSeen, owner, shot, kind,
               pos[0], pos[1], pos[2], sp, (unsigned long long)ownerObj, sh != g_netToPm.end() ? "найден" : "не в кэше");
    }
}

// Раз в кадр: читает список живых пуль, ведёт их пути, завершённые разбирает по геометрии.
static void ox_ballisticUpdate(std::vector<PlayerCacheData> &players, double now, float dt) {
    if (!g_gcQe) { g_bulletState = "нет менеджера пуль"; return; }
    if (now >= g_netToPmNext) {                                              // netId -> игрок, раз в секунду
        g_netToPmNext = now + 1.0;
        g_netToPm.clear();
        for (const PlayerCacheData &p : players) { const uint32_t id = ox_netIdOf(p.address); if (id) g_netToPm[id] = p.address; }
        if (ox_isPtr(g_localPlayer)) { const uint32_t id = ox_netIdOf(g_localPlayer); if (id) g_netToPm[id] = g_localPlayer; }
    }
    const uint64_t list = rpm<uint64_t>(g_gcQe + ox::QE_BULLETS);
    uint8_t hdr[16];
    if (!ox_isPtr(list) || !vm_readv((unsigned long)(list + ox::LIST_ITEMS), hdr, sizeof(hdr))) { g_bulletState = "список пуль не читается"; return; }
    uint64_t items;
    int size;
    memcpy(&items, hdr, 8); memcpy(&size, hdr + 8, 4);                        // _items @0x10, _size @0x18
    if (size < 0 || size > 512) { g_bulletState = "размер списка пуль неверен"; return; }
    for (auto &kv : g_bullets) kv.second.seen = false;
    if (size > 0 && ox_isPtr(items)) {
        const int n = size < 96 ? size : 96;
        uint64_t ptrs[96];
        if (vm_readv((unsigned long)(items + ox::ARRAY_DATA), ptrs, (size_t)n * 8))
            for (int i = 0; i < n; ++i) ox_bulletRead(ptrs[i], players, now, dt);
    }
    for (auto it = g_bullets.begin(); it != g_bullets.end();) {
        if (it->second.seen) { ++it; continue; }
        ox_bulletFinish(it->second, players, now, dt);
        it = g_bullets.erase(it);
    }
    g_bulletState = "ок";
}

// ── Состояние для экрана меню (две короткие строки) ───────────────────────────
std::string g_espStatus;
static void ox_statusUpdate(const std::vector<PlayerCacheData> &pl, double now) {
    static double s_next = 0.0;
    if (now < s_next) return;
    s_next = now + 1.0;
    int total = (int)pl.size(), named = 0;
    for (const PlayerCacheData &p : pl) if (!p.name.empty()) ++named;
    char a[96], b[96];
    if (g_rbk) snprintf(a, sizeof(a), "Nick: list %d, shown %d/%d", (int)g_roster.size(), named, total);
    else       snprintf(a, sizeof(a), "Nick: no list (st %d, gc %d)", g_rosterStage, g_gcStage);
    if (g_gcQe) snprintf(b, sizeof(b), "HP: shots %d, hits %d (mine %d)", g_shotsSeen, g_shotHits, g_hit.events);
    else        snprintf(b, sizeof(b), "HP: no bullets (gc %d), mine %d", g_gcStage, g_hit.events);
    g_espStatus = std::string(a) + "\n" + b;
}
// ── Ник, клан, HP и урон: end ───────────────────────────────────────────────

// Фоновый поток: находит klass GameControllerBase (тем же резолвером по имени, что PlayerManager). Запускается после
// стартового резолва (общий дедлайн скана), повторяет попытки, пока игрок не зайдёт в матч и класс не станет живым.
static std::atomic<bool> g_gcThreadStarted{false};
static void ox_gcResolveThread() {}   // поток не нужен: класс берётся из слота, см. ox_gcTick


// Оружие в руках: PM -> FPManager -> FPObject -> Item -> ItemData -> m_ShortName.
// Короткое имя компактнее для подписи под боксом ("ak47" вместо "Assault Rifle").

static std::string ox_readWeaponName(uint64_t pm) {
    if (!ox_isPtr(pm)) return "";
    uint64_t fp = rpm<uint64_t>(pm + ox::PM_FPMANAGER);
    if (!ox_isPtr(fp)) return "";
    uint64_t obj = rpm<uint64_t>(fp + ox::FP_CURRENT_WEAPON);
    if (!ox_isPtr(obj)) return "";
    uint64_t item = rpm<uint64_t>(obj + ox::FPOBJ_ITEM);
    if (!ox_isPtr(item)) return "";
    uint64_t data = rpm<uint64_t>(item + ox::ITEM_DATA);
    if (!ox_isPtr(data)) return "";
    std::string sn = ox_readManagedString(rpm<uint64_t>(data + ox::ITEMDATA_SHORTNAME));
    if (!sn.empty()) return sn;
    return ox_readManagedString(rpm<uint64_t>(data + ox::ITEMDATA_NAME));
}

static std::string ox_itemNameOf(uint64_t item, bool shortName) {
    if (!ox_isPtr(item)) return "";
    const uint64_t data = rpm<uint64_t>(item + ox::ITEM_DATA);
    if (!ox_isPtr(data)) return "";
    return ox_readManagedString(rpm<uint64_t>(data + (shortName ? ox::ITEMDATA_SHORTNAME : ox::ITEMDATA_NAME)));
}

// Английское название из ItemData (m_DisplayName.english) у конкретного предмета; если не прочиталось — подпись по id.
static std::string ox_gearLabel(const std::string &id);
static std::string ox_itemDisplayOf(uint64_t item, const std::string &id) {
    const uint64_t data = ox_isPtr(item) ? rpm<uint64_t>(item + ox::ITEM_DATA) : 0;
    if (ox_isPtr(data)) {
        const uint64_t ph = rpm<uint64_t>(data + ox::ITEMDATA_DISPLAY);
        const std::string game = ox_isPtr(ph) ? ox_readManagedString(rpm<uint64_t>(ph + ox::PHRASE_ENGLISH)) : std::string();
        if (gear::goodGameName(game)) return game;
    }
    return ox_gearLabel(id);
}

// Предмет в руке у ЛОКАЛЬНОГО игрока: Rys.EquippedItem (Ryr<Item>). У чужих это поле не реплицируется.
static uint64_t ox_heldItem(uint64_t pm) {
    const uint64_t rys = rpm<uint64_t>(pm + ox::PM_EVENT_HANDLER);
    if (!ox_isPtr(rys) || rpm<uint64_t>(rys + ox::RYS_MANAGER) != pm) return 0;
    const uint64_t r = rpm<uint64_t>(rys + ox::RYS_EQUIPPED_ITEM);
    if (!ox_isPtr(r)) return 0;
    for (uint64_t slot : { (uint64_t)ox::RYR_VALUE_A, (uint64_t)ox::RYR_VALUE_B_REF }) {
        const uint64_t it = rpm<uint64_t>(r + slot);
        if (ox_isPtr(it) && ox_isPtr(rpm<uint64_t>(it + ox::ITEM_DATA))) return it;
    }
    return 0;
}

// Auto-heal reads only fields confirmed in both 1.14.11949 dumps.
// UI list position is the physical hotbar slot; selected slot must match held Item.
static heal::Sample ox_healSample(double now) {
    heal::Sample s; s.now=now;s.owner=g_localPlayer;
    s.width=(int)ImGui::GetIO().DisplaySize.x;s.height=(int)ImGui::GetIO().DisplaySize.y;
    s.rotation=displayInfo.orientation;
    s.allowed=avis::Active()&&!g_menuOpen&&!ImGui::GetIO().MouseDown[0];
    if(!g_autoHeal.enabled||!s.allowed||!ox_isPtr(s.owner))return s;
    uint8_t respawn=1;
    if(!vm_readv(s.owner+ox::PM_RESPAWNING,&respawn,1)||respawn)return s;
    PlayerCacheData hp{};
    if(!ox_readHpLive(s.owner,hp,false)||hp.hpNow<=0||hp.hpMax<=0)return s;
    s.percent=100.f*hp.hpNow/hp.hpMax;
    const uint64_t inv=rpm<uint64_t>(s.owner+ox::PM_INVENTORY);
    const uint64_t data=ox_isPtr(inv)?rpm<uint64_t>(inv+ox::PINV_DATA):0;
    if(!ox_isPtr(data)||rpm<uint64_t>(data+ox::PINV_DATA_PLAYER)!=s.owner)return s;
    const uint64_t client=rpm<uint64_t>(inv+ox::PINV_CLIENT);
    const uint64_t bar=ox_isPtr(client)?rpm<uint64_t>(client+ox::INVCLIENT_HOTBAR):0;
    if(!ox_isPtr(bar))return s;
    const uint64_t list=rpm<uint64_t>(bar+ox::HOTBAR_SLOTS),selected=rpm<uint64_t>(bar+ox::HOTBAR_SELECTED);
    if(!ox_isPtr(list)||!ox_isPtr(selected))return s;
    int count=0;uint64_t arr=0;
    if(!vm_readv(list+ox::LIST_SIZE,&count,4)||count!=heal::kSlots||!vm_readv(list+ox::LIST_ITEMS,&arr,8)||!ox_isPtr(arr))return s;
    uint64_t slots[heal::kSlots]{};
    if(rpm<uint64_t>(arr+ox::ARRAY_COUNT)<heal::kSlots||!vm_readv(arr+ox::ARRAY_DATA,slots,sizeof(slots)))return s;
    for(int i=0;i<heal::kSlots;++i){
        if(!ox_isPtr(slots[i]))return s;
        const uint64_t cell=rpm<uint64_t>(slots[i]+ox::UI_SLOT_CELL);
        if(!ox_isPtr(cell))return s;
        if(!vm_readv(cell+ox::CELL_ITEM,&s.items[i],8))return s;
        if(slots[i]==selected)s.selected=i;
    }
    if(s.selected<0||s.items[s.selected]!=ox_heldItem(s.owner))return s;
    const int med=g_autoHeal.medicine;
    if(med<0||med>=heal::kSlots)return s;
    const std::string name=ox_itemNameOf(s.items[med],true);
    s.medical=name=="bandage"||name=="medkit";
    s.valid=true;return s;
}
static std::string ox_healPackage() {
    char p[80];snprintf(p,sizeof(p),"/proc/%d/cmdline",game_pid);
    FILE*f=fopen(p,"rb");if(!f)return {};char b[256]{};size_t n=fread(b,1,sizeof(b)-1,f);fclose(f);
    std::string pkg(b,strnlen(b,n));const auto colon=pkg.find(':');if(colon!=std::string::npos)pkg.resize(colon);
    return pkg;
}

static std::string ox_readWeaponFullName(uint64_t pm) {
    if (!ox_isPtr(pm)) return "";
    const uint64_t fp = rpm<uint64_t>(pm + ox::PM_FPMANAGER);
    if (ox_isPtr(fp)) {
        const uint64_t obj = rpm<uint64_t>(fp + ox::FP_CURRENT_WEAPON);
        if (ox_isPtr(obj)) {
            std::string n = ox_itemNameOf(rpm<uint64_t>(obj + ox::FPOBJ_ITEM), false);
            if (!n.empty()) return n;
        }
    }
    return ox_itemNameOf(ox_heldItem(pm), false);
}

// ── Предметы в рантайме ───────────────────────────────────────────────────────
// В репликации чужого игрока лежат номера (WeaponPiece.Number, индекс EquipPiece), а не имена. Соответствие находится само:
//  1) таблица id -> ItemData читается из игры (ItemDatabase.m_ById); ей доверяем, когда пары, увиденные у локального
//     игрока, совпали с id (или seed: id 6 = assault.rifle);
//  2) обучение у локального игрока: что в руке / что надето. Пары копятся в файлах на sdcard.
struct OxItemNames { std::string shortName, name, display; };
static std::mutex g_itemMtx;
static std::unordered_map<int, OxItemNames> g_itemsById;
static std::unordered_map<std::string, std::string> g_displayByKey;   // gear::key(m_ShortName / m_Name) -> ItemData.m_DisplayName.english
static std::unordered_map<int, std::string> g_learnWeapon, g_learnArmor;
static bool g_itemsLoaded = false, g_seedOk = false;
static double g_itemsNext = 0.0;
static int g_idHitW = 0, g_idMissW = 0, g_idHitA = 0, g_idMissA = 0;
static const char *kLearnDir = "/sdcard/Download/AvisTools/";

// Файл действителен только для той же сборки игры: в шапке число предметов в базе.
static void ox_learnLoad(const char *file, std::unordered_map<int, std::string> &m) {
    FILE *f = fopen((std::string(kLearnDir) + file).c_str(), "r");
    if (!f) return;
    char line[256];
    bool ok = false;
    while (fgets(line, sizeof(line), f)) {
        if (line[0] == '#') { size_t n = 0; if (sscanf(line, "# items %zu", &n) == 1) ok = (n == g_itemsById.size()); continue; }
        int k; char nm[200];
        if (ok && sscanf(line, "%d %199[^\n]", &k, nm) == 2) m[k] = nm;
    }
    fclose(f);
}
static void ox_learnSave(const char *file, const std::unordered_map<int, std::string> &m) {
    FILE *f = fopen((std::string(kLearnDir) + file).c_str(), "w");
    if (!f) return;
    fprintf(f, "# items %zu\n", g_itemsById.size());
    for (const auto &kv : m) fprintf(f, "%d %s\n", kv.first, kv.second.c_str());
    fclose(f);
}

static void ox_itemsTick(double now) {
    if (g_itemsLoaded || now < g_itemsNext) return;
    g_itemsNext = now + 3.0;
    uint64_t cands[2] = { 0, 0 };
    if (ox_isPtr(g_gcInst)) cands[0] = rpm<uint64_t>(g_gcInst + ox::GC_ITEM_DATABASE);
    if (const uint64_t k = g_gcKlass.load()) {
        const uint64_t st = rpm<uint64_t>(k + ox::CLASS_STATIC_FIELDS);
        if (ox_isPtr(st)) cands[1] = rpm<uint64_t>(st + 0x48);       // static ItemDatabase
    }
    for (uint64_t db : cands) {
        if (!ox_isPtr(db)) continue;
        const uint64_t dict = rpm<uint64_t>(db + ox::ITEMDB_BY_ID);
        if (!ox_isPtr(dict)) continue;
        const uint64_t entries = rpm<uint64_t>(dict + ox::DICT_ENTRIES);
        int count = ox_dictCount(dict);
        if (!ox_isPtr(entries) || count < 20 || count > 20000) continue;
        const uint64_t arrLen = rpm<uint64_t>(entries + ox::ARRAY_COUNT);
        if (arrLen == 0 || arrLen > 40000) continue;
        if ((uint64_t)count > arrLen) count = (int)arrLen;
        std::vector<uint8_t> buf((size_t)count * ox::DICT_ENTRY_STRIDE);
        if (!vm_readv((unsigned long)(entries + ox::ARRAY_DATA), buf.data(), buf.size())) continue;
        std::unordered_map<int, OxItemNames> tmp;
        std::unordered_map<std::string, std::string> disp;
        for (int i = 0; i < count; ++i) {
            const uint8_t *e = buf.data() + (size_t)i * ox::DICT_ENTRY_STRIDE;
            int32_t h, key; uint64_t v;
            memcpy(&h, e, 4); memcpy(&key, e + 8, 4); memcpy(&v, e + ox::DICT_ENTRY_VALUE, 8);
            if (h < 0 || !ox_isPtr(v)) continue;
            OxItemNames n;
            n.shortName = ox_readManagedString(rpm<uint64_t>(v + ox::ITEMDATA_SHORTNAME));
            n.name = ox_readManagedString(rpm<uint64_t>(v + ox::ITEMDATA_NAME));
            if (n.shortName.empty() && n.name.empty()) continue;
            const uint64_t ph = rpm<uint64_t>(v + ox::ITEMDATA_DISPLAY);                           // Phrase*: .english — название из интерфейса игры
            if (ox_isPtr(ph)) n.display = ox_readManagedString(rpm<uint64_t>(ph + ox::PHRASE_ENGLISH));
            if (gear::goodGameName(n.display)) {
                if (!n.shortName.empty()) disp[gear::key(n.shortName)] = n.display;
                if (!n.name.empty() && !disp.count(gear::key(n.name))) disp[gear::key(n.name)] = n.display;
            }
            tmp[key] = std::move(n);
        }
        if (tmp.size() < 20) continue;
        std::lock_guard<std::mutex> lk(g_itemMtx);
        g_displayByKey.swap(disp);
        g_itemsById.swap(tmp);
        g_itemsLoaded = true;
        auto s6 = g_itemsById.find(6);
        g_seedOk = s6 != g_itemsById.end() && s6->second.shortName == "assault.rifle";
        ox_learnLoad("weapons.txt", g_learnWeapon);
        ox_learnLoad("armor.txt", g_learnArmor);
        OXLOGI("[items] база предметов: %d шт, английских названий %d, seed 6=assault.rifle: %s, выучено оружия %d, брони %d",
               (int)g_itemsById.size(), (int)g_displayByKey.size(), g_seedOk ? "да" : "нет", (int)g_learnWeapon.size(), (int)g_learnArmor.size());
        {
            static const char *const kProbe[] = { "assault.rifle", "metal.chestplate", "metal.helmet", "hunting.rifle", "wooden.bow", "crossbow", "hazmat", "military.suit" };
            for (const char *id : kProbe) {
                auto it = g_displayByKey.find(gear::key(id));
                OXLOGI("[items] название %s -> %s", id, it != g_displayByKey.end() ? it->second.c_str() : "(нет в игре, таблица)");
            }
        }
        return;
    }
}

// ── Предметы: реестры игры и обучение ────────────────────────────────────────
// В репликации чужого игрока лежат НОМЕРА: WeaponPiece.Number (оружие в руке) и индексы SyncList<EquipPiece> (броня).
// И то и другое — индекс в массивах ScriptableObject PlayerEquipmentResources: weapons[] / equipments[],
// у элемента id вида "assault.rifle" / "metal.chestplate" (PlayerWeaponPiece.id / PlayerEquipmentPiece.id @0x18).
// Сам объект ресурсов ищется в куче по его klass, массивы читаются целиком. Соответствие проверяется на локальном игроке
// и дублируется обучением (файлы на sdcard).
static std::unordered_map<int, std::string> g_equipIdByNum, g_weaponIdByNum;
static std::atomic<int> g_regState{0};                 // бит 1 — equipments[] прочитан, бит 2 — weapons[]
struct OxStats { int held = 0, heldPw = 0, heldOn = 0, heldNamed = 0, arm = 0, armList = 0, armOn = 0, armNamed = 0; };
static OxStats g_st;                                   // счётчики за интервал статус-строки (поток отрисовки)

static void ox_logIdTable(const char *title, const std::unordered_map<int, std::string> &m) {
    int maxK = -1;
    for (const auto &kv : m) if (kv.first > maxK) maxK = kv.first;
    std::string row; int inRow = 0;
    for (int k = 0; k <= maxK; ++k) {
        auto it = m.find(k);
        row += (row.empty() ? "" : "  ") + std::to_string(k) + "=" + (it != m.end() ? it->second : std::string("-"));
        if (++inRow == 6 || k == maxK) { OXLOGB("[equip] %s: %s", title, row.c_str()); row.clear(); inRow = 0; }
    }
}

// Dictionary<int,string>: entries {hash, next, key, pad, value*}
static bool ox_readIntStringDict(uint64_t dict, std::unordered_map<int, std::string> &out) {
    if (!ox_isPtr(dict)) return false;
    const uint64_t entries = rpm<uint64_t>(dict + ox::DICT_ENTRIES);
    int count = ox_dictCount(dict);
    const uint64_t arrLen = ox_isPtr(entries) ? rpm<uint64_t>(entries + ox::ARRAY_COUNT) : 0;
    if (arrLen == 0 || arrLen > 20000) return false;
    if (count <= 0 || (uint64_t)count > arrLen) count = (int)arrLen;
    std::vector<uint8_t> buf((size_t)count * ox::DICT_ENTRY_STRIDE);
    if (!vm_readv((unsigned long)(entries + ox::ARRAY_DATA), buf.data(), buf.size())) return false;
    for (int i = 0; i < count; ++i) {
        const uint8_t *e = buf.data() + (size_t)i * ox::DICT_ENTRY_STRIDE;
        int32_t h, key; uint64_t v;
        memcpy(&h, e, 4); memcpy(&key, e + 8, 4); memcpy(&v, e + ox::DICT_ENTRY_VALUE, 8);
        if (h < 0 || !ox_isPtr(v)) continue;
        const std::string id = ox_readManagedString(v);
        if (!id.empty()) out[key] = id;
    }
    return out.size() >= 3;
}

// Реестры брони (kU) и оружия (kD): синглтон в static+0x0, словарь «номер -> id» по +0x20. Читаются один раз, повтор раз в 3 с до успеха.
static void ox_registryTick(double now) {
    static double next = 0.0;
    if (g_regState.load() == 3 || now < next) return;
    next = now + 3.0;
    static bool s_logFail = true;
    for (int which = 0; which < 2; ++which) {
        const int bit = which == 0 ? 1 : 2;
        if (g_regState.load() & bit) continue;
        const uint64_t rva = which == 0 ? OX_TI_EQUIP_REGISTRY : OX_TI_WEAPON_REGISTRY;
        const uint64_t kl = il2cpp_base ? rpm<uint64_t>(il2cpp_base + rva) : 0;
        const uint64_t st = ox_isPtr(kl) ? rpm<uint64_t>(kl + ox::CLASS_STATIC_FIELDS) : 0;
        const uint64_t inst = ox_isPtr(st) ? rpm<uint64_t>(st) : 0;
        std::unordered_map<int, std::string> tmp;
        if (!ox_isPtr(inst) || !ox_readIntStringDict(rpm<uint64_t>(inst + 0x20), tmp)) {
            if (s_logFail) OXLOGI("[equip] реестр %s пока недоступен: klass=0x%llx static=0x%llx inst=0x%llx", which == 0 ? "брони" : "оружия",
                                  (unsigned long long)kl, (unsigned long long)st, (unsigned long long)inst);
            continue;
        }
        {
            std::lock_guard<std::mutex> lk(g_itemMtx);
            (which == 0 ? g_equipIdByNum : g_weaponIdByNum).swap(tmp);
        }
        g_regState |= bit;
        OXLOGI("[equip] реестр %s загружен: %d записей", which == 0 ? "брони" : "оружия", (int)(which == 0 ? g_equipIdByNum : g_weaponIdByNum).size());
        ox_logIdTable(which == 0 ? "equipments" : "weapons", which == 0 ? g_equipIdByNum : g_weaponIdByNum);
    }
    s_logFail = false;
}

// Имя по номеру: выученное у локального игрока, затем реестр игры, затем таблица ItemDatabase (если её id подтверждены).
static std::string ox_nameFromNumber(int num, bool armor, std::string *fullOut = nullptr) {
    std::lock_guard<std::mutex> lk(g_itemMtx);
    const auto &learn = armor ? g_learnArmor : g_learnWeapon;
    const auto &reg = armor ? g_equipIdByNum : g_weaponIdByNum;
    // Реестр игры главный; выученное у локального игрока — только когда реестра нет (иначе устаревший файл портил бы имена).
    auto rt = reg.find(num);
    if (rt != reg.end()) { if (fullOut) *fullOut = rt->second; return rt->second; }
    auto lt = learn.find(num);
    if (lt != learn.end()) { if (fullOut) *fullOut = lt->second; return lt->second; }
    const int miss = armor ? g_idMissA : g_idMissW, hit = armor ? g_idHitA : g_idHitW;
    auto it = g_itemsById.find(num);
    if (it != g_itemsById.end() && miss == 0 && hit > 0) {
        if (fullOut) *fullOut = it->second.name;
        return it->second.shortName.empty() ? it->second.name : it->second.shortName;
    }
    return "";
}

// Подпись предмета: название из игры (ItemData.m_DisplayName.english) -> таблица -> id словами.
static std::string ox_gearLabel(const std::string &id) {
    std::string game;
    {
        std::lock_guard<std::mutex> lk(g_itemMtx);
        auto it = g_displayByKey.find(gear::key(id));
        if (it != g_displayByKey.end()) game = it->second;
    }
    return gear::label(id, game);
}

// Реестр брони по индексу (id вида "metal.chestplate"); пусто, если индекса нет.
static std::string ox_equipIdAt(int regIndex) {
    std::lock_guard<std::mutex> lk(g_itemMtx);
    auto rt = g_equipIdByNum.find(regIndex);
    return rt != g_equipIdByNum.end() ? rt->second : std::string();
}
static gear::ShiftVoter g_shiftVoter;                    // смещение индекса SyncList<EquipPiece> относительно реестра; только поток отрисовки
static int g_equipShift = ox::EQUIP_LIST_SHIFT;

// Компоненты NetworkBehaviour игрока (PM -> NetworkIdentity -> NetworkBehaviours[]).


// PlayerWeapon игрока: PlayerManager.weaponReference — это ОБЪЕКТ InterfaceReference<QF> (класс, не структура): его _component (+0x10)
// указывает на компонент PlayerWeapon. Кандидат принимается по обратной ссылке PlayerWeapon.player == PM; если её нет — по правдоподобному
// WeaponPiece. Найденное запоминается на игрока, повторный разбор раз в 3 с.
struct OxWeaponPiece { bool ok = false, enabled = false; int number = -1; uint64_t pw = 0; };
static bool ox_pieceLooksValid(const uint8_t *b) {
    if (b[0] > 1 || b[7] > 1) return false;
    const int num = (int)(int16_t)(b[2] | (b[3] << 8));
    return num >= -1 && num <= 4000;
}
static uint64_t ox_findPlayerWeaponRef(uint64_t pm) {
    static std::unordered_map<uint64_t, std::pair<uint64_t, double>> cache;
    static std::unordered_set<uint64_t> s_logged;
    const double now = (double)ImGui::GetTime();
    auto it = cache.find(pm);
    if (it != cache.end() && now < it->second.second) return it->second.first;
    const uint64_t ref = rpm<uint64_t>(pm + ox::PM_WEAPON_REF);
    uint64_t cands[4] = { ox_isPtr(ref) ? rpm<uint64_t>(ref + 0x10) : 0, ox_isPtr(ref) ? rpm<uint64_t>(ref + 0x18) : 0, ref, 0 };
    uint64_t strong = 0, weak = 0;
    int which = -1;
    for (int i = 0; i < 3; ++i) {
        const uint64_t c = cands[i];
        if (!ox_isPtr(c)) continue;
        if (!strong && rpm<uint64_t>(c + ox::PW_PLAYER) == pm) { strong = c; which = i; }
        uint8_t b[8];
        if (!weak && vm_readv((unsigned long)(c + ox::PW_WEAPON_PIECE), b, 8) && ox_pieceLooksValid(b)) weak = c;
    }
    const uint64_t pw = strong ? strong : weak;
    if (cache.size() > 256) cache.clear();
    cache[pm] = { pw, now + (pw ? 3.0 : 1.0) };
    if (s_logged.size() < 6 && s_logged.insert(pm).second) {
        uint8_t raw[8] = {0};
        if (pw) vm_readv((unsigned long)(pw + ox::PW_WEAPON_PIECE), raw, 8);
        OXLOGB("[held] pm=0x%llx ref=0x%llx _component=0x%llx fGB=0x%llx -> PlayerWeapon=0x%llx (%s) WeaponPiece=%02x%02x%02x%02x%02x%02x%02x%02x",
               (unsigned long long)pm, (unsigned long long)ref, (unsigned long long)cands[0], (unsigned long long)cands[1], (unsigned long long)pw,
               strong ? (which == 0 ? "по _component, обратная ссылка совпала" : which == 1 ? "по кэшу интерфейса, обратная ссылка совпала" : "напрямую, обратная ссылка совпала")
                      : weak ? "обратной ссылки нет, по правдоподобному WeaponPiece" : "НЕ НАЙДЕН",
               raw[0], raw[1], raw[2], raw[3], raw[4], raw[5], raw[6], raw[7]);
    }
    return pw;
}
static OxWeaponPiece ox_readWeaponPiece(uint64_t pm) {
    OxWeaponPiece r;
    const uint64_t pw = ox_findPlayerWeaponRef(pm);
    if (!pw) return r;
    uint8_t b[8];
    if (!vm_readv((unsigned long)(pw + ox::PW_WEAPON_PIECE), b, sizeof(b)) || !ox_pieceLooksValid(b)) return r;
    r.ok = true; r.pw = pw; r.enabled = b[0] != 0; r.number = (int)(int16_t)(b[2] | (b[3] << 8));
    return r;
}

static std::string ox_normName(const std::string &s) {
    std::string o;
    for (char c : s) if (isalnum((unsigned char)c)) o.push_back((char)tolower((unsigned char)c));
    return o;
}
static bool ox_sameItem(const std::string &a, const std::string &b) {
    const std::string x = ox_normName(a), y = ox_normName(b);
    return !x.empty() && !y.empty() && (x == y || x.find(y) != std::string::npos || y.find(x) != std::string::npos);
}

// Что надето у ЛОКАЛЬНОГО игрока: RBr.Dictionary<RBX,int> (ячейка -> индекс). Entry {hash, next, key*, int value}.
static void ox_readWornLocal(uint64_t pm, std::vector<std::pair<int, std::string>> &out, std::vector<int> *ids = nullptr) {
    out.clear();
    const uint64_t eq = rpm<uint64_t>(pm + ox::PM_EQUIPMENT);
    if (!ox_isPtr(eq)) return;
    const uint64_t dict = rpm<uint64_t>(eq + ox::EQUIP_SLOTS_DICT);
    if (!ox_isPtr(dict)) return;
    const uint64_t entries = rpm<uint64_t>(dict + ox::DICT_ENTRIES);
    int count = ox_dictCount(dict);
    if (!ox_isPtr(entries) || count <= 0 || count > 32) return;
    uint8_t buf[32 * 0x18];
    if (!vm_readv((unsigned long)(entries + ox::ARRAY_DATA), buf, (size_t)count * 0x18)) return;
    for (int i = 0; i < count; ++i) {
        const uint8_t *e = buf + (size_t)i * 0x18;
        int32_t hash, idx; uint64_t slot;
        memcpy(&hash, e, 4); memcpy(&slot, e + 8, 8); memcpy(&idx, e + 0x10, 4);
        if (hash < 0 || !ox_isPtr(slot)) continue;
        const uint64_t item = rpm<uint64_t>(slot + ox::SLOT_ITEM);
        std::string n = ox_itemNameOf(item, true);
        if (n.empty()) n = ox_itemNameOf(item, false);
        if (n.empty()) continue;
        out.emplace_back(idx, n);
        if (ids) {
            const uint64_t data = ox_isPtr(item) ? rpm<uint64_t>(item + ox::ITEM_DATA) : 0;
            ids->push_back(ox_isPtr(data) ? rpm<int>(data + ox::ITEMDATA_ID) : -1);
        }
    }
}

// Проверка и обучение на локальном игроке: пара «номер в репликации -> предмет» принимается, когда держится 0.4 с.
// Итог сверяется с реестром игры; расхождение пишется в лог и перекрывает реестр выученным значением.
static void ox_learnTick(double now) {
    static double next = 0.0;
    if (now < next) return;
    next = now + 0.1;
    const uint64_t lp = g_localPlayer;
    if (!ox_isPtr(lp)) return;
    static std::unordered_set<std::string> s_logged;
    auto logOnce = [&](const std::string &key, const std::string &msg) {
        if (s_logged.size() > 300 || !s_logged.insert(key).second) return;
        OXLOGB("%s", msg.c_str());
    };

    // Оружие / предмет в руке
    static int candNum = -2, candId = -1;
    static std::string candName;
    static double candSince = 0.0;
    static bool counted = false;
    const OxWeaponPiece w = ox_readWeaponPiece(lp);
    const uint64_t held = ox_heldItem(lp);
    std::string name = held ? ox_itemNameOf(held, true) : std::string();
    if (name.empty() && held) name = ox_itemNameOf(held, false);
    if (w.ok && w.enabled && w.number >= 0 && !name.empty()) {
        if (w.number != candNum || name != candName) {
            candNum = w.number; candName = name; candSince = now; counted = false;
            const uint64_t data = rpm<uint64_t>(held + ox::ITEM_DATA);
            candId = ox_isPtr(data) ? rpm<int>(data + ox::ITEMDATA_ID) : -1;
        } else if (!counted && now - candSince >= 0.4) {
            counted = true;
            std::string regId;
            {
                std::lock_guard<std::mutex> lk(g_itemMtx);
                auto r = g_weaponIdByNum.find(candNum);
                if (r != g_weaponIdByNum.end()) regId = r->second;
                if (candId == candNum) ++g_idHitW; else ++g_idMissW;
            }
            const bool agree = !regId.empty() && ox_sameItem(regId, candName);
            logOnce("w" + std::to_string(candNum) + candName,
                    "[map] оружие: номер " + std::to_string(candNum) + ", в руке '" + candName + "' (id предмета " + std::to_string(candId) +
                    "), реестр weapons[" + std::to_string(candNum) + "]='" + regId + "' -> " +
                    (regId.empty() ? "реестра нет, выучено" : agree ? "СОВПАЛО" : "РАСХОЖДЕНИЕ, выучено"));
            if (!agree) {
                std::lock_guard<std::mutex> lk(g_itemMtx);
                auto it = g_learnWeapon.find(candNum);
                if (it == g_learnWeapon.end() || it->second != candName) { g_learnWeapon[candNum] = candName; ox_learnSave("weapons.txt", g_learnWeapon); }
            }
        }
    } else candNum = -2;

    // Броня: сверка с локальным игроком. Значение в словаре надетого — не обязательно индекс списка репликации, поэтому здесь только лог
    // (по нему видно, совпадает ли индекс словаря с реестром напрямую или со смещением); обучения нет.
    static double nextArmor = 0.0;
    if (now < nextArmor) return;
    nextArmor = now + 1.0;
    std::vector<std::pair<int, std::string>> worn;
    ox_readWornLocal(lp, worn);
    for (const auto &wn : worn) {
        const int idx = wn.first;
        if (idx < 0 || idx > 4096 || gear::armorInfo(wn.second).slot < 0) continue;
        const std::string direct = ox_equipIdAt(idx), shifted = ox_equipIdAt(idx - g_equipShift);
        logOnce("a" + std::to_string(idx) + wn.second,
                "[map] броня: индекс " + std::to_string(idx) + ", надето '" + wn.second + "', реестр[" + std::to_string(idx) + "]='" + direct +
                "' (" + (!direct.empty() && ox_sameItem(direct, wn.second) ? "СОВПАЛО" : "нет") + "), реестр[" + std::to_string(idx - g_equipShift) + "]='" + shifted +
                "' (" + (!shifted.empty() && ox_sameItem(shifted, wn.second) ? "СОВПАЛО" : "нет") + "), смещение списка " + std::to_string(g_equipShift));
    }
}

// Предмет в руке: у себя — Rys.EquippedItem, у чужих — WeaponPiece.Number из репликации.
static void ox_readHeld(uint64_t pm, std::string &idOut, std::string &labelOut) {
    if (pm == g_localPlayer) {
        const uint64_t held = ox_heldItem(pm);
        std::string sn = ox_itemNameOf(held, true);
        if (sn.empty()) sn = ox_itemNameOf(held, false);
        if (!sn.empty()) { idOut = sn; labelOut = ox_itemDisplayOf(held, sn); }
        else if (idOut.empty()) { idOut = ox_readWeaponName(pm); if (!idOut.empty()) labelOut = ox_gearLabel(idOut); }
        return;
    }
    ++g_st.held;
    ++g_st.heldPw;
    const OxWeaponPiece w = ox_readWeaponPiece(pm);
    static std::unordered_set<uint64_t> s_pwSeen;
    if (w.ok && s_pwSeen.size() < 12 && s_pwSeen.insert(w.pw).second) {
        uint8_t raw[16] = {0}; vm_readv((unsigned long)(w.pw + ox::PW_WEAPON_PIECE), raw, 16);
        OXLOGB("[held] PlayerWeapon=0x%llx игрок=0x%llx WeaponPiece: enabled=%d number=%d skin=%d loaded=%d", (unsigned long long)w.pw, (unsigned long long)pm, (int)raw[0], w.number, (int)(int16_t)(raw[4] | (raw[5] << 8)), (int)raw[7]);
    }
    if (!w.ok || !w.enabled || w.number < 0) return;
    ++g_st.heldOn;
    const std::string sn = ox_nameFromNumber(w.number, false);
    static std::unordered_set<int> s_seen;
    if (s_seen.size() < 200 && s_seen.insert(w.number).second)
        OXLOGB("[held] номер оружия %d -> %s%s", w.number, sn.empty() ? "имени нет (реестр weapons[] не загружен или номер вне диапазона)" : ("'" + sn + "' = ").c_str(),
               sn.empty() ? "" : ox_gearLabel(sn).c_str());
    if (sn.empty()) return;
    ++g_st.heldNamed;
    idOut = sn; labelOut = ox_gearLabel(sn);
}

// SyncList<EquipPiece> чужого игрока: RBr+0xA0 -> SyncList -> List<EquipPiece> (смещение внутри ищем пробой) -> _items, шаг 8.
static bool ox_readEquipPieces(uint64_t pm, std::vector<std::pair<int, int>> &out /* индекс, skin */) {
    out.clear();
    const uint64_t eq = rpm<uint64_t>(pm + ox::PM_EQUIPMENT);
    if (!ox_isPtr(eq)) return false;
    const uint64_t sl = rpm<uint64_t>(eq + ox::EQUIP_PIECES);
    if (!ox_isPtr(sl)) return false;
    const uint64_t lst = rpm<uint64_t>(sl + ox::SYNCLIST_OBJECTS);        // SyncList<T>.objects (List<T>)
    if (!ox_isPtr(lst)) return false;
    const uint64_t items = rpm<uint64_t>(lst + ox::LIST_ITEMS);
    const int size = rpm<int>(lst + ox::LIST_SIZE);
    if (!ox_isPtr(items) || size <= 0 || size > 64) return false;
    uint8_t raw[64 * 8];
    if (!vm_readv((unsigned long)(items + ox::ARRAY_DATA), raw, (size_t)size * 8)) return false;
    for (int i = 0; i < size; ++i) {
        if (!raw[(size_t)i * 8]) continue;                                // Enabled
        int skin; memcpy(&skin, &raw[(size_t)i * 8 + 4], 4);
        out.emplace_back(i, skin);
    }
    return true;
}

// Надетая броня для подписей: id надетых деталей -> по одной на слот (gear::pickWorn). У чужого игрока детали — включённые элементы
// SyncList<EquipPiece>; индекс списка минус смещение (g_equipShift) — индекс реестра equipments[]. Элементы 0 и 1 — не броня.
static void ox_readEquipped(uint64_t pm, std::vector<gear::Worn> &out) {
    out.clear();
    if (!ox_isPtr(pm)) return;
    std::vector<std::string> ids;
    if (pm == g_localPlayer) {
        std::vector<std::pair<int, std::string>> worn;
        ox_readWornLocal(pm, worn);
        for (const auto &wn : worn) ids.push_back(wn.second);
    } else {
        ++g_st.arm;
        std::vector<std::pair<int, int>> pieces;
        if (ox_readEquipPieces(pm, pieces)) {
            ++g_st.armList;
            std::vector<int> idx;
            for (const auto &pc : pieces) if (pc.first >= 2) idx.push_back(pc.first);
            const int prev = g_equipShift;
            g_equipShift = g_shiftVoter.vote(idx, ox_equipIdAt);
            if (g_equipShift != prev)
                OXLOGI("[armor] смещение индекса списка относительно реестра: %d -> %d (оценки по смещениям 0..4: %d %d %d %d %d)", prev, g_equipShift,
                       g_shiftVoter.votes[0], g_shiftVoter.votes[1], g_shiftVoter.votes[2], g_shiftVoter.votes[3], g_shiftVoter.votes[4]);
            std::string key, desc;
            for (int i : idx) {
                const std::string id = ox_nameFromNumber(i - g_equipShift, true);
                key += std::to_string(i) + ",";
                desc += " " + std::to_string(i) + "->" + (id.empty() ? std::string("?") : id);
                if (!id.empty()) ids.push_back(id);
            }
            if (!idx.empty()) ++g_st.armOn;
            static std::unordered_set<std::string> s_seen;
            if (s_seen.size() < 60 && s_seen.insert(key).second)
                OXLOGB("[armor] включены индексы списка (смещение %d):%s", g_equipShift, desc.c_str());
        }
    }
    out = gear::pickWorn(ids, [](const std::string &id) { return ox_gearLabel(id); });
    if (pm != g_localPlayer && !out.empty()) ++g_st.armNamed;
}

// Флаги состояния. Enum PlayerManager.PlayerFlags: Sleeping / Spectating / Muted.
// Значения самих констант в дампе обнулены (обфускация), поэтому трактуем как
// битовую маску в порядке объявления — это стандартный [Flags] enum.
struct OxPlayerFlags { bool sleeping, spectating, muted, prime, inAir, respawning; };
static OxPlayerFlags ox_readPlayerFlags(uint64_t pm) {
    OxPlayerFlags f{};
    if (!ox_isPtr(pm)) return f;
    uint32_t bits = rpm<uint32_t>(pm + ox::PM_PLAYER_FLAGS);
    f.sleeping   = (bits & 1u) != 0;
    f.spectating = (bits & 2u) != 0;
    f.muted      = (bits & 4u) != 0;
    f.prime      = rpm<uint8_t>(pm + ox::PM_PRIME) != 0;
    f.inAir      = rpm<uint8_t>(pm + ox::PM_IS_IN_AIR) != 0;
    f.respawning = rpm<uint8_t>(pm + ox::PM_RESPAWNING) != 0;
    return f;
}

// Броня: PM -> vitals -> GenericVitals.m_Protection (ProtectionValues).
// Возвращает суммарное значение защиты, 0 если брони нет.
static float ox_readArmor(uint64_t pm) {
    if (!ox_isPtr(pm)) return 0.f;
    uint64_t v = rpm<uint64_t>(pm + ox::PM_VITALS);
    if (!ox_isPtr(v)) return 0.f;
    uint64_t prot = rpm<uint64_t>(v + ox::VITALS_PROTECTION);
    if (!ox_isPtr(prot)) return 0.f;
    // ProtectionValues — managed-объект с набором float'ов. Берём первое поле
    // после заголовка как обобщённый уровень защиты.
    float a = rpm<float>(prot + 0x10);
    if (!isfinite(a) || a < 0.f || a > 1000.f) return 0.f;
    return a;
}

// --- Кватернион-хелперы для обхода иерархии Transform ---
struct Quat { float x, y, z, w; };

static constexpr float DEG2RAD = 0.01745329251994f;

static inline Vector3 quatRotate(const Quat &q, const Vector3 &v) {
    float x2 = q.x * 2.f, y2 = q.y * 2.f, z2 = q.z * 2.f;
    float xx = q.x * x2, yy = q.y * y2, zz = q.z * z2;
    float xy = q.x * y2, xz = q.x * z2, yz = q.y * z2;
    float wx = q.w * x2, wy = q.w * y2, wz = q.w * z2;
    Vector3 r;
    r.x = (1.f - (yy + zz)) * v.x + (xy - wz) * v.y + (xz + wy) * v.z;
    r.y = (xy + wz) * v.x + (1.f - (xx + zz)) * v.y + (yz - wx) * v.z;
    r.z = (xz - wy) * v.x + (yz + wx) * v.y + (1.f - (xx + yy)) * v.z;
    return r;
}

static inline Quat quatMul(const Quat &a, const Quat &b) {
    return Quat{
        a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
        a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
        a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
        a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z
    };
}

// Низкоу��овневое чтение мировой TRS из НАТИВНОГО указателя Transform (managed).
// managed Transform + 0x10 -> internal; internal + 0x28 -> matrixData;
//   matrixData + 0x90 -> Vector3 pos; +0xA0 -> Quaternion rot.
// Возвращает true при валидном matrixData. rot/pos могут быть nullptr.
static bool ox_transformWorld(uint64_t transform, Vector3 *pos, Quat *rot, bool full, const char *tag) {
    if (!ox_isPtr(transform)) return false;
    uint64_t internal = rpm<uint64_t>(transform + ox::OBJ_CACHED_PTR);
    if (full && tag) oxlog::ptrstep(tag, transform + ox::OBJ_CACHED_PTR, internal);
    if (!ox_isPtr(internal)) return false;
    uint64_t matrixData = rpm<uint64_t>(internal + ox::TR_INT_MATRIXPTR);
    if (!ox_isPtr(matrixData)) return false;

    if (pos) *pos = rpm<Vector3>(matrixData + ox::TR_MATRIX_WORLDPOS);
    if (rot) *rot = rpm<Quat>(matrixData + ox::TR_MATRIX_ROT);
    return true;
}

// ============================================================================
//  МАТРИЦА КАМЕРЫ — забираем у игры то, чем она РИСУЕТ кадр
//
//  Сейчас базис камеры реконструируется из углов MouseLook + FOV из FPManager.
//  Это работает, но это ПРИБЛИЖЕНИЕ: любая правка, которую движок вносит в
//  матрицу (шейк, отдача, наклон, нестандартный projection при ADS) мимо нас.
//
//  Правильный источник — сама матрица:
//    RaycastManager.m_WorldCamera(0x30) -> UnityEngine.Camera (managed)
//    Camera + OBJ_CACHED_PTR(0x10)      -> нативный объект камеры (в libunity)
//    нативный объект + ???              -> worldToCameraMatrix / projectionMatrix
//
//  Последнее смещение зависит от версии Unity и живёт в libunity.so, поэтому
//  захардкодить его нельзя. Зато матрицу можно НАЙТИ по подписи:
//    * view-матрица: последняя строка ровно (0,0,0,1), верхний блок 3x3
//      ортонормирован (длина каждой строки == 1 с точностью до 1e-3)
//    * projection: столбцовая форма Unity — m00,m11 != 0, m23 == -1 либо 1,
//      остальные элементы вне диагонали и последнего столбца == 0
//
//  Сканируем ОДИН объект в окне 0x400 байт с шагом 4. Это ~256 точечных чтений
//  один раз за сессию, не массовый скан памяти — watchdog на такое не реагирует.
// ============================================================================


// Кэш найденных смещений. -1 = ещё не искали, -2 = искали и не нашли.
static int      g_camViewMatOff = -1;
static int      g_camProjMatOff = -1;
static uint64_t g_camNativeCached = 0;   // для какого нативного объекта нашли

// Проверка: похоже ли на матрицу вида (world->camera).
// Последняя строка (0,0,0,1) + ортонормированный поворот 3x3.
static bool ox_looksLikeViewMatrix(const OxMat4 &M) {
    for (int i = 0; i < 16; i++) {
        if (!isfinite(M.m[i]) || fabsf(M.m[i]) > 1e6f) return false;
    }
    // Unity Matrix4x4 в памяти: m00 m10 m20 m30 m01 m11 ... (column-major).
    // Последний столбец в памяти — элементы 12..15 = m03 m13 m23 m33.
    // Для view-матрицы m33 == 1, а строка (m30,m31,m32) == 0.
    if (fabsf(M.m[3])  > 1e-4f) return false;   // m30
    if (fabsf(M.m[7])  > 1e-4f) return false;   // m31
    if (fabsf(M.m[11]) > 1e-4f) return false;   // m32
    if (fabsf(M.m[15] - 1.0f) > 1e-4f) return false; // m33

    // Три базисных вектора (столбцы 0..2, без трансляции) должны быть единичными.
    float l0 = sqrtf(M.m[0]*M.m[0] + M.m[1]*M.m[1] + M.m[2]*M.m[2]);
    float l1 = sqrtf(M.m[4]*M.m[4] + M.m[5]*M.m[5] + M.m[6]*M.m[6]);
    float l2 = sqrtf(M.m[8]*M.m[8] + M.m[9]*M.m[9] + M.m[10]*M.m[10]);
    if (fabsf(l0 - 1.f) > 2e-3f) return false;
    if (fabsf(l1 - 1.f) > 2e-3f) return false;
    if (fabsf(l2 - 1.f) > 2e-3f) return false;

    // И взаимно перпендикулярными.
    float d01 = M.m[0]*M.m[4] + M.m[1]*M.m[5] + M.m[2]*M.m[6];
    float d02 = M.m[0]*M.m[8] + M.m[1]*M.m[9] + M.m[2]*M.m[10];
    if (fabsf(d01) > 3e-3f || fabsf(d02) > 3e-3f) return false;

    // Трансляция не должна быть нулевой (иначе это просто identity-заглушка).
    float t = fabsf(M.m[12]) + fabsf(M.m[13]) + fabsf(M.m[14]);
    if (t < 1e-4f) return false;
    return true;
}

// Проверка: похоже ли на проекционную матрицу перспективы.
// Unity column-major: m00 на [0], m11 на [5], m22 на [10], m23 на [11], m32 на [14].
static bool ox_looksLikeProjMatrix(const OxMat4 &M) {
    for (int i = 0; i < 16; i++) {
        if (!isfinite(M.m[i]) || fabsf(M.m[i]) > 1e6f) return false;
    }
    // Диагональные множители FOV: осмысленный диапазон для игровых камер.
    if (M.m[0] < 0.15f || M.m[0] > 12.f) return false;   // m00
    if (M.m[5] < 0.15f || M.m[5] > 12.f) return false;   // m11
    // m23 == -1 для right-handed перспективы Unity.
    if (fabsf(M.m[11] + 1.0f) > 1e-3f) return false;
    // m33 == 0 у перспективы (у ортографической было бы 1).
    if (fabsf(M.m[15]) > 1e-4f) return false;
    // Нули там, где их требует форма перспективной матрицы.
    const int zeros[] = {1, 2, 3, 4, 6, 7, 12, 13};
    for (int z : zeros) if (fabsf(M.m[z]) > 1e-4f) return false;
    // m22 отрицательный (far/near диапазон), m32 отрицательный.
    if (M.m[10] > 0.f || M.m[14] > 0.f) return false;
    return true;
}

// Ищет смещения обеих матриц внутри нативного объекта камеры.
// Вызывать редко: результат кэшируется до смены объекта камеры.
static Vector3 ox_readPos(uint64_t player, bool full);
static bool ox_cameraPosFromView(const OxMat4 &V, Vector3 *out);
#if defined(__x86_64__)
static bool ox_pcReadVisualOrigin(uint64_t player, double now, Vector3 &out, bool allowStale = true);
#endif
static void ox_findCameraMatrices(uint64_t nativeCam) {
    if (!ox_isPtr(nativeCam)) return;
    static double nextSearch=0.;
    const double now=ImGui::GetTime();
    if (nativeCam == g_camNativeCached) {
        if (g_camViewMatOff>=0 && g_camProjMatOff>=0) return;
        if (now<nextSearch) return;
    }
    nextSearch=now+.5;

    g_camNativeCached = nativeCam;
    g_camViewMatOff = -2;
    g_camProjMatOff = -2;

    // Окно поиска. Матрицы в UnityEngine::Camera лежат в первых ~1 КБ.
    const int WINDOW = 0x600;
    const int STEP   = 4;

    Vector3 body = ox_readPos(g_localPlayer, false);
#if defined(__x86_64__)
    Vector3 modelOrigin{};
    if (ox_pcReadVisualOrigin(g_localPlayer, now, modelOrigin))
        body = modelOrigin;
#endif
    unsigned char snapshot[WINDOW];
    if (!pvm((void*)nativeCam, snapshot, sizeof(snapshot), false)) {
        // Read failure is not a negative discovery result; retry next frame.
        g_camViewMatOff = g_camProjMatOff = -1;
        return;
    }
    for (int off = 0; off + 64 <= WINDOW; off += STEP) {
        OxMat4 M;
        memcpy(&M, snapshot + off, sizeof(M));

        Vector3 candidateEye;
        const bool eyeNearBody = ox_cameraPosFromView(M, &candidateEye) &&
            (body == Vector3::Zero() ||
             (hypotf(candidateEye.x-body.x,candidateEye.z-body.z)<=4.f &&
              candidateEye.y-body.y>=-1.5f && candidateEye.y-body.y<=3.5f));
        if (g_camViewMatOff == -2 && ox_looksLikeViewMatrix(M) && eyeNearBody) {
            g_camViewMatOff = off;
            OXLOGI("[cammat] view-матрица найдена @+0x%X  t=(%.2f %.2f %.2f)",
                   off, M.m[12], M.m[13], M.m[14]);
        }
        if (g_camProjMatOff == -2 && ox_looksLikeProjMatrix(M)) {
            g_camProjMatOff = off;
            OXLOGI("[cammat] proj-матрица найдена @+0x%X  m00=%.4f m11=%.4f",
                   off, M.m[0], M.m[5]);
        }
        if (g_camViewMatOff >= 0 && g_camProjMatOff >= 0) break;
    }

    if (g_camViewMatOff < 0)
        OXLOGI("[cammat] view-матрица НЕ найдена в окне 0x%X", WINDOW);
    if (g_camProjMatOff < 0)
        OXLOGI("[cammat] proj-матрица НЕ найдена в окне 0x%X", WINDOW);
}

// Достаёт нативный объект камеры из PM. Возвращает 0 если не вышло.
static uint64_t ox_getNativeCamera(uint64_t player) {
    if (!ox_isPtr(player)) return 0;
    uint64_t rm=0, camManaged=0, native=0;
    if (!pvm((void*)(player + ox::PM_RAYCASTMANAGER), &rm, sizeof(rm), false) || !ox_isPtr(rm)) return 0;
    if (!pvm((void*)(rm + ox::RM_WORLD_CAMERA), &camManaged, sizeof(camManaged), false) || !ox_isPtr(camManaged)) return 0;
    if (!pvm((void*)(camManaged + ox::OBJ_CACHED_PTR), &native, sizeof(native), false)) return 0;
    return ox_isPtr(native) ? native : 0;
}

// Позиция камеры ИЗ view-матрицы. Для ортонормированной view-матрицы
// V = [R | t], где t = -R * eye, поэтому eye = -R^T * t.
// Критично для аимбота: углы доворота обязаны считаться от ТОЙ ЖЕ точки, из
// которой строится проекция. Если брать позицию из worldCameraRoot (наша
// реконструкция), а проецировать матрицей — прицел уезжает по вертикали
// ровно на разницу этих двух точек. Это и был симптом «целит выше игрока».
static bool ox_cameraPosFromView(const OxMat4 &V, Vector3 *out) {
    if (!out) return false;
    // Column-major: столбец i = {V.m[i*4+0], V.m[i*4+1], V.m[i*4+2]}.
    // R^T * t: строки R — это компоненты одного индекса по всем столбцам.
    float tx = V.m[12], ty = V.m[13], tz = V.m[14];
    out->x = -(V.m[0]*tx + V.m[1]*ty + V.m[2]*tz);
    out->y = -(V.m[4]*tx + V.m[5]*ty + V.m[6]*tz);
    out->z = -(V.m[8]*tx + V.m[9]*ty + V.m[10]*tz);
    return isfinite(out->x) && isfinite(out->y) && isfinite(out->z);
}

// Читает VP = proj * view из нативной камеры. false если смещения неизвестны.
static bool ox_readViewProjection(uint64_t nativeCam, OxMat4 *outVP) {
    if (!outVP || !ox_isPtr(nativeCam)) return false;
    if (g_camViewMatOff < 0 || g_camProjMatOff < 0) return false;

    OxMat4 V, P;
    // Bulk read bypasses frame-cache blocks populated by slow metadata scans.
    // This is NOT an atomic snapshot of Unity; structural validation still
    // rejects torn/invalid matrices, with at most one immediate fresh retry.
    unsigned char snapshot[0x600];
    const int lo = std::min(g_camViewMatOff, g_camProjMatOff);
    const int hi = std::max(g_camViewMatOff, g_camProjMatOff) + (int)sizeof(OxMat4);
    if (lo < 0 || hi > (int)sizeof(snapshot)) return false;
    bool valid=false;
    for (int attempt=0; attempt<2 && !valid; ++attempt) {
        if (!pvm((void*)(nativeCam+lo), snapshot, (size_t)(hi-lo), false)) continue;
        memcpy(&V, snapshot+g_camViewMatOff-lo, sizeof(V));
        memcpy(&P, snapshot+g_camProjMatOff-lo, sizeof(P));
        valid=ox_looksLikeViewMatrix(V) && ox_looksLikeProjMatrix(P);
    }
    if (!valid) return false;

    Vector3 eye;
    OxMat4 vp;
    if (!ox_cameraPosFromView(V, &eye) || !overlaycore::Compose(V.m,P.m,vp.m)) return false;
    // Commit only a fully validated snapshot; failed reads do not corrupt the lease.
    g_camView = V;
    g_camPosFromMatrix = eye;
    g_camPosValid = true;
    *outVP = vp;
    return true;
}

// World -> screen через настоящую VP-матрицу игры.
// Возвращает false если точка за камерой или матрицы недоступны.
static bool ox_w2sMatrix(const OxMat4 &VP, const Vector3 &p,
                         float screenW, float screenH, ImVec2 *out) {
    if (!out) return false;
    float cx = VP.m[0]*p.x + VP.m[4]*p.y + VP.m[8]*p.z  + VP.m[12];
    float cy = VP.m[1]*p.x + VP.m[5]*p.y + VP.m[9]*p.z  + VP.m[13];
    float cw = VP.m[3]*p.x + VP.m[7]*p.y + VP.m[11]*p.z + VP.m[15];
    if (cw < 0.01f) return false;             // за камерой
    float ndcX = cx / cw, ndcY = cy / cw;
    if (!isfinite(ndcX) || !isfinite(ndcY)) return false;
    out->x = (ndcX * 0.5f + 0.5f) * screenW;
    out->y = (1.f - (ndcY * 0.5f + 0.5f)) * screenH;   // Y вниз в экранных
    return true;
}

// ============================================================================
//  ЯКОРЯ МОДЕЛИ — привязка ESP к тому, что игра РИСУЕТ, а не к серверному тику
//
//  Проблема старого пути: позиция бралась из PM.lastTickPosition (0x1C8) —
//  это серверный тик, 10-20 Гц. Модель на экране между тиками движется
//  интерполированно, поэтому бокс отставал от бегущей цели на 0.5-1 м, и
//  вертикальную привязку приходилось подгонять руками (espBoxYOffset).
//
//  Новый путь берёт данные ровно из тех объектов, по которым игра строит кадр:
//    KCC.head (0x88)                      -> Transform головы, интерполирован
//    KCC.Motor(0x68).LastInterpolatedPosition(0x1EC) -> позиция ног этого кадра
//
//  Габариты бокса теперь ФАКТИЧЕСКИЕ (от ног до головы), а не «позиция + 1.8 м
//  на глаз». Вертикальный оффсет при этом не нужен вообще.
// ============================================================================

struct OxModelAnchors {
    Vector3 head{0,0,0};    // мировая позиция головы (реальная кость)
    Vector3 feet{0,0,0};    // мировая позиция ног (интерполированная мотором)
    float   height = 0.f;   // фактический рост = head.y - feet.y
    bool    valid  = false;
    // Диагностика: на каком шаге оборвалась цепочка.
    // 0 = ок, 1 = нет kccReference, 2 = не нашли KCC ни в обёртке ни напрямую,
    // 3 = не прочитался трансформ головы, 4 = нет позиции ног,
    // 5 = геометрия не прошла санити (см. lastDy / lastDxz).
    int      failStage = 0;
    uint64_t kccPtr    = 0;
    float    lastDy    = 0.f;
    float    lastDxz   = 0.f;
    // Живые данные капсулы: высота этого кадра и признак приседа.
    uint64_t headTr    = 0;     // Transform головы (для диагностики stage 3)
    uint64_t headCached = 0;    // его m_CachedPtr
    uint64_t headMatrix = 0;    // matrixData внутри нативного трансформа
    bool     headFromCapsule = false; // голова взята геометрически, не из кости
    float    capsuleH  = 0.f;   // Motor.CapsuleHeight сейчас
    float    normalH   = 0.f;   // KCC.normalHeight (рост стоя)
    float    radius    = 0.f;   // Motor.CapsuleRadius — основа ширины бокса
    bool     crouching = false; // высота просела ниже 85% от нормальной
    Vector3  velocity{0,0,0};   // Motor.BaseVelocity — точнее численной производной
};

// Читает якоря модели игрока. ~6 точечных vm_readv, никаких сканов.
// Возвращает valid=false если цепочка оборвана или геометрия не прошла
// санити-чек — вызывающий тогда откатывается на старый путь.
static OxModelAnchors ox_readModelAnchors(uint64_t player) {
    OxModelAnchors a;
    if (!ox_isPtr(player)) return a;

    // PM.kccReference — это InterfaceReference<sA>, MANAGED-ОБЪЁКТ, а не сам KCC.
    // В дампе его поле _component значится на +0x0, но это смещение внутри
    // блока данных: у managed-объекта первые 0x10 байт занимает заголовок
    // (klass + monitor). Реальный KCC лежит на +0x10 от обёртки.
    // Пробуем оба варианта — на случай если поле инлайнится напрямую.
    uint64_t kccRaw = rpm<uint64_t>(player + ox::PM_KCC_REFERENCE);
    if (!ox_isPtr(kccRaw)) { a.failStage = 1; return a; }

    // Ищем настоящий KCC САМОПРОВЕРКОЙ, а не угадыванием смещения внутри
    // обёртки: у KCC поле player (+0x78) указывает ОБРАТНО на наш PM. Такое
    // совпадение случайным быть не может, поэтому проверка однозначна и
    // переживёт любую перетасовку полей InterfaceReference.
    // v9 (подтверждённо рабочая) проверка: back-ref KCC.player==PM. Мотор-проверку
    // из v10 откатил — она в критическом пути и могла отвергать валидный KCC, у
    // которого Motor на момент кадра ещё не присвоен.
    auto isRealKcc = [&](uint64_t cand) -> bool {
        if (!ox_isPtr(cand)) return false;
        return rpm<uint64_t>(cand + ox::KCC_PLAYER) == player;
    };

    uint64_t kcc = 0;
    if (isRealKcc(kccRaw)) {
        kcc = kccRaw;                       // поле хранит KCC напрямую
    } else {
        // Обёртка: перебираем её первые 0x40 байт — _component лежит там.
        for (int w = 0x00; w <= 0x30 && !kcc; w += 8) {
            uint64_t cand = rpm<uint64_t>(kccRaw + w);
            if (isRealKcc(cand)) kcc = cand;
        }
    }
    if (!kcc) { a.failStage = 2; return a; }
    a.kccPtr = kcc;

    // UPDATE 2026/07/31 v10: КРИТИЧЕСКИЙ ФИКС "боксы прилипли к камере".
    // Из лога: kcc self-verified (KCC.player@0x78 == PM), НО KCC.head@0x88 == 0x0
    // для ВСЕХ удалённых игроков (headTr=0x0, stage=3, anchors=0/N каждый кадр).
    // Причина: `head` Transform (FP-риг точки глаз) инстанцируется движком ТОЛЬКО
    // для ЛОКАЛЬНОГО игрока. У remote-игроков он null — их модель это TP-скелет.
    // СТАРЫЙ БАГ: `if (!ox_isPtr(headTr)) { failStage=3; return; }` возвращался
    // ДО Motor-фолбэка. Из-за этого W2S не получал НИ ОДНОГО валидного якоря →
    // ESP рисовал по устаревшим экранным координатам → боксы «прилипали к экрану»
    // и ехали вместе с камерой. Теперь head=null НЕ фатален: сразу идём в Motor
    // (feet + CapsuleHeight), который есть у всех игроков.
    // ═══════════════════════════════════════════════════════════════════════
    // UPDATE 2026/07/31 v17: ФУНДАМЕНТАЛЬНЫЙ ФИКС «боксы застряли на спавне».
    // ═══════════════════════════════════════════════════════════════════════
    // Доказано сравнением v9-лога (рабочего) и v13:
    //   v9: stage=0 (успех) = 0 раз, stage=3 (обрыв на head=null) = 61 раз.
    //       → anchor ВСЕГДА падал у remote, бокс откатывался на livePos
    //         (PM.lastTickPosition) — и та ДВИГАЛАСЬ. Поэтому v9 работал.
    //   v13: мой v10-«фикс» заставил anchor УСПЕВАТЬ через Motor-фолбэк.
    //        anch.feet = Motor.LastInterpolatedPosition, а она ЗАМОРОЖЕНА у
    //        remote-игроков (их KinematicCharacterMotor локально НЕ симулируется,
    //        позиция приходит через networkPositionObserver, не в Motor).
    //        В логе: pos=(-10.74,10.38,71.52) не менялась 7 кадров подряд.
    //
    // ВЫВОД: Motor.LastInterpolatedPosition НЕЛЬЗЯ использовать для позиции
    // remote-игроков. Единственный ДВИЖУЩИЙСЯ источник — PM.lastTickPosition.
    // Motor даёт только СКАЛЯР высоты капсулы (он валиден, cap=1.25 в логе) —
    // им пользуемся для роста бокса, но НЕ для позиции.
    //
    // Новый порядок:
    //   feet = PM.lastTickPosition (ДВИЖЕТСЯ — сервер-тик, интерполируется игрой)
    //   height = Motor.CapsuleHeight (скаляр, для верха бокса)
    //   head = feet + height + lookOffset
    uint64_t motor = rpm<uint64_t>(kcc + ox::KCC_MOTOR);

    // --- Ноги: ТОЛЬКО lastTickPosition (единственный движущийся источник) ---
    Vector3 tickPos = rpm<Vector3>(player + ox::PM_LAST_TICK_POS);
    bool haveFeet = false;
    if (isfinite(tickPos.x) && isfinite(tickPos.y) && isfinite(tickPos.z) &&
        (fabsf(tickPos.x) > 0.001f || fabsf(tickPos.z) > 0.001f)) {
        a.feet = tickPos; haveFeet = true;
    }
    // Фолбэк если tick пуст (первые кадры): lastSavedPosition.
    if (!haveFeet) {
        Vector3 savedPos = rpm<Vector3>(player + ox::PM_LAST_SAVED_POS);
        if (isfinite(savedPos.x) && (fabsf(savedPos.x) > 0.001f || fabsf(savedPos.z) > 0.001f)) {
            a.feet = savedPos; haveFeet = true;
        }
    }
    if (!haveFeet) { a.failStage = 4; return a; }

    // --- Высота капсулы (скаляр) из Motor — для роста бокса ---
    float capH = 1.80f;   // дефолт-рост если Motor не прочитался
    a.headTr = rpm<uint64_t>(kcc + ox::KCC_HEAD);   // для диагностики
    if (ox_isPtr(motor)) {
        float ch = rpm<float>(motor + ox::MOTOR_CAPSULE_HEIGHT);
        if (isfinite(ch) && ch > 0.3f && ch < 3.5f) capH = ch;
    }
    a.capsuleH = capH;

    // --- Голова = ноги + высота капсулы + lookHeightOffset ---
    float lo = rpm<float>(kcc + ox::KCC_LOOK_HEIGHT_OFF);
    if (!isfinite(lo) || lo < -1.f || lo > 1.f) lo = 0.f;
    a.head = Vector3(a.feet.x, a.feet.y + capH + lo, a.feet.z);
    a.headFromCapsule = true;

    // --- Санити: рост человека и голова примерно над ногами ---
    // Отсекает мусор от переиспользованной памяти и чужие указатели.
    float dy  = a.head.y - a.feet.y;
    float dx  = a.head.x - a.feet.x;
    float dz  = a.head.z - a.feet.z;
    float dxz = sqrtf(dx*dx + dz*dz);
    if (!isfinite(dy) || dy < 0.40f || dy > 2.60f || dxz > 1.50f) {
        a.failStage = 5; a.lastDy = dy; a.lastDxz = dxz; return a;
    }

    a.lastDy = dy; a.lastDxz = dxz;
    a.height = dy;

    // --- Живая геометрия капсулы: присед и скорость ---
    if (ox_isPtr(motor)) {
        float ch = rpm<float>(motor + ox::MOTOR_CAPSULE_HEIGHT);
        float nh = rpm<float>(kcc   + ox::KCC_NORMAL_HEIGHT);
        if (isfinite(ch) && ch > 0.2f && ch < 4.0f) a.capsuleH = ch;
        if (isfinite(nh) && nh > 0.2f && nh < 4.0f) a.normalH  = nh;
        float cr = rpm<float>(motor + ox::MOTOR_CAPSULE_RADIUS);
        if (isfinite(cr) && cr > 0.10f && cr < 1.0f) a.radius = cr;
        if (a.capsuleH > 0.f && a.normalH > 0.f)
            a.crouching = (a.capsuleH < a.normalH * 0.85f);

        Vector3 v = rpm<Vector3>(motor + ox::MOTOR_BASE_VELOCITY);
        if (isfinite(v.x) && isfinite(v.y) && isfinite(v.z) &&
            fabsf(v.x) < 100.f && fabsf(v.y) < 100.f && fabsf(v.z) < 100.f)
            a.velocity = v;
    }
    a.valid  = true;
    return a;
}

// ============================================================================
//  СКЕЛЕТ — чтение реальных костей модели игрока
//
//  Цепочка (оффсеты из il2cpp.h дампа 2026/07/24):
//    PM + PM_ANIMATOR(0x190)                -> UnityEngine.Animator
//    Animator..CharacterAnimation           -> ищем через PM.characterModel
//    CharacterAnimation + 0x30              -> PlayerModelInfo
//    PlayerModelInfo + 0x20 head            -> Transform головы
//                    + 0x28 rightWeaponHolder -> Transform правой кисти
//                    + 0x30 leftWeaponHolder  -> Transform левой кисти
//                    + 0x40 body            -> Transform корпуса
//    CharacterAnimation + 0x38              -> Ragdoll
//    Ragdoll + 0x20 m_Pelvis                -> Rigidbody таза
//
//  Читаем ЧЕТЫРЕ реальные кости (голова, корпус, две кисти) + таз, остальные
//  суставы достраиваем интерполяцией. Так на игрока уходит ~10 vm_readv вместо
//  ~45 при полном обходе скелета — важно, потому что watchdog игры реагирует
//  на объём чтений.
// ============================================================================

// ── ЖИВОЙ скелет ────────────────────────────────────────────────────────────
//  Настоящие кости модели. Иерархия нативных Transform читается напрямую (bones.h): раскладка
//  записей подбирается самокалибровкой по нескольким Transform одной модели, кости опознаются по
//  топологии гуманоида, каждый кадр читаются только нужные узлы одним системным вызовом. Поза —
//  то, что аниматор игры реально выставил, включая пальцы и носки; никакой дорисованной анимации.
//  Если кости прочитать не удалось, остаются только настоящие опорные точки (голова, корпус,
//  держатели оружия), остальное достроено по пропорциям и стоит на месте; в логе — причина.
struct OxMem {
    bool rd(uint64_t a, void *b, size_t n) { return vm_readv((unsigned long)a, b, n); }
    bool rdMulti(const uint64_t *a, int n, size_t each, void *out) { return vm_readv_multi(a, n, each, out); }
    bool isPtr(uint64_t p) { return ox_isPtr(p); }
};

static oxbone::Layout    g_trs;                 // раскладка Transform: одна на всю игру
static double            g_trsNextTry = 0.0;
static int               g_trsTries = 0;
static int               g_trsBadModels = 0;    // подряд моделей, на которых найденная раскладка не сработала
static oxskel::AxisCalib g_headAxis;            // какая локальная ось головной кости смотрит вперёд

struct OxSkelState {
    bool     linked = false;
    double   nextLink = 0.0;
    uint64_t tr[6] = {0, 0, 0, 0, 0, 0};        // управляемые Transform: голова, корпус, правая/левая рука, снаряжение, голова-модель
    uint64_t nat[6] = {0, 0, 0, 0, 0, 0};       // их нативные объекты
    int      natN = 0;
    oxbone::BoneState bone;
    int      mapFails = 0;
    double   lastBone = 0.0, lastGood = 0.0;
    float    yaw = 0.f;
    bool     haveYaw = false;
    double   nextMisc = 0.0;
    oxskel::Pose pose;
    oxskel::V3 poseFeet{};
    bool     havePose = false;
    int      src = 0;                           // 1 — кости модели, 2 — опорные точки
    int      srcLogged = -1;
    double   lastSeen = 0.0, nextLog = 0.0, nextStat = 0.0, nextCheck = 0.0;
#if defined(__x86_64__)
    Vector3  visualOrigin{0,0,0};
    double   visualStamp = -1.0;
#endif
};
static std::unordered_map<uint64_t, OxSkelState> g_skelStates;

// Expensive hierarchy/format discovery must never stall the drawing thread.
// Capture the PID as well as addresses: a job may outlive a game restart.
struct OxDiscoveryMem {
    int pid;
    int fd = -1;
    ~OxDiscoveryMem() { if (fd >= 0) close(fd); }
    bool rd(uint64_t a,void *b,size_t n) {
        if (!a || !b || !n) return false;
        iovec local{b,n}, remote{(void*)a,n};
        if (syscall(SYS_process_vm_readv,pid,&local,1,&remote,1,0)==(ssize_t)n) return true;
#if defined(__x86_64__)
        // BlueStacks rejects process_vm_readv for this process while
        // /proc/<pid>/mem remains readable. Discovery must use the same
        // fallback as regular game-memory reads, with one fd per job.
        if (fd < 0) {
            char path[64];
            snprintf(path,sizeof(path),"/proc/%d/mem",pid);
            fd=open(path,O_RDONLY | O_CLOEXEC);
        }
        return fd >= 0 && pread(fd,b,n,(off_t)a)==(ssize_t)n;
#else
        return false;
#endif
    }
    bool isPtr(uint64_t p) { return ox_isPtr(p); }
};
struct OxBoneDiscovery {
    bool calibration=false, ok=false;
    int pid=0, generation=0;
    uint64_t player=0, head=0, owner=0;
    oxbone::Layout layout;
    oxbone::BoneState bone;
    oxbone::CalibReport report;
};
static overlaycore::DiscoveryJob<OxBoneDiscovery> g_boneDiscovery;
static int g_boneGeneration=1;

static void ox_takeBoneDiscovery(double now) {
    OxBoneDiscovery r;
    if (!g_boneDiscovery.Take(r)) return;
    if (r.pid!=game_pid || r.owner!=g_localPlayer || r.generation!=g_boneGeneration) return;
    auto it=g_skelStates.find(r.player);
    if (it==g_skelStates.end()) return;
    OxSkelState &st=it->second;
    if (!st.linked || st.nat[0]!=r.head || now-st.lastSeen>3.) return;
    uint64_t native=0;
    if (!vm_readv(st.tr[0]+ox::OBJ_CACHED_PTR,&native,sizeof(native)) || native!=r.head) return;
    if (r.calibration) {
        if (r.ok && !g_trs.ok) {
            g_trs=r.layout; g_trsBadModels=0; ++g_boneGeneration;
            OXLOGI("[skel] background layout ready: hier=+0x%x index=+0x%x local=+0x%x parent=+0x%x stride=0x%x (%d reads)",
                   g_trs.hierOff,g_trs.idxOff,g_trs.localOff,g_trs.parentOff,g_trs.fmt.stride,r.report.reads);
        } else if (!r.ok && (g_trsTries <= 3 || g_trsTries % 5 == 0)) {
            OXLOGW("[skel] layout not found: native=%d hierarchy=%d pointers=%d parent=%d world=%d reads=%d",
                   r.report.nNat,r.report.nHier,r.report.nPtr,r.report.parentOk,r.report.worldOk,r.report.reads);
        }
        return;
    }
    if (r.ok) {
        st.bone=std::move(r.bone); st.mapFails=0;
        st.bone.nextMap=now+.2;
    } else {
        ++st.mapFails;
        if (st.mapFails == 1 || st.mapFails == 3)
            OXLOGW("[skel] pm=0x%llx: bone map failed: %s",(unsigned long long)r.player,r.bone.why);
        st.bone.nextMap=now+fmin(10.,(double)st.mapFails);
        if (st.mapFails==3 && ++g_trsBadModels>=3) {
            g_trs.ok=false;g_trsBadModels=0;++g_boneGeneration;
        }
    }
}

// PM -> KCC -> CharacterAnimation -> PlayerModelInfo -> Transform'ы модели. Каждое звено проверяется обратной ссылкой.
static bool ox_skelLink(uint64_t player, OxSkelState &st) {
    const uint64_t wrap = rpm<uint64_t>(player + ox::PM_KCC_REFERENCE);
    if (!ox_isPtr(wrap)) return false;
    uint64_t kcc = 0, span = 0;
    for (int w = -8; w <= 0x40 && !kcc; w += 8) {
        const uint64_t cand = (w < 0) ? wrap : rpm<uint64_t>(wrap + (uint64_t)w);
        if (!ox_isPtr(cand)) continue;
        if (rpm<uint64_t>(cand + ox::KCC_PLAYER) == player)       { kcc = cand; span = 0x1F0; }
        else if (rpm<uint64_t>(cand + ox::SKCC_PLAYER) == player) { kcc = cand; span = 0x210; }
    }
    if (!kcc) return false;
    uint64_t chunk[0x210 / 8 + 2];
    const size_t cnt = (size_t)((span - 0x60) / 8);
    if (!vm_readv(kcc + 0x60, chunk, cnt * 8)) return false;
    // Достаточно двойной ссылки CharacterAnimation(0x30) <-> PlayerModelInfo(0x60); совпадение PlayerManager (0x78)
    // с нашим игроком только предпочтительнее: у чужих игроков это поле может быть не заполнено.
    uint64_t pmi = 0, pmiLoose = 0;
    for (size_t i = 0; i < cnt && !pmi; ++i) {
        const uint64_t c = chunk[i];
        if (!ox_isPtr(c)) continue;
        const uint64_t m = rpm<uint64_t>(c + ox::CHARANIM_MODELINFO);
        if (!ox_isPtr(m) || rpm<uint64_t>(m + ox::PMI_CHAR_ANIM) != c) continue;
        if (rpm<uint64_t>(c + ox::CHARANIM_PLAYER) == player) pmi = m;
        else if (!pmiLoose) pmiLoose = m;
    }
    if (!pmi) pmi = pmiLoose;
    if (!pmi) return false;
    static const uint64_t offs[6] = { ox::PMI_HEAD, ox::PMI_BODY, ox::PMI_RIGHT_HAND, ox::PMI_LEFT_HAND, ox::PMI_EQUIPMENT, ox::PMI_HEAD_MODEL };
    st.natN = 0;
    for (int i = 0; i < 6; ++i) {
        st.tr[i] = rpm<uint64_t>(pmi + offs[i]);
        st.nat[i] = 0;
        if (!ox_isPtr(st.tr[i])) { st.tr[i] = 0; continue; }
        const uint64_t n = rpm<uint64_t>(st.tr[i] + ox::OBJ_CACHED_PTR);
        if (ox_isPtr(n)) { st.nat[i] = n; ++st.natN; }
    }
#if defined(__x86_64__)
    // PC uses only this Transform's world position. Requiring a second bone
    // hides an otherwise valid moving model when optional anchors are absent.
    return st.nat[0] != 0;
#else
    return st.nat[0] != 0 && st.natN >= 2;
#endif
}

#if defined(__x86_64__)
// On PC the PM position fields stay zero and the KCC Motor can remain at spawn.
// The model Transform moves with the visible player. For remote players its
// world position is near the feet, despite the field being called "head" in
// PlayerModelInfo. Use it for ESP and targeting alike.
static bool ox_pcReadVisualOrigin(uint64_t player, double now, Vector3 &out, bool allowStale) {
    if (!ox_isPtr(player) || !std::isfinite(now)) return false;
    static double nextPrune = 0.0;
    if (now >= nextPrune) {
        nextPrune = now + 2.0;
        for (auto it = g_skelStates.begin(); it != g_skelStates.end();)
            it = now - it->second.lastSeen > 3.0 ? g_skelStates.erase(it) : std::next(it);
    }
    OxSkelState &st = g_skelStates[player];
    st.lastSeen = now;
    // The camera, roster scan, and ESP can ask for the same player within one
    // frame. Reuse that sample without delaying the next rendered frame.
    if (st.visualStamp >= 0.0 && now - st.visualStamp >= 0.0 &&
        now - st.visualStamp < 0.005) {
        out = st.visualOrigin;
        return true;
    }
    if (!st.linked && now >= st.nextLink) {
        st.linked = ox_skelLink(player, st);
        if (!st.linked) st.nextLink = now + 0.5;
    }
    if (st.linked && st.tr[0]) {
        const uint64_t native = rpm<uint64_t>(st.tr[0] + ox::OBJ_CACHED_PTR);
        if (ox_isPtr(native) && native != st.nat[0]) {
            st.linked = false;
            st.havePose = false;
            st.bone = oxbone::BoneState{};
            st.visualStamp = -1.0;
            st.nextLink = now + 0.1;
        } else if (native == st.nat[0]) {
            Vector3 origin{};
            if (ox_transformWorld(st.tr[0], &origin, nullptr, false, nullptr) &&
                isfinite(origin.x) && isfinite(origin.y) && isfinite(origin.z) &&
                fabsf(origin.x) < 100000.f && fabsf(origin.y) < 100000.f &&
                fabsf(origin.z) < 100000.f &&
                (fabsf(origin.x) + fabsf(origin.y) + fabsf(origin.z)) > 0.001f &&
                !(fabsf(origin.x) < 0.05f && fabsf(origin.z) < 0.05f &&
                  fabsf(origin.y + 1.60f) < 0.20f)) {
                st.visualOrigin = origin;
                st.visualStamp = now;
                out = origin;
                return true;
            }
        }
    }
    // A single failed read should not snap the box back to the static Motor.
    if (allowStale && st.visualStamp >= 0.0 && now - st.visualStamp <= 0.25) {
        out = st.visualOrigin;
        return true;
    }
    return false;
}
#endif

static void ox_skelDumpTree(const oxbone::BoneState &b, const oxskel::V3 &feet) {
    static bool done = false;
    if (done) return;
    done = true;
    static const char *jn[oxskel::J_COUNT] = { "HEAD", "NECK", "CHEST", "SPINE", "PELVIS", "SH_R", "SH_L", "EL_R", "EL_L", "HAND_R", "HAND_L",
                                               "HIP_R", "HIP_L", "KNEE_R", "KNEE_L", "FOOT_R", "FOOT_L", "TOE_R", "TOE_L" };
    OXLOGI("[skel] ── дерево модели: узлов=%d (узел parent  x y z относительно ног  метка) ──", b.N);
    int printed = 0;
    for (int i = 0; i < b.N && printed < 320; ++i) {
        if (!b.have[i]) continue;
        const char *tag = "";
        for (int k = 0; k < oxskel::J_COUNT; ++k) if (b.map.j[k] == i) tag = jn[k];
        const oxskel::V3 w = b.wp[i];
        OXLOGI("[skel]  %3d %4d  %6.2f %6.2f %6.2f  %s", i, b.parent[i], w.x - feet.x, w.y - feet.y, w.z - feet.z, tag);
        ++printed;
    }
}

// Настоящие кости модели. true — поза заполнена.
static bool ox_boneRead(uint64_t player, OxSkelState &st, const Vector3 &feet, float ref, double now, oxskel::Pose &out) {
    OxMem mem;
    if (!st.linked) {
        if (now < st.nextLink) return false;
        st.linked = ox_skelLink(player, st);
        if (!st.linked) {
            st.nextLink = now + 1.5;
            if (now >= st.nextLog) { st.nextLog = now + 8.0; OXLOGW("[skel] pm=0x%llx: цепочка до PlayerModelInfo не найдена", (unsigned long long)player); }
            return false;
        }
        OXLOGI("[skel] pm=0x%llx: модель найдена, Transform'ов=%d (голова native=0x%llx)", (unsigned long long)player, st.natN, (unsigned long long)st.nat[0]);
    }
    // The visual-origin reader may have linked this model before skeleton
    // discovery. Always bind the native Transform before asking Map to read it.
    if (st.bone.internal != st.nat[0]) {
        st.bone = oxbone::BoneState{};
        st.bone.internal = st.nat[0];
        st.havePose = false;
    }
    const oxskel::V3 fv{ feet.x, feet.y, feet.z };
    ox_takeBoneDiscovery(now);
    if (!g_trs.ok) {
        if (st.natN < 2) return false; // calibration needs distinct model transforms
        if (now < g_trsNextTry || !g_boneDiscovery.Available()) return false;
        OxBoneDiscovery request;
        request.calibration=true; request.pid=game_pid;
        request.generation=g_boneGeneration; request.player=player;
        request.head=st.nat[0]; request.owner=g_localPlayer;
        std::vector<uint64_t> nats;
        for (int i=0;i<6;++i) if (st.nat[i]) nats.push_back(st.nat[i]);
        if (g_boneDiscovery.Start([request,nats,fv]() mutable {
            OXLOGI("[skel-worker] calibrate tid=%ld player=0x%llx transforms=%zu",
                   (long)syscall(SYS_gettid), (unsigned long long)request.player, nats.size());
            OxDiscoveryMem mem{request.pid};
#if defined(__x86_64__)
            // On this client the cached +0x90 value of "head" is the model
            // origin. It is not independent bone-position ground truth.
            request.ok=oxbone::Calibrate(mem,request.layout,nats.data(),(int)nats.size(),fv,
                &request.report,0,0);
#else
            request.ok=oxbone::Calibrate(mem,request.layout,nats.data(),(int)nats.size(),fv,
                &request.report,(int)ox::TR_INT_MATRIXPTR,(int)ox::TR_MATRIX_WORLDPOS);
#endif
            return request;
        })) {
            g_trsNextTry=now+fmin(30.,2.+2.*g_trsTries);
            ++g_trsTries;
        }
        return false; // anchor path draws while discovery is pending
    }
    const float yaw = st.yaw;
    const oxskel::V3 right{ cosf(yaw), 0, -sinf(yaw) }, fwd{ sinf(yaw), 0, cosf(yaw) };
    if (!st.bone.mapped) {
        if (now < st.bone.nextMap || !g_boneDiscovery.Available()) return false;
        OxBoneDiscovery request;
        request.pid=game_pid;request.generation=g_boneGeneration;
        request.player=player;request.head=st.nat[0];request.owner=g_localPlayer;
        request.layout=g_trs;request.bone=st.bone;
        if (g_boneDiscovery.Start([request,ref,right]() mutable {
            OXLOGI("[skel-worker] map tid=%ld player=0x%llx",
                   (long)syscall(SYS_gettid), (unsigned long long)request.player);
            OxDiscoveryMem mem{request.pid};
            request.ok=oxbone::Map(mem,request.layout,request.bone,ref,right);
            return request;
        })) st.bone.nextMap=now+.2;
        return false;
    }
    if (!oxbone::ReadPose(mem, g_trs, st.bone, fv, ref, right, fwd, g_headAxis, out)) {
        if (now >= st.nextLog) { st.nextLog = now + 6.0; OXLOGW("[skel] pm=0x%llx: поза не прочитана: %s", (unsigned long long)player, st.bone.why); }
        return false;
    }
    g_trsBadModels = 0;
#ifdef OX_DEEP_CAMERA_DIAG
    if (now >= st.nextCheck) {                        // сверка цепочки локальных TRS с кэшем мировой позиции движка
        st.nextCheck = now + 10.0;
        Vector3 cached;
        if (st.tr[0] && ox_transformWorld(st.tr[0], &cached, nullptr, false, nullptr))
            OXLOGI("[skel] pm=0x%llx: сверка головы: цепочка=(%.2f %.2f %.2f) кэш движка=(%.2f %.2f %.2f) разница=%.3f м",
                   (unsigned long long)player, out.j[oxskel::J_HEAD].x, out.j[oxskel::J_HEAD].y, out.j[oxskel::J_HEAD].z, cached.x, cached.y, cached.z,
                   len(oxskel::V3{ out.j[oxskel::J_HEAD].x - cached.x, out.j[oxskel::J_HEAD].y - cached.y, out.j[oxskel::J_HEAD].z - cached.z }));
    }
#endif
    return true;
}

// Запасной путь: настоящие опорные точки, остальное достроено, анимации нет.
static bool ox_anchorRead(OxSkelState &st, const Vector3 &feet, float S, float crouch, oxskel::Pose &out) {
#if defined(__x86_64__)
    // When hierarchy discovery is pending, use any plausible live anchors.
    // The Transform named "head" reports model origin on this client, so its
    // cached position is only a head anchor if it is actually above the feet.
    if (!isfinite(feet.x) || !isfinite(feet.y) || !isfinite(feet.z)) return false;
    auto anchor = [&](int i, Vector3 &p, float minY, float maxY) {
        if (!st.tr[i] || !ox_transformWorld(st.tr[i],&p,nullptr,false,nullptr)) return false;
        const float dx=p.x-feet.x,dz=p.z-feet.z,dy=p.y-feet.y;
        return isfinite(dx) && isfinite(dy) && isfinite(dz) &&
            hypotf(dx,dz)<1.5f && dy>=minY && dy<=maxY;
    };
    Vector3 head{},body{},rh{},lh{};
    const bool hh=anchor(0,head,0.9f,2.5f);
    const bool hb=anchor(1,body,0.45f,2.1f);
    const bool hr=anchor(2,rh,0.15f,2.3f);
    const bool hl=anchor(3,lh,0.15f,2.3f);
    const float yaw = st.yaw;
    const Vector3 fallbackHead(feet.x,feet.y+S,feet.z);
    const Vector3 &h=hh?head:fallbackHead;
    oxskel::AnchorPose(oxskel::V3{h.x,h.y,h.z},
                       hb?oxskel::V3{body.x,body.y,body.z}:oxskel::V3{},hb,
                       hr?oxskel::V3{rh.x,rh.y,rh.z}:oxskel::V3{},hr,
                       hl?oxskel::V3{lh.x,lh.y,lh.z}:oxskel::V3{},hl,
                       oxskel::V3{feet.x, feet.y, feet.z}, S,
                       oxskel::V3{sinf(yaw), 0, cosf(yaw)},
                       oxskel::V3{cosf(yaw), 0, -sinf(yaw)}, crouch, out);
    return out.ok;
#else
    if (!st.tr[0]) return false;
    Vector3 head, body, rh, lh;
    if (!ox_transformWorld(st.tr[0], &head, nullptr, false, nullptr)) return false;
    const bool hb = st.tr[1] && ox_transformWorld(st.tr[1], &body, nullptr, false, nullptr);
    const bool hr = st.tr[2] && ox_transformWorld(st.tr[2], &rh, nullptr, false, nullptr);
    const bool hl = st.tr[3] && ox_transformWorld(st.tr[3], &lh, nullptr, false, nullptr);
    const float yaw = st.yaw;
    using namespace oxskel;
    AnchorPose(V3{ head.x, head.y, head.z }, hb ? V3{ body.x, body.y, body.z } : V3{}, hb,
               hr ? V3{ rh.x, rh.y, rh.z } : V3{}, hr, hl ? V3{ lh.x, lh.y, lh.z } : V3{}, hl,
               V3{ feet.x, feet.y, feet.z }, S, V3{ sinf(yaw), 0, cosf(yaw) }, V3{ cosf(yaw), 0, -sinf(yaw) }, crouch, out);
    return out.ok;
#endif
}

static bool ox_readSkeleton(uint64_t player, const Vector3 &feet, PlayerCacheData &out, float capH, float normH, float dist) {
    out.hasSkeletonData = false;
    out.skelLive = false;
    out.fineN = 0;
    if (!ox_isPtr(player)) return false;
    const double now = (double)ImGui::GetTime();

    static double s_nextPrune = 0.0;
    if (now > s_nextPrune) {                       // забываем тех, кого не видели 3 с
        s_nextPrune = now + 2.0;
        for (auto it = g_skelStates.begin(); it != g_skelStates.end();)
            it = (now - it->second.lastSeen > 3.0) ? g_skelStates.erase(it) : std::next(it);
    }
    OxSkelState &st = g_skelStates[player];
    st.lastSeen = now;

    const float standH = normH > 0.6f ? normH : 1.80f;
    const float S = ::clamp<float>(standH * 0.92f, 1.2f, 2.4f);
    const oxskel::V3 fv{feet.x,feet.y,feet.z};
    float crouch = 0.f;
    if (capH > 0.3f && normH > 0.6f) crouch = ::clamp<float>((1.0f - capH / normH) / 0.4f, 0.f, 1.f);

    if (now >= st.nextMisc) {                      // направление взгляда: нужно только для имён «правый/левый» и оси лица
        st.nextMisc = now + 1.0 / 15.0;
        const float ya = rpm<float>(player + ox::PM_LOOK_ANGLE);
        if (isfinite(ya) && fabsf(ya) < 1440.f) { st.yaw = ya * 0.01745329252f; st.haveYaw = true; }
    }

    // Частота чтения: вблизи каждый кадр, дальше реже — поза всё равно держится до следующего чтения.
    const double period = dist < 60.f ? 0.0 : (dist < 120.f ? 1.0 / 30.0 : 1.0 / 15.0);
    if (!st.havePose || now - st.lastBone >= period) {
        st.lastBone = now;
        oxskel::Pose p;
        const double t0 = now;
        if (ox_boneRead(player, st, feet, S, now, p)) {
            st.pose = p; st.poseFeet = oxskel::V3{feet.x,feet.y,feet.z};
            st.havePose = true; st.src = 1; st.lastGood = now;
        } else if (st.havePose && st.src == 1 && now - st.lastGood < 0.30
#if defined(__x86_64__)
                   && oxskel::len(fv-st.poseFeet) < 2.0f
#endif
                   ) {
#if defined(__x86_64__)
            // A short read failure must not pin the joints to old world
            // coordinates while the player keeps moving.
            const oxskel::V3 delta=fv-st.poseFeet;
            for (int k=0;k<oxskel::J_COUNT;++k) st.pose.j[k]=st.pose.j[k]+delta;
            for (int k=0;k<st.pose.ne;++k) {
                st.pose.e[k].a=st.pose.e[k].a+delta;
                st.pose.e[k].b=st.pose.e[k].b+delta;
            }
            st.pose.headC=st.pose.headC+delta;
            st.poseFeet=fv;
#endif
        } else if (ox_anchorRead(st, feet, S, crouch, p)) {
            st.pose = p; st.poseFeet = fv; st.havePose = true; st.src = 2;
        }
        if (st.src != st.srcLogged && st.havePose) {
            st.srcLogged = st.src;
            OXLOGI("[skel] pm=0x%llx: источник позы -> %s", (unsigned long long)player, st.src == 1 ? "КОСТИ МОДЕЛИ (живые)" : "опорные точки (кости недоступны, ноги на месте)");
        }
        if (now >= st.nextStat && st.havePose) {
            st.nextStat = now + 5.0;
            OXLOGI("[skel] pm=0x%llx: src=%d узлов=%d читаем=%d d=%.0f м  чтение %.2f мс", (unsigned long long)player, st.src, st.bone.N, st.bone.needN, dist,
                   ((double)ImGui::GetTime() - t0) * 1000.0);
        }
    }
    if (!st.havePose) return false;

    using namespace oxskel;
    const Pose &p = st.pose;
    auto cv = [](V3 v) { return Vector3(v.x, v.y, v.z); };
    out.headPos = cv(p.j[J_HEAD]);         out.neckPos = cv(p.j[J_NECK]);
    out.spine1Pos = cv(p.j[J_CHEST]);      out.spineMidPos = cv(p.j[J_SPINE]);
    out.spine2Pos = cv(p.j[J_PELVIS]);
    out.rshoulderPos = cv(p.j[J_SH_R]);    out.lshoulderPos = cv(p.j[J_SH_L]);
    out.ruparmPos = cv(p.j[J_EL_R]);       out.luparmPos = cv(p.j[J_EL_L]);
    out.rlowarmPos = cv(p.j[J_HAND_R]);    out.llowarmPos = cv(p.j[J_HAND_L]);
    out.rhipPos = cv(p.j[J_HIP_R]);        out.lhipPos = cv(p.j[J_HIP_L]);
    out.rkneePos = cv(p.j[J_KNEE_R]);      out.lkneePos = cv(p.j[J_KNEE_L]);
    out.rfootPos = cv(p.j[J_FOOT_R]);      out.lfootPos = cv(p.j[J_FOOT_L]);
    out.rtoePos = cv(p.j[J_TOE_R]);        out.ltoePos = cv(p.j[J_TOE_L]);
    out.headCenter = cv(p.headC);          out.faceDir = cv(p.face);
    out.headRadius = p.headR;
    out.fineN = p.ne;
    for (int k = 0; k < p.ne; ++k) { out.fineA[k] = cv(p.e[k].a); out.fineB[k] = cv(p.e[k].b); }
    out.skelSrc = st.src;
#if defined(__x86_64__)
    out.skelLive = st.src == 1;
#else
    out.skelLive = true; // preserve the phone's moving-anchor fallback
#endif
    out.hasSkeletonData = true;
    return true;
}

#if defined(__x86_64__)
// On the PC client lastTickPosition may stay zero. The motor's interpolated
// position is a managed Vector3 with offsets verified in the x86_64 dump.
// The interface can contain KCC or SingleKcc; require the PlayerManager
// back-reference before following either component's motor field.
static bool ox_pcReadMotorPos(uint64_t player, Vector3 &out) {
    const uint64_t ref=ox_readDirect<uint64_t>(player+ox::PM_KCC_REFERENCE);
    if (!ox_isPtr(ref)) return false;
    uint64_t kcc=0, motorOff=0;
    auto accept=[&](uint64_t candidate) {
        if (!ox_isPtr(candidate)) return false;
        if (ox_readDirect<uint64_t>(candidate+ox::KCC_PLAYER)==player) {
            kcc=candidate;motorOff=ox::KCC_MOTOR;return true;
        }
        if (ox_readDirect<uint64_t>(candidate+ox::SKCC_PLAYER)==player) {
            kcc=candidate;motorOff=ox::SKCC_MOTOR;return true;
        }
        return false;
    };
    if (!accept(ref)) for (uint64_t off=0;off<=0x30 && !kcc;off+=8) {
        const uint64_t candidate=ox_readDirect<uint64_t>(ref+off);
        accept(candidate);
    }
    if (!kcc) return false;
    const uint64_t motor=ox_readDirect<uint64_t>(kcc+motorOff);
    if (!ox_isPtr(motor)) return false;
    Vector3 pos{};
    if (!pvm((void*)(motor+ox::MOTOR_INTERP_POS),&pos,sizeof(pos),false)) return false;
    if (!isfinite(pos.x) || !isfinite(pos.y) || !isfinite(pos.z) ||
        fabsf(pos.x)>100000.f || fabsf(pos.y)>100000.f || fabsf(pos.z)>100000.f ||
        (fabsf(pos.x)+fabsf(pos.y)+fabsf(pos.z))<0.001f) return false;
    out=pos;
    return true;
}
#endif

// Мировая позиция игрока: managed tick/saved position, then validated fallbacks.
static Vector3 ox_readPos(uint64_t player, bool full) {
    // UPDATE 2026/07/31 v15: ОТКАТ к рабочему v9 варианту. В v13/v14 я переставил
    // приоритет на Motor.LastInterpolatedPosition и characterModel.transform,
    // предположив что lastTickPosition стоит на месте. **Ошибка** — в v9 боксы
    // двигались именно потому что lastTickPosition обновляется. Motor/characterModel
    // как раз стоят на месте для remote-игроков (у них клиентская физика/GO не
    // тикает). Возвращаемся к порядку v9: lastTickPosition → savedPos → transform.
    //
    // Раньше читали worldCameraRoot (@0x68) — у remote игроков он NULL, отсюда
    // ESP крепился к нашей камере вместо тел противников.
    Vector3 tickPos = rpm<Vector3>(player + ox::PM_LAST_TICK_POS);
    if (full) OXLOGT("  lastTickPos = (%.2f, %.2f, %.2f)", tickPos.x, tickPos.y, tickPos.z);
    if (tickPos.x != 0.f || tickPos.y != 0.f || tickPos.z != 0.f) return tickPos;

    // Fallback #1: lastSavedPosition (иногда актуальнее чем lastTickPos на первых кадрах)
    Vector3 savedPos = rpm<Vector3>(player + ox::PM_LAST_SAVED_POS);
    if (savedPos.x != 0.f || savedPos.y != 0.f || savedPos.z != 0.f) {
        if (full) OXLOGT("  lastSavedPos fallback = (%.2f, %.2f, %.2f)", savedPos.x, savedPos.y, savedPos.z);
        return savedPos;
    }

#if defined(__x86_64__)
    Vector3 motorPos{};
    if (ox_pcReadMotorPos(player,motorPos)) {
        if (full) OXLOGT("  PC Motor.LastInterpolatedPosition fallback = (%.2f, %.2f, %.2f)",
                         motorPos.x,motorPos.y,motorPos.z);
        return motorPos;
    }
#endif

    // Fallback #2: worldCameraRoot (работает только для локального игрока)
    Vector3 wPos(0, 0, 0);
    uint64_t transform = rpm<uint64_t>(player + ox::PM_TRANSFORM);
    if (full) oxlog::ptrstep("player + TRANSFORM(0x68)", player + ox::PM_TRANSFORM, transform);
    ox_transformWorld(transform, &wPos, nullptr, full, "  transform + m_CachedPtr(0x10)");
    if (full) OXLOGT("  worldCamRoot fallback = (%.2f, %.2f, %.2f)", wPos.x, wPos.y, wPos.z);
    return wPos;
}

static inline void ox_normalize3(Vector3 &v) {
    float n = sqrtf(v.x*v.x + v.y*v.y + v.z*v.z);
    if (n > 1e-6f) { v.x/=n; v.y/=n; v.z/=n; }
}

// ============================================================================
//  FIX bug #1/#2/#3 — базис камеры ИЗ УГЛОВ (kqP.x pitch, kqP.y yaw).
//  ---------------------------------------------------------------------------
//  Раньше базис брался из МИРОВОГО кватерниона m_LookRoot через нативный
//  Transform (matrixData+0xA0). Это ЛОМАЛОСЬ дважды:
//    (a) matrixData читался по internal+0x28; в Unity Transform_internal 0x28 =
//        `self` (back-ptr), а mData@0x38 -> читался мусор;
//    (b) даже с верным 0x38 world-кватернион лежит в libunity (icall
//        get_rotation_Injected) — оффсет непроверяем и версионно-хрупок.
//  Симптомы: ESP уезжал по вертикали при наклоне камеры, «плавал» по экрану,
//  а LOS-луч (для аима-через-стены) стартовал из неверной точки/направления.
//
//  Теперь используем ПРОВЕРЕННЫЕ managed-поля MouseLook.kqP:
//    pitch° = kqP.x @0x60   (disasm uae: m_LookRoot.localRotation=Euler(kqP.x,0,roll))
//    yaw°   = kqP.y @0x64   (аккумулятор yaw; конвенция == aimbot write)
//  Прямая тригонометрия (Unity left-handed, y-up), сверена численно с обратной
//  математикой аимбота до 1e-16:
//    right   = ( cosYaw,            0,        -sinYaw )
//    up      = ( sinYaw*sinPitch,   cosPitch,  cosYaw*sinPitch )
//    forward = ( sinYaw*cosPitch,  -sinPitch,  cosYaw*cosPitch )
//  Никаких нативных Transform-чтений — только два float'а. Инверты — на вызове.
//  eyePos НЕ выставляем здесь (позиция глаза считается отдельно из feet+eye).
// ============================================================================
static bool ox_readLookBasis(uint64_t player, Vector3 &right, Vector3 &up,
                             Vector3 &fwd, Vector3 *eyePos, bool full) {
    (void)eyePos;
    uint64_t mouseLook = rpm<uint64_t>(player + ox::PM_MOUSELOOK);
    if (!ox_isPtr(mouseLook)) return false;
    float pitchDeg = rpm<float>(mouseLook + ox::ML_PITCH); // kqP.x
    float yawDeg   = rpm<float>(mouseLook + ox::ML_YAW);   // kqP.y
    if (!isfinite(pitchDeg) || !isfinite(yawDeg)) return false;
    // Санитарная проверка pitch (игра клампит его к look-лимитам, |pitch|<=~89).
    if (fabsf(pitchDeg) > 179.f) return false;

    float p = pitchDeg * DEG2RAD;
    float y = yawDeg   * DEG2RAD;
    float sp = sinf(p), cp = cosf(p);
    float sy = sinf(y), cy = cosf(y);

    right   = Vector3(cy,        0.f, -sy);
    up      = Vector3(sy*sp,     cp,   cy*sp);
    fwd     = Vector3(sy*cp,    -sp,   cy*cp);
    ox_normalize3(right); ox_normalize3(up); ox_normalize3(fwd);
    if (full) OXLOGT("  lookBasis(angles) pitch=%.2f yaw=%.2f fwd=(%.3f,%.3f,%.3f)",
                     pitchDeg, yawDeg, fwd.x, fwd.y, fwd.z);
    return true;
}

// Живой ВЕРТИКАЛЬНЫЙ FOV камеры + ADS-детект из FPManager (PM+0x90).
//   effFOV = kYl(0xA0) - kSP(0xB4) ; base = _kSQ(0xAC).
//   aiming = effFOV < base*ADS_FOV_RATIO (при прицеле FOV зумится вниз).
// Возвращает верт. FOV (>0) или 0, если FPManager недоступен/значения мусор.
// aimingOut (может быть nullptr) — true если игрок целится.
static float ox_readCameraFovV(uint64_t player, bool *aimingOut, bool full) {
    if (aimingOut) *aimingOut = false;
    uint64_t fp = rpm<uint64_t>(player + ox::PM_FPMANAGER);
    if (!ox_isPtr(fp)) return 0.f;
    float cur  = rpm<float>(fp + ox::FP_FOV_CURRENT); // kYl
    float off  = rpm<float>(fp + ox::FP_FOV_OFFSET);  // kSP
    float base = rpm<float>(fp + ox::FP_FOV_BASE);    // _kSQ
    if (!isfinite(cur) || !isfinite(off) || !isfinite(base)) return 0.f;
    float eff = cur - off;
    if (eff < ox::EYE_FOV_MIN || eff > ox::EYE_FOV_MAX) return 0.f;
    if (aimingOut) {
        // ADS = текущий FOV ощутимо ниже БАЗОВОГО (зум прицела). База — это
        // хипфайр-FOV игрока (_kSQ), сравниваем ОТНОСИТЕЛЬНО его, чтобы работало
        // и при низком пользовательском FOV. Если _kSQ протух (мусор) — дефолт 60.
        float ref = (isfinite(base) && base > ox::EYE_FOV_MIN && base < ox::EYE_FOV_MAX)
                        ? base : ox::DEFAULT_VFOV;
        *aimingOut = (cur < ref * ox::ADS_FOV_RATIO);
    }
    if (full) OXLOGT("  FOV: kYl=%.2f kSP=%.2f base=%.2f -> effV=%.2f aiming=%d",
                     cur, off, base, eff, aimingOut ? (int)*aimingOut : -1);
    // Периодический лог (раз в ~2 сек) — без него нельзя понять почему
    // ADS-детект не срабатывает: нужны живые значения kYl/_kSQ с устройства.
    {
        static double s_lastFovLog = 0.0;
        double now = (double)time(nullptr);
        if (now - s_lastFovLog >= 2.0) {
            s_lastFovLog = now;
            OXLOGI("[ads] kYl=%.2f kSP=%.2f base=%.2f eff=%.2f ratio=%.3f aiming=%d",
                   cur, off, base, eff,
                   (base > 1.f ? cur / base : -1.f),
                   aimingOut ? (int)*aimingOut : -1);
        }
    }
    return eff;
}

// Строит камеру из КОНКРЕТНОГО (локального) игрока.
//   pos    = feet(lastTickPosition) + EYE_HEIGHT  (managed-поле, проверяемо)
//   basis  = из углов kqP.x(pitch)/kqP.y(yaw)     (проверяемо, без libunity)
//   fovV   = живой верт. FOV из FPManager          (kYl - kSP), меняется при ADS
// Дёшево (несколько managed-чтений) — можно звать каждый кадр.
static CameraView ox_buildCameraFromPlayer(uint64_t player, bool full) {
    CameraView cam;
    cam.valid = false;
    cam.fovH  = camFov;   // legacy горизонтальный fallback
    if (!ox_isPtr(player)) return cam;

    Vector3 body = ox_readPos(player, full);

    Vector3 right{1,0,0}, up{0,1,0}, fwd{0,0,1};
    bool haveDir = ox_readLookBasis(player, right, up, fwd, nullptr, full);

    // FIX ESP drift on spawn/respawn: перед тем как строить cam.pos из lastTickPos,
    // предпочитаем LIVE позицию из worldCameraRoot Transform, если она доступна.
    // lastTickPosition обновляется на server tick (~20 Hz) и после respawn
    // задерживается или показывает (0,0,0) — до этого ESP уезжает "с камерой".
    // worldCameraRoot — нативный Transform игрока, обновляется каждый кадр игрой.
    uint64_t camRoot = rpm<uint64_t>(player + ox::PM_TRANSFORM);
    Vector3 camRootPos{0,0,0};
    bool haveCamRoot = ox_isPtr(camRoot) &&
                       ox_transformWorld(camRoot, &camRootPos, nullptr, false, nullptr) &&
                       (camRootPos.x != 0.f || camRootPos.y != 0.f || camRootPos.z != 0.f);
    // Санити: worldCameraRoot обязан быть над своим же телом. После смерти
    // Transform остаётся на месте гибели, а lastTickPosition уезжает на точку
    // респавна — расхождение в метрах. Такой Transform брать нельзя, иначе
    // камера окажется в старой точке и вся сцена «поедет» относительно неё.
    if (haveCamRoot) {
#if defined(__x86_64__)
        // Motor is a spawn position on this client. Comparing the live camera
        // to it disables the camera as soon as the player starts moving.
        haveCamRoot = isfinite(camRootPos.x) && isfinite(camRootPos.y) &&
                      isfinite(camRootPos.z) && fabsf(camRootPos.x) < 100000.f &&
                      fabsf(camRootPos.y) < 100000.f && fabsf(camRootPos.z) < 100000.f &&
                      !(fabsf(camRootPos.x) < 0.05f && fabsf(camRootPos.z) < 0.05f && camRootPos.y < 0.05f);
        // A cached camera root can survive a respawn. Compare it to the live
        // model when available; the Motor position is frozen on this client.
        Vector3 modelOrigin{};
        if (haveCamRoot && ox_pcReadVisualOrigin(player, (double)ImGui::GetTime(), modelOrigin)) {
            const float dx = camRootPos.x - modelOrigin.x;
            const float dz = camRootPos.z - modelOrigin.z;
            const float dy = camRootPos.y - modelOrigin.y;
            if (hypotf(dx, dz) > 4.f || dy < 0.5f || dy > 3.5f)
                haveCamRoot = false;
        }
#else
        float dx = camRootPos.x - body.x, dz = camRootPos.z - body.z;
        float dxz = sqrtf(dx*dx + dz*dz);
        float dy  = camRootPos.y - body.y;
        if (!isfinite(dxz) || dxz > 2.0f || dy < -0.5f || dy > 3.0f) {
            if (full) OXLOGW("[camera] worldCameraRoot разошёлся с телом "
                             "(dxz=%.2f dy=%.2f) — беру feet+eye", dxz, dy);
            haveCamRoot = false;
        }
#endif
    }

    if (haveCamRoot) {
        cam.pos = camRootPos;                       // real head position (fresh)
    } else {
#if defined(__x86_64__)
        Vector3 visualOrigin{};
        if (ox_pcReadVisualOrigin(player, (double)ImGui::GetTime(), visualOrigin))
            cam.pos = visualOrigin + Vector3(0.f, ox::EYE_HEIGHT, 0.f);
        else
            cam.pos = body + Vector3(0.f, ox::EYE_HEIGHT, 0.f);
#else
        cam.pos = body + Vector3(0.f, ox::EYE_HEIGHT, 0.f);   // fallback: feet + eye_height
#endif
    }
    // Basis validity: kqP.x/y == 0 exactly = MouseLook ещё не проинициализирован
    // (респавн, первый кадр после смерти). Пока не валидировано — cam.valid=false
    // чтобы render-loop не рисовал ESP с identity-basis'ом (ESP липнет к камере).
    if (haveDir) {
        float fwdSum = fabsf(fwd.x) + fabsf(fwd.y) + fabsf(fwd.z);
        if (fwdSum < 0.01f || (fabsf(fwd.x) < 1e-4f && fabsf(fwd.z) < 1e-4f && fabsf(fwd.y - 1.f) < 1e-4f)) {
            // basis == identity forward (0,0,1) или zero — kqP не готов
            haveDir = false;
            if (full) OXLOGW("[camera] kqP не инициализирован (basis identity/zero) — ESP отключён до синка");
        }
    }

    // Живой FOV + ADS-состояние (для W2S-масштаба и aimbot ADS-only).
    bool aiming = false;
    float fovV = ox_readCameraFovV(player, &aiming, full);
    cam.fovV   = fovV;      // 0 => W2S упадёт на горизонтальный слайдер
    cam.aiming = aiming;

    if (haveDir) {
        // Инверты — чистые флипы осей проекции (управляются галками в меню).
        if (camInvertYaw)   right = Vector3(-right.x, -right.y, -right.z);
        if (camInvertPitch) up    = Vector3(-up.x,    -up.y,    -up.z);
        cam.hasBasis = true;
        cam.right = right; cam.up = up; cam.forward = fwd;
    }

    // yaw/pitch как fallback (если базис не собрался).
    float distXZ = sqrtf(fwd.x*fwd.x + fwd.z*fwd.z);
    float yaw    = atan2f(fwd.x, fwd.z) * 57.2957795f;
    float pitch  = atan2f(fwd.y, distXZ) * 57.2957795f;
    if (camInvertPitch) pitch = -pitch;
    if (camInvertYaw)   yaw   = -yaw;
    cam.pitch = pitch;
    cam.yaw   = yaw;
    // КРИТИЧНО: без валидного базиса камеру нельзя объявлять годной. Раньше
    // здесь стояло безусловное cam.valid = true, и при мёртвом/несинхронном
    // MouseLook рендер получал identity-forward (0,0,1) — все проекции
    // считались от неподвижной оси, из-за чего боксы «прилипали» к экрану
    // и ездили вместе с камерой. Теперь такой кадр просто пропускается.
#if defined(__x86_64__)
    const bool eyeValid = isfinite(cam.pos.x) && isfinite(cam.pos.y) && isfinite(cam.pos.z) &&
        fabsf(cam.pos.x) < 100000.f && fabsf(cam.pos.y) < 100000.f && fabsf(cam.pos.z) < 100000.f &&
        !(fabsf(cam.pos.x) < 0.05f && fabsf(cam.pos.z) < 0.05f && cam.pos.y < 0.05f);
    cam.valid = haveDir && eyeValid;
#else
    cam.valid = haveDir;
#endif
    if (!haveDir && full)
        OXLOGW("[camera] базис не собран — кадр пропущен (ESP не рисуется)");

    if (full) {
        OXLOGI("ЛОКАЛЬНЫЙ игрок=0x%llx", (unsigned long long)player);
        OXLOGI("  feet=(%.2f,%.2f,%.2f) eye=+%.2f -> cam.pos=(%.3f,%.3f,%.3f)",
               body.x, body.y, body.z, ox::EYE_HEIGHT, cam.pos.x, cam.pos.y, cam.pos.z);
        OXLOGI("  forward=(%.3f,%.3f,%.3f) haveBasis=%d fovV=%.2f aiming=%d",
               fwd.x, fwd.y, fwd.z, (int)haveDir, cam.fovV, (int)cam.aiming);
    }
    return cam;
}

// Проверка: остаётся ли кэшированный g_localPlayer валидным (не респавн).
// После смерти + респавна игра часто выделяет НОВЫЙ PlayerManager для локального
// игрока, а старый освобождается. Кэшированный g_localPlayer тогда указывает
// в garbage → камера строится с мусором → ESP плывёт.
// Валидация: у живого локального PM должны быть mouseLook + raycastManager
// non-null (только у него их выставляют).
// ФИКС респавна (2026/07/25): прошлая проверка требовала лишь чтобы
// mouseLook/raycastManager ВЫГЛЯДЕЛИ как указатели. После смерти игра
// освобождает PlayerManager, но освобождённая память ещё какое-то время
// хранит старые байты — проверка проходила, и камера продолжала строиться
// из мёртвого объекта. Отсюда «ESP липнет к моей камере»: kqP у мёртвого
// MouseLook больше не обновляется, базис застывает, проекции едут вместе
// с экраном. Через минуту GC перетирал память, указатели становились
// мусором, проверка наконец падала — ESP «сам чинился».
//
// Теперь живость проверяется по независимым признакам:
//   1) mouseLook / raycastManager — валидные указатели
//   2) mouseLook->m_LookRoot — живой Transform (у трупа нулится/мусор)
//   3) kqP.x / kqP.y — конечные углы в разумном диапазоне
// Плюс в ox_getCamera: присутствие PM в activePlayerList (игра убирает
// труп из списка сразу при смерти — самый надёжный сигнал).
// Checked ownership: unreadable memory is UNKNOWN, not proof of death.
// No geometric fallback: remote players can have the same camera components.
static overlaycore::OwnerStatus ox_localOwnerStatus(uint64_t pm) {
    using S = overlaycore::OwnerStatus;
    if (!ox_isPtr(pm)) return S::Rejected;
#if defined(__x86_64__)
    // Mirror's isLocalPlayer flag is not always set in the emulator. The
    // controller publishes the actual local PlayerManager independently.
    if (il2cpp_base) {
        uint64_t gcKlass = g_gcKlass.load(std::memory_order_relaxed);
        if (!gcKlass) {
            gcKlass = ox_klassFromSlot(OX_TI_GAMECONTROLLER, "GameControllerBase");
            if (gcKlass) g_gcKlass.store(gcKlass, std::memory_order_relaxed);
        }
        const uint64_t statics = ox_isPtr(gcKlass)
            ? ox_readDirect<uint64_t>(gcKlass + ox::CLASS_STATIC_FIELDS) : 0;
        const uint64_t gcLocal = ox_isPtr(statics)
            ? ox_readDirect<uint64_t>(statics + ox::GC_STATIC_LOCAL_PM) : 0;
        if (gcLocal == pm && ox_readDirect<uint64_t>(pm) == g_playerManagerKlass) {
            uint8_t respawning = 0;
            if (!pvm((void*)(pm + ox::PM_RESPAWNING), &respawning, 1, false)) return S::Unknown;
            return respawning == 0 ? S::Verified : S::Rejected;
        }
    }
#endif
    uint64_t ni=0; uint8_t local=0, respawning=0;
    if (!pvm((void*)(pm + ox::NB_NET_IDENTITY), &ni, sizeof(ni), false)) return S::Unknown;
    if (!ox_isPtr(ni)) return S::Rejected;
    if (!pvm((void*)(ni + ox::NI_IS_LOCAL_PLAYER), &local, sizeof(local), false)) return S::Unknown;
    if (local!=1) return S::Rejected;
    if (!pvm((void*)(pm + ox::PM_RESPAWNING), &respawning, sizeof(respawning), false)) return S::Unknown;
    return !respawning ? S::Verified : S::Rejected;
}
static bool ox_localPlayerStillValid() {
    return ox_localOwnerStatus(g_localPlayer) != overlaycore::OwnerStatus::Rejected;
}

// ── Детект «замороженной» камеры ────────────────────────────────────────────
// Симптом с устройства: после респавна ESP держится верно ПОКА не двигаешь
// камеру, а при повороте боксы остаются на прежнем месте экрана. То есть
// позиции целей читаются нормально, а базис камеры застыл — kqP выбранного
// MouseLook больше не обновляется (объект мёртвый, игра пишет углы в НОВЫЙ).
// Статически такой труп неотличим: указатели валидны, углы конечны.
//
// Единственный надёжный признак — ДИНАМИКА. Живой MouseLook меняет kqP
// постоянно (даже стоя: микро-дрейф, отдача, дыхание). Мёртвый застывает
// намертво. Считаем сколько секунд углы не менялись; если дольше порога —
// объявляем PM мёртвым и форсируем пере-выбор.
// БАГ ПРОШЛОЙ ВЕРСИИ: наблюдение велось в ОДНОЙ глобальной ячейке, а
// ox_lookFrozen вызывается по очереди для НЕСКОЛЬКИХ кандидатов. Каждый вызов
// с другим pm сбрасывал ячейку и возвращал false («только начали наблюдать»).
// Порог 2.5 с не достигался НИКОГДА — детект был мёртвым кодом, поэтому баг
// после респавна остался. Теперь слот на каждого кандидата.
struct OxLookSlot {
    uint64_t pm    = 0;
    float    pitch = 0.f, yaw = 0.f;
    double   lastChange = 0.0;
    bool     seeded = false;
};
static OxLookSlot g_lookSlots[8];

static OxLookSlot* ox_lookSlotFor(uint64_t pm, double nowSec) {
    OxLookSlot* free_ = nullptr;
    OxLookSlot* oldest = &g_lookSlots[0];
    for (auto &sl : g_lookSlots) {
        if (sl.pm == pm) return &sl;
        if (!sl.seeded && !free_) free_ = &sl;
        if (sl.lastChange < oldest->lastChange) oldest = &sl;
    }
    OxLookSlot* pick = free_ ? free_ : oldest;
    *pick = OxLookSlot{};
    pick->pm = pm;
    pick->lastChange = nowSec;
    return pick;
}

// Возвращает true если углы этого PM «мертвы» (не менялись дольше stallSec).
static bool ox_lookFrozen(uint64_t pm, double nowSec, float stallSec = 1.2f) {
    if (!ox_isPtr(pm)) return true;
    uint64_t ml = rpm<uint64_t>(pm + ox::PM_MOUSELOOK);
    if (!ox_isPtr(ml)) return true;
    float p = rpm<float>(ml + ox::ML_PITCH);
    float y = rpm<float>(ml + ox::ML_YAW);
    if (!isfinite(p) || !isfinite(y)) return true;

    OxLookSlot* sl = ox_lookSlotFor(pm, nowSec);
    if (!sl->seeded) {
        sl->pitch = p; sl->yaw = y; sl->lastChange = nowSec; sl->seeded = true;
        return false;                      // только начали наблюдать
    }
    if (fabsf(p - sl->pitch) > 1e-4f || fabsf(y - sl->yaw) > 1e-4f) {
        sl->pitch = p; sl->yaw = y; sl->lastChange = nowSec;
        return false;
    }
    return (nowSec - sl->lastChange) > (double)stallSec;
}

// Сбросить наблюдение (при смене локального игрока).
static void ox_lookWatchReset() {
    for (auto &sl : g_lookSlots) sl = OxLookSlot{};
}

// Находит локального игрока в списке, запоминает g_localPlayer и строит камеру.
#if defined(__x86_64__)
static void ox_pcLogLocalCandidate(uint64_t pm);
#endif
static CameraView ox_getCamera(uint64_t elems, int count, bool full,
                               std::vector<uint64_t> *playerSnapshot = nullptr) {
    if (full) oxlog::section("CAMERA (local player)");

    uint64_t confirmed=0;
    auto currentStatus=ox_localOwnerStatus(g_localPlayer);
    // Scan the whole roster: an old freed PM can retain isLocalPlayer bytes.
    // Never confuse a failed/partial read with confirmed roster absence.
    std::vector<uint64_t> roster;
    bool complete=false, present=false, readable=false;
    if (count>0 && count<=4096 && ox_isPtr(elems)) {
        roster.resize((size_t)count);
        complete=pvm((void*)elems,roster.data(),roster.size()*sizeof(uint64_t),false);
        readable=complete;
        if (!complete && count<=256) {
            bool everySlot=true;
            for (int i=0;i<count;++i) {
                uint64_t candidate=0;
                const bool ok=pvm((void*)(elems+(uint64_t)i*8),&candidate,8,false);
                roster[(size_t)i]=ok ? candidate : 0;
                readable|=ok;
                everySlot&=ok;
            }
            complete=everySlot;
        }
    }
    // The target process can rebuild this List<T> while we scan it. Keep the
    // exact roster that was used to identify the local player and reuse it for
    // target discovery; a second cached read can otherwise see empty slots.
    if (playerSnapshot) {
        if (readable) *playerSnapshot = roster;
        else playerSnapshot->clear();
    }
    if (readable) for (uint64_t candidate : roster) {
        if (candidate==g_localPlayer) present=true;
        if (!ox_isPtr(candidate)) continue;
        const auto status=candidate==g_localPlayer ? currentStatus : ox_localOwnerStatus(candidate);
        if (status==overlaycore::OwnerStatus::Verified &&
            (!confirmed || candidate==g_localPlayer)) confirmed=candidate;
    }
#if defined(__x86_64__)
    // GameControllerBase exposes the actual local PlayerManager as a static
    // field. In the x86_64 build the Mirror isLocalPlayer flag can remain
    // unset while the player is already in the match. Verify the PM class and
    // respawn state here; camera availability is checked separately below.
    if (!confirmed && il2cpp_base) {
        uint64_t gcKlass = g_gcKlass.load(std::memory_order_relaxed);
        if (!gcKlass) {
            gcKlass = ox_klassFromSlot(OX_TI_GAMECONTROLLER, "GameControllerBase");
            if (gcKlass) g_gcKlass.store(gcKlass, std::memory_order_relaxed);
        }
        const uint64_t gcStatics = ox_isPtr(gcKlass) ? ox_readDirect<uint64_t>(gcKlass + ox::CLASS_STATIC_FIELDS) : 0;
        const uint64_t gcLocal = ox_isPtr(gcStatics) ? ox_readDirect<uint64_t>(gcStatics + ox::GC_STATIC_LOCAL_PM) : 0;
        if (ox_isPtr(gcLocal) &&
            ox_localOwnerStatus(gcLocal) == overlaycore::OwnerStatus::Verified) {
            confirmed = gcLocal;
            static uint64_t lastGcLocal = 0;
            if (gcLocal != lastGcLocal) {
                lastGcLocal = gcLocal;
                oxlog::diagf("[pc-local] GameControllerBase static local PM=0x%llx", (unsigned long long)gcLocal);
            }
        }
    }
#endif
    static overlaycore::OwnerRosterGuard absence;
    if (absence.Missing(g_localPlayer,complete,present,ImGui::GetTime()))
        currentStatus=overlaycore::OwnerStatus::Rejected;
    // A verified current owner survives an unreadable/rebuilding roster; it
    // cannot acquire a different owner's camera without an explicit flag.
    if (!confirmed && currentStatus==overlaycore::OwnerStatus::Verified)
        confirmed=g_localPlayer;
    const uint64_t player=overlaycore::SelectOwner(g_localPlayer,confirmed,currentStatus);
    if (player != g_localPlayer) {
        OXLOGI("[local] verified owner changed 0x%llx -> 0x%llx",
               (unsigned long long)g_localPlayer, (unsigned long long)player);
        g_localPlayer=player;
#if defined(__x86_64__)
        ox_pcLogLocalCandidate(player);
#endif
        g_localTeamName.clear();
        ox_lookWatchReset();
    }
    if (player) {
        // Team-ключ обновляем КАЖДЫЙ раз, а не только при смене локального PM.
        // Команда собирается уже в матче: на момент первого выбора игрока
        // PM.team ещё null, и старый код кэшировал пустую строку навсегда —
        // отсюда «скрыть тимейтов не работает».
        {
            std::string tk = ox_teamKey(player);
            if (tk != g_localTeamName) {
                OXLOGI("[local] teamKey: '%s' -> '%s'", g_localTeamName.c_str(), tk.c_str());
                g_localTeamName = tk;
                cache_needs_update = true;   // пере-оценить состав кэша
            }
        }
        return ox_buildCameraFromPlayer(player, full);
    }
    if (full) OXLOGW("Локальный игрок не найден (нет живого PM с mouseLook в списке)");
    CameraView cam; cam.valid = false; cam.fovH = camFov;
    return cam;
}

#if defined(__x86_64__)
static void ox_pcLogLocalCandidate(uint64_t pm) {
    if (!ox_isPtr(pm)) return;
    const uint64_t klass=ox_readDirect<uint64_t>(pm);
    const uint64_t ml=ox_readDirect<uint64_t>(pm+ox::PM_MOUSELOOK);
    const uint64_t root=ox_readDirect<uint64_t>(pm+ox::PM_TRANSFORM);
    const uint64_t identity=ox_readDirect<uint64_t>(pm+ox::NB_NET_IDENTITY);
    uint8_t respawning=255;
    const bool respOk=pvm((void*)(pm+ox::PM_RESPAWNING),&respawning,1,false);
    Vector3 tick{},motor{};
    const bool tickOk=pvm((void*)(pm+ox::PM_LAST_TICK_POS),&tick,sizeof(tick),false);
    const bool motorOk=ox_pcReadMotorPos(pm,motor);
    const float pitch=ox_isPtr(ml) ? ox_readDirect<float>(ml+ox::ML_PITCH) : 0.f;
    const float yaw=ox_isPtr(ml) ? ox_readDirect<float>(ml+ox::ML_YAW) : 0.f;
    oxlog::diagf("[pc-local-raw] pm=0x%llx klass=0x%llx expected=0x%llx identity=0x%llx resp=%u read=%d mouseLook=0x%llx angles=%.2f,%.2f root=0x%llx tick=%d/%.1f,%.1f,%.1f motor=%d/%.1f,%.1f,%.1f",
                 (unsigned long long)pm,(unsigned long long)klass,
                 (unsigned long long)g_playerManagerKlass,(unsigned long long)identity,
                 respawning,(int)respOk,(unsigned long long)ml,pitch,yaw,
                 (unsigned long long)root,(int)tickOk,tick.x,tick.y,tick.z,
                 (int)motorOk,motor.x,motor.y,motor.z);
}
#endif

static float ox_normalizeAngle(float angle) {
    while (angle > 180.0f) angle -= 360.0f;
    while (angle < -180.0f) angle += 360.0f;
    return angle;
}

// ============================================================================
//  LOS-чек через BuildingPiece.saveList
// ============================================================================
//  Резолвим BuildingPiece_TypeInfo (обновлённый RVA 0xB8B97E0) -> static_fields ->
//  saveList (List<BuildingPiece>) -> перебираемm_Bounds (локальные) + m_CorrectPosition
//  (мировые) -> world AABB -> классический slab-method ray-AABB.
//
//  Кэш: раз в N кадров (BUILDING_CACHE_INTERVAL) перечитываем список построек,
//  между кадрами — переиспользуем. Это убирает ~2000*8 байт/кадр лишних чтений.
//  Альтернативно — для получения ВСЕХ твёрдых объектов стоило бы звать
//  Physics.Raycast, но это требует внедрения метода в процесс — вне рамок
//  внешнего чита. Building-LOS покрывает ~90% случаев (стены/фундаменты/потолки).
//
//  Структура Bounds (UnityEngine, TypeDefIndex 13482):
//    0x00  Vector3 m_Center
//    0x0C  Vector3 m_Extents
//  min = center - extents, max = center + extents
// ============================================================================

struct WorldAABB {
    Vector3 min;
    Vector3 max;
};

struct BuildingCacheEntry {
    uint64_t address;       // адрес BuildingPiece (для лога)
    WorldAABB bounds;       // World-space AABB
    bool      valid;
};

static std::vector<BuildingCacheEntry> g_buildingCache;
static std::mutex g_buildingMutex;
static int g_buildingCacheFrame = -1000;
static constexpr int BUILDING_CACHE_INTERVAL = 30; // перечитываем раз в 30 кадров (~0.5с)

// Резолв static_fields для класса по его TypeInfo RVA. Возвращает 0 при ошибке.
// Читает static_fields класса. Приоритет — кэширован��ый указатель Il2CppClass
// (надёжно на metadata v39). Если его нет, откат на TypeInfo RVA (нестабилен).
static uint64_t ox_getClassStatics(uint64_t typeInfoRVA, uint64_t cachedKlass, bool tryLog) {
    if (!il2cpp_base) { if (tryLog) OXLOGE("il2cpp_base == 0 (getClassStatics)"); return 0; }
    uint64_t klass = ox_isPtr(cachedKlass) ? cachedKlass : 0;
    if (!ox_isPtr(klass)) {
        uint64_t typeInfoAddr = il2cpp_base + typeInfoRVA;
        klass = rpm<uint64_t>(typeInfoAddr);
        if (tryLog) OXLOGD("getClassStatics: klass из RVA 0x%llx -> 0x%llx",
                           (unsigned long long)typeInfoRVA, (unsigned long long)klass);
    }
    if (!ox_isPtr(klass)) { if (tryLog) OXLOGE("klass невалиден (RVA=0x%llx, cached=0x%llx)", (unsigned long long)typeInfoRVA, (unsigned long long)cachedKlass); return 0; }
    uint64_t statics = rpm<uint64_t>(klass + ox::CLASS_STATIC_FIELDS);
    if (!ox_isPtr(statics)) { if (tryLog) OXLOGE("static_fields невалиден"); return 0; }
    return statics;
}

// Развёртка List<T> -> {elements_ptr, count}. Аналог ox_evalContainer, без проверки
// однородности (для BuildingPiece.saveList не нужно — оно типизировано).
static bool ox_readList(uint64_t listObj, uint64_t &elems, int &count) {
    elems = 0; count = 0;
    if (!ox_isPtr(listObj)) return false;
    uint64_t items = rpm<uint64_t>(listObj + ox::LIST_ITEMS);
    if (!ox_isPtr(items)) return false;
    int listSize = rpm<int>(listObj + ox::LIST_SIZE);
    uint64_t arrLen = rpm<uint64_t>(items + ox::ARRAY_COUNT);
    if (listSize > 0 && listSize <= ox::LOS_SAVELIST_MAX) count = listSize;
    else if (arrLen > 0 && arrLen <= (uint64_t)ox::LOS_SAVELIST_MAX) count = (int)arrLen;
    else return false;
    elems = items + ox::ARRAY_DATA;
    return count > 0;
}

// ============================================================================
//  FIX bug #1: BuildingPiece.saveList — это HashSet<T>, а НЕ List<T>.
//  Старый ox_readList на HashSet возвращал мусор -> кэш построек всегда пуст ->
//  aimCheckWalls/espColorByVisibility НИКОГДА не срабатывали. Ниже — корректный
//  обход Mono HashSet<T> и Dictionary<K,V> (fallback).
// ============================================================================

// Обходит Mono HashSet<T> (T — ссылочный тип), вызывая cb(value) для каждого
// живого элемента. Читает Slot[] одним bulk-vm_readv (быстро, без пер-элемент чтений).
//   set+0x18 -> Slot[] _slots ; set+0x24 -> _lastIndex
//   Slot { int hashCode; int next; T value } stride 0x10, занятый: hashCode>=0.
// Возвращает число обойдённых живых элементов, -1 при невалидном наборе.
template<typename CB>
static int ox_forEachHashSet(uint64_t setObj, CB&& cb) {
    if (!ox_isPtr(setObj)) return -1;
    uint64_t slots = rpm<uint64_t>(setObj + ox::HASHSET_SLOTS);
    if (!ox_isPtr(slots)) return -1;
    int lastIndex = rpm<int>(setObj + ox::HASHSET_LASTINDEX);
    int count     = rpm<int>(setObj + ox::HASHSET_COUNT);
    if (lastIndex <= 0 || lastIndex > ox::LOS_SAVELIST_MAX) {
        // _lastIndex мусор — попробуем _count как границу.
        if (count <= 0 || count > ox::LOS_SAVELIST_MAX) return -1;
        lastIndex = count;
    }
    uint64_t arrLen = rpm<uint64_t>(slots + ox::ARRAY_COUNT);
    if (arrLen == 0 || arrLen > (uint64_t)ox::LOS_SAVELIST_MAX) return -1;
    if ((uint64_t)lastIndex > arrLen) lastIndex = (int)arrLen;

    // Bulk-read всего slots-массива (Slot stride 0x10) одним чтением.
    uint64_t dataBase = slots + ox::ARRAY_DATA;
    size_t bytes = (size_t)lastIndex * (size_t)ox::HASHSET_SLOT_STRIDE;
    std::vector<uint8_t> buf(bytes);
    if (!vm_readv(dataBase, buf.data(), bytes)) return -1;

    int seen = 0;
    for (int i = 0; i < lastIndex; ++i) {
        const uint8_t* s = buf.data() + (size_t)i * ox::HASHSET_SLOT_STRIDE;
        int32_t hashCode; memcpy(&hashCode, s + ox::HASHSET_SLOT_HASHCODE, 4);
        if (hashCode < 0) continue; // свободный слот
        uint64_t value; memcpy(&value, s + ox::HASHSET_SLOT_VALUE, 8);
        if (!ox_isPtr(value)) continue;
        cb(value);
        ++seen;
    }
    return seen;
}

// Обходит Mono Dictionary<int,T> (fallback для saveLookup) -> cb(value).
//   dict+0x18 -> Entry[] entries ; dict+0x28 -> count
//   Entry { int hashCode; int next; int key; T value } stride 0x18, занят: hashCode>=0.
template<typename CB>
static int ox_forEachDictValues(uint64_t dictObj, CB&& cb) {
    if (!ox_isPtr(dictObj)) return -1;
    uint64_t entries = rpm<uint64_t>(dictObj + ox::DICT_ENTRIES);
    if (!ox_isPtr(entries)) return -1;
    int count = ox_dictCount(dictObj);
    if (count <= 0 || count > ox::LOS_SAVELIST_MAX) return -1;
    uint64_t arrLen = rpm<uint64_t>(entries + ox::ARRAY_COUNT);
    if (arrLen == 0 || arrLen > (uint64_t)ox::LOS_SAVELIST_MAX) return -1;
    if ((uint64_t)count > arrLen) count = (int)arrLen;

    uint64_t dataBase = entries + ox::ARRAY_DATA;
    size_t bytes = (size_t)count * (size_t)ox::DICT_ENTRY_STRIDE;
    std::vector<uint8_t> buf(bytes);
    if (!vm_readv(dataBase, buf.data(), bytes)) return -1;

    int seen = 0;
    for (int i = 0; i < count; ++i) {
        const uint8_t* e = buf.data() + (size_t)i * ox::DICT_ENTRY_STRIDE;
        int32_t hashCode; memcpy(&hashCode, e + ox::DICT_ENTRY_HASHCODE, 4);
        if (hashCode < 0) continue;
        uint64_t value; memcpy(&value, e + ox::DICT_ENTRY_VALUE, 8);
        if (!ox_isPtr(value)) continue;
        cb(value);
        ++seen;
    }
    return seen;
}

// Читает Bounds в мировую AABB. Инфлейтит на LOS_AABB_INFLATE со всех сторон.
// Euler (deg, Unity ZXY) -> Quat. Для поворота локальных bounds в мир.
static Quat ox_eulerToQuat(const Vector3 &degEuler) {
    float rx = degEuler.x * DEG2RAD * 0.5f;
    float ry = degEuler.y * DEG2RAD * 0.5f;
    float rz = degEuler.z * DEG2RAD * 0.5f;
    float cx = cosf(rx), sx = sinf(rx);
    float cy = cosf(ry), sy = sinf(ry);
    float cz = cosf(rz), sz = sinf(rz);
    // Unity order ZXY: q = Y * X * Z (applied right-to-left)
    Quat qx{ sx, 0, 0, cx };
    Quat qy{ 0, sy, 0, cy };
    Quat qz{ 0, 0, sz, cz };
    return quatMul(quatMul(qy, qx), qz);
}

static bool ox_readWorldAABB(uint64_t building, WorldAABB &out) {
    out = WorldAABB{Vector3(0,0,0), Vector3(0,0,0)};
    if (!ox_isPtr(building)) return false;

    // World-позиция постройки (server-authoritative m_CorrectPosition @0x8C).
    Vector3 worldPos = rpm<Vector3>(building + ox::BP_CORRECT_POSITION);
    // m_CorrectRotation (Euler deg @0x98) — поворот постройки в мире.
    Vector3 worldRotEuler = rpm<Vector3>(building + ox::BP_CORRECT_ROTATION);
    // Bounds локальны к pivot'у (m_Center 0x0, m_Extents 0xC на building+BP_BOUNDS).
    uint64_t bAddr = building + ox::BP_BOUNDS;
    Vector3 center = rpm<Vector3>(bAddr + ox::BOUNDS_CENTER);
    Vector3 extents = rpm<Vector3>(bAddr + ox::BOUNDS_EXTENTS);

    // Валидность.
    if (extents.x < 0.f || extents.y < 0.f || extents.z < 0.f) return false;
    if (extents.x > 100.f || extents.y > 100.f || extents.z > 100.f) return false;
    if (!isfinite(center.x) || !isfinite(center.y) || !isfinite(center.z)) return false;
    if (!isfinite(extents.x) || !isfinite(extents.y) || !isfinite(extents.z)) return false;
    if (!isfinite(worldRotEuler.x) || !isfinite(worldRotEuler.y) || !isfinite(worldRotEuler.z))
        worldRotEuler = Vector3(0,0,0);

    float infl = ox::LOS_AABB_INFLATE;

    // FIX bug #1: учитываем ПОВОРОТ постройки. Стены/фундаменты в Oxide повёрнуты
    // (кратно 90° и не только) -> без учёта rotation AABB съезжал и LOS промахивался.
    // Строим мировой axis-aligned AABB из 8 повёрнутых углов локального Bounds.
    bool rotated = (fabsf(worldRotEuler.x) > 0.01f || fabsf(worldRotEuler.y) > 0.01f ||
                    fabsf(worldRotEuler.z) > 0.01f);
    if (!rotated) {
        Vector3 wc(center.x + worldPos.x, center.y + worldPos.y, center.z + worldPos.z);
        out.min = Vector3(wc.x - extents.x - infl, wc.y - extents.y - infl, wc.z - extents.z - infl);
        out.max = Vector3(wc.x + extents.x + infl, wc.y + extents.y + infl, wc.z + extents.z + infl);
        return true;
    }

    Quat q = ox_eulerToQuat(worldRotEuler);
    Vector3 mn( 1e30f, 1e30f, 1e30f), mx(-1e30f,-1e30f,-1e30f);
    for (int sx = -1; sx <= 1; sx += 2)
    for (int sy = -1; sy <= 1; sy += 2)
    for (int sz = -1; sz <= 1; sz += 2) {
        Vector3 localCorner(center.x + sx*extents.x,
                            center.y + sy*extents.y,
                            center.z + sz*extents.z);
        Vector3 r = quatRotate(q, localCorner);      // повернули вокруг pivot
        Vector3 w(r.x + worldPos.x, r.y + worldPos.y, r.z + worldPos.z);
        if (w.x < mn.x) mn.x = w.x; if (w.x > mx.x) mx.x = w.x;
        if (w.y < mn.y) mn.y = w.y; if (w.y > mx.y) mx.y = w.y;
        if (w.z < mn.z) mn.z = w.z; if (w.z > mx.z) mx.z = w.z;
    }
    out.min = Vector3(mn.x - infl, mn.y - infl, mn.z - infl);
    out.max = Vector3(mx.x + infl, mx.y + infl, mx.z + infl);
    return true;
}

// Slab-method ray-AABB. Возвращает true если луч попадает в AABB, и t-интервал
// [tNear, tFar]. Если начало луча внутри AABB — tNear=0, tFar=dist до выхода.
static bool ox_rayAABB(const Vector3 &origin, const Vector3 &dirNorm,
                       const WorldAABB &b, float &tNear, float &tFar) {
    tNear = -1e30f;
    tFar  = +1e30f;
    const float *o = &origin.x;
    const float *d = &dirNorm.x;
    const float *mn = &b.min.x;
    const float *mx = &b.max.x;
    for (int i = 0; i < 3; ++i) {
        float oi = o[i], di = d[i], mni = mn[i], mxi = mx[i];
        if (fabsf(di) < 1e-6f) {
            // Параллельная оси — луч вне slab
            if (oi < mni || oi > mxi) return false;
        } else {
            float inv = 1.0f / di;
            float t1 = (mni - oi) * inv;
            float t2 = (mxi - oi) * inv;
            if (t1 > t2) { float t = t1; t1 = t2; t2 = t; }
            if (t1 > tNear) tNear = t1;
            if (t2 < tFar)  tFar  = t2;
            if (tNear > tFar) return false;
        }
    }
    return tFar >= 0.f; // пересечение в положительном направлении
}

// Обновляет кэш построе��. Тяжёлая часть — single-thread-safe (locks mutex).
static void ox_updateBuildingCache(bool) {}   // проверка видимости убрана

// Главная функция LOS-чека. Возвращает true, если путь origin→target свободен
// (не перекрыт никаким BuildingPiece). assumeBuilding=true → считается, что
// невидима. distance = |target - origin|.
static bool ox_lineOfSightClear(const Vector3 &origin, const Vector3 &target, float distance) {
    if (g_buildingCache.empty()) return true; // безblocks не резолвится => считаем видимым
    Vector3 dir = target - origin;
    float len = sqrtf(dir.x*dir.x + dir.y*dir.y + dir.z*dir.z);
    if (len < 0.001f) return true;
    Vector3 dirN = Vector3(dir.x/len, dir.y/len, dir.z/len);

    // Небольшой отступ от камеры: игнорируем стены, в чьём инфлейт-AABB мы
    // фактически стоим (иначе стоя вплотную к стене ВСЁ считалось бы за стеной).
    const float NEAR_EPS = 0.35f;

    std::lock_guard<std::mutex> lock(g_buildingMutex);
    for (const BuildingCacheEntry &e : g_buildingCache) {
        if (!e.valid) continue;
        float tNear, tFar;
        if (!ox_rayAABB(origin, dirN, e.bounds, tNear, tFar)) continue;
        // Блокирует ТОЛЬКО стена, стоящая МЕЖДУ камерой и целью:
        //   tNear в (NEAR_EPS .. distance - TARGET_EPS).
        // tNear <= NEAR_EPS => мы внутри/у самой стены (не считаем перекрытием).
        // tNear >= distance - eps => стена за целью (не мешает).
        if (tNear > NEAR_EPS && tNear < distance - ox::LOS_TARGET_EPS)
            return false;
    }
    return true;
}

// Родной ассист игры: Rys.AimRaycast (Ryr<RyT>) — луч игры из центра экрана; RyT.PlayerManager непуст, только если
// игрок попал в луч первым (стена перекрывает). Видимость считаем подтверждённой, пока цель была под лучом.
static std::atomic<int> g_nativeSeenHits{0};
static uint64_t g_nativeAimPm = 0;
static double   g_nativeAimT  = 0.0;
static void ox_nativeAimUpdate(double) {}
static bool ox_nativeSeen(uint64_t) { return false; }

// Булева видимость цели: true если path от камеры до точкиBone свободен.
// Используется и в ESP (для окрашивания бокса), и в aimbot для фильтрации.
static bool ox_losHasData() {
    std::lock_guard<std::mutex> lock(g_buildingMutex);
    return !g_buildingCache.empty();
}

static bool ox_isTargetVisible(const Vector3 &camPos, const Vector3 &targetPos) {
    float dist = Vector3::Distance(camPos, targetPos);
    if (dist < 0.001f) return true;
    // Без искусственного лимита дальности — ray-AABB дёшево (200 построек × 12
    // сравнений), а aimMaxDistance может быть до 1000м.
    return ox_lineOfSightClear(camPos, targetPos, dist);
}

// Одноразовый runtime-профиль для обновления игры. Запускается кнопкой из меню
// и пишет в обычный avis_tools_*.log: реальные адреса, цепочки статиков и полей,
// а также хексы первых игроков. Это не заменяет Il2CppDumper для RVA методов,
// но даёт все runtime offsets, которые нужны ESP/LOS/aim для калибровки версии.
[[maybe_unused]] static std::string g_runtimeDumpStatus = "No runtime dump yet";

[[maybe_unused]] static void ox_dumpRuntimeProfile() {
    oxlog::section("RUNTIME OFFSET DUMP");
    const char *logPath = oxlog::init();

    if (!ox_ensureBase(true)) {
        g_runtimeDumpStatus = "Dump failed: libil2cpp.so is not loaded";
        OXLOGE("[DUMP] %s", g_runtimeDumpStatus.c_str());
        return;
    }

    OXLOGI("[DUMP] PID=%d base=0x%llx log=%s", game_pid,
           (unsigned long long)il2cpp_base, logPath ? logPath : "<none>");
    OXLOGI("[DUMP] RVA PlayerManager_TypeInfo=0x%llx BuildingPiece_TypeInfo=0x%llx",
           (unsigned long long)g_playerManagerTypeInfoRVA,
           (unsigned long long)g_buildingPieceTypeInfoRVA);
    OXLOGI("[DUMP] PlayerManager fields: transform=0x%llx mouseLook=0x%llx raycastManager=0x%llx vitals=0x%llx local=0x%llx team=0x%llx",
           (unsigned long long)ox::PM_TRANSFORM,
           (unsigned long long)ox::PM_MOUSELOOK,
           (unsigned long long)ox::PM_RAYCASTMANAGER,
           (unsigned long long)ox::PM_VITALS,
           (unsigned long long)ox::PM_IS_LOCAL_PLAYER,
           (unsigned long long)ox::PM_TEAM_NAME);
    OXLOGI("[DUMP] MouseLook fields: lookRoot=0x%llx pitch=0x%llx yaw=0x%llx",
           (unsigned long long)ox::ML_LOOKROOT,
           (unsigned long long)ox::ML_PITCH,
           (unsigned long long)ox::ML_YAW);
    OXLOGI("[DUMP] BuildingPiece fields: worldPos=0x%llx bounds=0x%llx health=0x%llx saveList(static)=0x%llx",
           (unsigned long long)ox::BP_CORRECT_POSITION,
           (unsigned long long)ox::BP_BOUNDS,
           (unsigned long long)ox::BP_HEALTH,
           (unsigned long long)ox::STATIC_BUILDING_SAVELIST);

    // Полная карта модулей и проверка ELF magic помогают сразу увидеть неверную базу.
    ox_moduleInfo();

    uint64_t playerStatics = ox_getStatics(true);
    if (!playerStatics) {
        g_runtimeDumpStatus = "Dump partial: PlayerManager statics unresolved";
        OXLOGE("[DUMP] %s", g_runtimeDumpStatus.c_str());
        return;
    }

    PlayerListView players = ox_scanForPlayerList(playerStatics, true);
    if (!players.ok) {
        g_runtimeDumpStatus = "Dump partial: activePlayerList unresolved";
        OXLOGE("[DUMP] %s", g_runtimeDumpStatus.c_str());
        return;
    }

    OXLOGI("[DUMP] players: static+0x%llx list=0x%llx elements=0x%llx count=%d",
           (unsigned long long)players.statOff,
           (unsigned long long)players.container,
           (unsigned long long)players.elems,
           players.count);

    CameraView cam = ox_getCamera(players.elems, players.count, true);
    OXLOGI("[DUMP] camera: valid=%d local=0x%llx pos=(%.3f,%.3f,%.3f) fov=%.3f",
           (int)cam.valid, (unsigned long long)g_localPlayer,
           cam.pos.x, cam.pos.y, cam.pos.z, cam.fovH);

    if (ox_isPtr(g_localPlayer)) {
        uint64_t mouseLook = rpm<uint64_t>(g_localPlayer + ox::PM_MOUSELOOK);
        uint64_t raycast = rpm<uint64_t>(g_localPlayer + ox::PM_RAYCASTMANAGER);
        OXLOGI("[DUMP] local MouseLook=0x%llx pitch=%.3f yaw=%.3f",
               (unsigned long long)mouseLook,
               rpm<float>(mouseLook + ox::ML_PITCH),
               rpm<float>(mouseLook + ox::ML_YAW));
        OXLOGI("[DUMP] RaycastManager=0x%llx camera=0x%llx rayLength=%.3f aimRayLength=%.3f mask=0x%x aimMask=0x%x",
               (unsigned long long)raycast,
               (unsigned long long)rpm<uint64_t>(raycast + ox::RM_WORLD_CAMERA),
               rpm<float>(raycast + ox::RM_RAY_LENGTH),
               rpm<float>(raycast + ox::RM_AIM_RAY_LENGTH),
               rpm<int>(raycast + ox::RM_LAYER_MASK),
               rpm<int>(raycast + ox::RM_AIM_LAYER_MASK));
    }

    oxlog::section("RUNTIME OFFSET DUMP - PLAYER SAMPLES");
    for (int i = 0, dumped = 0; i < players.count && dumped < 3; ++i) {
        uint64_t player = rpm<uint64_t>(players.elems + i * 8);
        if (!ox_isPtr(player)) continue;
        ox_dumpPlayer(i, player);
        ++dumped;
    }

    uint64_t buildingStatics = ox_getClassStatics(g_buildingPieceTypeInfoRVA, g_buildingPieceKlass, true);
    uint64_t saveList   = buildingStatics ? rpm<uint64_t>(buildingStatics + ox::STATIC_BUILDING_SAVELIST) : 0;
    uint64_t saveLookup = buildingStatics ? rpm<uint64_t>(buildingStatics + ox::STATIC_BUILDING_SAVELOOKUP) : 0;
    // saveList — HashSet<BuildingPiece>, НЕ List. Считаем корректным обходом.
    int hsCount = 0, dCount = 0;
    ox_forEachHashSet(saveList, [&](uint64_t){ ++hsCount; });
    ox_forEachDictValues(saveLookup, [&](uint64_t){ ++dCount; });
    OXLOGI("[DUMP] BuildingPiece: statics=0x%llx saveList(HashSet)=0x%llx count=%d | saveLookup(Dict)=0x%llx count=%d",
           (unsigned long long)buildingStatics,
           (unsigned long long)saveList, hsCount,
           (unsigned long long)saveLookup, dCount);

    ox_updateBuildingCache(true);
    size_t cachedBuildings = 0;
    {
        std::lock_guard<std::mutex> lock(g_buildingMutex);
        cachedBuildings = g_buildingCache.size();
    }
    OXLOGI("[DUMP] Building LOS cache=%zu", cachedBuildings);

    g_runtimeDumpStatus = "Dump saved: " + std::string(logPath ? logPath : "/sdcard/Download");
    OXLOGI("[DUMP] COMPLETE: %s", g_runtimeDumpStatus.c_str());
}

// playerPosition = FEET (lastTickPosition, server-authoritative). Bones — offsets
// ВВЕРХ от ног. Стоящая модель: макушка ~1.85, центр головы ~1.62, шея ~1.45,
// грудь ~1.30. bug #4: при aimCrouchSafe опускаем на crouch-дельту (ручной режим,
// т.к. реальное состояние присед недоступно внешнему читу — см. коммент выше).
static Vector3 ox_aimPoint(Vector3 playerPosition) {
    float h;
    switch (aimcurbone) {
        case 0: h = 1.62f; break; // head (центр головы, а не макушка — надёжнее)
        case 1: h = 1.45f; break; // neck
        default: h = 1.30f; break; // body/chest
    }
    if (aimCrouchSafe) h -= aimCrouchDrop;
    // Та же вертикальная привязка что и у ESP-бокса — иначе прицел уедет
    // относительно того что нарисовано на экране.
    return playerPosition + Vector3(0.f, ox_boxYOffset() + h, 0.f);
}

// Точка прицеливания по ФАКТИЧЕСКИМ габаритам модели, когда якоря прочитаны.
// Доли от реального роста вместо абсолютных метров: работает и на приседе, и
// на нестандартной модели, и не зависит от espBoxYOffset. Если якорей нет —
// откат на старую формулу, поведение прежнее.
// Точка цели по ЖИВЫМ костям модели (те же, по которым рисуется скелет): центр головы, шея, грудь. Без скелета — по габаритам модели.
static bool ox_boneUsable(const Vector3 &p, const Vector3 &feet) {
    return isfinite(p.x) && isfinite(p.y) && isfinite(p.z) && !(p.x == 0.f && p.y == 0.f && p.z == 0.f) &&
           p.y > feet.y - 0.2f && p.y < feet.y + 2.8f && fabsf(p.x - feet.x) < 2.0f && fabsf(p.z - feet.z) < 2.0f;
}
static Vector3 ox_aimPointBone(const PlayerCacheData& pl, int bone);
static Vector3 ox_aimPointBoneAnchor(const PlayerCacheData& pl, int bone);
static Vector3 ox_aimPointBone(const PlayerCacheData& pl, int bone) {
    if (pl.hasSkeletonData && pl.skelLive) {
        const Vector3 feet = pl.usedModelAnchor ? pl.anchorFeet : pl.position;
        const Vector3 p = bone == 0 ? pl.headCenter : bone == 1 ? pl.neckPos : pl.spine1Pos;
        if (ox_boneUsable(p, feet)) return p;
    }
    return ox_aimPointBoneAnchor(pl, bone);
}
static Vector3 ox_aimPointBoneAnchor(const PlayerCacheData& pl, int bone) {
    if (!pl.usedModelAnchor) return ox_aimPoint(pl.position);

    // H — ФАКТИЧЕСКАЯ высота цели В ЭТОМ КАДРЕ. Когда игрок приседает, игра
    // опускает голову, H уменьшается, и точка прицела едет вниз ВМЕСТЕ с ним.
    // Никакого ручного «crouch drop» больше не нужно — присед учитывается сам.
    float H = pl.anchorHead.y - pl.anchorFeet.y;
    if (!isfinite(H) || H < 0.40f || H > 2.60f) return ox_aimPoint(pl.position);

    // Доли от реального роста, а не абсолютные метры. anchorHead — это точка
    // KCC.head (уровень глаз/шеи), поэтому:
    //   1.00 = ровно глаза, 0.90 ≈ центр головы, 0.80 ≈ шея, 0.66 ≈ грудь.
    float frac;
    switch (bone) {
        case 0: frac = 0.97f; break;  // head — чуть ниже глаз, по центру черепа
        case 1: frac = 0.86f; break;  // neck
        default: frac = 0.68f; break; // body — центр массы груди
    }

    // Ручной crouch-safe оставлен как страховка, но при живом приседе он уже
    // не нужен: применяем его только когда капсула НЕ показывает присед.
    if (aimCrouchSafe && !pl.anchorCrouching) frac -= aimCrouchDrop / H;
    frac = ::clamp<float>(frac, 0.10f, 1.02f);

    // По X/Z берём голову: на бегу корпус наклонён, ноги отстают от торса.
    return Vector3(pl.anchorHead.x,
                   pl.anchorFeet.y + H * frac,
                   pl.anchorHead.z);
}

static Vector3 ox_aimPointFor(const PlayerCacheData& pl) { return ox_aimPointBone(pl, aimcurbone == 3 ? 0 : aimcurbone); }


// UPDATE 2026/07/31 v22: детект «стреляем сейчас» для режимов Fire/ADS+Fire.
// Читает FPManager (PM+0x90) -> _currentWeapon (0x50). Флаг стрельбы у оружия
// обфусцирован, поэтому используем change-detection: пока идёт стрельба, движок
// быстро меняет состояние weapon-объекта (анимация отдачи/таймеры). Держим
// хэш небольшого окна weapon-объекта, при изменении считаем «стреляет» ещё
// FIRE_HOLD_MS. Оффсет-независимо. Если не сработает на устройстве — снимем
// точный fire-флаг из одного лога.
static bool ox_localIsFiring() {
    if (!ox_isPtr(g_localPlayer)) return false;
    uint64_t fp = rpm<uint64_t>(g_localPlayer + ox::PM_FPMANAGER);
    if (!ox_isPtr(fp)) return false;
    uint64_t weap = rpm<uint64_t>(fp + ox::FP_CURRENT_WEAPON);
    if (!ox_isPtr(weap)) return false;

    // Хэшируем окно 0x30..0x90 weapon-объекта (там таймеры/состояние отдачи).
    uint8_t buf[96] = {0};
    if (!vm_readv(weap + 0x30, buf, sizeof(buf))) return false;
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < sizeof(buf); ++i) { h ^= buf[i]; h *= 16777619u; }

    static uint32_t s_lastHash = 0;
    static double   s_lastChange = -10.0;
    double now = (double)ImGui::GetTime();
    if (h != s_lastHash) { s_lastHash = h; s_lastChange = now; }
    // «Стреляет», если состояние менялось в последние 160 мс.
    return (now - s_lastChange) < 0.160;
}

// Углы камеры в объекте MouseLook: по дампу это Vector2 @0x88 (x — pitch, +вниз; y — yaw), но смещение помечено UNVERIFIED, и в объекте есть
// ещё два Vector2 (0x4C, 0x70). Поэтому читаются поля САМОГО объекта (0x90 байт, без поиска по памяти) и сверяются с настоящим направлением
// камеры из матрицы: совпавшие на разных углах поля становятся рабочими. До этого момента используются оффсеты из заголовка.
static aimcore::AngleCalib g_aimCalib;
static int g_aimPitchOff = -1, g_aimYawOff = -1;
static void ox_aimOffsets(int *p, int *y) {
    *p = g_aimPitchOff >= 0 ? g_aimPitchOff : (int)ox::ML_PITCH;
    *y = g_aimYawOff >= 0 ? g_aimYawOff : (int)ox::ML_YAW;
}
static void ox_aimCalibTick(double now) {
    static double next = 0.0;
    if (g_aimCalib.done || now < next || !g_camVPValid || !ox_isPtr(g_localPlayer)) return;
    next = now + 0.05;
    const uint64_t ml = rpm<uint64_t>(g_localPlayer + ox::PM_MOUSELOOK);
    if (!ox_isPtr(ml)) return;
    float ty, tp;
    if (!aimcore::anglesFromVP(g_camVP.m, &ty, &tp)) return;
    float words[aimcore::AngleCalib::kWords] = {0};
    if (!vm_readv((unsigned long)ml, words, 0x100) && !vm_readv((unsigned long)ml, words, 0xA0)) return;
    static bool hinted = false;
    if (!hinted) { hinted = true; g_aimCalib.setHint((int)ox::ML_PITCH, (int)ox::ML_YAW); }
    g_aimCalib.feed(words, ty, tp);
    if (g_aimCalib.ready(&g_aimPitchOff, &g_aimYawOff))
        OXLOGI("[aim] поля углов MouseLook: pitch=+0x%x yaw=+0x%x (заголовок: +0x%x/+0x%x) — %s", g_aimPitchOff, g_aimYawOff,
               (unsigned)ox::ML_PITCH, (unsigned)ox::ML_YAW,
               (g_aimPitchOff == (int)ox::ML_PITCH && g_aimYawOff == (int)ox::ML_YAW) ? "совпало" : "ОТЛИЧАЕТСЯ, используются найденные");
}

// ── Состояние ввода локального игрока: читается из самой игры, без подбора по памяти ──
// ADS: Rys.Aim (VsC, bool по +0x10) — состояние «целюсь», запасной признак — зум FOV.
// Стрельба: PlayerWeapon.weaponState (Fire/Attack); запасные признаки — изменение Rys.Recoil и состояние оружия в памяти.
struct OxInputState { bool ads = false, fire = false; bool adsGame = false, fireState = false, fireRecoil = false; int wstate = -1; float recoilX = 0, recoilY = 0; };
static OxInputState ox_readInputState(bool fovAiming) {
    OxInputState r;
    const uint64_t pm = g_localPlayer;
    if (!ox_isPtr(pm)) return r;
    const double now = (double)ImGui::GetTime();
    const uint64_t rys = rpm<uint64_t>(pm + ox::PM_EVENT_HANDLER);
    const bool rysOk = ox_isPtr(rys) && rpm<uint64_t>(rys + ox::RYS_MANAGER) == pm;
    if (rysOk) {
        const uint64_t aim = rpm<uint64_t>(rys + ox::RYS_AIM_STATE);
        if (ox_isPtr(aim)) { const uint8_t b = rpm<uint8_t>(aim + ox::VSC_VALUE); if (b <= 1) r.adsGame = b == 1; }
        const uint64_t rec = rpm<uint64_t>(rys + ox::RYS_RECOIL);
        float rv[2];
        if (ox_isPtr(rec) && vm_readv((unsigned long)(rec + ox::RYR_VALUE_A), rv, sizeof(rv)) && isfinite(rv[0]) && isfinite(rv[1]) && fabsf(rv[0]) < 90.f && fabsf(rv[1]) < 90.f) {
            r.recoilX = rv[0]; r.recoilY = rv[1];
            static float s_lx = 0, s_ly = 0; static double s_lastMove = -10.0;
            if (fabsf(rv[0] - s_lx) > 1e-4f || fabsf(rv[1] - s_ly) > 1e-4f) { s_lx = rv[0]; s_ly = rv[1]; s_lastMove = now; }
            r.fireRecoil = (now - s_lastMove) < 0.12 && (fabsf(rv[0]) > 1e-3f || fabsf(rv[1]) > 1e-3f);
        }
    }
    const uint64_t pw = ox_findPlayerWeaponRef(pm);
    if (ox_isPtr(pw)) {
        const int st = rpm<int>(pw + ox::PW_WEAPON_STATE);
        if (st >= 0 && st <= 8) { r.wstate = st; r.fireState = (st == 5 || st == 2); }
    }
    r.ads = r.adsGame || fovAiming;
    r.fire = r.fireState || r.fireRecoil;
    if (!r.fire && r.wstate < 0) r.fire = ox_localIsFiring();           // состояние оружия недоступно — прежний признак
    static int s_lastBits = -1; static double s_lastLog = 0.0;
    const int bits = (int)r.adsGame | ((int)fovAiming << 1) | ((int)r.fireState << 2) | ((int)r.fireRecoil << 3) | ((r.wstate + 1) << 4);
    if (bits != s_lastBits && now - s_lastLog > 0.5) {
        s_lastBits = bits; s_lastLog = now;
        OXLOGI("[input] ADS: игра=%d FOV=%d | стрельба: состояние оружия=%d (%d) отдача=%d (%.3f %.3f)", (int)r.adsGame, (int)fovAiming, r.wstate,
               (int)r.fireState, (int)r.fireRecoil, r.recoilX, r.recoilY);
    }
    return r;
}

// Selects the target nearest the crosshair and adjusts the local MouseLook angles.
static bool s_lockAddrReset = false;
// ── Silent aim ───────────────────────────────────────────────────────────────────────────────────────────────────────────────────
// Метод 0 «Look direction» (основной): перед выстрелом перезаписывается Rys.LookDirection — направление взгляда, из которого игра строит
// выстрел (origin + direction уходят на сервер командой, пуля летит по ним же). Камера не двигается: поле — результат расчёта взгляда, а не
// его источник. Поток записи крутится каждые ~200 мкс и пишет направление на цель (с упреждением и падением по параметрам оружия), пока
// есть цель в круге FOV; когда цели нет — один раз возвращает направление камеры. Так сервер получает путь, совпадающий с тем, по которому
// пуля действительно летит. Метод 1 «Bullet» (запасной): правится уже созданная пуля, сервер её исходный путь знает.
// Отдельный поток также опрашивает список живых пуль (GameControllerBase.ballisticShots -> List<Ff>) каждые ~2.5 мс. Физика игры шагает пули раз
// в ~20 мс, поэтому новую пулю видно ещё у ствола, до первого шага. У новой своей пули один раз записывается BallisticState.Velocity:
// направление на цель, модуль скорости прежний. Работает независимо от обычного аима (aimm) и от ESP: позиции целей читаются здесь же.
// Что решает логика (silent_core.h, проверена на хосте): новая ли пуля (ShotId/OwnerId в этой версии всегда 0, объекты берутся из пула),
// своя ли (родилась у камеры, летит по линии взгляда), куда целиться (зона тела, упреждение по скорости и гравитации пули).
// Для каждой подменённой пули считается результат: засчитала ли игра попадание (счётчик Rys.lastHitTime) в течение времени полёта.
#define OX_SILENT_BUILD "v35-arc"
bool silentAim = false, silentPredict = true, silentSkipSleeping = true, silentSkipSpectating = true, silentDrawFov = true;
int silentZone = 2;               // 0 голова, 1 шея, 2 грудь (по умолчанию: самая большая зона попадания), 3 ближайшая к прицелу
float silentFovPx = 400.f;        // радиус круга FOV вокруг прицела, пиксели
float silentRange = 300.f;        // дальность, м
float silentLeadMs = 0.f;         // поправка времени полёта для упреждения, мс (минус — целиться меньше вперёд)
int silentMode = 0;               // 0 — Look direction (до выстрела), 1 — Bullet (после выстрела)
bool silentOnlyFiring = false;    // писать направление только пока идёт стрельба (меньше следа, но первый выстрел может уйти по камере)
float silentMaxCorr = 5.f;        // максимальный сдвиг пути пули у цели, м: больше — пулю не трогаем (сервер такое всё равно отвергает)
std::string g_silentStatus;       // три короткие строки для вкладки Silent

struct SilentTarget {
    targetlife::Ticket life;
    uint64_t addr = 0;
    Vector3 pos, vel;
    Vector3 head, neck, chest;
    bool poseValid = false, skip = false;
};
struct SilentCam { bool ok = false, vpValid = false; float vp[16] = { 0 }; Vector3 pos, fwd; CameraView cv; };
struct SilentRedir { double t = 0; float tof = 0, dist = 0, px = 0, speed = 0, natMiss = 0, angle = 0, render = 0, aimH = 0, corr = 0, bodyMiss = 0; int zone = 0, kind = 0; };   // kind 0 перенаправлена, 1 шла на цель сама, 2 слишком далеко
static std::mutex g_silMtx;                       // защищает четыре объекта ниже
static SilentCam g_silCam;                        // камера последнего кадра
static std::vector<SilentTarget> g_silTargets;    // цели последнего кадра (позиция «ног» по серверному тику, скорость из окна позиций)
static std::vector<SilentRedir> g_silRedir;       // подменённые пули, ждущие результата
static std::vector<double> g_silHits;             // моменты событий попадания игры
static std::atomic<int> sPolls{0}, sNew{0}, sOwn{0}, sNoTarget{0}, sWriteFail{0}, sDone{0}, sHeld{0}, sChecked{0}, sMaxList{0}, sHitEv{0};
static std::atomic<int> sHit{0}, sMiss{0}, sHitMov{0}, sMissMov{0}, sHitNear{0}, sMissNear{0};
static std::atomic<int> sHitFix{0}, sMissFix{0}, sHitNat{0}, sMissNat{0}, sSkipDead{0}, sSkipSelf{0};
static std::atomic<int> sHitUnt{0}, sMissUnt{0}, sHitFar{0}, sMissFar{0}, sHitRed{0}, sMissRed{0}, sUntouched{0}, sTooFar{0};   // Unt: шла на цель сама и не тронута; Far: сдвиг больше silentMaxCorr, не тронута   // Fix: луч без подмены прошёл бы мимо цели (>0.35 м); Nat: попал бы и так
static std::atomic<const char *> sErr{""};
static std::atomic<bool> g_silThread{false};
// Look-direction plan: immutable target life ticket plus optional ballistic model. Life is re-read before writes.
struct SilentAimPlan { targetlife::Ticket life; uint64_t weapon=0; bool ballistic=false; float launchSpeed=0, gravity=0, drag=0, lead=0; bool predict=false; Vector3 target; bool valid = false, firing = true; double t = 0; Vector3 eye, eyeVel, point, tvel, fwd; const char *why = "off"; };
static SilentAimPlan g_silPlan;                   // защищено g_silMtx
static std::atomic<int> sLookWrites{0}, sLookAligned{0}, sLookTotal{0};
static std::atomic<const char *> sLookState{""};
// Стрелковое оружие в руках (ox_silentWeapon): 0 нет, 1 лук, 2 арбалет, 3 копьё. Снаряд — ShaftedProjectile со своей физикой, а не пуля из ballisticShots.
static std::atomic<int> g_silArrowKind{0};
static std::atomic<uint64_t> g_silWeaponPtr{0};
static std::atomic<float> g_silArrowDrag{0.f};
static std::atomic<float> g_silWr[3];                                         // последнее записанное в LookDirection направление
static std::atomic<double> g_silWrT{-100.0};
static std::atomic<int> sArrSeen{0}, sArrOwn{0}, sArrSteered{0}, sArrCamera{0}, sArrOther{0}, sArrNoPlan{0};
static std::atomic<bool> g_arrThread{false};
static void ox_arrowThread();
static std::atomic<float> g_silObsSpeed{0.f}, g_silObsGrav{0.f};          // скорость и гравитация последней своей пули (точнее конфига)
static std::atomic<double> g_silObsT{-100.0};
static std::atomic<uint64_t> g_silObsWeapon{0};
// Parameters read from OWN ShaftedProjectile instances. Do not infer initial
// speed from a projectile already slowed by drag or mix weapons in one mean.
struct SilentArrowSample {uint64_t weapon=0;int kind=0;float speed=0,gravity=0,drag=0;double at=0;};
static std::mutex g_arrowSampleMutex;
static SilentArrowSample g_arrowSample;

static std::atomic<double> g_silHotUntil{0.0};   // до какого момента поток silent работает в полную силу (есть цель в круге FOV или своя пуля)

static double ox_silentClock() { return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count(); }

// Направление взгляда камеры: из VP-матрицы (строка w клипа = вперёд), иначе из базиса/углов камеры.
static bool ox_camForward(const CameraView &cam, Vector3 &f) {
    if (g_camVPValid) {
        const float *m = g_camVP.m;
        const float l = sqrtf(m[3] * m[3] + m[7] * m[7] + m[11] * m[11]);
        if (l > 1e-4f) { f = Vector3(m[3] / l, m[7] / l, m[11] / l); return true; }
    }
    if (!cam.valid) return false;
    if (cam.hasBasis) { f = cam.forward; return true; }
    const float yw = cam.yaw * 0.01745329f, pt = cam.pitch * 0.01745329f;
    f = Vector3(sinf(yw) * cosf(pt), -sinf(pt), cosf(yw) * cosf(pt));
    return true;
}

static void ox_silentThread() {
    OXLOGI("[thread] silent tid=%ld", (long)syscall(SYS_gettid));
    struct Pv { silentcore::V3 p, v; };
    std::unordered_map<uint64_t, Pv> prev, cur;
    struct Pending { uint64_t ptr = 0; float dir[3] = { 0, 0, 0 }; double at = 0.0; };
    Pending pend[8];
    constexpr uint64_t kOff = ox::QR_STATE_POS;           // 0x38: позиция, +0xC скорость, +0x18 гравитация, +0x1C сопротивление воздуха
    constexpr size_t kLen = 0x20;
    static uint8_t buf[64 * kLen];
    uint64_t listPtr = 0; double listAt = -10.0;
    int logNew = 0, logDone = 0;
    // Запись LookDirection (метод 0).
    uint64_t lookPm = 0, lookObj = 0; double lookAt = -10.0, lastWrite = -10.0; bool wrote = false; int logLook = 0;
    double arrowPlanTime=-1,arrowSolveAt=-1;Vector3 arrowDirection;bool arrowSolved=false;
    auto writeDir = [&](float dx, float dy, float dz) -> bool {
        const float d[3] = { dx, dy, dz };
        const bool okw = vm_writev((unsigned long)(lookObj + ox::RYR_VALUE_A), d, sizeof(d));
        if (okw) { g_silWr[0] = dx; g_silWr[1] = dy; g_silWr[2] = dz; g_silWrT = ox_silentClock(); }
        return okw;
    };
    auto resolveLook = [&](double t) {
        lookAt = t;
        const uint64_t pm = g_localPlayer;
        lookObj = 0; lookPm = pm;
        if (!ox_isPtr(pm)) { sLookState = "no local player"; return; }
        const uint64_t rys = rpm<uint64_t>(pm + ox::PM_EVENT_HANDLER);
        if (!ox_isPtr(rys) || rpm<uint64_t>(rys + ox::RYS_MANAGER) != pm) { sLookState = "no event handler"; return; }
        const uint64_t lo = rpm<uint64_t>(rys + ox::RYS_LOOK_DIRECTION);
        float v[3];
        if (!ox_isPtr(lo) || !vm_readv((unsigned long)(lo + ox::RYR_VALUE_A), v, sizeof(v)) || !isfinite(v[0]) || !isfinite(v[1]) || !isfinite(v[2])) { sLookState = "LookDirection unreadable"; return; }
        const float l = sqrtf(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        if (l < 0.8f || l > 1.2f) { sLookState = "LookDirection unexpected value"; return; }   // не единичный вектор: это не то поле
        lookObj = lo; sLookState = "ok";
        if (logLook < 6) {
            ++logLook;
            Vector3 cf; { std::lock_guard<std::mutex> lk(g_silMtx); cf = g_silCam.fwd; }
            const float cl = sqrtf(cf.x * cf.x + cf.y * cf.y + cf.z * cf.z);
            const float cs = cl > 1e-4f ? (v[0] * cf.x + v[1] * cf.y + v[2] * cf.z) / (l * cl) : 0.f;
            OXLOGI("[silent] LookDirection найден: Rys=0x%llx объект=0x%llx значение=(%.3f %.3f %.3f) |v|=%.3f, камера=(%.3f %.3f %.3f), угол между ними %.2f°",
                   (unsigned long long)rys, (unsigned long long)lo, v[0], v[1], v[2], l, cf.x, cf.y, cf.z, acosf(::clamp<float>(cs, -1.f, 1.f)) * 57.29578f);
        }
    };
    auto restoreLook = [&]() {
        if (!wrote || !lookObj) { wrote = false; return; }
        Vector3 cf; { std::lock_guard<std::mutex> lk(g_silMtx); cf = g_silCam.fwd; }
        const float cl = sqrtf(cf.x * cf.x + cf.y * cf.y + cf.z * cf.z);
        if (cl > 1e-4f) writeDir(cf.x / cl, cf.y / cl, cf.z / cl);
        wrote = false;
    };
    double lastMon = ox_silentClock();
    while (main_thread_flag) {
        if (!silentAim) { sErr = ""; prev.clear(); restoreLook(); std::this_thread::sleep_for(std::chrono::milliseconds(50)); continue; }
        // Пока записи направления нет (нет цели в круге FOV), поток просыпается раз в 1 мс, а не 5000 раз в секунду: опрос пуль идёт раз
        // в 2.5 мс, а план обновляется раз в кадр, поэтому задержка первой записи не заметна.
        {
            const double t0 = ox_silentClock();
            // Нет цели в круге FOV и своих пуль больше двух секунд — запись и опрос пуль не нужны: просыпаемся раз в 12 мс (≈80 в секунду
            // вместо тысяч), цель появляется — следующий кадр снова «разогревает» поток.
            const bool cold = t0 > g_silHotUntil.load(std::memory_order_relaxed);
            std::this_thread::sleep_for(std::chrono::microseconds(cold ? 12000 : (t0 - lastWrite > 0.3 ? 1000 : 200)));
        }
        const double now = ox_silentClock();

        if (silentMode == 0) {
            if (lookPm != g_localPlayer || (!lookObj && now - lookAt > 0.5) || now - lookAt > 3.0) resolveLook(now);
            if (lookObj) {
                SilentAimPlan pl; { std::lock_guard<std::mutex> lk(g_silMtx); pl = g_silPlan; }
                const double age = now - pl.t;
                if (pl.valid && pl.firing && age >= 0.0 && age < 0.08 &&
                    ox_lifeRead(pl.life,true)==targetlife::State::Alive) {
                    const float dtp = (float)age;
                    const Vector3 eye = pl.eye + pl.eyeVel * dtp, pt = pl.point + pl.tvel * dtp;     // с момента кадра цель и глаз сдвинулись
                    Vector3 d=pt-eye;
                    if(pl.ballistic) {
                        // Re-solve the actual arc for the age of the render snapshot.
                        // Bound the maths to 250 Hz; life is still checked every write.
                        if(arrowPlanTime!=pl.t || now>=arrowSolveAt) {
                            arrowPlanTime=pl.t;arrowSolveAt=now+.004;
                            const Vector3 target=pl.target+(pl.predict ? pl.tvel*dtp : Vector3(0,0,0));
                            const auto arc=silentcore::solveArrow({eye.x,eye.y,eye.z},{target.x,target.y,target.z},
                                {pl.tvel.x,pl.tvel.y,pl.tvel.z},pl.launchSpeed,pl.gravity,pl.drag,pl.predict,pl.lead);
                            arrowSolved=arc.ok;arrowDirection=Vector3(arc.direction.x,arc.direction.y,arc.direction.z);
                        }
                        if(!arrowSolved) {restoreLook();continue;}
                        d=arrowDirection;
                    }
                    const float l=sqrtf(d.x*d.x+d.y*d.y+d.z*d.z);
                    // A weapon change invalidates an old plan before the next frame.
                    const uint64_t fp=rpm<uint64_t>(g_localPlayer+ox::PM_FPMANAGER);
                    const bool sameWeapon=ox_isPtr(fp) && rpm<uint64_t>(fp+ox::FP_CURRENT_WEAPON)==pl.weapon;
                    if(isfinite(l) && l>.5f && sameWeapon &&
                       ox_lifeRead(pl.life,true)==targetlife::State::Alive &&
                       writeDir(d.x/l,d.y/l,d.z/l)) {++sLookWrites;wrote=true;lastWrite=now;}
                    else if(wrote) restoreLook();
                } else if (wrote) restoreLook(); // no 50 ms grace period on a dead/unknown target
            }
        } else if (wrote) restoreLook();

        if (now - lastMon < 0.0025) continue;                     // опрос пуль — раз в 2.5 мс, запись — каждые 200 мкс
        const float dt = (float)(now - lastMon); lastMon = now;
        ++sPolls;

        // Проверка записи спустя ~30 мс: скорость пули должна остаться направленной на цель (допуск — падение под гравитацией).
        for (Pending &pd : pend) {
            if (!pd.ptr || now - pd.at < 0.03) continue;
            uint8_t r[kLen];
            if (vm_readv((unsigned long)(pd.ptr + kOff), r, sizeof(r))) {
                float v[3]; memcpy(v, r + 12, 12);
                const float sp = sqrtf(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
                if (isfinite(sp) && sp > 1.f) {
                    const float c = (v[0] * pd.dir[0] + v[1] * pd.dir[1] + v[2] * pd.dir[2]) / sp;
                    const bool held = c > 0.9986f;                                          // < 3°
                    ++sChecked; if (held) ++sHeld;
                    if (sChecked <= 6)
                        OXLOGI("[silent] проверка #%d: отклонение от заданного направления %.2f° -> %s", sChecked.load(),
                               acosf(::clamp<float>(c, -1.f, 1.f)) * 57.29578f, held ? "запись держится" : "игра перезаписала скорость");
                }
            }
            pd.ptr = 0;
        }

        if (!g_gcQe) { sErr = "no bullet manager"; continue; }
        if (now - listAt > 1.0 || !ox_isPtr(listPtr)) { listPtr = rpm<uint64_t>(g_gcQe + ox::QE_BULLETS); listAt = now; }
        uint8_t hdr[16];
        if (!ox_isPtr(listPtr) || !vm_readv((unsigned long)(listPtr + ox::LIST_ITEMS), hdr, sizeof(hdr))) { sErr = "bullet list unreadable"; listAt = -10.0; continue; }
        uint64_t items; int size;
        memcpy(&items, hdr, 8); memcpy(&size, hdr + 8, 4);
        if (size < 0 || size > 512) { sErr = "bad list size"; continue; }
        sErr = "";
        if (size == 0 || !ox_isPtr(items)) { prev.clear(); continue; }
        if (size > sMaxList) sMaxList = size;
        const int n = size < 64 ? size : 64;
        uint64_t ptrs[64], addrs[64], valid[64]; int nv = 0;
        if (!vm_readv((unsigned long)(items + ox::ARRAY_DATA), ptrs, (size_t)n * 8)) { sErr = "bullet array unreadable"; continue; }
        for (int i = 0; i < n; ++i) if (ox_isPtr(ptrs[i])) { valid[nv] = ptrs[i]; addrs[nv] = ptrs[i] + kOff; ++nv; }
        if (!nv) continue;
        if (!vm_readv_multi(addrs, nv, kLen, buf)) { sErr = "bullet read failed"; continue; }

        cur.clear();
        bool haveSnap = false; SilentCam sc; std::vector<SilentTarget> tg;
        for (int i = 0; i < nv; ++i) {
            const uint8_t *r = buf + (size_t)i * kLen;
            float pos[3], vel[3], grav, drag;
            memcpy(pos, r, 12); memcpy(vel, r + 12, 12); memcpy(&grav, r + 24, 4); memcpy(&drag, r + 28, 4);
            const float sp = sqrtf(vel[0] * vel[0] + vel[1] * vel[1] + vel[2] * vel[2]);
            if (!isfinite(pos[0]) || !isfinite(pos[1]) || !isfinite(pos[2]) || !isfinite(sp) || sp < 15.f || sp > 5000.f) continue;
            const silentcore::V3 bp{ pos[0], pos[1], pos[2] }, bv{ vel[0], vel[1], vel[2] };
            auto pv = prev.find(valid[i]);
            const bool hp = pv != prev.end();
            const bool isNew = silentcore::isNewBullet(hp, hp ? pv->second.p : silentcore::V3(), hp ? pv->second.v : silentcore::V3(), bp, bv, dt);
            cur[valid[i]] = { bp, bv };
            if (!isNew) continue;
            ++sNew;
            if (!haveSnap) { std::lock_guard<std::mutex> lk(g_silMtx); sc = g_silCam; tg = g_silTargets; haveSnap = true; }
            if (!sc.ok) continue;
            const silentcore::V3 cp{ sc.pos.x, sc.pos.y, sc.pos.z }, cf{ sc.fwd.x, sc.fwd.y, sc.fwd.z };
            const bool own = silentcore::isOwnBullet(cp, cf, bp, bv);
            if (logNew < 14) {
                ++logNew;
                const silentcore::V3 dc = bp - cp;
                const silentcore::V3 rt0{ cf.z, 0.f, -cf.x }; const float rl = silentcore::len(rt0);
                const silentcore::V3 rt = rl > 1e-4f ? rt0 * (1.f / rl) : silentcore::V3{ 1.f, 0.f, 0.f };
                const silentcore::V3 up2{ rt.y * cf.z - rt.z * cf.y, rt.z * cf.x - rt.x * cf.z, rt.x * cf.y - rt.y * cf.x };
                OXLOGI("[silent] новая пуля #%d: 0x%llx скорость=%.0f g=%.2f сопротивление=%.3f от камеры: вперёд %.2f, вправо %.2f, вверх %.2f -> %s", sNew.load(), (unsigned long long)valid[i],
                       sp, grav, drag, silentcore::dot(dc, cf), silentcore::dot(dc, rt), silentcore::dot(dc, up2), own ? "своя" : "чужая");
            }
            if (!own) continue;
            ++sOwn; g_silHotUntil = now + 3.0;
            if (isfinite(grav) && fabsf(grav) < 50.f) { g_silObsSpeed = sp; g_silObsGrav = grav; g_silObsWeapon=g_silWeaponPtr.load();g_silObsT = now; }

            // Кандидаты: цели вблизи прицела по позициям последнего кадра, потом свежие данные модели у лучших четырёх.
            const float W = (float)abs_ScreenX, Hs = (float)abs_ScreenY;
            const ImVec2 ctr(W * 0.5f, Hs * 0.5f);
            OxMat4 vpm; memcpy(vpm.m, sc.vp, sizeof(vpm.m));
            auto proj = [&](const Vector3 &p, ImVec2 &out) -> bool {
                bool on = false;
                if (sc.vpValid) on = ox_w2sMatrix(vpm, p, W, Hs, &out);
                else out = w2s_angular(p, sc.cv, &on);
                return on;
            };
            struct Cd { float dpx; int k; };
            Cd cds[64]; int nc = 0;
            for (size_t k = 0; k < tg.size() && nc < 64; ++k) {
                const SilentTarget &t = tg[k];
                if (t.skip || ox_lifeRead(t.life,true)!=targetlife::State::Alive) continue;
                const Vector3 mid(t.pos.x, t.pos.y + 1.0f, t.pos.z);
                const float ed = Vector3::Distance(sc.pos, mid);
                if (ed < 1.f || (silentRange > 0.f && ed > silentRange + 15.f)) continue;
                ImVec2 s;
                if (!proj(mid, s)) continue;
                const float dx = s.x - ctr.x, dy = s.y - ctr.y, dpx = sqrtf(dx * dx + dy * dy);
                if (dpx > silentFovPx + 260.f) continue;               // запас: позиция устарела, а зона не в середине тела
                cds[nc++] = { dpx, (int)k };
            }
            std::sort(cds, cds + nc, [](const Cd &x, const Cd &y) { return x.dpx < y.dpx; });
            if (nc > 4) nc = 4;

            // Выбор цели как раньше: в круге FOV, ближайшая к центру прицела. Зона тела — только для выбора; точку определяет planShot.
            float bestD = silentFovPx, bestDist = 0.f, bestSpd = 0.f, bestRad = 0.35f; int bestZone = -1; bool have = false;
            Vector3 bestFeet, bestHead, bestVel; uint64_t bestAddr = 0; targetlife::Ticket bestLife;
            for (int c = 0; c < nc; ++c) {
                const SilentTarget &t = tg[cds[c].k];
#if defined(__x86_64__)
                // Remote PM tick is zero and Motor stays at spawn on PC.
                // t.pos already came from the live model on the render thread.
                const OxModelAnchors an{};
#else
                const OxModelAnchors an = ox_readModelAnchors(t.addr);
#endif
                Vector3 feet = an.valid ? an.feet : t.pos, head = an.valid ? an.head : Vector3(t.pos.x, t.pos.y + 1.8f, t.pos.z);
                float Hh = head.y - feet.y;
                if (!isfinite(Hh) || Hh < 0.4f || Hh > 2.6f) { Hh = 1.8f; head = Vector3(feet.x, feet.y + Hh, feet.z); }
                const float spd = sqrtf(t.vel.x * t.vel.x + t.vel.z * t.vel.z);
                const float ed = Vector3::Distance(sc.pos, head);
                if (silentRange > 0.f && ed > silentRange) continue;
                const float rad = (an.valid && an.radius > 0.15f && an.radius < 0.8f) ? an.radius : 0.35f;
                const int z0 = silentZone == 3 ? 0 : (silentZone < 0 ? 0 : (silentZone > 2 ? 2 : silentZone));
                const int z1 = silentZone == 3 ? 2 : z0;
                for (int z = z0; z <= z1; ++z) {
                    const Vector3 pt(head.x, feet.y + Hh * silentcore::zoneFrac(z), head.z);
                    ImVec2 s;
                    if (!proj(pt, s)) continue;
                    const float dx = s.x - ctr.x, dy = s.y - ctr.y, dpx = sqrtf(dx * dx + dy * dy);
                    if (dpx >= bestD) continue;
                    bestD = dpx; bestZone = z; bestSpd = spd; have = true; bestRad = rad;
                    bestFeet = feet; bestHead = head; bestVel = t.vel; bestAddr = t.addr; bestLife=t.life;
                    bestDist = Vector3::Distance(Vector3(pos[0], pos[1], pos[2]), pt);
                }
            }
            if (!have) { ++sNoTarget; continue; }
            const silentcore::V3 d0n{ vel[0] / sp, vel[1] / sp, vel[2] / sp };
            const silentcore::Plan plan = silentcore::planShot(bp, d0n, sp, grav, silentcore::V3{ bestFeet.x, bestFeet.y, bestFeet.z }, silentcore::V3{ bestHead.x, bestHead.y, bestHead.z },
                                                               silentcore::V3{ bestVel.x, bestVel.y, bestVel.z }, bestRad, silentZone == 3 ? 3 : bestZone, silentPredict,
                                                               silentLeadMs * 0.001f, silentMaxCorr);
            float bestRender = -1.f;
#if !defined(__x86_64__)
            { const Vector3 rp = ox_readPos(bestAddr, false);
              if (rp != Vector3::Zero()) bestRender = sqrtf((rp.x - bestFeet.x) * (rp.x - bestFeet.x) + (rp.z - bestFeet.z) * (rp.z - bestFeet.z)); }
#endif
            const float aimH = bestFeet.y;
            // Пуля, уже идущая через зону цели, и пуля, которой нужен слишком большой сдвиг, остаются как есть; их исход тоже считается, чтобы сравнить с перенаправленными.
            if (silentMode == 0 || plan.noop || plan.tooFar) {                 // метод 0: пулю не трогаем, только смотрим, куда она шла
                if (plan.noop) ++sUntouched; else ++sTooFar;
                if (silentMode == 0) { ++sLookTotal; if (plan.noop) ++sLookAligned; }
                SilentRedir rd; rd.t = now; rd.tof = plan.tof; rd.dist = bestDist; rd.px = bestD; rd.speed = bestSpd; rd.natMiss = plan.bodyMiss; rd.bodyMiss = plan.bodyMiss; rd.corr = plan.corr;
                rd.render = bestRender; rd.aimH = aimH; rd.zone = bestZone; rd.kind = plan.noop ? 1 : 2;
                std::lock_guard<std::mutex> lk(g_silMtx); if (g_silRedir.size() < 256) g_silRedir.push_back(rd);
                continue;
            }
            const Vector3 nd = Vector3(plan.aim.x, plan.aim.y, plan.aim.z) - Vector3(pos[0], pos[1], pos[2]);
            const float len = sqrtf(nd.x * nd.x + nd.y * nd.y + nd.z * nd.z);
            if (!isfinite(len) || len < 0.5f) continue;
            const float nvv[3] = { nd.x / len * sp, nd.y / len * sp, nd.z / len * sp };
            if (ox_lifeRead(bestLife,true)!=targetlife::State::Alive) {++sSkipDead;continue;}
            if (!vm_writev((unsigned long)(valid[i] + ox::QR_STATE_VEL), nvv, 12)) { ++sWriteFail; continue; }
            ++sDone;
            cur[valid[i]].v = silentcore::V3{ nvv[0], nvv[1], nvv[2] };       // иначе смена скорости в следующем опросе сойдёт за новую пулю
            for (Pending &pd : pend) if (!pd.ptr) { pd.ptr = valid[i]; pd.at = now; pd.dir[0] = nd.x / len; pd.dir[1] = nd.y / len; pd.dir[2] = nd.z / len; break; }
            const float ang = acosf(::clamp<float>((vel[0] * nd.x + vel[1] * nd.y + vel[2] * nd.z) / (sp * len), -1.f, 1.f)) * 57.29578f;
            { SilentRedir rd; rd.t = now; rd.tof = plan.tof; rd.dist = bestDist; rd.px = bestD; rd.speed = bestSpd; rd.natMiss = plan.zoneMiss; rd.bodyMiss = plan.bodyMiss; rd.corr = plan.corr;
              rd.angle = ang; rd.render = bestRender; rd.aimH = aimH; rd.zone = bestZone; rd.kind = 0;
              std::lock_guard<std::mutex> lk(g_silMtx); if (g_silRedir.size() < 256) g_silRedir.push_back(rd); }
            (void)logDone;
        }
        prev.swap(cur);
    }
}

// Счётчик событий попадания самой игры (Rys.lastHitTime): растёт, когда игра регистрирует попадание у локального игрока.
static void ox_silentHitWatch(double now) {
    static uint64_t pm = 0, tobj = 0;
    static float t0[2] = { 0.f, 0.f };
    static bool have = false;
    static double nextResolve = 0.0;
    if (!ox_isPtr(g_localPlayer)) return;
    if (pm != g_localPlayer) { pm = g_localPlayer; tobj = 0; have = false; }
    if (!tobj) {
        if (now < nextResolve) return;
        nextResolve = now + 1.0;
        const uint64_t rys = rpm<uint64_t>(g_localPlayer + ox::PM_EVENT_HANDLER);
        if (!ox_isPtr(rys) || rpm<uint64_t>(rys + ox::RYS_MANAGER) != g_localPlayer) return;
        const uint64_t o = rpm<uint64_t>(rys + ox::RYS_LAST_HIT_TIME);
        if (!ox_isPtr(o)) return;
        tobj = o; have = false;
        OXLOGI("[silent] счётчик попаданий игры найден: объект=0x%llx", (unsigned long long)o);
    }
    float t[2];
    if (!vm_readv((unsigned long)(tobj + ox::RYR_VALUE_A), t, sizeof(t))) { tobj = 0; return; }
    if (!isfinite(t[0]) || !isfinite(t[1])) return;
    if (!have) { t0[0] = t[0]; t0[1] = t[1]; have = true; return; }
    if (t[0] != t0[0] || t[1] != t0[1]) {
        t0[0] = t[0]; t0[1] = t[1];
        ++sHitEv;
        std::lock_guard<std::mutex> lk(g_silMtx);
        if (g_silHits.size() < 64) g_silHits.push_back(now);
    }
}

// Итог по каждой подменённой пуле: попала ли она. Событие попадания засчитывается самой старой подмене, у которой оно укладывается в время
// полёта + 0.45 с; подмена без события за это время — промах. Первые 60 итогов идут в лог с параметрами выстрела.
static void ox_silentResolve(double now) {
    static int logged = 0;
    std::vector<std::pair<SilentRedir, bool>> done;
    {
        std::lock_guard<std::mutex> lk(g_silMtx);
        std::vector<char> res(g_silRedir.size(), 0), hit(g_silRedir.size(), 0);
        for (double h : g_silHits)
            for (size_t i = 0; i < g_silRedir.size(); ++i)
                if (!res[i] && h >= g_silRedir[i].t - 0.02 && h <= g_silRedir[i].t + g_silRedir[i].tof + 0.45) { res[i] = hit[i] = 1; break; }
        g_silHits.clear();
        for (size_t i = 0; i < g_silRedir.size(); ++i)
            if (!res[i] && now > g_silRedir[i].t + g_silRedir[i].tof + 0.5) res[i] = 1;
        std::vector<SilentRedir> keep;
        for (size_t i = 0; i < g_silRedir.size(); ++i) { if (res[i]) done.push_back({ g_silRedir[i], hit[i] != 0 }); else keep.push_back(g_silRedir[i]); }
        g_silRedir.swap(keep);
    }
    for (const auto &d : done) {
        const SilentRedir &r = d.first; const bool h = d.second;
        const bool moving = r.speed > 2.f, nearT = r.dist < 40.f, fix = r.bodyMiss > 0.35f;
        if (h) { ++sHit; if (moving) ++sHitMov; if (nearT) ++sHitNear; if (fix) ++sHitFix; else ++sHitNat; }
        else   { ++sMiss; if (moving) ++sMissMov; if (nearT) ++sMissNear; if (fix) ++sMissFix; else ++sMissNat; }
        if (r.kind == 0) { if (h) ++sHitRed; else ++sMissRed; } else if (r.kind == 1) { if (h) ++sHitUnt; else ++sMissUnt; } else { if (h) ++sHitFar; else ++sMissFar; }
        if (logged < 1500) {                                     // OXLOGB — без ограничения однотипных строк, по строке на каждую пулю
            ++logged;
            static const char *const kKind[3] = { "ПЕРЕНАПРАВЛЕНА", "шла на цель", "мимо цели, не тронута" };
            OXLOGB("[silent] итог #%d: %s | %s | дист %.0f м, до центра %.0f px, зона %d, скорость цели %.1f м/с, полёт %.2f с | сдвиг пути %.2f м (промах до сдвига: зона %.2f м, тело %.2f м), угол %.1f°, тик/отрисовка %.2f м",
                   logged, h ? "ПОПАДАНИЕ" : "нет", kKind[r.kind < 0 || r.kind > 2 ? 0 : r.kind], r.dist, r.px, r.zone, r.speed, r.tof, r.corr, r.natMiss, r.bodyMiss, r.angle, r.render);
        }
    }
}

// Скорость и гравитация снаряда оружия в руках: PM -> FPManager -> текущее оружие.
//  · FPHitscan / ракетница: HitscanWeaponConfig (BulletSpeed, ballistic.gravity);
//  · лук, арбалет, копьё: снаряд — ShaftedProjectile, его префаб лежит в самом оружии (m_ArrowPrefab / m_SpearPrefab), скорость запуска,
//    гравитация и сопротивление воздуха — поля префаба. Класс оружия определяется по имени, а не по смещению: у FPBow и FPCrossbow
//    поля лежат по соседним адресам, и чтение «на удачу» принимало бы за конфиг чужой указатель.
// false — в руках нет оружия с баллистикой (нож, инструмент, пусто).
static bool ox_silentWeapon(double now, float &speed, float &grav) {
    static uint64_t s_pm = 0; static float s_sp = 0.f, s_g = 5.f; static bool s_ok = false; static double s_next = 0.0;
    const uint64_t pm = g_localPlayer;
    const uint64_t fp = ox_isPtr(pm) ? rpm<uint64_t>(pm + ox::PM_FPMANAGER) : 0;
    const uint64_t weapon = ox_isPtr(fp) ? rpm<uint64_t>(fp + ox::FP_CURRENT_WEAPON) : 0;
    static uint64_t s_weapon=0;
    if(s_pm==pm && s_weapon==weapon && !g_silArrowKind.load() && now<s_next && now>=s_next-.3) {
        speed=s_sp;grav=s_g;return s_ok;
    }
    s_pm=pm;s_weapon=weapon;s_next=now+.25;s_ok=false;
    int kind = 0; float drag = 0.f;
    if (ox_isPtr(weapon)) {
        char wn[64]; ox_objClassName(weapon, wn, sizeof(wn));
        uint64_t prefabOff = 0;
        if (!strcmp(wn, "FPBow")) { kind = 1; prefabOff = ox::FPBOW_ARROW_PREFAB; }
        else if (!strcmp(wn, "FPCrossbow")) { kind = 2; prefabOff = ox::FPCROSSBOW_ARROW_PREFAB; }
        else if (!strcmp(wn, "FPSpear")) { kind = 3; prefabOff = ox::FPSPEAR_PREFAB; }
        static char s_lastWn[64] = "";
        if (strcmp(s_lastWn, wn)) { snprintf(s_lastWn, sizeof(s_lastWn), "%s", wn); OXLOGI("[silent] оружие в руках: %s (%s)", wn, kind ? "снаряд ShaftedProjectile" : "пуля/конфиг"); }
        if (kind) {
            const uint64_t pf = rpm<uint64_t>(weapon + prefabOff);
            if (ox_isPtr(pf)) {
                const float ls = rpm<float>(pf + ox::SP_LAUNCH_SPEED), gr = rpm<float>(pf + ox::SP_GRAVITY), dr = rpm<float>(pf + ox::SP_AIR_DRAG);
                if (isfinite(ls) && ls >= 5.f && ls <= 800.f && isfinite(gr) && fabsf(gr) < 60.f) {
                    s_sp = ls; s_g = fabsf(gr); drag = (isfinite(dr) && dr >= 0.f && dr < 3.f) ? dr : 0.f; s_ok = true;
                    static uint64_t s_lastPf = 0;
                    if (pf != s_lastPf) { s_lastPf = pf; OXLOGI("[silent] снаряд %s: скорость запуска %.1f м/с, гравитация %.2f, сопротивление воздуха %.3f (префаб 0x%llx)", wn, ls, gr, dr, (unsigned long long)pf); }
                }
            }
        }
        if (!s_ok && !kind) { // ShaftedProjectile must never fall back to unrelated bullet fields.
            static const uint64_t offs[3] = { ox::FPHITSCAN_CONFIG, ox::FPCROSSBOW_CONFIG, ox::FPROCKET_CONFIG };
            for (uint64_t o : offs) {
                const uint64_t cfg = rpm<uint64_t>(weapon + o);
                if (!ox_isPtr(cfg)) continue;
                uint8_t raw[0x50];
                if (!vm_readv((unsigned long)(cfg + ox::HSCFG_DAMAGE), raw, sizeof(raw))) continue;
                float damage, maxDist, bspeed;
                memcpy(&damage, raw, 4);
                memcpy(&maxDist, raw + (ox::HSCFG_MAX_DISTANCE - ox::HSCFG_DAMAGE), 4);
                memcpy(&bspeed, raw + (ox::HSCFG_BULLET_SPEED - ox::HSCFG_DAMAGE), 4);
                if (!(isfinite(damage) && damage >= 1.f && damage <= 1000.f && isfinite(maxDist) && maxDist >= 3.f && maxDist <= 3000.f && isfinite(bspeed) && bspeed >= 30.f && bspeed <= 3000.f)) continue;
                float g = 5.f;
                const uint64_t bal = rpm<uint64_t>(cfg + ox::HSCFG_BALLISTIC);
                if (ox_isPtr(bal)) { const float gg = rpm<float>(bal + ox::BPROFILE_GRAVITY); if (isfinite(gg) && gg >= 0.f && gg < 50.f) g = gg; }
                s_sp = bspeed; s_g = g; s_ok = true;
                break;
            }
        }
    }
    if(kind) {
        SilentArrowSample sample;{std::lock_guard<std::mutex> lk(g_arrowSampleMutex);sample=g_arrowSample;}
        const double age=ox_silentClock()-sample.at;
        if(sample.weapon==weapon && sample.kind==kind && age>=0 && age<10) {
            s_sp=sample.speed;s_g=sample.gravity;drag=sample.drag;s_ok=true;
        }
    }
    g_silArrowKind = kind; g_silWeaponPtr = weapon; g_silArrowDrag = drag;
    speed = s_sp; grav = s_g;
    return s_ok;
}

// Раз в кадр (поток отрисовки): публикует потоку опроса камеру и цели со свежими позициями и скоростями, считает итоги попаданий и статус.
static void ox_silentFrame(const CameraView &cam, const std::vector<PlayerCacheData> &players) {
    silentMode = 0;
    static double s_statNext = 0.0, s_diagNext = 0.0;
    struct MotionSample {silentcore::MotionTrack track;uint64_t klass=0,health=0;uint32_t netId=0;};
    static std::unordered_map<uint64_t,MotionSample> s_trk;
    if (!silentAim) return;
    const double now = ox_silentClock();
    ox_gcTick((double)ImGui::GetTime());                       // менеджер пуль нужен и при выключенном ESP (сам ограничивает частоту до 1 раза в секунду)
    if (!g_silThread.exchange(true)) std::thread(ox_silentThread).detach();
    if (!g_arrThread.exchange(true)) std::thread(ox_arrowThread).detach();

    SilentCam sc;
    Vector3 fwd;
    sc.ok = ox_camForward(cam, fwd);
    sc.fwd = fwd;
    sc.pos = (g_camVPValid && g_camPosValid) ? g_camPosFromMatrix : cam.pos;
    sc.vpValid = g_camVPValid;
    if (g_camVPValid) memcpy(sc.vp, g_camVP.m, sizeof(sc.vp));
    sc.cv = cam;

    // Differentiate at movement updates; smooth server-tick noise and reset immediately on reversal, death or identity replacement.
    std::vector<SilentTarget> list; list.reserve(players.size());
    for (const PlayerCacheData &p : players) {
        if (!ox_isPtr(p.address) || p.address == g_localPlayer) continue;
        targetlife::Ticket life;
        if (ox_lifeSnapshot(p.address,life)!=targetlife::State::Alive) {
            ++sSkipDead;s_trk.erase(p.address);continue;
        }
#if defined(__x86_64__)
        // PC tick/Motor can be zero or frozen even while the visible model moves.
        Vector3 pos = p.position;
        Vector3 currentOrigin{};
        if (ox_pcReadVisualOrigin(p.address, (double)ImGui::GetTime(), currentOrigin, false)) pos = currentOrigin;
#else
        Vector3 pos = rpm<Vector3>(p.address + ox::PM_LAST_TICK_POS);
        if (!isfinite(pos.x) || !isfinite(pos.y) || !isfinite(pos.z) || (fabsf(pos.x) < 0.001f && fabsf(pos.z) < 0.001f)) pos = p.position;
#endif
        if (pos == Vector3::Zero()) continue;
        {   // Локальный игрок определяется эвристикой и бывает не тем PM: свой же PM рядом с камерой не цель.
            const float ex = pos.x - sc.pos.x, ez = pos.z - sc.pos.z, ey = pos.y - sc.pos.y;
            if (ex * ex + ez * ez < 1.2f * 1.2f && ey > -2.6f && ey < 1.0f) { ++sSkipSelf; continue; }
        }
        auto &motion=s_trk[p.address];
        if(motion.klass!=life.klass || motion.netId!=life.netId || motion.health!=life.health) {
            motion=MotionSample{};motion.klass=life.klass;motion.netId=life.netId;motion.health=life.health;
        }
        const auto velocity=motion.track.update({pos.x,pos.y,pos.z},now);
        SilentTarget st;
        st.addr = p.address; st.pos = pos; st.vel=Vector3(velocity.x,velocity.y,velocity.z);st.life=life;
        if (p.hasSkeletonData && p.skelLive && ox_boneUsable(p.headCenter,pos) &&
            ox_boneUsable(p.neckPos,pos) && ox_boneUsable(p.spine1Pos,pos)) {
            st.head=p.headCenter;st.neck=p.neckPos;st.chest=p.spine1Pos;st.poseValid=true;
        }
        st.skip = (silentSkipSleeping && p.flagSleeping) || (silentSkipSpectating && p.flagSpectating);
        list.push_back(st);
    }
    if (s_trk.size() > players.size() * 2 + 16) {                // игроков, которых уже нет, не копим
        std::unordered_map<uint64_t,MotionSample> keep;
        for (const SilentTarget &st : list) keep[st.addr] = s_trk[st.addr];
        s_trk.swap(keep);
    }
    // План метода «Look direction»: цель в круге FOV, точка прицеливания с упреждением и падением.
    SilentAimPlan plan; plan.t = now; plan.weapon=g_silWeaponPtr.load(); plan.fwd = sc.fwd; plan.eye = sc.pos;
    {
        static Vector3 s_prevEye; static double s_prevT = 0.0; static Vector3 s_eyeVel;
        if (s_prevT > 0.0 && now - s_prevT > 0.001 && now - s_prevT < 0.25) {
            Vector3 v = (sc.pos - s_prevEye) * (1.0f / (float)(now - s_prevT));
            const float vl = sqrtf(v.x * v.x + v.y * v.y + v.z * v.z);
            if (vl > 15.f) v = v * (15.f / vl);
            s_eyeVel = s_eyeVel * 0.5f + v * 0.5f;
        } else s_eyeVel = Vector3(0.f, 0.f, 0.f);
        s_prevEye = sc.pos; s_prevT = now;
        plan.eyeVel = s_eyeVel;
    }
    if (silentMode != 0) plan.why = "bullet method";
    else if (!sc.ok) plan.why = "no camera";
    else {
        float wsp = 0.f, wg = 0.f;
        const bool haveW = ox_silentWeapon((double)ImGui::GetTime(), wsp, wg);
        const int arrowKind = g_silArrowKind.load();
        plan.weapon=g_silWeaponPtr.load();
        const float minSpeed = arrowKind ? 5.f : 30.f;                      // стрела медленнее пули: порог 30 м/с отсёк бы лук
        if (!arrowKind && g_silObsWeapon.load()==plan.weapon &&
            now-g_silObsT.load()>=0 && now-g_silObsT.load()<4 && g_silObsSpeed.load()>minSpeed) { wsp = g_silObsSpeed; wg = g_silObsGrav; }
        else if (!haveW) wsp = 0.f;
        if (wsp < minSpeed) plan.why = "no ranged weapon";
        else {
            const float W = (float)abs_ScreenX, Hs = (float)abs_ScreenY; const ImVec2 ctr(W * 0.5f, Hs * 0.5f);
            auto proj = [&](const Vector3 &p, ImVec2 &out) -> bool {
                bool on = false;
                if (g_camVPValid) on = ox_w2sMatrix(g_camVP, p, W, Hs, &out); else out = w2s_angular(p, cam, &on);
                return on;
            };
            struct Cd { float dpx; int k; };
            Cd cds[64]; int nc = 0;
            for (size_t k = 0; k < list.size() && nc < 64; ++k) {
                const SilentTarget &t = list[k];
                if (t.skip) continue;
                const Vector3 mid = t.poseValid ? t.chest : Vector3(t.pos.x, t.pos.y + 1.0f, t.pos.z);
                const float ed = Vector3::Distance(sc.pos, mid);
                if (ed < 1.f || (silentRange > 0.f && ed > silentRange + 15.f)) continue;
                ImVec2 sp2;
                if (!proj(mid, sp2)) continue;
                const float dx = sp2.x - ctr.x, dy = sp2.y - ctr.y, dpx = sqrtf(dx * dx + dy * dy);
                if (dpx > silentFovPx + 260.f) continue;
                cds[nc++] = { dpx, (int)k };
            }
            std::sort(cds, cds + nc, [](const Cd &x, const Cd &y) { return x.dpx < y.dpx; });
            if (nc > 4) nc = 4;
            float bestD = silentFovPx; bool have = false; Vector3 bestPt, bestVel;
            targetlife::Ticket bestLife;
            for (int c = 0; c < nc; ++c) {
                const SilentTarget &t = list[cds[c].k];
#if defined(__x86_64__)
                const OxModelAnchors an{};
#else
                const OxModelAnchors an = ox_readModelAnchors(t.addr);
#endif
                Vector3 feet = an.valid ? an.feet : t.pos, head = an.valid ? an.head : Vector3(t.pos.x, t.pos.y + 1.8f, t.pos.z);
                float Hh = head.y - feet.y;
                if (!isfinite(Hh) || Hh < 0.4f || Hh > 2.6f) { Hh = 1.8f; head = Vector3(feet.x, feet.y + Hh, feet.z); }
                Vector3 joint[3]{};
                bool haveJoints = t.poseValid;
                if (haveJoints) {
                    joint[0]=t.head;joint[1]=t.neck;joint[2]=t.chest;
                } else {
                    PlayerCacheData sk{};
                    if (ox_readSkeleton(t.addr,feet,sk,an.valid?an.capsuleH:0.f,
                                        an.valid?an.normalH:0.f,0.f) && sk.skelLive &&
                        ox_boneUsable(sk.headCenter,feet) && ox_boneUsable(sk.neckPos,feet) &&
                        ox_boneUsable(sk.spine1Pos,feet)) {
                        joint[0]=sk.headCenter;joint[1]=sk.neckPos;joint[2]=sk.spine1Pos;
                        haveJoints=true;
                    }
                }
                if (silentRange > 0.f && Vector3::Distance(sc.pos,haveJoints?joint[0]:head) > silentRange) continue;
                auto consider = [&](const Vector3 &pt) {
                    ImVec2 sp2;
                    if (!proj(pt, sp2)) return;
                    const float dx = sp2.x - ctr.x, dy = sp2.y - ctr.y, dpx = sqrtf(dx * dx + dy * dy);
                    if (dpx >= bestD) return;
                    bestD = dpx; bestPt = pt; bestVel = t.vel; have = true;
                    bestLife=t.life;
                };
                const int zc = silentZone < 0 ? 0 : (silentZone > 2 ? 2 : silentZone);
                auto pointAt = [&](int z) {
                    return haveJoints ? joint[z] : Vector3(head.x,feet.y+Hh*silentcore::zoneFrac(z),head.z);
                };
                if (silentZone == 3) for (int z = 0; z <= 2; ++z) consider(pointAt(z));
                else consider(pointAt(zc));
            }
            if (!have) plan.why = "no target in FOV";
            else {
                float tof = 0.f;
                silentcore::V3 aim = silentcore::leadPoint(silentcore::V3{ sc.pos.x, sc.pos.y, sc.pos.z }, silentcore::V3{ bestPt.x, bestPt.y, bestPt.z },
                                                           silentcore::V3{ bestVel.x, bestVel.y, bestVel.z }, wsp, wg, silentLeadMs * 0.001f, silentPredict, &tof);
                bool arrowOk = true;
                if (arrowKind) {
                    // Стрела: падение в метры, сопротивление воздуха — численная траектория вместо одной поправки 0.5·g·t².
                    const silentcore::ArrowAim aa = silentcore::solveArrow(silentcore::V3{ sc.pos.x, sc.pos.y, sc.pos.z }, silentcore::V3{ bestPt.x, bestPt.y, bestPt.z },
                                                                           silentcore::V3{ bestVel.x, bestVel.y, bestVel.z }, wsp, wg, g_silArrowDrag.load(), silentPredict, silentLeadMs * 0.001f);
                    if(aa.ok) {
                        aim=aa.aim;tof=aa.tof;plan.ballistic=true;plan.target=bestPt;
                        plan.launchSpeed=wsp;plan.gravity=wg;plan.drag=g_silArrowDrag.load();
                        plan.predict=silentPredict;plan.lead=silentLeadMs*.001f;
                    } else arrowOk=false;
                }
                if (!arrowOk) plan.why = "target out of arrow range";
                else {
                    const auto state=ox_lifeRead(bestLife);
                    if(state!=targetlife::State::Alive) {
                        plan.why="target dead or unreadable";
                        if(state==targetlife::State::Dead) ox_chamsDeath(bestLife,ImGui::GetTime());
                    } else { plan.life=bestLife;plan.point=Vector3(aim.x,aim.y,aim.z);plan.tvel=bestVel;plan.valid=true;plan.why="ok"; }
                }
            }
        }
        if (silentOnlyFiring) {
            static double s_lastFire = -10.0;
            if (ox_readInputState(cam.aiming).fire) s_lastFire = now;
            plan.firing = now - s_lastFire < 0.25;
        }
    }
    { std::lock_guard<std::mutex> lk(g_silMtx); g_silCam = sc; g_silTargets.swap(list); g_silPlan = plan; }
    if (plan.valid) g_silHotUntil = now + 2.0;

    ox_silentHitWatch(now);
    ox_silentResolve(now);

    const int hit = sHit, miss = sMiss;
    if (now >= s_statNext) {
        s_statNext = now + 0.5;
        char a[96], b[96], c[96];
        const int hr = sHitRed, mr = sMissRed, hu = sHitUnt, mu = sMissUnt, hf2 = sHitFar, mf2 = sMissFar;
        if (silentMode == 0) {
            if (sArrOwn > 0) snprintf(a, sizeof(a), "Look writes %d, arrows %d (steered %d, camera %d)", sLookWrites.load(), sArrOwn.load(), sArrSteered.load(), sArrCamera.load());
            else             snprintf(a, sizeof(a), "Look writes %d, own shots %d", sLookWrites.load(), sOwn.load());
            if (sLookTotal > 0) snprintf(b, sizeof(b), "Bullets on target %d/%d, hit events %d/%d", sLookAligned.load(), sLookTotal.load(), hu + hf2, hu + mu + hf2 + mf2);
            else                snprintf(b, sizeof(b), "Bullets on target: no data yet");
        } else {
            snprintf(a, sizeof(a), "Mine %d: redirected %d, on target %d", sOwn.load(), sDone.load(), sUntouched.load());
            if (hit + miss > 0) snprintf(b, sizeof(b), "Hits: redirected %d/%d, on target %d/%d", hr, hr + mr, hu, hu + mu);
            else                snprintf(b, sizeof(b), "Hits: no data yet");
        }
        const char *err = sErr.load();
        const char *ls = sLookState.load();
        const char *why = (err && *err) ? err : (silentMode == 0 ? ((ls && *ls && strcmp(ls, "ok")) ? ls : plan.why) : (sDone ? "ok" : sOwn ? "no target in FOV" : sNew ? "bullets seen, none yours" : "waiting for a shot"));
        snprintf(c, sizeof(c), "%s  [%s]", why, OX_SILENT_BUILD);
        g_silentStatus = std::string(a) + "\n" + b + "\n" + c;
    }
    if (now >= s_diagNext) {
        s_diagNext = now + 5.0;
        const char *err = sErr.load();
        OXLOGI("[silent %s] диагностика: опросов %d (макс. список %d), новых пуль %d, своих %d, без цели %d, сбоев записи %d, подмен %d, держится %d/%d; "
               "попадания: события игры %d, засчитано %d из %d (движущиеся %d/%d, ближе 40 м %d/%d); "
               "перенаправлено: засчитано %d из %d; шли на цель (не тронуты): %d из %d; мимо цели или сдвиг больше %.1f м (не тронуты): %d из %d; "
               "Look direction: записей %d, пуль на цель %d из %d, состояние %s; пропущено мёртвых %d, себя %d; цели %d; %s",
               OX_SILENT_BUILD, sPolls.load(), sMaxList.load(), sNew.load(), sOwn.load(), sNoTarget.load(), sWriteFail.load(), sDone.load(), sHeld.load(), sChecked.load(),
               sHitEv.load(), hit, hit + miss, sHitMov.load(), sHitMov.load() + sMissMov.load(), sHitNear.load(), sHitNear.load() + sMissNear.load(),
               sHitRed.load(), sHitRed.load() + sMissRed.load(), sHitUnt.load(), sHitUnt.load() + sMissUnt.load(), silentMaxCorr, sHitFar.load(), sHitFar.load() + sMissFar.load(),
               sLookWrites.load(), sLookAligned.load(), sLookTotal.load(), sLookState.load(), sSkipDead.load(), sSkipSelf.load(),
               (int)players.size(), (err && *err) ? err : "ok");
        if (sArrSeen > 0 || g_silArrowKind.load())
            OXLOGI("[silent %s] стрелы: оружие=%d (1 лук, 2 арбалет, 3 копьё), замечено %d, своих %d: по записанному направлению %d, по камере %d, неясно %d, без цели в плане %d",
                   OX_SILENT_BUILD, g_silArrowKind.load(), sArrSeen.load(), sArrOwn.load(), sArrSteered.load(), sArrCamera.load(), sArrOther.load(), sArrNoPlan.load());
    }
}

static void ox_runAimbot(const CameraView& cam, const std::vector<PlayerCacheData>& players) {
    g_aimHasTarget = false;
    if (!aimm || (!cam.valid && !g_camVPValid) || !ox_isPtr(g_localPlayer)) return;

    // Режим активации: 0 Always | 1 ADS | 2 Fire | 3 ADS или Fire | 4 ADS и Fire. Состояния читаются из самой игры (ox_readInputState);
    // стрельба держится ещё aimFireHold секунд после последнего признака, чтобы наводка не обрывалась между выстрелами очереди.
    {
        static double s_lastFire = -10.0;
        const double nowF = (double)ImGui::GetTime();
        const OxInputState in = ox_readInputState(cam.aiming);
        if (in.fire) s_lastFire = nowF;
        const bool fire = nowF - s_lastFire < (double)aimFireHold, ads = in.ads;
        bool allow;
        switch (aimTriggerMode) {
            case 0:  allow = true;        break;
            case 1:  allow = ads;         break;
            case 2:  allow = fire;        break;
            case 3:  allow = ads || fire; break;
            case 4:  allow = ads && fire; break;
            default: allow = ads;         break;
        }
        if (!allow) { s_lockAddrReset = true; return; }
    }

    const ImVec2 center((float)abs_ScreenX * 0.5f, (float)abs_ScreenY * 0.5f);
    const float maxFovSq = aimFovPixels * aimFovPixels;
    const Vector3 eye = (g_camVPValid && g_camPosValid) ? g_camPosFromMatrix : cam.pos;

    struct Cand { uint64_t addr; Vector3 point; ImVec2 scr; float fovSq; targetlife::Ticket life; };
    Cand best{}, locked{};
    best.fovSq = maxFovSq; locked.fovSq = -1.0f;
    static uint64_t s_lockAddr = 0;
    static double s_acquireT = 0.0;
    if (s_lockAddrReset) { s_lockAddr = 0; s_lockAddrReset = false; }

    auto project = [&](const Vector3 &pt, ImVec2 &out) -> bool {
        bool on = false;
        if (g_camVPValid) {
            if (!ox_w2sMatrix(g_camVP, pt, (float)abs_ScreenX, (float)abs_ScreenY, &out)) return false;
            on = out.x >= 0.f && out.x <= abs_ScreenX && out.y >= 0.f && out.y <= abs_ScreenY;
        } else out = w2s_angular(pt, cam, &on);
        return on || !aimvisible;
    };

    for (PlayerCacheData player : players) {
        if (!ox_isPtr(player.address) || player.address==g_localPlayer) continue;
        targetlife::Ticket life;
        if(ox_lifeSnapshot(player.address,life)!=targetlife::State::Alive) {
            if(s_lockAddr==player.address) {s_lockAddr=0;s_acquireT=-1.0;}
            continue;
        }
        if (aimSkipSleeping && player.flagSleeping) continue;
        if (aimSkipSpectating && player.flagSpectating) continue;
#if defined(__x86_64__)
        // Aim must read the current pose even when the ESP skeleton toggle is
        // off or the heavy cache has just rebuilt its PlayerCacheData entries.
        Vector3 currentOrigin{};
        if (ox_pcReadVisualOrigin(player.address, (double)ImGui::GetTime(), currentOrigin, false))
            player.position = currentOrigin;
        player.distance = Vector3::Distance(eye, player.position);
        if (player.distance < 220.f)
            ox_readSkeleton(player.address, player.position, player, 0.f, 0.f, player.distance);
#endif

        Vector3 vel = player.velocity;
        if (vel.x == 0.f && vel.y == 0.f && vel.z == 0.f &&
            (player.motorVelocity.x != 0.f || player.motorVelocity.y != 0.f || player.motorVelocity.z != 0.f))
            vel = player.motorVelocity;

        const int firstBone = aimcurbone == 3 ? 0 : aimcurbone, lastBone = aimcurbone == 3 ? 2 : aimcurbone;
        for (int bone = firstBone; bone <= lastBone; ++bone) {
            Vector3 point = ox_aimPointBone(player, bone);
            const float distance = Vector3::Distance(eye, point);
            if (aimMaxDistance > 0.f && distance > aimMaxDistance) break;

            if (aimPrediction && aimProjectileSpeed > 1.0f) {
                const float lat = aimLatencyMs * 0.001f;
                float leadTime = distance / aimProjectileSpeed + lat;
                const int iters = aimPredictIters < 1.f ? 1 : (aimPredictIters > 6.f ? 6 : (int)(aimPredictIters + 0.5f));
                for (int it = 0; it < iters; ++it) {
                    const float d = Vector3::Distance(eye, point + vel * leadTime);
                    float t = ::clamp<float>(d / aimProjectileSpeed + lat, 0.0f, aimMaxLeadTime);
                    if (fabsf(t - leadTime) < 0.0005f) { leadTime = t; break; }
                    leadTime = t;
                }
                leadTime = ::clamp<float>(leadTime, 0.0f, aimMaxLeadTime);
                point += vel * leadTime;
                if (aimProjectileGravity > 0.001f) {
                    const float drop = 0.5f * aimProjectileGravity * leadTime * leadTime;
                    if (isfinite(drop) && drop < 20.0f) point.y += drop;
                }
            }

            ImVec2 scr;
            if (!project(point, scr)) continue;
            const float dx = scr.x - center.x, dy = scr.y - center.y, fsq = dx * dx + dy * dy;
            if (fsq > maxFovSq) continue;
            if (player.address == s_lockAddr && (locked.fovSq < 0.0f || fsq < locked.fovSq)) locked = Cand{ player.address, point, scr, fsq, life };
            if (fsq < best.fovSq) best = Cand{ player.address, point, scr, fsq, life };
        }
    }

    if (!best.addr) { s_lockAddr = 0; return; }
    Cand pick = best;
    if (aimSticky && locked.addr && locked.addr != best.addr && aimcore::keepLocked(locked.fovSq, best.fovSq, aimSwitchMargin * aimSwitchMargin)) pick = locked;
    if (s_lockAddr != pick.addr) s_acquireT = (double)ImGui::GetTime();
    s_lockAddr = pick.addr;
    g_aimHasTarget = true; g_aimTargetScreen = pick.scr;

    const uint64_t ml = rpm<uint64_t>(g_localPlayer + ox::PM_MOUSELOOK);
    if (!ox_isPtr(ml)) return;
    const Vector3 delta = pick.point - eye;
    const float horiz = sqrtf(delta.x * delta.x + delta.z * delta.z);
    if (horiz < 0.001f) return;

    // Углы камеры в MouseLook (смещения подтверждаются сверкой с матрицей камеры, см. ox_aimCalibTick).
    int pOff, yOff;
    ox_aimOffsets(&pOff, &yOff);
    const float curPitch = rpm<float>(ml + (uint64_t)pOff), curYaw = rpm<float>(ml + (uint64_t)yOff);
    if (!isfinite(curPitch) || !isfinite(curYaw) || fabsf(curPitch) > 95.f) return;
    const float targetPitch = -atan2f(delta.y, horiz) * aimcore::kRadToDeg;
    const float targetYaw = atan2f(delta.x, delta.z) * aimcore::kRadToDeg;

    // Лимиты наклона берём у самой игры (MouseLook.defaultLookLimits), иначе ±80.
    float lim[2] = { -80.f, 80.f };
    float gl[2];
    if (vm_readv((unsigned long)(ml + ox::ML_DEFAULT_LOOK_LIMITS), gl, sizeof(gl)) && isfinite(gl[0]) && isfinite(gl[1]) &&
        gl[0] < gl[1] && gl[0] > -90.f && gl[1] < 90.f) { lim[0] = gl[0]; lim[1] = gl[1]; }

    // Реальное направление камеры берём из матрицы: отдача и покачивание сдвигают камеру относительно поля углов, и прицел, наведённый
    // по полю, промахивается. Разница «камера − поле» сглаживается и учитывается в ошибке. Используется только когда сверка полей с матрицей
    // уже подтвердила, что матрица и поле в одной системе углов.
    static float s_offP = 0.f, s_offY = 0.f, s_lastP = 1e9f, s_lastY = 1e9f;
    float offP = 0.f, offY = 0.f;
    if (aimRecoilComp && g_aimCalib.done && g_camVPValid) {
        float cy, cp;
        if (aimcore::anglesFromVP(g_camVP.m, &cy, &cp)) {
            const bool still = fabsf(curPitch - s_lastP) < 0.15f && fabsf(aimcore::wrapDeg(curYaw - s_lastY)) < 0.15f;
            if (still || s_lastP > 1e8f) {
                const float rp = ::clamp<float>(cp - curPitch, -20.f, 20.f), ry = ::clamp<float>(aimcore::wrapDeg(cy - curYaw), -20.f, 20.f);
                s_offP += (rp - s_offP) * 0.5f; s_offY += (ry - s_offY) * 0.5f;
            }
        }
        offP = s_offP; offY = s_offY;
    } else { s_offP = s_offY = 0.f; }
    s_lastP = curPitch; s_lastY = curYaw;

    const float dt = ImGui::GetIO().DeltaTime;
    // Слежение: пружина с опережением по скорости цели (aim_core.h). Состояние сбрасывается при новой цели и после паузы в наводке.
    static aimcore::Spring1D s_spP, s_spY;
    static double s_trackT = -1.0, s_lastCall = -10.0;
    const double nowT = (double)ImGui::GetTime();
    if (s_trackT != s_acquireT || nowT - s_lastCall > 0.12) { s_spP.reset(); s_spY.reset(); s_trackT = s_acquireT; }
    s_lastCall = nowT;
    const float ramp = aimcore::rampScale((float)(nowT - s_acquireT), aimRampMs * 0.001f);
    float nextPitch = curPitch, nextYaw = curYaw, stP = 0.0f, stY = 0.0f;
    if (aimVert) {
        const float cur = curPitch + offP;
        const float st = aimSmoothConst ? aimcore::constStep(targetPitch - cur, dt, aimSmooth, aimMaxSpeed * ramp, aimDeadzone)
                                        : s_spP.update(targetPitch, cur, dt, aimSmooth, ramp, aimMaxSpeed, aimDeadzone, false);
        stP = st;
        nextPitch = ::clamp<float>(curPitch + st, lim[0], lim[1]);
    }
    if (aimHoriz) {
        const float cur = curYaw + offY;
        const float st = aimSmoothConst ? aimcore::constStep(aimcore::wrapDeg(targetYaw - cur), dt, aimSmooth, aimMaxSpeed * ramp, aimDeadzone)
                                        : s_spY.update(targetYaw, cur, dt, aimSmooth, ramp, aimMaxSpeed, aimDeadzone, true);
        stY = st;
        nextYaw = aimcore::wrapDeg(curYaw + st);
    }
    // Revalidate immediately before the write, not only during selection.
    const auto finalLife=ox_lifeRead(pick.life);
    if(finalLife!=targetlife::State::Alive) {
        if(finalLife==targetlife::State::Dead) ox_chamsDeath(pick.life,ImGui::GetTime());
        g_aimHasTarget=false;s_lockAddr=0;s_acquireT=-1.0;
        s_spP.reset();s_spY.reset();return;
    }
    bool wrote = true;
    if (nextPitch != curPitch || nextYaw != curYaw) {
        if (yOff == pOff + 4) { const float out[2] = { nextPitch, nextYaw }; wrote = vm_writev((unsigned long)(ml + (uint64_t)pOff), out, sizeof(out)); }
        else wrote = vm_writev((unsigned long)(ml + (uint64_t)pOff), &nextPitch, 4) & vm_writev((unsigned long)(ml + (uint64_t)yOff), &nextYaw, 4);
    }
    static double s_lastLog = 0.0;
    const double nowL = (double)ImGui::GetTime();
    if (nowL - s_lastLog > 2.0) {
        s_lastLog = nowL;
        OXLOGI("[aim] pitch %.2f->%.2f yaw %.2f->%.2f (цель %.2f/%.2f, поправка камеры %.2f/%.2f) поля +0x%x/+0x%x%s запись=%s", curPitch, nextPitch, curYaw, nextYaw,
               targetPitch, targetYaw, offP, offY, pOff, yOff, g_aimCalib.done ? " (проверены по матрице)" : " (из заголовка, ещё не проверены)", wrote ? "ok" : "ОШИБКА");
    }
}

// ── Memory: No Recoil / No Spread ───────────────────────────────────────────────────────────────────
// Отдача и разброс задаются общими конфигами оружия (RecoilConfig, DispersionConfig, HitscanWeaponConfig). Правка — по фиксированной цепочке
// от FPManager._currentWeapon (см. weapon_patch.h), без поиска по памяти. Оригиналы запоминаются и возвращаются при выключении.
// Накопленная отдача камеры (Rys.Recoil) и накопленный разброс (калькулятор Fg) дополнительно обнуляются каждый кадр.
static std::string ox_classNameCached(uint64_t obj);
struct OxPatchMem {
    bool rd(uint64_t a, void *b, size_t n) { return vm_readv((unsigned long)a, b, n); }
    bool wr(uint64_t a, const void *b, size_t n) { return vm_writev((unsigned long)a, b, n); }
    std::string cls(uint64_t o) { return ox_classNameCached(o); }
};
static xray::Engine g_xrayEngine;
static chams::Effects g_chamsEffects;
static chams::Settings ox_chamsSettings() {
    chams::Settings s;s.style=chamsStyle;s.opacity=chamsOpacity;s.glow=chamsGlow;
    s.speed=chamsSpeed;s.duration=chamsDuration;s.animated=chamsAnimated;return s;
}
static oxskel::Pose ox_chamsPose(const PlayerCacheData &p) {
    using namespace oxskel;
    Pose out{};
    auto v=[](const Vector3 &x){return V3{x.x,x.y,x.z};};
    out.j[J_HEAD]=v(p.headPos);out.j[J_NECK]=v(p.neckPos);
    out.j[J_CHEST]=v(p.spine1Pos);out.j[J_PELVIS]=v(p.spine2Pos);
    out.j[J_SPINE]=p.skelLive ? v(p.spineMidPos) : lerp(out.j[J_CHEST],out.j[J_PELVIS],.5f);
    out.j[J_SH_R]=v(p.rshoulderPos);out.j[J_SH_L]=v(p.lshoulderPos);
    out.j[J_EL_R]=v(p.ruparmPos);out.j[J_EL_L]=v(p.luparmPos);
    out.j[J_HAND_R]=v(p.rlowarmPos);out.j[J_HAND_L]=v(p.llowarmPos);
    out.j[J_HIP_R]=v(p.rhipPos);out.j[J_HIP_L]=v(p.lhipPos);
    out.j[J_KNEE_R]=v(p.rkneePos);out.j[J_KNEE_L]=v(p.lkneePos);
    out.j[J_FOOT_R]=v(p.rfootPos);out.j[J_FOOT_L]=v(p.lfootPos);
    out.j[J_TOE_R]=p.skelLive ? v(p.rtoePos) : out.j[J_FOOT_R];
    out.j[J_TOE_L]=p.skelLive ? v(p.ltoePos) : out.j[J_FOOT_L];
    out.headC=p.skelLive ? v(p.headCenter) : out.j[J_HEAD]+V3{0,.05f,0};
    out.headR=p.skelLive ? p.headRadius : .105f;
    return out;
}
static void ox_chamsDeath(const targetlife::Ticket &t,double now) {
    const auto it=g_chamsEffects.seen.find(t.pm);
    if(it==g_chamsEffects.seen.end()) return;
    if(it->second.klass!=t.klass || it->second.netId!=t.netId) return;
    g_chamsEffects.death(t.pm,now,ox_chamsSettings(),chamsOn && chamsDissolve);
}
static void ox_chamsBegin(double now,bool cameraAlive) {
    static uint64_t local=0;
    std::vector<OxDeathNotice> notices;
    {std::lock_guard<std::mutex> lk(g_deathMutex);notices.swap(g_deathNotices);}
    if (!chamsOn || !cameraAlive || local!=g_localPlayer) {
        g_chamsEffects.clear();local=g_localPlayer;return;
    }
    // The worker's clock is steady_clock; age is converted to the UI clock.
    // Consume notifications on this frame: workers never touch ImGui/effects.
    const double clock=ox_lifeClock();
    for(const auto &n:notices) {
        if(clock-n.at>=0 && clock-n.at<.25 && rpm<uint64_t>(n.ticket.pm)==n.ticket.klass &&
           ox_netIdOf(n.ticket.pm)==n.ticket.netId)
            ox_chamsDeath(n.ticket,now); // first visible frame after the live death read
    }
    g_chamsEffects.prune(now);
    if (!chamsDissolve) g_chamsEffects.bursts.clear();
    // Copy keys: ox_lifeSnapshot can erase the pose immediately on death.
    std::vector<uint64_t> tracked;tracked.reserve(g_chamsEffects.seen.size());
    for(const auto &entry:g_chamsEffects.seen) tracked.push_back(entry.first);
    for(uint64_t pm:tracked) {
        const auto it=g_chamsEffects.seen.find(pm);if(it==g_chamsEffects.seen.end()) continue;
        if(rpm<uint64_t>(pm)!=it->second.klass || ox_netIdOf(pm)!=it->second.netId) {
            g_chamsEffects.seen.erase(it);continue;
        }
        targetlife::Ticket ticket;ox_lifeSnapshot(pm,ticket);
    }
}
static void ox_xrayStop() {
    OxPatchMem mem;
    g_xrayEngine.stop(mem);
    g_xrayStatus=g_xrayEngine.status;
}
static void ox_xrayTick(double now) {
    OxPatchMem mem;
    uint64_t owner=0,cam=0;
    if (xrayOn && ox_isPtr(g_localPlayer) && ox_localPlayerStillValid()) {
        const uint64_t rm=rpm<uint64_t>(g_localPlayer+ox::PM_RAYCASTMANAGER);
        if (ox_isPtr(rm)) owner=rpm<uint64_t>(rm+ox::RM_WORLD_CAMERA);
        if (ox_isPtr(owner)) cam=rpm<uint64_t>(owner+ox::OBJ_CACHED_PTR);
        if (!ox_isPtr(cam)) cam=0;
        if (cam && (cam!=g_camNativeCached || g_camProjMatOff<0)) ox_findCameraMatrices(cam);
    }
    g_xrayEngine.tick(mem,owner,cam,g_camProjMatOff,g_camViewMatOff,xrayOn,xrayDistance,now);
    g_xrayStatus=g_xrayEngine.status;
}
// ── Memory: Stretch и Boost ──────────────────────────────────────────────────────────────────────────────────────────────────────
// Камера берётся независимо от ESP (нужен только локальный игрок); смещения матриц ищет тот же ox_findCameraMatrices, что и ESP.
// Стретч (соотношение сторон) и дальность отрисовки — два экземпляра одного движка (stretch_core.h): поле находится по совпадению со
// значением из матрицы проекции и подтверждается реакцией матрицы, без реакции записи откатываются.
static int ox_overlayCap() {
    static const int kCaps[5] = { 0, 90, 60, 45, 30 };
    int cap = kCaps[boostFpsMode < 0 ? 0 : (boostFpsMode > 4 ? 4 : boostFpsMode)];
    if (cap == 0) {
#if defined(__x86_64__)
        cap = 60; // Uncapped Auto reached 240 overlay fps on the PC emulator.
#else
        if (g_menuOpen) cap = 60;
#endif
    }
    return cap;
}
static constexpr uint64_t OX_TI_WSCONTROLLER = oxarch::kCur.tiWorldStreaming;   // WorldStreamingController_TypeInfo (script.json 1.14.11949)
static constexpr uint64_t WS_STAT_GRASS = 0x18, WS_STAT_TREES = 0x19;   // public static bool GrassEnabled / TreesEnabled

static void ox_stretchTick(double now) {
    static stretch::Engine ES(stretch::Kind::Aspect), ED(stretch::Kind::FarClip);
    static boost::BoolPatch grass, trees;
    static OxPatchMem mem;
    uint64_t cam = 0;
    if (ox_isPtr(g_localPlayer)) cam = ox_getNativeCamera(g_localPlayer);
    if ((stretchOn || boostDraw) && cam && (g_camProjMatOff < 0 || cam != g_camNativeCached)) ox_findCameraMatrices(cam);
    const float scr = (abs_ScreenX > 0 && abs_ScreenY > 0) ? (float)abs_ScreenX / (float)abs_ScreenY : 16.f / 9.f;
    ES.tick(mem, cam, g_camProjMatOff, g_camViewMatOff, stretchOn, stretch::presetAspect(stretchMode, stretchCustom), scr, now);
    ED.tick(mem, cam, g_camProjMatOff, g_camViewMatOff, boostDraw, boostDrawDist, 0.f, now);
    for (const std::string &l : ES.drain()) OXLOGI("%s", l.c_str());
    for (const std::string &l : ED.drain()) OXLOGI("%s", l.c_str());
    g_stretchStatus = ES.status;
    g_boostStatus[0] = ED.status;

    // Трава и деревья мира: статические флаги WorldStreamingController.
    static uint64_t s_wsKlass = 0;
    uint64_t statics = 0;
    if (boostGrass || boostTrees || grass.taken || trees.taken) {
        if (!s_wsKlass) s_wsKlass = ox_klassFromSlot(OX_TI_WSCONTROLLER, "WorldStreamingController");
        const uint64_t st = s_wsKlass ? rpm<uint64_t>(s_wsKlass + ox::CLASS_STATIC_FIELDS) : 0;
        if (ox_isPtr(st)) statics = st;
    }
    const boost::Result rg = grass.tick(mem, statics ? statics + WS_STAT_GRASS : 0, boostGrass, now);
    const boost::Result rt = trees.tick(mem, statics ? statics + WS_STAT_TREES : 0, boostTrees, now);
    static bool s_logG = false, s_logT = false;
    if ((rg == boost::Result::Held) != s_logG) { s_logG = rg == boost::Result::Held; OXLOGI("[boost] grass %s (original %d, overwritten by the game %d times)", s_logG ? "hidden" : "restored", (int)grass.original, grass.overwrites); }
    if ((rt == boost::Result::Held) != s_logT) { s_logT = rt == boost::Result::Held; OXLOGI("[boost] trees %s (original %d, overwritten by the game %d times)", s_logT ? "hidden" : "restored", (int)trees.original, trees.overwrites); }
    auto word = [&](boost::Result r) { return r == boost::Result::Held ? "hidden" : r == boost::Result::Waiting ? "waiting for the game" : r == boost::Result::Invalid ? "field not recognised" : "drawn"; };
    char w[120]; snprintf(w, sizeof(w), "World: grass %s, trees %s", word(rg), word(rt));
    g_boostStatus[1] = w;

    // Частота кадров оверлея: пауза перед кадром задаётся в основном цикле (ox_overlayPace); здесь — статус.
    const int cap = ox_overlayCap();
    char o[120];
    if (cap <= 0) snprintf(o, sizeof(o), "Overlay: auto (%.0f fps)", ImGui::GetIO().Framerate);
    else snprintf(o, sizeof(o), "Overlay: limit %d fps (now %.0f)", cap, ImGui::GetIO().Framerate);
    g_boostStatus[2] = o;

    // Логи: каждая строка — запись в файл на sdcard; выключенные логи уменьшают нагрузку.
    static bool s_logOff = false, s_savedEnabled = true;
    if (boostNoLog != s_logOff) {
        if (boostNoLog) { OXLOGI("[boost] logs switched off"); s_savedEnabled = oxlog::enabled; oxlog::enabled = false; }
        else { oxlog::enabled = s_savedEnabled; OXLOGI("[boost] logs switched on"); }
        s_logOff = boostNoLog;
    }
    g_boostStatus[3] = boostNoLog ? "Logs: off" : "Logs: on (turn off for a bit more speed)";
}

// Limit overlay rendering even while the menu is open. An uncapped menu was
// drawing 100-120 frames/s in BlueStacks and competing with the game GPU.
static void ox_overlayPace() {
    const int cap = ox_overlayCap();
    const double now = std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
    static double s_lastEnd = 0.0;
    if (cap > 0 && s_lastEnd > 0.0) {
        // BlueStacks does not reliably block on vsync. The 3 ms early margin
        // made a requested 60 fps cap run near 70 fps, so use the full period.
        const double sl = boost::frameSleep(s_lastEnd, now, cap, 0.0);
        if (sl > 0.0005) usleep((useconds_t)(sl * 1e6));
    }
    s_lastEnd = std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

static void ox_memoryTick(double now) {
    static wpatch::Patcher<OxPatchMem> P;
    static OxPatchMem mem;
    static wpatch::Ctx ctx;
    static uint64_t lastWeapon = 0;
    static double nextResolve = 0.0;
    static bool lastRec = false, lastSpr = false;
    static std::unordered_set<uint64_t> logged;
    static int recWrites = 0, sprWrites = 0, liveZeroed = 0, rysZeroed = 0;

    if (!noRecoil && lastRec) { const int n = P.restore(mem, wpatch::kRecoil); OXLOGI("[mem] No Recoil выключен: возвращено полей %d", n); }
    if (!noSpread && lastSpr) { const int n = P.restore(mem, wpatch::kSpread); OXLOGI("[mem] No Spread выключен: возвращено полей %d", n); }
    lastRec = noRecoil; lastSpr = noSpread;
    if (!noRecoil && !noSpread) { g_memStatus = "No Recoil / No Spread: off"; return; }
    if (!ox_isPtr(g_localPlayer)) { g_memStatus = "Waiting for local player..."; return; }

    const uint64_t fp = rpm<uint64_t>(g_localPlayer + ox::PM_FPMANAGER);
    const uint64_t weapon = ox_isPtr(fp) ? rpm<uint64_t>(fp + ox::FP_CURRENT_WEAPON) : 0;
    if (weapon != lastWeapon || now >= nextResolve) {
        const bool changed = weapon != lastWeapon;
        lastWeapon = weapon;
        const bool ok = P.resolve(mem, weapon, ctx);
        nextResolve = now + (ok ? 3.0 : 1.0);
        if (ok) {
            const int r = noRecoil ? P.applyRecoil(mem, ctx) : 0, sp = noSpread ? P.applySpread(mem, ctx) : 0;
            recWrites += r; sprWrites += sp;
            if (logged.size() < 40 && logged.insert(ctx.cfg).second)
                OXLOGI("[mem] оружие 0x%llx: HitscanWeaponConfig=0x%llx (по +0x%llx) RecoilConfig=0x%llx DispersionConfig=0x%llx калькулятор разброса=%s | записано полей: отдача %d, разброс %d (сохранено оригиналов: %d/%d)",
                       (unsigned long long)weapon, (unsigned long long)ctx.cfg, (unsigned long long)ctx.cfgOff, (unsigned long long)ctx.recoil, (unsigned long long)ctx.disp,
                       ctx.calc ? "подтверждён" : "нет", r, sp, P.count(wpatch::kRecoil), P.count(wpatch::kSpread));
        } else if (changed) {
            OXLOGI("[mem] в руках 0x%llx — не огнестрельное оружие (конфиги не найдены)", (unsigned long long)weapon);
        }
    }
    if (ctx.ok() && weapon == ctx.weapon) {
        if (noSpread && P.zeroLiveSpread(mem, ctx)) ++liveZeroed;
    }
    if (noRecoil) {
        const uint64_t rys = rpm<uint64_t>(g_localPlayer + ox::PM_EVENT_HANDLER);
        if (ox_isPtr(rys) && rpm<uint64_t>(rys + ox::RYS_MANAGER) == g_localPlayer) {
            const uint64_t rec = rpm<uint64_t>(rys + ox::RYS_RECOIL);
            float v[2];
            if (ox_isPtr(rec) && vm_readv((unsigned long)(rec + ox::RYR_VALUE_A), v, sizeof(v)) && isfinite(v[0]) && isfinite(v[1]) &&
                fabsf(v[0]) < 90.f && fabsf(v[1]) < 90.f && (fabsf(v[0]) > 1e-4f || fabsf(v[1]) > 1e-4f)) {
                const float z[2] = { 0.f, 0.f };
                if (vm_writev((unsigned long)(rec + ox::RYR_VALUE_A), z, sizeof(z))) ++rysZeroed;
            }
        }
    }
    static double nextStatus = 0.0;
    if (now >= nextStatus) {
        nextStatus = now + 0.5;
        char b[200];
        if (!ctx.ok() || weapon != ctx.weapon) snprintf(b, sizeof(b), "Held item has no recoil/spread config");
        else snprintf(b, sizeof(b), "Weapon patched: recoil %s, spread %s", noRecoil ? "0" : "-", noSpread ? "0" : "-");
        g_memStatus = b;
    }
    static double nextLog = 0.0;
    if (now >= nextLog) {
        nextLog = now + 30.0;
        OXLOGI("[mem] No Recoil=%d No Spread=%d | оружие %s | записей отдачи %d, разброса %d, обнулений накопленного разброса %d, отдачи камеры %d", (int)noRecoil, (int)noSpread,
               ctx.ok() && weapon == ctx.weapon ? "найдено" : "без конфигов", recWrites, sprWrites, liveZeroed, rysZeroed);
    }
}

// ── Мир: постройки (для проверки видимости) и руда ───────────────────────────
// Обе категории — сетевые объекты, значит клиент знает их через Mirror NetworkClient.spawned. Один фоновый поток обходит
// реестр раз в 2 с: NetworkIdentity -> NetworkBehaviours[] -> компонент опознаётся по самосогласованным полям.
// Отвергнутые объекты запоминаются (повторно не читаются), найденные перепроверяются дёшево.
bool oreEsp = true, oreStone = true, oreMetal = true, oreSulfur = true, oreCoal = true, oreDistText = true;
float oreMaxDist = 150.f;
enum { ORE_STONE, ORE_METAL, ORE_SULFUR, ORE_COAL, ORE_KINDS };
struct OxOre { int kind = -1; Vector3 pos; };
static std::mutex g_oreMtx;
static std::vector<OxOre> g_oreList;
static std::atomic<bool> g_worldThreadStarted{false};
static std::atomic<int> g_worldStage{0};     // 0 нет klass NetworkClient, 1 spawned не читается, 2 обход идёт
static std::atomic<int> g_worldWalked{0}, g_worldBuildings{0}, g_worldOres{0};

// ── Животные: MineableObject с entityType животного. Вид включается отдельно, дальность общая ──
bool animalEsp = true, animalBear = true, animalBoar = true, animalDeer = true, animalRabbit = true, animalHare = true,
     animalChicken = true, animalFish = true, animalRat = true, animalCannibal = true, animalDistText = true;
float animalMaxDist = 200.f;
enum { ANI_BEAR, ANI_BOAR, ANI_DEER, ANI_RABBIT, ANI_HARE, ANI_CHICKEN, ANI_FISH, ANI_RAT, ANI_CANNIBAL, ANI_KINDS };
struct OxAnimal { int type = -1; uint64_t comp = 0; Vector3 pos; double stamp = 0.0; };
static std::mutex g_animalMtx;
static std::vector<OxAnimal> g_animalList;
static std::atomic<int> g_worldAnimals{0};
static double ox_nowSec() { return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count(); }
// ── База: шкафы, турели/ловушки, спальники, отключившиеся (спящие) игроки. Объекты неподвижны: позиция и имя читаются один раз ──
bool baseEsp = true, baseCupboard = true, baseTurret = true, baseBag = true, baseSleeper = true, baseDistText = true;
float baseMaxDist = 300.f;
// Explicit overlay mode, independent of Base ESP and the ordinary cupboard filter.
bool cupboardFinder = false;
bool cupboardGuide = true;
float cupboardRadius = 100.f;
enum { BASE_CUPBOARD, BASE_TURRET, BASE_TURRET_SG, BASE_TURRET_SNOW, BASE_TRAP, BASE_SAM, BASE_BAG, BASE_SLEEPER, BASE_KINDS };
struct OxBase { int kind = -1; Vector3 pos; uint64_t klass = 0; std::string text; };
static std::mutex g_baseMtx;
static std::vector<OxBase> g_baseList;
static std::atomic<int> g_worldBase{0};
// Имена классов — точные: у учебных/вложенных вариантов (TutorialCupboard и т. п.) имя другое.
static int ox_baseKind(const std::string &cls) {
    if (cls == "Cupboard") return BASE_CUPBOARD;
    if (cls == "AutoTurret") return BASE_TURRET;
    if (cls == "AutoTurretShotgun") return BASE_TURRET_SG;
    if (cls == "AutoSnowballTurret") return BASE_TURRET_SNOW;
    if (cls == "GunTrap") return BASE_TRAP;
    if (cls == "AutoSamTurret") return BASE_SAM;
    if (cls == "SleepingBag") return BASE_BAG;
    if (cls == "DisconnectedSleeper") return BASE_SLEEPER;
    return -1;
}
static int ox_animalType(int et) {
    switch (et) {
        case ox::ENT_BEAR: return ANI_BEAR;       case ox::ENT_BOAR: return ANI_BOAR;     case ox::ENT_DEER: return ANI_DEER;
        case ox::ENT_RABBIT: return ANI_RABBIT;   case ox::ENT_HARE: return ANI_HARE;     case ox::ENT_CHICKEN: return ANI_CHICKEN;
        case ox::ENT_FISH: return ANI_FISH;       case ox::ENT_RAT: return ANI_RAT;       case ox::ENT_CANNIBAL: return ANI_CANNIBAL;
        default: return -1;
    }
}

// ── Позиция нативного Transform по иерархии (как для костей): мировая позиция = цепочка локальных TRS до корня ──
static bool ox_nativeWorldPos(uint64_t nat, Vector3 &out) {
    if (!ox_isPtr(nat)) return false;
    static const oxbone::Layout s_def;                                   // раскладка по умолчанию, если g_trs ещё не откалибрована
    const oxbone::Layout &L = g_trs.ok ? g_trs : s_def;
    OxMem mem;
    uint64_t hier = 0, lb = 0, pb = 0;
    int idx = 0;
    if (!oxbone::ReadHeader(mem, L, nat, hier, idx) || !oxbone::ReadArrays(mem, L, hier, lb, pb)) return false;
    const int stride = L.fmt.stride > 0 && L.fmt.stride <= 0x100 ? L.fmt.stride : 0x30;
    int chain[24], n = 0, cur = idx;
    while (cur >= 0 && n < 24) {
        chain[n++] = cur;
        int par = -1;
        if (!vm_readv((unsigned long)(pb + 4ULL * (uint64_t)cur), &par, 4) || par >= oxskel::kMaxNodes) return false;
        cur = par;
    }
    if (cur >= 0 || n == 0) return false;
    oxskel::TRS loc[24]; int parent[24]; uint8_t have[24];
    uint8_t buf[64];
    const size_t rec = (size_t)(stride < 64 ? stride : 64);
    for (int k = 0; k < n; ++k) {
        if (!vm_readv((unsigned long)(lb + (uint64_t)chain[k] * (uint64_t)stride), buf, rec) || !oxskel::ParseTRS(buf, L.fmt, loc[k])) return false;
        parent[k] = k + 1 < n ? k + 1 : -1; have[k] = 1;
    }
    oxskel::Hier h; h.N = n; h.parent = parent; h.loc = loc; h.have = have;
    oxskel::V3 p;
    if (!oxskel::WorldPR(h, 0, &p, nullptr)) return false;
    if (!isfinite(p.x) || !isfinite(p.y) || !isfinite(p.z) || fabsf(p.x) > 50000.f || fabsf(p.z) > 50000.f || fabsf(p.y) > 5000.f) return false;
    out = Vector3(p.x, p.y, p.z);
    return true;
}

// ── Позиция компонента, у которого нет managed-поля Transform ──
// Цепочка по нативным объектам Unity: MonoBehaviour+0x10 -> нативный компонент -> GameObject (+a) -> массив компонентов (+b) -> Transform (+c).
// Смещения a/b/c зависят от версии Unity, поэтому один раз подтверждаются по реальным игрокам: позиция, посчитанная по цепочке для PlayerManager,
// должна совпасть с известной позицией игрока (ox_readPos). Перебор — несколько сотен чтений нескольких байт, без сканов памяти.
static std::atomic<bool> g_posChainOk{false};
static int g_posA = 0, g_posB = 0, g_posC = 0;
static bool ox_chainPos(uint64_t mb, int a, int b, int c, Vector3 &out) {
    const uint64_t nat = rpm<uint64_t>(mb + ox::OBJ_CACHED_PTR);
    if (!ox_isPtr(nat)) return false;
    const uint64_t go = rpm<uint64_t>(nat + (uint64_t)a);
    if (!ox_isPtr(go)) return false;
    const uint64_t arr = rpm<uint64_t>(go + (uint64_t)b);
    if (!ox_isPtr(arr)) return false;
    const uint64_t tr = rpm<uint64_t>(arr + (uint64_t)c);
    return ox_isPtr(tr) && ox_nativeWorldPos(tr, out);
}

// ── Трекер стрел (лук, арбалет, копьё) ───────────────────────────────────────────────────────────────────────────────────────────
// Стрела — сетевой объект ShaftedProjectile со своей физикой; в ballisticShots (пули автоматов) её нет. Пока в руках стрелковое оружие,
// раз в ~25 мс просматривается NetworkClient.spawned: новые ключи (netId) с компонентом ShaftedProjectile отслеживаются по позиции
// нативного Transform (m_Pivot/m_Model). По первым ~70 мс полёта считается начальная скорость и направление (с поправкой на гравитацию)
// и сравнивается с тем, что мы записали в LookDirection, и с камерой. Это единственный способ узнать, берёт ли игра направление стрелы
// из LookDirection: по дампу видно лишь, что у FPBow/FPCrossbow есть поле Camera. Измеренная скорость идёт в план следующего выстрела.
static bool ox_arrowPos(uint64_t c, Vector3 &out) {
    for (uint64_t off : { (uint64_t)ox::SP_PIVOT, (uint64_t)ox::SP_MODEL }) {
        const uint64_t tr = rpm<uint64_t>(c + off);
        if (!ox_isPtr(tr)) continue;
        if (ox_nativeWorldPos(rpm<uint64_t>(tr + ox::OBJ_CACHED_PTR), out) && !(out.x == 0.f && out.y == 0.f && out.z == 0.f)) return true;
    }
    return g_posChainOk.load() && ox_chainPos(c, g_posA, g_posB, g_posC, out) && !(out.x == 0.f && out.y == 0.f && out.z == 0.f);
}

static void ox_arrowThread() {
    OXLOGI("[thread] arrow tid=%ld", (long)syscall(SYS_gettid));
    struct Trk { uint64_t comp = 0; uint32_t key = 0; double born = 0.0, t[10]; Vector3 p[10]; int n = 0; };
    std::unordered_set<uint32_t> seen;
    std::unordered_map<uint64_t, bool> klassIsArrow;
    std::vector<Trk> trk; std::vector<uint8_t> buf;
    bool baseline = false; uint64_t klass = 0; int logged = 0; int32_t lastVersion = -1, lastCount = -1;
    auto angleDeg = [](float ax, float ay, float az, float bx, float by, float bz) {
        const float la = sqrtf(ax * ax + ay * ay + az * az), lb = sqrtf(bx * bx + by * by + bz * bz);
        if (la < 1e-4f || lb < 1e-4f) return 180.f;
        return acosf(::clamp<float>((ax * bx + ay * by + az * bz) / (la * lb), -1.f, 1.f)) * 57.29578f;
    };
    while (main_thread_flag) {
        std::this_thread::sleep_for(std::chrono::milliseconds(25));
        const int kind = g_silArrowKind.load();
        if (!silentAim || !kind) { if (baseline || !trk.empty()) { seen.clear(); trk.clear(); baseline = false; } std::this_thread::sleep_for(std::chrono::milliseconds(100)); continue; }
        const double now = ox_silentClock();
        if (!klass) klass = ox_klassFromSlot(OX_TI_NETWORKCLIENT, "NetworkClient");
        if (!klass) continue;
        const uint64_t st = rpm<uint64_t>(klass + ox::CLASS_STATIC_FIELDS);
        const uint64_t dict = ox_isPtr(st) ? rpm<uint64_t>(st + ox::NC_SPAWNED_DICT) : 0;
        // Словарь меняется только при появлении/исчезновении объекта; _count/_freeList/_freeCount/_version лежат подряд (0x20..0x2C) — одно
        // маленькое чтение. Пока версия и счётчик те же, 144 КБ записей читать незачем (раньше это шло 40 раз в секунду).
        int32_t dh[4] = { 0, 0, 0, 0 };
        if (ox_isPtr(dict) && vm_readv((unsigned long)(dict + 0x20), dh, sizeof(dh)) && baseline && dh[3] == lastVersion && dh[0] == lastCount) goto track;
        {
        const uint64_t entries = ox_isPtr(dict) ? rpm<uint64_t>(dict + ox::DICT_ENTRIES) : 0;
        int count = ox_isPtr(dict) ? ox_dictCount(dict) : 0;
        const uint64_t arrLen = ox_isPtr(entries) ? rpm<uint64_t>(entries + ox::ARRAY_COUNT) : 0;
        if (!ox_isPtr(entries) || count <= 0 || arrLen == 0) continue;
        if ((uint64_t)count > arrLen) count = (int)arrLen;
        if (count > 6000) count = 6000;
        buf.resize((size_t)count * ox::DICT_ENTRY_STRIDE);
        if (!vm_readv((unsigned long)(entries + ox::ARRAY_DATA), buf.data(), buf.size())) continue;
        if (seen.size() > 30000) { seen.clear(); baseline = false; }
        lastVersion = dh[3]; lastCount = dh[0];
        for (int i = 0; i < count; ++i) {
            const uint8_t *e = buf.data() + (size_t)i * ox::DICT_ENTRY_STRIDE;
            int32_t h; uint32_t key; uint64_t ni;
            memcpy(&h, e, 4); memcpy(&key, e + 8, 4); memcpy(&ni, e + ox::DICT_ENTRY_VALUE, 8);
            if (h < 0 || !ox_isPtr(ni)) continue;
            if (!seen.insert(key).second || !baseline) continue;          // первый проход — только запоминаем уже существующие объекты
            const uint64_t bArr = rpm<uint64_t>(ni + ox::NI_BEHAVIOURS);
            const uint64_t bn = ox_isPtr(bArr) ? rpm<uint64_t>(bArr + ox::ARRAY_COUNT) : 0;
            if (bn == 0 || bn > 16) continue;
            uint64_t comps[16];
            if (!vm_readv((unsigned long)(bArr + ox::ARRAY_DATA), comps, (size_t)bn * 8)) continue;
            for (uint64_t k = 0; k < bn; ++k) {
                const uint64_t c = comps[k];
                if (!ox_isPtr(c)) continue;
                const uint64_t kl = rpm<uint64_t>(c);
                auto it = klassIsArrow.find(kl);
                if (it == klassIsArrow.end()) {
                    char cn[64]; ox_className(kl, cn, sizeof(cn));
                    if (klassIsArrow.size() > 4000) klassIsArrow.clear();
                    it = klassIsArrow.emplace(kl, strcmp(cn, "ShaftedProjectile") == 0).first;
                }
                if (!it->second) continue;
                Trk t; t.comp = c; t.key = key; t.born = now;
                trk.push_back(t); ++sArrSeen;
                break;
            }
        }
        baseline = true;
        }
        track:

        for (size_t ti = 0; ti < trk.size();) {
            Trk &T = trk[ti];
            bool drop = now - T.born > 0.7;
            Vector3 pos;
            if (!drop && T.n < 10 && ox_arrowPos(T.comp, pos) && (T.n == 0 || now - T.t[T.n - 1] >= 0.02)) { T.p[T.n] = pos; T.t[T.n] = now; ++T.n; }
            if (!drop && T.n >= 3 && T.t[T.n - 1] - T.t[0] >= 0.06) {
                const double span = T.t[T.n - 1] - T.t[0];
                const float g = fabsf(rpm<float>(T.comp + ox::SP_GRAVITY));
                Vector3 v = (T.p[T.n - 1] - T.p[0]) * (float)(1.0 / span);
                v.y += (isfinite(g) && g < 60.f ? g : 0.f) * (float)(span * 0.5);                // v(0) = средняя + g·T/2
                const float sp = sqrtf(v.x * v.x + v.y * v.y + v.z * v.z);
                SilentCam sc; SilentAimPlan pl;
                { std::lock_guard<std::mutex> lk(g_silMtx); sc = g_silCam; pl = g_silPlan; }
                if (isfinite(sp) && sp >= 3.f) {
                    const Vector3 d = v * (1.f / sp);
                    const Vector3 toEye = sc.pos - T.p[0];
                    const float along = toEye.x * d.x + toEye.y * d.y + toEye.z * d.z;
                    const float px = toEye.x - d.x * along, py = toEye.y - d.y * along, pz = toEye.z - d.z * along;
                    const float perp = sqrtf(px * px + py * py + pz * pz);
                    const bool weaponMatch = ox_isPtr(g_silWeaponPtr.load()) && rpm<uint64_t>(T.comp + ox::SP_WEAPON_LAUNCHED) == g_silWeaponPtr.load();
                    const bool mine = sc.ok && (weaponMatch || (perp < 2.0f && along < 3.f));
                    if (mine) {
                        ++sArrOwn;
                        const bool wrFresh = now - g_silWrT.load() < 0.6;
                        const float angW = wrFresh ? angleDeg(d.x, d.y, d.z, g_silWr[0].load(), g_silWr[1].load(), g_silWr[2].load()) : 180.f;
                        const float angC = angleDeg(d.x, d.y, d.z, sc.fwd.x, sc.fwd.y, sc.fwd.z);
                        const bool hadPlan = pl.valid && now - pl.t < 0.5 && wrFresh;
                        const char *verdict;
                        if (!hadPlan) { ++sArrNoPlan; verdict = "в плане не было цели"; }
                        else if (angW <= 3.f && angC > 3.f) { ++sArrSteered; verdict = "ПО ЗАПИСАННОМУ НАПРАВЛЕНИЮ (LookDirection работает для стрел)"; }
                        else if (angC <= 3.f && angW > 3.f) { ++sArrCamera; verdict = "по камере (LookDirection для стрел НЕ используется)"; }
                        else { ++sArrOther; verdict = "неясно (цель почти на прицеле или направление иное)"; }
                        if(weaponMatch) {
                            float fields[3];
                            if(vm_readv(T.comp+ox::SP_LAUNCH_SPEED,fields,sizeof(fields)) &&
                               isfinite(fields[0]) && fields[0]>=5 && fields[0]<=800 &&
                               isfinite(fields[1]) && fields[1]>=0 && fields[1]<60 &&
                               isfinite(fields[2]) && fields[2]>=0 && fields[2]<3) {
                                SilentArrowSample sample;sample.weapon=rpm<uint64_t>(T.comp+ox::SP_WEAPON_LAUNCHED);
                                char launcherClass[64];ox_objClassName(sample.weapon,launcherClass,sizeof(launcherClass));
                                sample.kind=!strcmp(launcherClass,"FPBow") ? 1 : !strcmp(launcherClass,"FPCrossbow") ? 2 : !strcmp(launcherClass,"FPSpear") ? 3 : 0;
                                sample.speed=fields[0];sample.gravity=fields[1];sample.drag=fields[2];sample.at=now;
                                if(sample.kind) {std::lock_guard<std::mutex> lk(g_arrowSampleMutex);g_arrowSample=sample;}
                            }
                        }
                        if (logged < 24 || sArrOwn.load() % 10 == 0) {
                            ++logged;
                            OXLOGI("[silent] стрела #%d (оружие %d): скорость %.1f м/с, гравитация %.2f, замеров %d за %.0f мс | угол к записанному %.1f°, к камере %.1f° | по оружию=%d, мимо глаза %.2f м | %s",
                                   sArrOwn.load(), kind, sp, g, T.n, span * 1000.0, angW, angC, (int)weaponMatch, perp, verdict);
                        }
                    }
                }
                drop = true;
            }
            if (drop) trk.erase(trk.begin() + (long)ti); else ++ti;
        }
    }
}
static void ox_posChainCalibrate(const std::vector<PlayerCacheData> &players, double now) {
    static double next = 0.0; static int tries = 0;
    if (g_posChainOk.load() || now < next || !ox_isPtr(g_localPlayer)) return;
    next = now + (tries < 6 ? 2.0 : 30.0); ++tries;
    struct Ref { uint64_t pm; Vector3 p; } refs[4]; int nr = 0;
    refs[nr++] = Ref{ g_localPlayer, ox_readPos(g_localPlayer, false) };
    for (const PlayerCacheData &pl : players) { if (nr >= 4) break; if (pl.address != g_localPlayer && ox_isPtr(pl.address)) refs[nr++] = Ref{ pl.address, ox_readPos(pl.address, false) }; }
    if (refs[0].p == Vector3::Zero()) return;
    static const int A[] = { 0x30, 0x28, 0x38, 0x20, 0x18, 0x40, 0x10, 0x48 };
    static const int B[] = { 0x30, 0x28, 0x38, 0x20, 0x18, 0x40, 0x10, 0x48, 0x50, 0x58 };
    static const int C[] = { 0x8, 0x0, 0x10, 0x18 };
    int reads = 0;
    for (int a : A) for (int b : B) for (int c : C) {
        ++reads;
        Vector3 p;
        if (!ox_chainPos(g_localPlayer, a, b, c, p)) continue;
        auto close = [&](const Vector3 &r, const Vector3 &q) { return fabsf(q.x - r.x) < 3.5f && fabsf(q.z - r.z) < 3.5f && q.y - r.y > -2.5f && q.y - r.y < 3.0f; };
        if (!close(refs[0].p, p)) continue;
        bool all = true; int others = 0;
        for (int i = 1; i < nr; ++i) {
            if (refs[i].p == Vector3::Zero()) continue;
            Vector3 q;
            if (!ox_chainPos(refs[i].pm, a, b, c, q) || !close(refs[i].p, q)) { all = false; break; }
            ++others;
        }
        if (!all) continue;
        g_posA = a; g_posB = b; g_posC = c; g_posChainOk = true;
        OXLOGI("[pos] цепочка позиции компонента подтверждена: native=+0x10 -> +0x%x -> +0x%x -> +0x%x (по локальному игроку и %d другим); раскладка Transform: %s",
               a, b, c, others, g_trs.ok ? "откалибрована по костям" : "по умолчанию");
        return;
    }
    OXLOGW("[pos] цепочка позиции компонента не подтверждена (попытка %d, проверено %d вариантов, ориентир=(%.1f %.1f %.1f)); руда возьмёт позицию из поля Transform",
           tries, reads, refs[0].p.x, refs[0].p.y, refs[0].p.z);
    if (tries <= 2) {
        uint8_t b[0x80];
        const uint64_t nat = rpm<uint64_t>(g_localPlayer + ox::OBJ_CACHED_PTR);
        if (ox_isPtr(nat) && vm_readv((unsigned long)nat, b, sizeof(b))) oxlog::hexdump("нативный объект PlayerManager", nat, b, sizeof(b));
        for (int off : { 0x30, 0x28, 0x38 }) {
            const uint64_t go = ox_isPtr(nat) ? rpm<uint64_t>(nat + (uint64_t)off) : 0;
            if (ox_isPtr(go) && vm_readv((unsigned long)go, b, sizeof(b))) { char t[48]; snprintf(t, sizeof(t), "GameObject по +0x%x", off); oxlog::hexdump(t, go, b, sizeof(b)); }
        }
    }
}

// ── Руда: Oxide.MineableObject (MineableStone и др.). Вид — прямо из поля entityType, положение — из Transform объекта ──
struct OxOreStats { int mineable = 0, stone = 0, iron = 0, sulfur = 0, ice = 0, tree = 0, coal = 0, posRru = 0, posChain = 0, posFail = 0, plausibleFail = 0; };
static OxOreStats g_oreStats;
static std::mutex g_oreStatMtx;

// Это MineableObject? Признаки независимы друг от друга (здоровье, сопротивление, вид сущности), поэтому совпадение случайным объектом практически исключено.
static bool ox_isMineable(uint64_t obj, int &entityType) {
    float f[2];
    if (!vm_readv((unsigned long)(obj + ox::MINE_RESISTANCE), f, 8)) return false;        // resistance 0x74 и currentHealth 0x78 подряд
    const float res = f[0], cur = f[1];
    const float mx = rpm<float>(obj + ox::MINE_MAX_HEALTH);
    entityType = rpm<int>(obj + ox::MINE_ENTITY_TYPE);
    if (!isfinite(res) || !isfinite(cur) || !isfinite(mx)) return false;
    if (res <= 0.0f || res > 1.0001f) return false;
    if (mx <= 0.0f || mx > 1e7f || cur < 0.0f || cur > mx * 1.05f) return false;
    return entityType >= 0 && entityType <= 25;
}

// Уголь — не отдельный вид сущности: это камень, в луте которого есть coal.
static bool ox_lootHas(uint64_t obj, const char *word) {
    const uint64_t list = rpm<uint64_t>(obj + ox::MINE_LOOT);
    if (!ox_isPtr(list)) return false;
    const uint64_t arr = rpm<uint64_t>(list + ox::LIST_ITEMS);
    const int n = rpm<int>(list + ox::LIST_SIZE);
    if (!ox_isPtr(arr) || n <= 0 || n > 16) return false;
    for (int i = 0; i < n; ++i) {
        const uint64_t li = rpm<uint64_t>(arr + ox::ARRAY_DATA + 8 * (uint64_t)i);
        if (!ox_isPtr(li)) continue;
        std::string nm = ox_readManagedString(rpm<uint64_t>(li + ox::LOOTITEM_NAME));
        for (char &c : nm) c = (char)tolower((unsigned char)c);
        if (nm.find(word) != std::string::npos) return true;
    }
    return false;
}

// Имя класса объекта по klass (кэш по указателю klass: чтение имени — один раз на тип).
static std::string ox_classNameCached(uint64_t obj) {
    static std::unordered_map<uint64_t, std::string> cache;
    const uint64_t k = rpm<uint64_t>(obj);
    if (!ox_isPtr(k)) return "";
    auto it = cache.find(k);
    if (it != cache.end()) return it->second;
    char cn[96] = {0};
    ox_objClassName(obj, cn, sizeof(cn));
    if (cache.size() > 4096) cache.clear();
    return cache[k] = cn;
}

// Первое «осмысленное» имя из лута объекта (то, что он отдаёт при добыче): sulfur.ore, metal.ore, stone, wood...
static std::string ox_lootNames(uint64_t obj, int maxItems = 3) {
    std::string out;
    const uint64_t list = rpm<uint64_t>(obj + ox::MINE_LOOT);
    if (!ox_isPtr(list)) return out;
    const uint64_t arr = rpm<uint64_t>(list + ox::LIST_ITEMS);
    const int n = rpm<int>(list + ox::LIST_SIZE);
    if (!ox_isPtr(arr) || n <= 0 || n > 16) return out;
    for (int i = 0; i < n && i < maxItems; ++i) {
        const uint64_t li = rpm<uint64_t>(arr + ox::ARRAY_DATA + 8 * (uint64_t)i);
        if (!ox_isPtr(li)) continue;
        std::string nm = ox_readManagedString(rpm<uint64_t>(li + ox::LOOTITEM_NAME));
        for (char &c : nm) c = (char)tolower((unsigned char)c);
        if (!nm.empty()) out += (out.empty() ? "" : ",") + nm;
    }
    return out;
}

// Вид руды: 1) entityType (Stone/Iron/Sulfur), 2) по лутy, 3) по имени класса (MineableStone / MineableCompositeStone — камни). -1 — не руда.
static int ox_oreKind(int et, const std::string &cls, const std::string &loot) {
    auto has = [&](const char *w) { return loot.find(w) != std::string::npos; };
    if (et == ox::ENT_STONE) return has("coal") ? ORE_COAL : ORE_STONE;
    if (et == ox::ENT_IRON) return ORE_METAL;
    if (et == ox::ENT_SULFUR) return ORE_SULFUR;
    if (et == ox::ENT_TREE || et == ox::ENT_ICE) return -1;
    if (et >= 1 && et <= 7) return -1;                                            // животные
    if (cls.find("Tree") != std::string::npos || cls.find("Animal") != std::string::npos) return -1;
    if (has("sulfur")) return ORE_SULFUR;
    if (has("metal") || has("iron")) return ORE_METAL;
    if (has("coal")) return ORE_COAL;
    if (has("stone")) return ORE_STONE;
    if (cls.find("Stone") != std::string::npos) return ORE_STONE;                  // камень без распознаваемого лута
    return -1;
}

static bool ox_orePosition(uint64_t obj, Vector3 &out, int &how) {
    const uint64_t rru = rpm<uint64_t>(obj + ox::MINE_TRANSFORM);
    if (ox_isPtr(rru)) {
        const uint64_t nat = rpm<uint64_t>(rru + ox::OBJ_CACHED_PTR);
        if (ox_nativeWorldPos(nat, out)) { how = 1; return true; }
    }
    if (g_posChainOk.load() && ox_chainPos(obj, g_posA, g_posB, g_posC, out)) { how = 2; return true; }
    if (ox_isPtr(rru) && ox_transformWorld(rru, &out, nullptr, false, nullptr) && isfinite(out.x) && isfinite(out.y) && isfinite(out.z) &&
        !(out.x == 0.f && out.y == 0.f && out.z == 0.f)) { how = 3; return true; }
    return false;
}

static void ox_worldWorker() {
    OXLOGI("[thread] world tid=%ld", (long)syscall(SYS_gettid));
    // Руда — сетевые объекты: обход NetworkClient.spawned по смещениям. Отвергнутые объекты запоминаются и повторно не читаются, найденные
    // читаются один раз (руда неподвижна). Работает только при включённом Ore ESP и не чаще раза в 3 с.
    std::unordered_set<uint64_t> rejected;
    std::unordered_map<uint64_t, OxOre> knownO;
    std::unordered_map<uint64_t, OxBase> knownB;              // объекты базы: позиция и имя читаются один раз (klass проверяется каждый проход)
    std::unordered_set<uint64_t> noPos;                      // руда без позиции: пробуем снова, когда подтвердится цепочка
    std::unordered_set<std::string> seenCombos;
    std::unordered_map<uint64_t, int> notOre;                // MineableObject, не являющиеся рудой (деревья, животные): entityType
    int nearPasses = 0; double nextNear = 0.0;
    time_t lastReset = time(nullptr);
    bool chainWas = false;
    int passes = 0;
    while (main_thread_flag) {
        sleep(3);
        if (!oreEsp && !animalEsp && !baseEsp && !cupboardFinder) continue;
        if (!g_networkClientKlass) {
            g_networkClientKlass = ox_klassFromSlot(OX_TI_NETWORKCLIENT, "NetworkClient");
            if (!g_networkClientKlass) { g_worldStage = 0; continue; }
        }
        if (time(nullptr) - lastReset > 90) { rejected.clear(); notOre.clear(); knownB.clear(); lastReset = time(nullptr); }
        if (g_posChainOk.load() && !chainWas) { chainWas = true; noPos.clear(); }
        const uint64_t st = rpm<uint64_t>(g_networkClientKlass + ox::CLASS_STATIC_FIELDS);
        const uint64_t dict = ox_isPtr(st) ? rpm<uint64_t>(st + ox::NC_SPAWNED_DICT) : 0;
        const uint64_t entries = ox_isPtr(dict) ? rpm<uint64_t>(dict + ox::DICT_ENTRIES) : 0;
        int count = ox_isPtr(dict) ? ox_dictCount(dict) : 0;
        const uint64_t arrLen = ox_isPtr(entries) ? rpm<uint64_t>(entries + ox::ARRAY_COUNT) : 0;
        if (!ox_isPtr(entries) || count <= 0 || arrLen == 0) {
            g_worldStage = 1;
            OXLOGW("[ore] NetworkClient.spawned не читается: static=0x%llx dict=0x%llx count=%d", (unsigned long long)st, (unsigned long long)dict, count);
            continue;
        }
        if ((uint64_t)count > arrLen) count = (int)arrLen;
        if (count > 40000) count = 40000;
        std::vector<uint8_t> buf((size_t)count * ox::DICT_ENTRY_STRIDE);
        if (!vm_readv((unsigned long)(entries + ox::ARRAY_DATA), buf.data(), buf.size())) { g_worldStage = 1; continue; }
        g_worldStage = 2;
        std::vector<OxOre> listO;
        std::vector<OxAnimal> listA;                       // животные этого прохода
        std::vector<OxBase> listB;                         // объекты базы этого прохода
        std::unordered_map<uint64_t, OxBase> nextB;
        const double passT = ox_nowSec();
        std::unordered_map<uint64_t, OxOre> nextO;
        OxOreStats stats;
        int walked = 0;
        for (int i = 0; i < count && main_thread_flag; ++i) {
            const uint8_t *e = buf.data() + (size_t)i * ox::DICT_ENTRY_STRIDE;
            int32_t h; uint64_t ni;
            memcpy(&h, e, 4); memcpy(&ni, e + ox::DICT_ENTRY_VALUE, 8);
            if (h < 0 || !ox_isPtr(ni) || rejected.count(ni)) continue;
            ++walked;
            const uint64_t bArr = rpm<uint64_t>(ni + ox::NI_BEHAVIOURS);
            const uint64_t bn = ox_isPtr(bArr) ? rpm<uint64_t>(bArr + ox::ARRAY_COUNT) : 0;
            if (bn == 0 || bn > 16) { rejected.insert(ni); continue; }
            uint64_t comps[16];
            if (!vm_readv((unsigned long)(bArr + ox::ARRAY_DATA), comps, (size_t)bn * 8)) continue;
            bool isOre = false, isBase = false;
            for (uint64_t k = 0; k < bn && !isOre; ++k) {
                const uint64_t c = comps[k];
                if (!ox_isPtr(c)) continue;
                auto ko = knownO.find(c);
                if (ko != knownO.end()) {
                    nextO[c] = ko->second; listO.push_back(ko->second); isOre = true;
                    if (ko->second.kind == ORE_STONE) ++stats.stone; else if (ko->second.kind == ORE_METAL) ++stats.iron;
                    else if (ko->second.kind == ORE_SULFUR) ++stats.sulfur; else if (ko->second.kind == ORE_COAL) ++stats.coal;
                    ++stats.mineable;
                    continue;
                }
                auto no = notOre.find(c);
                if (no != notOre.end()) {
                    isOre = true; ++stats.mineable;
                    const int at = ox_animalType(no->second);
                    if (at >= 0 && animalEsp) {
                        OxAnimal an; an.type = at; an.comp = c; an.stamp = passT; int how = 0;
                        if (ox_orePosition(c, an.pos, how)) listA.push_back(an);
                    }
                    if (no->second == ox::ENT_TREE) ++stats.tree; else if (no->second == ox::ENT_ICE) ++stats.ice;
                    continue;
                }
                auto kb = knownB.find(c);
                if (kb != knownB.end() && kb->second.klass == rpm<uint64_t>(c)) { nextB[c] = kb->second; listB.push_back(kb->second); isBase = true; continue; }
                // Опознание: имя класса «Mineable…» (MineableStone, MineableCompositeStone, MineableTree, MineableAnimal …) — надёжнее числовых
                // проверок полей (у камней сопротивление и здоровье могут быть нестандартными). Числовая проверка — запасная, для неизвестных подклассов.
                const std::string cls = ox_classNameCached(c);
                {
                    const int bk = ox_baseKind(cls);
                    if (bk >= 0) {
                        isBase = true;                                              // распознан: не отвергаем и не пробуем как руду
                        Vector3 bp;
                        if ((baseEsp || cupboardFinder) && g_posChainOk.load() && ox_chainPos(c, g_posA, g_posB, g_posC, bp)) {
                            OxBase ob; ob.kind = bk; ob.pos = bp; ob.klass = rpm<uint64_t>(c);
                            if (bk == BASE_BAG) ob.text = ox_readStringUtf8(rpm<uint64_t>(c + ox::SLEEPBAG_NAME), 24);
                            else if (bk == BASE_SLEEPER) {
                                ob.text = ox_readStringUtf8(rpm<uint64_t>(c + ox::SLEEPER_NICK), 24);
                                const std::string tag = ox_readStringUtf8(rpm<uint64_t>(c + ox::SLEEPER_CLAN), 8);
                                if (!tag.empty()) ob.text += " [" + tag + "]";
                            }
                            static std::unordered_set<std::string> seenBase;           // только поток обхода
                            if (seenBase.size() < 40 && seenBase.insert(cls).second)
                                OXLOGB("[base] новый вид: класс=%s -> тип %d позиция=(%.1f %.1f %.1f) текст='%s'", cls.c_str(), bk, bp.x, bp.y, bp.z, ob.text.c_str());
                            nextB[c] = ob; listB.push_back(ob);
                        }
                        continue;
                    }
                }
                int et = -1;
                if (cls.compare(0, 8, "Mineable") == 0) {
                    et = rpm<int>(c + ox::MINE_ENTITY_TYPE);
                    if (et < 0 || et > 25) et = -1;
                } else if (!ox_isMineable(c, et)) continue;
                isOre = true;
                ++stats.mineable;
                const std::string loot = (et == ox::ENT_TREE || (et >= 1 && et <= 7) || cls.find("Tree") != std::string::npos || cls.find("Animal") != std::string::npos) ? std::string() : ox_lootNames(c);
                // Гистограмма «класс | entityType | лут»: каждое новое сочетание логируется один раз — по ней видно, чем на самом деле является руда.
                {
                    char key[200]; snprintf(key, sizeof(key), "%s|%d|%s", cls.c_str(), et, loot.c_str());
                    if (seenCombos.size() < 80 && seenCombos.insert(key).second)
                        OXLOGB("[ore] новый вид MineableObject: класс=%s entityType=%d лут='%s' -> %s", cls.c_str(), et, loot.c_str(),
                               ox_oreKind(et, cls, loot) < 0 ? "не руда" : (ox_oreKind(et, cls, loot) == ORE_STONE ? "камень" : ox_oreKind(et, cls, loot) == ORE_METAL ? "железо" : ox_oreKind(et, cls, loot) == ORE_SULFUR ? "сера" : "уголь"));
                }
                if (et == ox::ENT_TREE) ++stats.tree; else if (et == ox::ENT_ICE) ++stats.ice;
                const int kind = ox_oreKind(et, cls, loot);
                if (kind == ORE_STONE) ++stats.stone; else if (kind == ORE_METAL) ++stats.iron; else if (kind == ORE_SULFUR) ++stats.sulfur; else if (kind == ORE_COAL) ++stats.coal;
                if (kind < 0) {
                    const int at = ox_animalType(et);
                    if (at >= 0) {
                        static std::unordered_set<std::string> seenAnimals;                   // только поток обхода
                        if (seenAnimals.size() < 30 && seenAnimals.insert(cls + "|" + std::to_string(et)).second)
                            OXLOGB("[animal] новый вид: класс=%s entityType=%d -> тип %d (hp %.1f/%.1f)", cls.c_str(), et, at,
                                   rpm<float>(c + ox::MINE_CURRENT_HEALTH), rpm<float>(c + ox::MINE_MAX_HEALTH));
                        if (animalEsp) {
                            OxAnimal an; an.type = at; an.comp = c; an.stamp = passT; int how = 0;
                            if (ox_orePosition(c, an.pos, how)) listA.push_back(an);
                        }
                    }
                    if (notOre.size() < 20000) notOre[c] = et;
                    continue;
                }
                Vector3 p; int how = 0;
                if (!ox_orePosition(c, p, how)) {
                    ++stats.posFail;
                    if (noPos.insert(c).second && noPos.size() <= 3) {
                        char cn[96] = {0}; ox_objClassName(c, cn, sizeof(cn));
                        OXLOGB("[ore] руда без позиции: объект=0x%llx класс=%s вид=%d rru=0x%llx (цепочка %s)", (unsigned long long)c, cn, et,
                               (unsigned long long)rpm<uint64_t>(c + ox::MINE_TRANSFORM), g_posChainOk.load() ? "подтверждена" : "не подтверждена");
                    }
                    continue;
                }
                OxOre o; o.kind = kind; o.pos = p;
                nextO[c] = o; listO.push_back(o);
                (how == 2 ? stats.posChain : stats.posRru)++;
                if (nextO.size() <= 3 && knownO.size() < 3) {
                    char cn[96] = {0}; ox_objClassName(c, cn, sizeof(cn));
                    OXLOGB("[ore] найдена руда: класс=%s вид=%d(%s) позиция=(%.1f %.1f %.1f) источник позиции=%s", cn, et,
                           kind == ORE_STONE ? "камень" : kind == ORE_METAL ? "железо" : kind == ORE_SULFUR ? "сера" : "уголь", p.x, p.y, p.z,
                           how == 1 ? "Transform объекта по иерархии" : how == 2 ? "цепочка нативных объектов" : "старый путь matrixData");
                }
            }
            if (!isOre && !isBase) rejected.insert(ni);
        }
        // Диагностика: что лежит рядом с игроком (первые три прохода после подтверждения позиции). Показывает, являются ли камни на экране
        // сетевыми объектами и какими классами представлены.
        if (g_posChainOk.load() && nearPasses < 3 && (double)time(nullptr) >= nextNear && ox_isPtr(g_localPlayer)) {
            nextNear = (double)time(nullptr) + 20.0; ++nearPasses;
            const Vector3 me = ox_readPos(g_localPlayer, false);
            struct NearRow { float d; std::string text; };
            std::vector<NearRow> rows;
            int total = 0;
            for (int i = 0; i < count; ++i) {
                const uint8_t *e = buf.data() + (size_t)i * ox::DICT_ENTRY_STRIDE;
                int32_t h; uint64_t ni; memcpy(&h, e, 4); memcpy(&ni, e + ox::DICT_ENTRY_VALUE, 8);
                if (h < 0 || !ox_isPtr(ni)) continue;
                const uint64_t bArr = rpm<uint64_t>(ni + ox::NI_BEHAVIOURS);
                const uint64_t bn = ox_isPtr(bArr) ? rpm<uint64_t>(bArr + ox::ARRAY_COUNT) : 0;
                if (bn == 0 || bn > 16) continue;
                uint64_t comps[16];
                if (!vm_readv((unsigned long)(bArr + ox::ARRAY_DATA), comps, (size_t)bn * 8)) continue;
                Vector3 p; bool have = false;
                for (uint64_t k = 0; k < bn && !have; ++k) if (ox_isPtr(comps[k]) && ox_chainPos(comps[k], g_posA, g_posB, g_posC, p)) have = true;
                if (!have) continue;
                ++total;
                const float d = sqrtf((p.x - me.x) * (p.x - me.x) + (p.z - me.z) * (p.z - me.z));
                if (d > 45.f) continue;
                std::string names;
                for (uint64_t k = 0; k < bn; ++k) if (ox_isPtr(comps[k])) { const std::string n = ox_classNameCached(comps[k]); if (!n.empty() && names.find(n) == std::string::npos) names += (names.empty() ? "" : ",") + n; }
                char line[300]; snprintf(line, sizeof(line), "%.1f м (dy %.1f): %s", d, p.y - me.y, names.c_str());
                rows.push_back({ d, line });
            }
            std::sort(rows.begin(), rows.end(), [](const NearRow &x, const NearRow &y) { return x.d < y.d; });
            OXLOGB("[near] объектов spawned с известной позицией: %d, в радиусе 45 м от игрока: %d (проход %d)", total, (int)rows.size(), nearPasses);
            for (size_t i = 0; i < rows.size() && i < 30; ++i) OXLOGB("[near]   %s", rows[i].text.c_str());
        }
        knownO.swap(nextO);
        knownB.swap(nextB);
        g_worldBase = (int)listB.size();
        { std::lock_guard<std::mutex> lk(g_baseMtx); g_baseList.swap(listB); }
        g_worldWalked = walked; g_worldOres = (int)listO.size();
        { std::lock_guard<std::mutex> lk(g_oreStatMtx); g_oreStats = stats; }
        { std::lock_guard<std::mutex> lk(g_oreMtx); g_oreList.swap(listO); }
        g_worldAnimals = (int)listA.size();
        { std::lock_guard<std::mutex> lk(g_animalMtx); g_animalList.swap(listA); }
        if (passes++ < 2 || (passes % 10) == 0)
            OXLOGI("[ore] обход spawned (%d объектов): MineableObject=%d (камень %d, железо %d, сера %d, уголь %d, лёд %d, деревья %d), с позицией %d, без позиции %d",
                   count, stats.mineable, stats.stone, stats.iron, stats.sulfur, stats.coal, stats.ice, stats.tree, stats.posRru + stats.posChain, stats.posFail);
    }
}


static void ox_ensureWorldWorker() {
    if ((oreEsp || animalEsp || baseEsp || cupboardFinder) && !g_worldThreadStarted.exchange(true)) std::thread(ox_worldWorker).detach();
}

// Сводка состояния подсистем раз в 15 с: по ней сразу видно, что работает, а что нет.
static void ox_statusTick(double now, size_t players) {
    static double next = 0.0;
    if (now < next) return;
    next = now + 15.0;
    OxOreStats os; { std::lock_guard<std::mutex> lk(g_oreStatMtx); os = g_oreStats; }
#if defined(__x86_64__)
#define OX_STATUS_LOG oxlog::diagf
#else
#define OX_STATUS_LOG(...) OXLOGI(__VA_ARGS__)
#endif
    OX_STATUS_LOG("[STATUS] игроки=%d | реестры: броня=%d оружие=%d | рука: игроков %d, включено %d, с именем %d | броня: список %d/%d, надето %d, с иконкой %d | руда: на экране-кандидатов=%d (камень %d, железо %d, сера %d, уголь %d; без позиции %d), этап %d, обойдено %d, цепочка позиции=%s | GC=%s",
           (int)players, (int)g_equipIdByNum.size(), (int)g_weaponIdByNum.size(), g_st.held, g_st.heldOn, g_st.heldNamed,
           g_st.armList, g_st.arm, g_st.armOn, g_st.armNamed, g_worldOres.load(), os.stone, os.iron, os.sulfur, os.coal, os.posFail, g_worldStage.load(), g_worldWalked.load(),
           g_posChainOk.load() ? "да" : "нет", g_gcKlass.load() ? "да" : "нет");
#undef OX_STATUS_LOG
    g_st = OxStats();
}

static void ox_drawOres(ImDrawList *dl, const CameraView &cam, const std::vector<PlayerCacheData> &players) {
    if (!oreEsp) return;
    ox_ensureWorldWorker();
    ox_posChainCalibrate(players, (double)ImGui::GetTime());
    std::vector<OxOre> ores;
    { std::lock_guard<std::mutex> lk(g_oreMtx); ores = g_oreList; }
    const Vector3 eye = (g_camVPValid && g_camPosValid) ? g_camPosFromMatrix : cam.pos;
    const float sc = (float)abs_ScreenY / 1080.f;
    static const bool *const enabled[ORE_KINDS] = { &oreStone, &oreMetal, &oreSulfur, &oreCoal };
    static const char *const oreName[ORE_KINDS] = { "Stone", "Metal", "Sulfur", "Coal" };
    static const ImU32 colors[ORE_KINDS] = { IM_COL32(190, 190, 200, 255), IM_COL32(120, 190, 255, 255),
                                             IM_COL32(255, 225, 80, 255), IM_COL32(150, 150, 150, 255) };
    for (const OxOre &o : ores) {
        if (o.kind < 0 || !*enabled[o.kind]) continue;
        const float dx = o.pos.x - eye.x, dy = o.pos.y - eye.y, dz = o.pos.z - eye.z;
        const float dist = sqrtf(dx * dx + dy * dy + dz * dz);
        if (dist > oreMaxDist || dist < 1.f) continue;
        ImVec2 sp; bool vis = false;
        const Vector3 mid = o.pos + Vector3(0.f, 0.9f, 0.f);               // центр глыбы: основание объекта + ~0.9 м
        if (g_camVPValid) vis = ox_w2sMatrix(g_camVP, mid, (float)abs_ScreenX, (float)abs_ScreenY, &sp);
        else if (cam.valid) sp = w2s_angular(mid, cam, &vis);
        if (!vis || sp.x < 0 || sp.y < 0 || sp.x > abs_ScreenX || sp.y > abs_ScreenY) continue;
        const float sz = ImClamp(40.f - dist * 0.12f, 20.f, 40.f) * sc;
        // Метка: цветная точка и английское название руды (с дистанцией, если включена).
        dl->AddCircleFilled(sp, sz * 0.3f, colors[o.kind], 12);
        char b[40];
        if (oreDistText) snprintf(b, sizeof(b), "%s %dm", oreName[o.kind], (int)dist); else snprintf(b, sizeof(b), "%s", oreName[o.kind]);
        const ImVec2 ts = ImGui::CalcTextSize(b);
        const float textY = sp.y + sz * 0.3f + 2.f;
        dl->AddText(ImVec2(sp.x - ts.x * 0.5f + 1.f, textY + 1.f), IM_COL32(0, 0, 0, 200), b);
        dl->AddText(ImVec2(sp.x - ts.x * 0.5f, textY), colors[o.kind], b);
    }
}

// ── Животные: подпись «вид + дистанция» без иконок. Позиция читается воркером раз в 3 с, а ближние животные обновляются здесь (8 раз в секунду,
// не больше 16 чтений позиции за тик) и плавно подтягиваются к новому месту — иначе подпись «скачет» за бегущим зверем ──
extern int TrialLang();   // язык меню: 0 русский, 1 English (trial_menu.cpp)
static void ox_drawAnimals(ImDrawList *dl, const CameraView &cam, const std::vector<PlayerCacheData> &players) {
    if (!animalEsp) return;
    ox_ensureWorldWorker();
    ox_posChainCalibrate(players, (double)ImGui::GetTime());
    std::vector<OxAnimal> list;
    { std::lock_guard<std::mutex> lk(g_animalMtx); list = g_animalList; }
    if (list.empty()) return;
    struct Track { Vector3 target, shown; double read = 0.0; bool init = false; };
    static std::unordered_map<uint64_t, Track> tracks;
    static double nextRead = 0.0, lastT = 0.0;
    static size_t cursor = 0;
    const double now = ox_nowSec();
    const float dt = lastT > 0.0 ? (float)ImClamp(now - lastT, 0.0, 0.1) : 0.016f;
    lastT = now;
    if (tracks.size() > list.size() * 2 + 64) tracks.clear();            // зверей, которых уже нет в мире, не копим
    const Vector3 eye = (g_camVPValid && g_camPosValid) ? g_camPosFromMatrix : cam.pos;
    // Порядок = enum ANI_*.
    static const bool *const enabled[ANI_KINDS] = { &animalBear, &animalBoar, &animalDeer, &animalRabbit, &animalHare,
                                                    &animalChicken, &animalFish, &animalRat, &animalCannibal };
    static const char *const label[ANI_KINDS][2] = {
        { "Медведь", "Bear" }, { "Кабан", "Boar" }, { "Олень", "Deer" }, { "Кролик", "Rabbit" }, { "Заяц", "Hare" },
        { "Курица", "Chicken" }, { "Рыба", "Fish" }, { "Крыса", "Rat" }, { "Каннибал", "Cannibal" } };
    static const ImU32 colors[ANI_KINDS] = {                              // опасные — красно-оранжевые, мирные — спокойные
        IM_COL32(255, 70, 70, 255),  IM_COL32(255, 150, 60, 255), IM_COL32(120, 220, 120, 255), IM_COL32(235, 235, 235, 255), IM_COL32(215, 215, 190, 255),
        IM_COL32(255, 225, 110, 255), IM_COL32(110, 190, 255, 255), IM_COL32(170, 170, 170, 255), IM_COL32(225, 40, 40, 255) };
    std::vector<size_t> near;                                              // включённые виды в пределах дальности
    for (size_t i = 0; i < list.size(); ++i) {
        const OxAnimal &a = list[i];
        if (a.type < 0 || a.type >= ANI_KINDS || !*enabled[a.type]) continue;
        Track &t = tracks[a.comp];
        if (a.stamp > t.read) { t.target = a.pos; t.read = a.stamp; if (!t.init) { t.shown = a.pos; t.init = true; } }
        const float dx = t.target.x - eye.x, dy = t.target.y - eye.y, dz = t.target.z - eye.z;
        if (sqrtf(dx * dx + dy * dy + dz * dz) <= animalMaxDist + 20.f) near.push_back(i);
    }
    if (near.empty()) return;
    if (now >= nextRead) {
        nextRead = now + 0.125;
        const size_t n = near.size() < 16 ? near.size() : 16;
        for (size_t k = 0; k < n; ++k) {
            const OxAnimal &a = list[near[(cursor + k) % near.size()]];
            Vector3 p; int how = 0;
            if (ox_orePosition(a.comp, p, how)) { Track &t = tracks[a.comp]; t.target = p; t.read = now; }
        }
        cursor += n;
    }
    const int lang = TrialLang() == 1 ? 1 : 0;
    const float k = ImMin(1.f, dt * 12.f);
    for (size_t idx : near) {
        const OxAnimal &a = list[idx];
        Track &t = tracks[a.comp];
        const float jx = t.target.x - t.shown.x, jy = t.target.y - t.shown.y, jz = t.target.z - t.shown.z;
        if (jx * jx + jy * jy + jz * jz > 225.f) t.shown = t.target;      // телепорт/респавн — без «пролёта» через карту
        else { t.shown.x += jx * k; t.shown.y += jy * k; t.shown.z += jz * k; }
        const float dx = t.shown.x - eye.x, dy = t.shown.y - eye.y, dz = t.shown.z - eye.z;
        const float dist = sqrtf(dx * dx + dy * dy + dz * dz);
        if (dist > animalMaxDist || dist < 1.f) continue;
        ImVec2 sp; bool vis = false;
        const Vector3 mid = t.shown + Vector3(0.f, 0.8f, 0.f);
        if (g_camVPValid) vis = ox_w2sMatrix(g_camVP, mid, (float)abs_ScreenX, (float)abs_ScreenY, &sp);
        else if (cam.valid) sp = w2s_angular(mid, cam, &vis);
        if (!vis || sp.x < 0 || sp.y < 0 || sp.x > abs_ScreenX || sp.y > abs_ScreenY) continue;
        char b[48];
        if (animalDistText) snprintf(b, sizeof(b), "%s %dm", label[a.type][lang], (int)dist);
        else                snprintf(b, sizeof(b), "%s", label[a.type][lang]);
        const ImVec2 ts = ImGui::CalcTextSize(b);
        const float ty = sp.y - ts.y * 0.5f;
        dl->AddText(ImVec2(sp.x - ts.x * 0.5f + 1.f, ty + 1.f), IM_COL32(0, 0, 0, 220), b);
        dl->AddText(ImVec2(sp.x - ts.x * 0.5f, ty), colors[a.type], b);
    }
}

// ── База: подписи «вид + имя + дистанция» без иконок ──
static void ox_drawBase(ImDrawList *dl, const CameraView &cam, const std::vector<PlayerCacheData> &players) {
    if (!baseEsp && !cupboardFinder) return;
    ox_ensureWorldWorker();
    ox_posChainCalibrate(players, (double)ImGui::GetTime());
    std::vector<OxBase> list;
    { std::lock_guard<std::mutex> lk(g_baseMtx); list = g_baseList; }
    if (list.empty()) return;
    const Vector3 eye = (g_camVPValid && g_camPosValid) ? g_camPosFromMatrix : cam.pos;
    Vector3 playerPos;
    // A checked read, not rpm's zero-on-failure: radius is relative to the player,
    // not a detached/death camera. Suppress finder output if the origin is unknown.
    const bool finderReady = cupboardFinder && cam.valid && ox_isPtr(g_localPlayer) &&
        vm_readv((unsigned long)(g_localPlayer + ox::PM_LAST_TICK_POS), &playerPos, sizeof(playerPos)) &&
        cupboardfinder::Valid({playerPos.x, playerPos.y, playerPos.z});
    // Порядок = enum BASE_*.
    const bool on[BASE_KINDS] = { baseCupboard, baseTurret, baseTurret, baseTurret, baseTurret, baseTurret, baseBag, baseSleeper };
    static const char *const label[BASE_KINDS][2] = {
        { "Шкаф", "Cupboard" }, { "Турель", "Turret" }, { "Турель (дробовик)", "Shotgun turret" }, { "Снежная турель", "Snowball turret" },
        { "Ловушка", "Gun trap" }, { "ПВО", "SAM turret" }, { "Спальник", "Sleeping bag" }, { "Спящий", "Sleeper" } };
    static const ImU32 colors[BASE_KINDS] = {
        IM_COL32(255, 215, 80, 255),  IM_COL32(255, 70, 70, 255),   IM_COL32(255, 100, 60, 255), IM_COL32(150, 210, 255, 255),
        IM_COL32(255, 130, 50, 255),  IM_COL32(255, 90, 160, 255),  IM_COL32(120, 230, 140, 255), IM_COL32(160, 175, 215, 255) };
    const int lang = TrialLang() == 1 ? 1 : 0;
    for (const OxBase &o : list) {
        if (o.kind < 0 || o.kind >= BASE_KINDS) continue;
        const float dx = o.pos.x - eye.x, dy = o.pos.y - eye.y, dz = o.pos.z - eye.z;
        const float dist = sqrtf(dx * dx + dy * dy + dz * dz);
        float finderDist = 0.f, finderHeight = 0.f;
        const bool found = finderReady && o.kind == BASE_CUPBOARD &&
            cupboardfinder::Measure({playerPos.x, playerPos.y, playerPos.z},
                {o.pos.x, o.pos.y, o.pos.z}, cupboardRadius, finderDist, finderHeight);
        const bool ordinary = baseEsp && on[o.kind] && isfinite(dist) && dist <= baseMaxDist && dist >= 1.f;
        if (!found && !ordinary) continue;
        ImVec2 sp; bool vis = false;
        const Vector3 mid = o.pos + Vector3(0.f, 0.5f, 0.f);
        if (g_camVPValid) vis = ox_w2sMatrix(g_camVP, mid, (float)abs_ScreenX, (float)abs_ScreenY, &sp);
        else if (cam.valid) sp = w2s_angular(mid, cam, &vis);
        if (!vis || sp.x < 0 || sp.y < 0 || sp.x > abs_ScreenX || sp.y > abs_ScreenY) continue;
        if (found) {
            // Screen projection only; walls never suppress this overlay marker.
            const ImU32 gold = IM_COL32(255, 215, 80, 255);
            const float scale = ImClamp((float)abs_ScreenY / 900.f, .6f, 2.f);
            const float r = 8.f * scale;
            if (cupboardGuide) {
                dl->AddLine(ImVec2(abs_ScreenX*.5f, abs_ScreenY*.92f), sp, IM_COL32(0,0,0,210), 3.f*scale);
                dl->AddLine(ImVec2(abs_ScreenX*.5f, abs_ScreenY*.92f), sp, IM_COL32(255,215,80,180), 1.f*scale);
            }
            dl->AddCircleFilled(sp, r+2.f*scale, IM_COL32(0,0,0,220), 16);
            dl->AddRect(ImVec2(sp.x-r,sp.y-r), ImVec2(sp.x+r,sp.y+r), gold, 2.f*scale, 0, 2.f*scale);
            char text[96];
            snprintf(text, sizeof(text), "%s %.0fm | %s %+.1fm", label[BASE_CUPBOARD][lang],
                     finderDist, lang ? "height" : "высота", finderHeight);
            const ImVec2 size = ImGui::CalcTextSize(text);
            ImVec2 p(sp.x-size.x*.5f, sp.y-r-size.y-5.f*scale);
            p.x=ImClamp(p.x, 0.f, ImMax(0.f,(float)abs_ScreenX-size.x));
            p.y=ImClamp(p.y, 0.f, ImMax(0.f,(float)abs_ScreenY-size.y));
            dl->AddRectFilled(ImVec2(p.x-3.f,p.y-2.f), ImVec2(p.x+size.x+3.f,p.y+size.y+2.f), IM_COL32(0,0,0,200), 3.f);
            dl->AddText(p, gold, text);
            continue; // Don't draw the ordinary label a second time.
        }
        std::string txt = label[o.kind][lang];
        if (!o.text.empty()) txt += " " + o.text;
        if (baseDistText) txt += " " + std::to_string((int)dist) + "m";
        const char *b = txt.c_str();
        const ImVec2 ts = ImGui::CalcTextSize(b);
        const float ty = sp.y - ts.y * 0.5f;
        dl->AddText(ImVec2(sp.x - ts.x * 0.5f + 1.f, ty + 1.f), IM_COL32(0, 0, 0, 220), b);
        dl->AddText(ImVec2(sp.x - ts.x * 0.5f, ty), colors[o.kind], b);
    }
}

// ============================================================================
//  РАДАР 360° — миникарта вокруг локального игрока.
//  Чистое рисование по уже собранному кэшу: ни одного лишнего vm_readv.
//  Точки поворачиваются на yaw камеры, поэтому "вверх" на радаре = куда
//  смотришь. Кольцо дистанции + сектор обзора для ориентации.
// ============================================================================
static void ox_drawRadar(ImDrawList* dl, const CameraView& cam,
                         const std::vector<PlayerCacheData>& players) {
    if (!dl || !cam.valid) return;

    const float R  = radarSize * 0.5f;
    const ImVec2 c(radarPos[0] + R, radarPos[1] + R);
    const int    aBg = (int)(::clamp<float>(radarAlpha, 0.05f, 1.0f) * 255.f);

    // --- Подложка: тёмный круг + мягкая рамка ---
    dl->AddCircleFilled(c, R, IM_COL32(8, 8, 14, aBg), 64);
    dl->AddCircle(c, R, IM_COL32(120, 140, 180, 130), 64, 1.6f);
    // кольца дистанции на 1/3 и 2/3 радиуса
    dl->AddCircle(c, R * 0.66f, IM_COL32(120, 140, 180, 55), 48, 1.0f);
    dl->AddCircle(c, R * 0.33f, IM_COL32(120, 140, 180, 40), 40, 1.0f);
    // перекрестье
    dl->AddLine(ImVec2(c.x - R, c.y), ImVec2(c.x + R, c.y), IM_COL32(120, 140, 180, 45), 1.0f);
    dl->AddLine(ImVec2(c.x, c.y - R), ImVec2(c.x, c.y + R), IM_COL32(120, 140, 180, 45), 1.0f);

    // --- Сектор обзора (куда смотрит камера — всегда вверх) ---
    {
        float half = (cam.fovV > 1.f ? cam.fovV : 60.f) * 0.5f * 0.01745329f;
        ImVec2 l(c.x + sinf(-half) * R, c.y - cosf(-half) * R);
        ImVec2 r(c.x + sinf( half) * R, c.y - cosf( half) * R);
        dl->AddTriangleFilled(c, l, r, IM_COL32(90, 170, 255, 40));
        dl->AddLine(c, l, IM_COL32(90, 170, 255, 90), 1.0f);
        dl->AddLine(c, r, IM_COL32(90, 170, 255, 90), 1.0f);
    }

    // --- Точки игроков ---
    // Мир -> радар: смещение относительно камеры, повёрнутое на -yaw, чтобы
    // направление взгляда смотрело вверх экрана.
    const float yawRad = cam.yaw * 0.01745329f;
    const float cs = cosf(yawRad), sn = sinf(yawRad);
    const float range = radarRange < 20.f ? 20.f : radarRange;

    // cached_players уже отфильтрован в UpdatePlayerCache: локального игрока
    // и (при espHideTeammates) сокомандников там нет. Доп. проверок не нужно.
    for (const auto& pl : players) {
        if (pl.address == 0 || pl.address == g_localPlayer) continue;

        float dx = pl.position.x - cam.pos.x;
        float dz = pl.position.z - cam.pos.z;
        if (!isfinite(dx) || !isfinite(dz)) continue;

        // Поворот в систему камеры: X вправо, Z вперёд.
        float rx =  dx * cs - dz * sn;
        float rz =  dx * sn + dz * cs;

        float dist = sqrtf(rx * rx + rz * rz);
        float k = R / range;
        float px = c.x + rx * k;
        float py = c.y - rz * k;   // вперёд = вверх

        bool  clamped = false;
        if (dist > range) {
            // За пределами радиуса — прижимаем к кромке стрелкой-треугольником.
            float nx = rx / dist, nz = rz / dist;
            px = c.x + nx * (R - 5.f);
            py = c.y - nz * (R - 5.f);
            clamped = true;
        }

        // Цвет точки: по высоте относительно камеры (выше/ниже) либо по HP.
        float dy = pl.position.y - cam.pos.y;
        ImU32 col;
        if (dy > 2.5f)       col = IM_COL32(255, 190, 80, 255);   // выше — оранжевый
        else if (dy < -2.5f) col = IM_COL32(120, 200, 255, 255);  // ниже — голубой
        else                 col = IM_COL32(255, 70, 70, 255);    // на уровне — красный
        if (pl.flagSleeping) col = IM_COL32(140, 140, 155, 255);  // спит — серый

        if (clamped) {
            // Треугольник, направленный наружу.
            float ang = atan2f(py - c.y, px - c.x);
            float a1 = ang + 2.6f, a2 = ang - 2.6f;
            dl->AddTriangleFilled(ImVec2(px, py),
                                  ImVec2(px + cosf(a1) * 7.f, py + sinf(a1) * 7.f),
                                  ImVec2(px + cosf(a2) * 7.f, py + sinf(a2) * 7.f), col);
        } else {
            dl->AddCircleFilled(ImVec2(px, py), 4.2f, col, 12);
            dl->AddCircle(ImVec2(px, py), 4.2f, IM_COL32(0, 0, 0, 170), 12, 1.2f);
            // Дистанция мелким текстом рядом с точкой.
            char ds[16]; snprintf(ds, sizeof(ds), "%.0f", pl.distance);
            dl->AddText(ImVec2(px + 6.f, py - 6.f), IM_COL32(0, 0, 0, 180), ds);
            dl->AddText(ImVec2(px + 5.f, py - 7.f), IM_COL32(225, 230, 240, 220), ds);
        }
    }

    // --- Локальный игрок в центре: стрелка вверх ---
    dl->AddTriangleFilled(ImVec2(c.x, c.y - 7.f), ImVec2(c.x - 5.f, c.y + 5.f),
                          ImVec2(c.x + 5.f, c.y + 5.f), IM_COL32(90, 230, 130, 255));
    dl->AddTriangle(ImVec2(c.x, c.y - 7.f), ImVec2(c.x - 5.f, c.y + 5.f),
                    ImVec2(c.x + 5.f, c.y + 5.f), IM_COL32(0, 0, 0, 160), 1.2f);

    // Подпись радиуса в правом-нижнем углу виджета.
    {
        char rs[24]; snprintf(rs, sizeof(rs), "%.0fm", range);
        dl->AddText(ImVec2(c.x + R - 34.f, c.y + R - 16.f), IM_COL32(0,0,0,180), rs);
        dl->AddText(ImVec2(c.x + R - 35.f, c.y + R - 17.f), IM_COL32(150,170,200,200), rs);
    }
}


// функция обновления кэша игроков (Oxide)
void UpdatePlayerCache() {
    if (!(espdraw || chamsOn || aimm || silentAim || oreEsp || animalEsp || baseEsp || cupboardFinder || noRecoil || noSpread || stretchOn || boostDraw || xrayOn)) {
        cache_needs_update = false;
        return;
    }

    // UPDATE v15: убрано ожидание g_startupInProgress. UpdatePlayerCache
    // теперь стартует сразу; если klass ещё не резолвился — resolver внутри
    // фонового треда возьмёт его, а мы просто вернёмся с cache_needs_update.
    // Раньше пользователь ждал 2-3 мин пока фоновый резолвер добежит.
    if (!g_playerManagerKlass && !ox_fastSeedTypeInfoFromHeader()) {
        cache_needs_update = false;
        return;
    }

    oxlog::frameCounter++;
    bool full = oxlog::shouldLogFull();   // подробно — первые N кадров
    static int diag = 0;
    bool logNow = full || ((diag++ % 120) == 0); // ��альше — сводка раз в ~2c

    if (full) {
        oxlog::section("FRAME UpdatePlayerCache");
        OXLOGT("il2cpp_base=0x%llx screen=%dx%d",
               (unsigned long long)il2cpp_base, ::abs_ScreenX, ::abs_ScreenY);
    }

    // Ленивый резолв базы: игра могла ещё не загрузить libil2cpp.so на старте.
    if (!ox_ensureBase(full || logNow)) {
        if (logNow) OXLOGW("Ждём загрузку %s игрой... (base=0)", ox::MODULE);
        cache_needs_update = false;
        return;
    }

    // The class can replace static_fields as IL2CPP finishes initialization.
    // A pointer captured in the lobby then points at an obsolete block in a
    // match: the core probe sees six players while this scan sees a null list.
    static uint64_t statics_cached = 0;
    static uint64_t base_at_cache  = 0;
    static int pid_at_cache = -1;
    static uint64_t listOff_cached = ~0ULL;
#if defined(__x86_64__)
    // A short, incomplete player scan can replace cached_players with an empty
    // snapshot. Keep names obtained from the authoritative match roster by
    // network identity so the label survives that gap or a new PM allocation.
    struct VerifiedNick { std::string value; double seenAt; };
    static std::unordered_map<uint32_t, VerifiedNick> verifiedNicks;
#endif
    if (base_at_cache != il2cpp_base || pid_at_cache != game_pid) {
        const bool gameChanged = base_at_cache != 0 &&
                                 (base_at_cache != il2cpp_base || pid_at_cache != game_pid);
        base_at_cache = il2cpp_base;
        pid_at_cache = game_pid;
        statics_cached = 0;
        listOff_cached = ~0ULL;
#if defined(__x86_64__)
        verifiedNicks.clear();
#endif
        // On the initial pass a background resolver may already have found the
        // class. Clear it only when a previously observed game really changed.
        if (gameChanged) {
            g_playerManagerKlass = 0;
            g_buildingPieceKlass = 0;
        }
    }
    const uint64_t currentStatics = ox_getStatics(full);
    if (currentStatics && currentStatics != statics_cached) {
        if (statics_cached)
            oxlog::diagf("[pc-static] static_fields changed 0x%llx -> 0x%llx",
                         (unsigned long long)statics_cached, (unsigned long long)currentStatics);
        statics_cached = currentStatics;
        listOff_cached = ~0ULL;
    }
    if (!statics_cached) {
        if (logNow) OXLOGW("static_fields не резолвится (base=0x%llx)", (unsigned long long)il2cpp_base);
        cache_needs_update = false;
        return;
    }

    // Список игроков ищем авто-сканом; кэшируем найденный оффсет (см. выше).
    PlayerListView plist;
    if (listOff_cached != ~0ULL) {
        // Быстрый путь: пересчитываем по изв��стному оффсету.
        uint64_t c = ox_readDirect<uint64_t>(statics_cached + listOff_cached);
        int cnt, homo, checked; uint64_t elems; char cls[96];
        // One-player lists are valid (only our player is present at match entry).
        if (ox_evalContainer(c, elems, cnt, cls, sizeof(cls), homo, checked) && homo >= 1) {
            plist.ok = true; plist.elems = elems; plist.count = cnt;
            plist.container = c; plist.statOff = listOff_cached;
        } else {
            plist.ok = false; listOff_cached = ~0ULL; // сбросить — перескан
        }
    }
    if (!plist.ok) {
        plist = ox_scanForPlayerList(statics_cached, full || logNow);
        if (plist.ok) {
            listOff_cached = plist.statOff;
            oxlog::armFull(20); // список найден (в��шли в матч) — писать подробно 20 кадров
            full = oxlog::shouldLogFull();
        }
    }
#if defined(__x86_64__)
    if (!plist.ok) {
        // This field is a known List<PlayerManager> in the PC dump. Do not
        // discard the whole roster just because a class-name probe or the
        // mutable array header was unreadable during a game update.
        const uint64_t c=ox_readDirect<uint64_t>(statics_cached+ox::STATIC_PLAYER_LIST);
        const uint64_t items=ox_isPtr(c) ? ox_readDirect<uint64_t>(c+ox::LIST_ITEMS) : 0;
        const int count=ox_isPtr(c) ? ox_readDirect<int>(c+ox::LIST_SIZE) : 0;
        if (ox_isPtr(items) && count>0 && count<=128) {
            plist.ok=true;plist.elems=items+ox::ARRAY_DATA;plist.count=count;
            plist.container=c;plist.statOff=ox::STATIC_PLAYER_LIST;
        }
    }
#endif
    static double lastPcListDiag = -5.0;
    const double pcDiagNow = ImGui::GetTime();
    const bool pcDiagDue = oxarch::kCur.tiPlayerManager == oxarch::kX86_64.tiPlayerManager &&
                           pcDiagNow - lastPcListDiag >= 5.0;
    if (pcDiagDue) lastPcListDiag = pcDiagNow;
    if (!plist.ok) {
        int localCamValid = 0;
#if defined(__x86_64__)
        // The PC client can briefly clear clientPlayerList while the
        // controller still owns a live local PlayerManager. Resolve it even
        // without a target roster so local-only features can keep running.
        localCamValid = ox_getCamera(0, 0, false).valid ? 1 : 0;
#endif
        if (pcDiagDue) {
            const uint64_t c = ox_readDirect<uint64_t>(statics_cached + ox::STATIC_PLAYER_LIST);
            const uint64_t items = ox_isPtr(c) ? ox_readDirect<uint64_t>(c + ox::LIST_ITEMS) : 0;
            const int count = ox_isPtr(c) ? ox_readDirect<int>(c + ox::LIST_SIZE) : -1;
            const uint64_t capacity = ox_isPtr(items) ? ox_readDirect<uint64_t>(items + ox::ARRAY_COUNT) : 0;
            const uint64_t first = ox_isPtr(items) ? ox_readDirect<uint64_t>(items + ox::ARRAY_DATA) : 0;
            const uint64_t gcKlass = g_gcKlass.load(std::memory_order_relaxed);
            const uint64_t gcStatics = ox_isPtr(gcKlass)
                ? ox_readDirect<uint64_t>(gcKlass + ox::CLASS_STATIC_FIELDS) : 0;
            const uint64_t gcLocal = ox_isPtr(gcStatics)
                ? ox_readDirect<uint64_t>(gcStatics + ox::GC_STATIC_LOCAL_PM) : 0;
            oxlog::diagf("[pc-list] valid=0 statics=0x%llx list=0x%llx items=0x%llx size=%d capacity=%llu first=0x%llx gcLocal=0x%llx local=0x%llx camera=%d",
                         (unsigned long long)statics_cached, (unsigned long long)c,
                         (unsigned long long)items, count,
                         (unsigned long long)capacity, (unsigned long long)first,
                         (unsigned long long)gcLocal, (unsigned long long)g_localPlayer,
                         localCamValid);
#if defined(__x86_64__)
            ox_pcLogLocalCandidate(gcLocal);
#endif
        }
        cache_needs_update = false;
        return;
    }

    uint64_t elems = plist.elems;
    int size = plist.count;

    std::vector<uint64_t> playerSnapshot;
    CameraView cam = ox_getCamera(elems, size, full, &playerSnapshot);
    auto playerAt = [&](int i) -> uint64_t {
        if (playerSnapshot.size() == (size_t)size) return playerSnapshot[(size_t)i];
        // A bulk read can fail when the game replaces the array. Fall back to
        // an exact field read, never to the frame cache for mutable list slots.
        return ox_readDirect<uint64_t>(elems + (uint64_t)i * sizeof(uint64_t));
    };

    // Дамп первых игроков — только в под��обных кадрах, для поиска оффсетов HP/позиции.
    if (full) {
        oxlog::section("PLAYER DUMP (offset discovery)");
        for (int i = 0; i < size && i < 2; i++) {
            uint64_t p = playerAt(i);
            if (ox_isPtr(p)) ox_dumpPlayer(i, p);
        }
    }

    std::vector<PlayerCacheData> new_cache;
    double sampleTime = ImGui::GetTime();
    int valid = 0;
    int checkedHP = 0, skippedHP = 0, skippedPos = 0, skippedLocal = 0, skippedTeam = 0, skippedVis = 0;

    if (full) oxlog::section("PLAYER SCAN");

    for (int i = 0; i < size; i++) {
        uint64_t player = playerAt(i);
        if (!ox_isPtr(player)) continue;

#if defined(__x86_64__)
        if (pcDiagDue && i < 3) {
            const uint64_t klass = ox_readDirect<uint64_t>(player);
            const uint64_t vitals = ox_readDirect<uint64_t>(player + ox::PM_VITALS);
            const float maxHp = ox_isPtr(vitals)
                ? ox_readDirect<float>(vitals + ox::VITALS_HEALTH) : -1.f;
            const uint64_t handler = ox_readDirect<uint64_t>(player + ox::PM_EVENT_HANDLER);
            const uint64_t identity = ox_readDirect<uint64_t>(player + ox::NB_NET_IDENTITY);
            const uint32_t netId = ox_isPtr(identity)
                ? ox_readDirect<uint32_t>(identity + ox::NI_NET_ID) : 0;
            const uint8_t mirrorLocal = ox_isPtr(identity)
                ? ox_readDirect<uint8_t>(identity + ox::NI_IS_LOCAL_PLAYER) : 0;
            const uint8_t respawning = ox_readDirect<uint8_t>(player + ox::PM_RESPAWNING);
            Vector3 tick{},saved{},motor{};
            const bool tickOk=pvm((void*)(player+ox::PM_LAST_TICK_POS),&tick,sizeof(tick),false);
            const bool savedOk=pvm((void*)(player+ox::PM_LAST_SAVED_POS),&saved,sizeof(saved),false);
            const bool motorOk=ox_pcReadMotorPos(player,motor);
            oxlog::diagf("[pc-player] i=%d pm=0x%llx klass=0x%llx expected=0x%llx vitals=0x%llx maxHp=%.1f handler=0x%llx identity=0x%llx netId=%u mirrorLocal=%u respawn=%u tick=%d/%.1f,%.1f,%.1f saved=%d/%.1f,%.1f,%.1f motor=%d/%.1f,%.1f,%.1f",
                         i, (unsigned long long)player, (unsigned long long)klass,
                         (unsigned long long)g_playerManagerKlass, (unsigned long long)vitals,
                         maxHp, (unsigned long long)handler, (unsigned long long)identity,
                         netId, mirrorLocal, respawning,
                         (int)tickOk,tick.x,tick.y,tick.z,
                         (int)savedOk,saved.x,saved.y,saved.z,
                         (int)motorOk,motor.x,motor.y,motor.z);
        }
#endif

        float hp = ox_readHP(player, full && i < 2);
        checkedHP++;
#if defined(__x86_64__)
        // GenericVitals can be absent or expose an uninitialized maximum for
        // remote players. Prefer the resolved live-health chain; when that is
        // unavailable, the active PlayerManager roster and respawn flag still
        // identify an in-match player for ESP and target selection.
        if (hp < ox::HP_MIN || hp > ox::HP_MAX) {
            PlayerCacheData live{};
            if (ox_readHpLive(player, live, false)) {
                hp = live.hpNow;
            } else {
                uint8_t respawning = 1;
                const bool active = ox_readDirect<uint64_t>(player) == g_playerManagerKlass &&
                    pvm((void*)(player + ox::PM_RESPAWNING), &respawning, 1, false) &&
                    respawning == 0;
                if (active) hp = 100.f;
            }
        }
#endif
        if (hp < ox::HP_MIN || hp > ox::HP_MAX) {
            skippedHP++;
            if (full && i < 8) OXLOGT("player[%d]=0x%llx откинут: hp=%.2f вне [%.0f..%.0f]",
                                      i, (unsigned long long)player, hp, ox::HP_MIN, ox::HP_MAX);
            continue;
        }

        Vector3 pos = ox_readPos(player, full && i < 2);
#if defined(__x86_64__)
        Vector3 modelOrigin{};
        if (ox_pcReadVisualOrigin(player, sampleTime, modelOrigin))
            pos = modelOrigin;
#endif
        if (pos == Vector3::Zero()) { skippedPos++; continue; }

        // Себя не рисуем. Основной критерий — прямой флаг Mirror:
        // NetworkBehaviour.netIdentity(0x40).isLocalPlayer(0x4A). Он не зависит
        // от того, успел ли ox_getCamera выбрать владельца, поэтому свой бокс
        // не мелькает в первые кадры матча. Сверка по указателю оставлена
        // вторым условием на случай, если netIdentity ещё не привязан.
        {
            bool isSelf = (player == g_localPlayer);
            if (!isSelf) {
                uint64_t ni = rpm<uint64_t>(player + ox::NB_NET_IDENTITY);
                if (ox_isPtr(ni) && rpm<uint8_t>(ni + ox::NI_IS_LOCAL_PLAYER) != 0)
                    isSelf = true;
            }
            if (isSelf) { skippedLocal++; continue; }
        }

        // FIX bug #2: стабильный team-key (raw UTF-16 teamName / pf.teamId / pf-ptr).
        // pf-указатель как fallback — все тимейты имеют один shared pf, разные — разные pf.
        std::string teamKey = ox_teamKey(player);
        // Диагностика: первые 4 игрока за проход логируем team-ключ (одна строка).
        if (full && checkedHP < 4) {
            OXLOGI("[team] player[%d]=0x%llx teamKey='%s' localKey='%s' match=%d",
                   checkedHP, (unsigned long long)player,
                   teamKey.c_str(), g_localTeamName.c_str(),
                   (int)(!g_localTeamName.empty() && !teamKey.empty() && teamKey == g_localTeamName));
        }
        // Скрытие тимейтов: сначала прямая проверка по составу команды
        // (не зависит от строковых полей), затем сравнение team-ключей.
        bool isMate = ox_isTeammate(g_localPlayer, player) ||
                      (!g_localTeamName.empty() && !teamKey.empty() &&
                       teamKey == g_localTeamName);
        if (espHideTeammates && isMate) {
            skippedTeam++;
            continue;
        }

        PlayerCacheData data{};
        data.address = player;
        {
            const uint64_t identity = ox_readDirect<uint64_t>(player + ox::NB_NET_IDENTITY);
            if (ox_isPtr(identity)) data.netId = ox_readDirect<uint32_t>(identity + ox::NI_NET_ID);
        }
        data.health  = (int)hp;
        data.armor   = 0;
        data.teamId  = 0;
        data.position = pos;
        data.sampledPosition = pos;
        data.sampleTime = sampleTime;
        data.teamName = teamKey;   // хранит team-key для aimbot-фильтра
        data.velocity = Vector3::Zero();

        const PlayerCacheData *prevP = nullptr;
        for (const PlayerCacheData& previous : cached_players) {
            if (previous.address != player) continue;
            prevP = &previous;
            double dt = sampleTime - previous.sampleTime;
            if (dt > 0.01 && dt < 2.0) {
                Vector3 measured = (pos - previous.sampledPosition) / (float)dt;
                float speed = measured.magnitude();
                if (isfinite(speed) && speed <= 30.0f)
                    data.velocity = previous.velocity * 0.65f + measured * 0.35f;
            }
            break;
        }
        data.distance = cam.valid ? Vector3::Distance(cam.pos, pos) : 0.f;

        // Огромный радиус по умолчанию (5000 м). 0 = вообще без лимита.
        if (espMaxDistance > 0.f && data.distance > espMaxDistance &&
            (!chamsOn || data.distance>chams::Clamp(chamsRange,20,220,180))) { skippedVis++; continue; }

        w2sLogDetail = (full && valid < 3); // детальная трассировка для первых целей
        // pos = уровень глаз/головы → низ бокса опускаем к ногам, верх чуть выше макушки.
        // espBoxYOffset — живая вертикальная привязка (см. комментарий у глобала).
        Vector3 anchor = pos + Vector3(0.f, ox_boxYOffset(), 0.f);
        data.w2sBottom = w2s_angular(anchor - Vector3(0, ox::BOX_FOOT, 0), cam, &data.isVisibleBottom);
        data.w2sTop    = w2s_angular(anchor + Vector3(0, ox::BOX_HEAD, 0), cam, &data.isVisibleTop);
        w2sLogDetail = false;

        // Расширенные данные — читаем в тяжёлом скане (раз в g_cacheInterval
        // кадров), не каждый кадр: цепочки длинные, а меняются они редко.
        // Имя и клан почти не меняются, оружие/броня/флаги — раз в четверть секунды: между этими моментами берётся прошлое значение того же
        // игрока (каждое чтение — системный вызов в процесс игры). Включённый тумблер или пустое имя обновляются сразу.
        {
            const int mask = (espname ? 1 : 0) | (espclan ? 2 : 0) | (espweapon ? 4 : 0) | (espArmor ? 8 : 0);
            const bool sameMask = prevP && prevP->extMask == mask;
            const bool staticDue = !sameMask || sampleTime - prevP->extStaticStamp >= 2.0 || (espname && prevP->name.empty());
            const bool dynDue    = !sameMask || sampleTime - prevP->extDynStamp >= 0.25;
            if (staticDue) {
                data.name = espname ? ox_playerNick(player, &data.nameFromRoster) : std::string();
                data.clan = espclan ? ox_playerClan(player) : std::string();
                data.extStaticStamp = sampleTime;
#if defined(__x86_64__)
                if (espname && data.netId && data.nameFromRoster && !data.name.empty()) {
                    if (verifiedNicks.size() >= 512 && !verifiedNicks.count(data.netId))
                        verifiedNicks.clear();
                    verifiedNicks[data.netId] = {data.name, sampleTime};
                }
#endif
                // Roster/managed-string reads can fail while the game updates
                // its player list. Keep a previously verified name for the
                // same network identity and retry the next cache pass.
                if (espname && data.name.empty() && prevP && data.netId != 0 &&
                    prevP->netId == data.netId && !prevP->name.empty()) {
                    data.name = prevP->name;
                    data.nameFromRoster = prevP->nameFromRoster;
                    data.extStaticStamp = sampleTime - 2.0;
                }
#if defined(__x86_64__)
                // A PM can be reallocated on respawn and the whole previous
                // frame cache can disappear after one partial list read. Only
                // reuse a recent roster name for the same nonzero network ID.
                if (espname && data.name.empty() && data.netId) {
                    auto known = verifiedNicks.find(data.netId);
                    if (known != verifiedNicks.end() && sampleTime >= known->second.seenAt &&
                        sampleTime - known->second.seenAt <= 15.0) {
                        data.name = known->second.value;
                        data.nameFromRoster = true;
                        data.extStaticStamp = sampleTime - 2.0;
                    }
                }
#endif
            } else {
                data.name = prevP->name; data.nameFromRoster = prevP->nameFromRoster; data.clan = prevP->clan;
                data.extStaticStamp = prevP->extStaticStamp;
            }
            if (dynDue) {
                if (espweapon) ox_readHeld(player, data.weapon, data.weaponLabel);
                if (espArmor) ox_readEquipped(player, data.armorWorn);
                data.armor  = (int)ox_readArmor(player);
                OxPlayerFlags pf = ox_readPlayerFlags(player);
                data.flagSleeping   = pf.sleeping;
                data.flagSpectating = pf.spectating;
                data.flagPrime      = pf.prime;
                data.extDynStamp = sampleTime;
            } else {
                data.weapon = prevP->weapon; data.weaponLabel = prevP->weaponLabel; data.armorWorn = prevP->armorWorn; data.armor = prevP->armor;
                data.flagSleeping = prevP->flagSleeping; data.flagSpectating = prevP->flagSpectating; data.flagPrime = prevP->flagPrime;
                data.extDynStamp = prevP->extDynStamp;
            }
            data.extMask = mask;
        }
        data.viewPtr = 0;
        data.hasSkeletonData = false;

        if (logNow && valid < 5)
            OXLOGI("ЦЕЛЬ[%d]=0x%llx hp=%.0f pos=(%.2f,%.2f,%.2f) dist=%.1f visB=%d visT=%d w2sB=(%.0f,%.0f) w2sT=(%.0f,%.0f)",
                   i, (unsigned long long)player, hp, pos.x, pos.y, pos.z, data.distance,
                   (int)data.isVisibleBottom, (int)data.isVisibleTop,
                   data.w2sBottom.x, data.w2sBottom.y, data.w2sTop.x, data.w2sTop.y);

        // 360° counter fix: НЕ отсеиваем игроков вне frustum'а. Просто помечаем
        // visibility, downstream ESP-render сам скипнет отрисовку если оба
        // isVisibleBottom/Top=false. Счётчик g_enemyCount теперь считает ВСЕХ
        // живых игроков в матче, не только тех кого мы видим.
        new_cache.push_back(data);
        valid++;
    }

    if (logNow)
        OXLOGI("ИТОГ: static+0x%llx elems=0x%llx count=%d camValid=%d | проверено HP=%d, откинуто(hp=%d,pos=%d,local=%d,team=%d,vis=%d) -> целей=%d",
               (unsigned long long)plist.statOff, (unsigned long long)elems, size,
               (int)cam.valid, checkedHP, skippedHP, skippedPos, skippedLocal, skippedTeam, skippedVis, valid);
    if (pcDiagDue)
    {
        const uint64_t gcKlass = g_gcKlass.load(std::memory_order_relaxed);
        const uint64_t gcStatics = ox_isPtr(gcKlass)
            ? ox_readDirect<uint64_t>(gcKlass + ox::CLASS_STATIC_FIELDS) : 0;
        const uint64_t gcLocal = ox_isPtr(gcStatics)
            ? ox_readDirect<uint64_t>(gcStatics + ox::GC_STATIC_LOCAL_PM) : 0;
        oxlog::diagf("[pc-scan] size=%d snapshot=%zu first=0x%llx checkedHP=%d skipHP=%d skipPos=%d skipSelf=%d skipTeam=%d skipRange=%d targets=%d camera=%d gcLocal=0x%llx",
                     size, playerSnapshot.size(), (unsigned long long)(size ? playerAt(0) : 0),
                     checkedHP, skippedHP, skippedPos, skippedLocal, skippedTeam,
                     skippedVis, valid, (int)cam.valid, (unsigned long long)gcLocal);
#if defined(__x86_64__)
        ox_pcLogLocalCandidate(gcLocal);
#endif
    }

    ox_dropDuplicateNicks(new_cache);              // одинаковая «подпись» у разных игроков — заготовка, а не ник

    {
        std::lock_guard<std::mutex> lock(player_data_mutex);
        cached_players = std::move(new_cache);
        cache_needs_update = false;
        g_enemyCount = (int)cached_players.size();
    }
}

// ============================================================================
//  Стартовый диагностический дамп. Пишется в файл лога
//  (/sdcard/Download/avis_tools_<время>.log) ОДИН раз при запуске,
//  НЕЗАВИСИМО от verbose-режима меню (oxlog::enabled по умолчанию true).
//  Содержит всё для отладки оффсетов после апдейта игры: версию
//  il2cpp-метаданных, базы модулей, результат авто-резолва TypeInfo
//  и полную таблицу оффсетов из oxide_offsets.h.
// ============================================================================

// Лёгкий пробник версии метаданных: находит первый валидный заголовок
// 0xFAB11BAF и возвращает version/size БЕЗ копирования blob в файл.
static bool ox_probeMetadataVersion(uint32_t &outVersion, size_t &outSize) {
    outVersion = 0; outSize = 0;
    if (game_pid <= 0) return false;
    std::vector<OxMapRange> maps;
    ox_collectMetadataMaps(maps, 1024ULL * 1024 * 1024);
    const size_t chunkSize = 1024 * 1024;
    std::vector<uint8_t> buffer(chunkSize + 4);
    for (const OxMapRange &map : maps) {
        size_t carry = 0;
        for (uint64_t at = map.start; at < map.end;) {
            size_t want = (size_t)std::min<uint64_t>(chunkSize, map.end - at);
            if (!vm_readv(at, buffer.data() + carry, want)) { carry = 0; at += want; continue; }
            size_t total = carry + want;
            for (size_t i = 0; i + sizeof(uint32_t) <= total; i += sizeof(uint32_t)) {
                uint32_t magic = 0;
                memcpy(&magic, buffer.data() + i, sizeof(magic));
                if (magic != IL2CPP_METADATA_MAGIC) continue;
                uint64_t candidate = at - carry + i;
                size_t sz = 0; uint32_t ver = 0;
                if (ox_validateMetadataHeader(candidate, map.end, sz, ver)) {
                    outVersion = ver; outSize = sz;
                    return true;
                }
            }
            carry = std::min(sizeof(uint32_t) - 1, total);
            memmove(buffer.data(), buffer.data() + total - carry, carry);
            at += want;
        }
    }
    return false;
}

static void ox_logStartupDiagnostics() {
    oxlog::section("STARTUP DIAGNOSTICS");
    OXLOGI("build: %s %s", __DATE__, __TIME__);
    OXLOGI("package=%s module=%s native=%s", ox::PACKAGE, ox::MODULE, ox::MODULE_NATIVE);
    OXLOGI("game_pid=%d libil2cpp_mapped=%s", game_pid,
           (game_pid > 0 && pidHasModule(game_pid, ox::MODULE)) ? "yes" : "no");

    // --- Базы модулей ---
    if (!ox_ensureBase(true))
        OXLOGW("il2cpp base ещё не готова (игра догрузит либу) — будет до-резолв в кадре");
    OXLOGI("il2cpp_base = 0x%llx", (unsigned long long)il2cpp_base);
    uint64_t nativeBase = get_module_base_real(ox::MODULE_NATIVE);
    OXLOGI("%s base = 0x%llx", ox::MODULE_NATIVE, (unsigned long long)nativeBase);

    // --- Версия il2cpp метаданных (лёгкий пробник, без дампа файла) ---
    uint32_t metaVer = 0; size_t metaSize = 0;
    if (ox_probeMetadataVersion(metaVer, metaSize))
        OXLOGI("il2cpp metadata: version=%u size=%zu (0x%zx)", metaVer, metaSize, metaSize);
    else
        OXLOGW("il2cpp metadata header не найден (зашифрован/ещё не расшифрован)");

    // --- Авто-резолв TypeInfo (перекрывает fallback из хедера) ---
    OXLOGI("TypeInfo fallback из хедера: PM=0x%llx BP=0x%llx PV=0x%llx",
           (unsigned long long)ox::PLAYERMANAGER_TYPEINFO,
           (unsigned long long)ox::BUILDINGPIECE_TYPEINFO,
           (unsigned long long)ox::PLAYERVITALS_TYPEINFO);
    if (il2cpp_base) {
        bool ok = ox_autoResolveTypeInfos(true);
        OXLOGI("TypeInfo auto-resolve: %s -> PM=0x%llx BP=0x%llx",
               ok ? "OK" : "PARTIAL/FAIL",
               (unsigned long long)g_playerManagerTypeInfoRVA,
               (unsigned long long)g_buildingPieceTypeInfoRVA);
    } else {
        OXLOGW("TypeInfo auto-resolve пропущен: нет il2cpp base");
    }

    // --- Полная таблица оффсетов из oxide_offsets.h ---
    oxlog::section("OFFSETS TABLE (oxide_offsets.h)");
    #define OXDUMP(name) OXLOGI("  %-24s = 0x%llx", #name, (unsigned long long)ox::name)
    OXDUMP(CLASS_STATIC_FIELDS); OXDUMP(STATIC_ACTIVE_LIST); OXDUMP(STATIC_BUILDING_SAVELIST);
    OXDUMP(CLASS_NAME); OXDUMP(CLASS_NAMESPACE);
    OXDUMP(LIST_ITEMS); OXDUMP(LIST_SIZE); OXDUMP(ARRAY_COUNT); OXDUMP(ARRAY_DATA);
    OXDUMP(PM_TRANSFORM); OXDUMP(PM_MOUSELOOK); OXDUMP(PM_RAYCASTMANAGER);
    OXDUMP(PM_IS_LOCAL_PLAYER); OXDUMP(PM_VITALS); OXDUMP(PM_TEAM_ID); OXDUMP(PM_TEAM_NAME);
    OXDUMP(ML_ANGLES); OXDUMP(ML_LOOKROOT); OXDUMP(ML_PITCH); OXDUMP(ML_YAW);
    OXDUMP(RM_WORLD_CAMERA); OXDUMP(RM_RAY_LENGTH); OXDUMP(RM_AIM_RAY_LENGTH);
    OXDUMP(RM_LAYER_MASK); OXDUMP(RM_AIM_LAYER_MASK);
    OXDUMP(VITALS_HEALTH);
    OXDUMP(OBJ_CACHED_PTR); OXDUMP(TR_INT_MATRIXPTR); OXDUMP(TR_MATRIX_WORLDPOS);
    OXDUMP(TR_MATRIX_ROT); OXDUMP(TR_MATRIX_SCALE);
    OXDUMP(BP_CORRECT_POSITION); OXDUMP(BP_BOUNDS); OXDUMP(BP_CORRECT_ROTATION);
    OXDUMP(BP_ADDITIONAL_BOUNDS); OXDUMP(BP_M_GRADE); OXDUMP(BP_GRADE_HOLDER);
    OXDUMP(BP_PIECE_NAME); OXDUMP(BP_ID); OXDUMP(BP_HEALTH); OXDUMP(BP_MAXHEALTH);
    #undef OXDUMP

    // Полный runtime-sweep всех известных TypeInfo — 11 классов ×
    // ox_findAscii+ox_scanClassByName по writable/anon памяти. При стабильной
    // шапке это чистый лаг; включается только под OX_DEEP_DIAG (при апдейте
    // libil2cpp.so, когда действительно нужны свежие RVA).
#if OX_DEEP_DIAG
    if (il2cpp_base) ox_sweepAllTypeInfos(true);
    else OXLOGW("[sweep] пропущен: il2cpp_base ещё не готова");
#else
    OXLOGI("[sweep] пропущен (OX_DEEP_DIAG=0). Включить: -DOX_DEEP_DIAG=1");
#endif

    OXLOGI("STARTUP DIAGNOSTICS завершён");
}

// UPDATE 2026/07/31: SIGSEGV/SIGBUS handler.
// Причина: на Android 16 (API 36) private SurfaceFlinger символы, которые
// dlsym'ит ANativeWindowCreator, часто возвращают null или указывают в
// удалённую .so — вызов ловит SIGSEGV до вывода первого printf. Без хендлера
// процесс просто исчезает, лог обрывается на последней успешной строке.
// Хендлер печатает адрес фолта + короткий backtrace через glibc-совместимую
// функцию unw_step (или fallback — просто фрейм-указатели), потом
// _exit(139). Восстанавливать процесс НЕ пытаемся — там уже несогласованное
// состояние ImGui/EGL.
// bionic не имеет execinfo.h/backtrace — печатаем regs + fp-walk вручную.
#include <signal.h>
#include <ucontext.h>
static void ox_signal_handler(int sig, siginfo_t *info, void *ucontext_v) {
    OXLOGE("!!!!!!!!!! ФАТАЛЬНЫЙ СИГНАЛ %d !!!!!!!!!!", sig);
    OXLOGE("thread tid=%ld main=%d", (long)syscall(SYS_gettid), (int)(syscall(SYS_gettid) == getpid()));
    OXLOGE("si_code=%d si_addr=0x%llx", info->si_code, (unsigned long long)info->si_addr);
    if (ucontext_v) {
        ucontext_t *uc = (ucontext_t *)ucontext_v;
#if defined(__aarch64__)
        OXLOGE("PC=0x%llx  LR=0x%llx  SP=0x%llx  FP=0x%llx",
               (unsigned long long)uc->uc_mcontext.pc,
               (unsigned long long)uc->uc_mcontext.regs[30],
               (unsigned long long)uc->uc_mcontext.sp,
               (unsigned long long)uc->uc_mcontext.regs[29]);
        for (int i = 0; i < 30; i += 4) {
            OXLOGE("X%d=0x%llx  X%d=0x%llx  X%d=0x%llx  X%d=0x%llx",
                   i,   (unsigned long long)uc->uc_mcontext.regs[i],
                   i+1, (unsigned long long)uc->uc_mcontext.regs[i+1],
                   i+2, (unsigned long long)uc->uc_mcontext.regs[i+2],
                   i+3, (unsigned long long)uc->uc_mcontext.regs[i+3]);
        }
#elif defined(__x86_64__)
        // Индексы gregs[] из <sys/ucontext.h>: REG_RBP=10, REG_RSP=15, REG_RIP=16.
        const uint64_t rip = (uint64_t)uc->uc_mcontext.gregs[16], rsp = (uint64_t)uc->uc_mcontext.gregs[15], rbp = (uint64_t)uc->uc_mcontext.gregs[10];
        OXLOGE("RIP=0x%llx  RSP=0x%llx  RBP=0x%llx", (unsigned long long)rip, (unsigned long long)rsp, (unsigned long long)rbp);
        OXLOGE("RDI=0x%llx RSI=0x%llx RDX=0x%llx",
               (unsigned long long)uc->uc_mcontext.gregs[8],
               (unsigned long long)uc->uc_mcontext.gregs[9],
               (unsigned long long)uc->uc_mcontext.gregs[12]);
        Dl_info dl;
        if (dladdr((void *)rip, &dl) && dl.dli_fname)
            OXLOGE("  #0 (RIP): 0x%llx  %s+0x%llx  (%s+0x%llx)", (unsigned long long)rip, dl.dli_sname ? dl.dli_sname : "?",
                   (unsigned long long)((char *)rip - (char *)dl.dli_saddr), dl.dli_fname, (unsigned long long)((char *)rip - (char *)dl.dli_fbase));
#endif
    }
    // Frame-pointer walk (AArch64: FP=x29, каждый фрейм: [FP]=next_fp, [FP+8]=LR).
#if defined(__aarch64__)
    if (ucontext_v) {
        ucontext_t *uc = (ucontext_t *)ucontext_v;
        uint64_t fp = uc->uc_mcontext.regs[29];
        uint64_t lr = uc->uc_mcontext.regs[30];
        Dl_info dl;
        if (dladdr((void*)lr, &dl) && dl.dli_fname) {
            OXLOGE("  #0 (LR): 0x%llx  %s+0x%llx  (%s+0x%llx)",
                   (unsigned long long)lr,
                   dl.dli_sname ? dl.dli_sname : "?",
                   (unsigned long long)((char*)lr - (char*)dl.dli_saddr),
                   dl.dli_fname,
                   (unsigned long long)((char*)lr - (char*)dl.dli_fbase));
        }
        for (int i = 1; i < 20 && fp != 0; i++) {
            uint64_t next_fp, ret_lr;
            // fp может быть уже мусорной — оборачиваем в try (в реальности просто читаем)
            next_fp = *(uint64_t*)(fp);
            ret_lr  = *(uint64_t*)(fp + 8);
            Dl_info di;
            if (dladdr((void*)ret_lr, &di) && di.dli_fname) {
                OXLOGE("  #%d: 0x%llx  %s+0x%llx  (%s+0x%llx)",
                       i, (unsigned long long)ret_lr,
                       di.dli_sname ? di.dli_sname : "?",
                       (unsigned long long)((char*)ret_lr - (char*)di.dli_saddr),
                       di.dli_fname,
                       (unsigned long long)((char*)ret_lr - (char*)di.dli_fbase));
            } else {
                OXLOGE("  #%d: LR=0x%llx  (unresolved)", i, (unsigned long long)ret_lr);
            }
            if (next_fp <= fp || (next_fp - fp) > 0x10000) break;
            fp = next_fp;
        }
    }
#endif
    oxlog::shutdown();
    _exit(128 + sig);
}

static void ox_install_signal_handlers() {
    struct sigaction sa = {};
    sa.sa_sigaction = ox_signal_handler;
    sa.sa_flags = SA_SIGINFO | SA_RESTART;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, nullptr);
    sigaction(SIGBUS,  &sa, nullptr);
    sigaction(SIGILL,  &sa, nullptr);
    sigaction(SIGFPE,  &sa, nullptr);
    sigaction(SIGABRT, &sa, nullptr);
}

// ── Замеры нагрузки ──────────────────────────────────────────────────────────────────────────────────────────────────────────────
// Раз в 5 с: сколько кадров в секунду отдаёт оверлей, сколько времени занимает работа кадра (p95 и максимум — это и есть «рывки») и своп,
// сколько стоит скан игроков и сколько чтений памяти игры идёт в секунду (из них системных вызовов и попаданий в кэш кадра).
// Строка [perf] в логе и последняя строка вкладки Memory -> Boost.
struct OxPerf {
    std::vector<float> work;
    double swapSum = 0, swapMax = 0, scanSum = 0, scanMax = 0, winStart = 0;
    int scans = 0;
    VmStats base{};
    bool started = false;
    void frame(double workMs, double swapMs) { if (work.size() < 4000) work.push_back((float)workMs); swapSum += swapMs; if (swapMs > swapMax) swapMax = swapMs; }
    void scan(double ms) { ++scans; scanSum += ms; if (ms > scanMax) scanMax = ms; }
    void report(double now) {
        if (!started) { started = true; winStart = now; base = vm_stats(); return; }
        const double dt = now - winStart;
        if (dt < 5.0 || work.empty()) return;
        std::vector<float> w = work; std::sort(w.begin(), w.end());
        double sum = 0; for (float v : w) sum += v;
        const int n = (int)w.size();
        const double avg = sum / n, p95 = w[(size_t)((n - 1) * 0.95)], mx = w.back(), swapAvg = swapSum / n, fps = n / dt;
        const VmStats now_s = vm_stats();
        const double sysRender = (double)(now_s.thSyscalls - base.thSyscalls) / dt, readsRender = (double)(now_s.thReads - base.thReads) / dt;
        const double hitPct = now_s.thReads > base.thReads ? 100.0 * (double)(now_s.thHits - base.thHits) / (double)(now_s.thReads - base.thReads) : 0.0;
        const double sysAll = (double)(now_s.syscalls - base.syscalls) / dt, kb = (double)(now_s.bytes - base.bytes) / 1024.0 / dt;
        OXLOGI("[perf] %.0f кадров/с | работа кадра, мс: сред %.2f, p95 %.2f, макс %.2f | рендер+своп сред %.2f, макс %.1f | скан игроков %d раз: сред %.2f, макс %.2f мс | "
               "чтений/с в потоке отрисовки %.0f -> системных вызовов %.0f (кэш кадра %.0f%%); все потоки %.0f вызовов/с, %.0f КБ/с | запись/с %.0f",
               fps, avg, p95, mx, swapAvg, swapMax, scans, scans ? scanSum / scans : 0.0, scanMax, readsRender, sysRender, hitPct, sysAll, kb,
               (double)(now_s.writes - base.writes) / dt);
        char b[160];
        snprintf(b, sizeof(b), "Load: %.0f fps, frame %.1f ms (max %.0f), memory calls %.0f/s", fps, avg, mx, sysAll);
        g_boostStatus[4] = b;
        work.clear(); swapSum = swapMax = scanSum = scanMax = 0; scans = 0; winStart = now; base = now_s;
    }
};

int main(int argc, char *argv[]) {
    oxlog::init();
    ox_install_signal_handlers();
    oxlog::section("STARTUP");
    OXLOGI("Avis tools запущен, uid=%d, pid=%d", (int)getuid(), (int)getpid());
    OXLOGI("SIGSEGV/SIGBUS/SIGILL/SIGFPE/SIGABRT handlers установлены");

    // UPDATE 2026/07/31: подробный boot-лог по запросу erafox.
    // Дампит все ключевые offsets/RVA/TDI сразу, чтобы можно было удалённо
    // диагностировать без включения debug-мода из меню.
    OXLOGI("========== AVIS TOOLS BUILD INFO ==========");
    OXLOGI("release:            v2.6");
    OXLOGI("build:              %s %s", __DATE__, __TIME__);
    OXLOGI("target package:     %s", ox::PACKAGE);
    OXLOGI("target module:      %s", ox::MODULE);
    OXLOGI("game version:       1.15.11966 (%s)", oxarch::kCur.name);
    OXLOGI("platform auto-detected: %s", oxarch::kCur.name[0] == 'x' ? "PC / Android x86_64" : "Android ARM64");
    OXLOGI("");
    OXLOGI("========== TYPEINFO / TDI 1.15.11966 ==========");
    OXLOGI("PlayerManager RVA=0x%llx TDI=%u", (unsigned long long)OX_TI_PLAYERMANAGER, OX_TDI_PLAYERMANAGER);
    OXLOGI("GameController RVA=0x%llx", (unsigned long long)OX_TI_GAMECONTROLLER);
    OXLOGI("NetworkClient RVA=0x%llx TDI=%u", (unsigned long long)OX_TI_NETWORKCLIENT, OX_TDI_NETWORKCLIENT);
    OXLOGI("BuildingPiece RVA=0x%llx TDI=%u", (unsigned long long)oxarch::kCur.tiBuildingPiece, OX_TDI_BUILDINGPIECE);
    OXLOGI("PlayerVitals RVA=0x%llx TDI=%u", (unsigned long long)oxarch::kCur.tiPlayerVitals, OX_TDI_PLAYERVITALS);
    OXLOGI("TYPEDEF_COUNT=%u", OX_TYPEDEF_COUNT);
    OXLOGI("Нативные metadata RVA не сверены без libil2cpp.so/global-metadata.dat");
    OXLOGI("");
    OXLOGI("========== LOG SETTINGS ==========");
    OXLOGI("oxlog::enabled  = %d", (int)oxlog::enabled);
    OXLOGI("oxlog::verbose  = %d (первые %d кадров пишем hex-дампы)",
           (int)oxlog::verbose, 300 /*FULL_LOG_FRAMES*/);
    OXLOGI("log directory   = %s", oxlog::activeDir());
    OXLOGI("log file        = %s", "avis_tools_YYYYMMDD_HHMMSS.log");
    OXLOGI("logcat tag      = AvisTools  (adb logcat -s AvisTools)");
    OXLOGI("=============================================");

    screen_config();
    ::abs_ScreenX = (displayInfo.height > displayInfo.width ? displayInfo.height : displayInfo.width);
    ::abs_ScreenY = (displayInfo.height < displayInfo.width ? displayInfo.height : displayInfo.width);
    OXLOGI("Экран: raw %dx%d, ориентация=%d -> abs %dx%d",
           displayInfo.width, displayInfo.height, displayInfo.orientation,
           ::abs_ScreenX, ::abs_ScreenY);
    
    ::native_window_screen_x = (displayInfo.height > displayInfo.width ? displayInfo.height : displayInfo.width);
    ::native_window_screen_y = (displayInfo.height < displayInfo.width ? displayInfo.height : displayInfo.width);
    
    // Log both sides of GUI initialization so later crashes are not mistaken
    // for a SurfaceFlinger/dlsym failure.
    OXLOGI("========== GUI INIT ==========");
    OXLOGI("native_window_screen: %dx%d", (int)native_window_screen_x, (int)native_window_screen_y);
    OXLOGI("orientation: %d", (int)displayInfo.orientation);
    OXLOGI("вызываю initGUI_draw(...)");
    if (!initGUI_draw(native_window_screen_x, native_window_screen_y, true)) {
        OXLOGE("Не удалось создать окно или инициализировать ImGui/EGL");
        OXLOGE("Скорее всего ANativeWindowCreator::Create вернул null-символ через dlsym.");
        OXLOGE("Проверь /sdcard/Download/AvisTools/*.log до этого места и addr2line на бинарнике.");
        fprintf(stderr, "ERROR: overlay initialization failed (window, EGL, or ImGui)\n");
        return -1;
    }
    OXLOGI("initGUI_draw ok — окно, EGL, ImGui поднялись");

    if (!Touch_Init(displayInfo.width, displayInfo.height, displayInfo.orientation, true))
        OXLOGE("Не найден доступный ввод /dev/input: проверь root и устройства ввода эмулятора");
    else {
        const TouchStats input = Touch_GetStats();
        OXLOGI("Ввод: %d устройств (touch=%d pointer=%d)", input.sources, input.touchSources, input.pointerSources);
    }
	// The bundle picked the CPU-compatible ELF before entering main().
	game_pid = getGameProcessID(ox::PACKAGE, ox::MODULE);
	if (game_pid <= 0) game_pid = getProcessID(ox::PACKAGE);
	if (game_pid <= 0) {
		OXLOGW("Игра пока не запущена: %s", ox::PACKAGE);
		printf("Waiting for Oxide to start: %s\n", ox::PACKAGE);
		fflush(stdout);
		while (main_thread_flag && game_pid <= 0) {
			sleep(1);
			game_pid = getGameProcessID(ox::PACKAGE, ox::MODULE);
			if (game_pid <= 0) game_pid = getProcessID(ox::PACKAGE);
		}
		if (!main_thread_flag) { shutdown(); return -1; }
		OXLOGI("Игра найдена после ожидания, pid=%d", game_pid);
	}
	OXLOGI("PID игры '%s' = %d (%s libil2cpp)", ox::PACKAGE, game_pid,
	       pidHasModule(game_pid, ox::MODULE) ? "есть" : "пока нет");

    avis::Init(AVIS_DATA_DIR);   // система ключей: проверка сохранённого ключа и связь с сервером идут в фоновом потоке

	// RVA из script.json отсчитываются от базы модуля = самый нижний маппинг (ELF header).
	// Пробуем сразу; если игра ещё не подгрузила либу — база до-резолвится в цикле (ox_ensureBase).
	oxlog::section("MODULE BASE");
	il2cpp_base = get_module_base_real(ox::MODULE);
	OXLOGI("%s стартовая база = 0x%llx%s", ox::MODULE,
	       (unsigned long long)il2cpp_base,
	       il2cpp_base ? "" : " (пока не загруж��н — дождёмся в цикле)");
	if (!il2cpp_base) dump_maps_matching("il2cpp", 12);

    // Логи, dump метадаты и всё что чит пишет наружу — в одну папку.
    OXLOGI("Артефакты в: %s", oxlog::activeDir());

    // Полный стартовый диагностический дамп + TypeInfo auto-resolve вынесены в
    // фоновый поток, чтобы главный цикл рендера запустился с первого кадра, а
    // меню появилось сразу — до этой правки клиент подвисал минуты на сканах
    // памяти (см. лог erafox: обрывался на "TypeInfo fallback из хедера: ...").
    //
    // Второе издание: после первой полной диагностики поток НЕ выходит, а спит
    // 20 сек и повторяет auto-resolve пока хоть один класс не нашёлся. Это
    // покрывает кейс «чит запущен раньше входа в матч»: в лобби IL2Cpp lazy-load
    // ещё не тронул PlayerManager, строк в памяти нет — но как только игрок
    // зайдёт в матч и Unity создаст класс, следующий проход через 20 сек его
    // подхватит, чит не надо перезапускать. Максимум 45 попыток ≈ 15 мин.
    if (!g_startupThreadStarted.exchange(true)) {
        std::thread([](){
            g_startupInProgress = true;
            ox_setStartupStatus("startup diagnostics...");
            OXLOGI("[startup] фоновая диагностика стартовала (tid=%ld)", (long)syscall(SYS_gettid));

            // UPDATE 2026/07/31 v15: МАКСИМАЛЬНО агрессивный старт по требованию.
            // - g_startupInProgress ставим в false СРАЗУ, чтобы UpdatePlayerCache
            //   мог начать работу как только классы появятся — не ждёт нас.
            // - первые 20 попыток БЕЗ паузы (packed retry) — если классы уже готовы
            //   (обычно в лобби/матче), поймаем за ~200-500 мс всё.
            // - 20-100 попыток — по 100 мс (10 попыток в секунду).
            // - 100+ — по 500 мс.
            // Резолвер (ox_fastSeedTypeInfoFromHeader → ox_resolveKlassRobust) сам
            // делает кэш при успехе, повторные проходы дешёвые.
            ox_setStartupStatus("resolving classes...");
            g_startupInProgress = false;   // разрешаем UpdatePlayerCache работать сразу
            const int MAX_TRIES = 6000;    // long-tail retry — 30 мин если надо
            for (int i = 0; i < MAX_TRIES; ++i) {
                if (!main_thread_flag) { OXLOGI("[startup] прерван"); break; }
                if (ox_fastSeedTypeInfoFromHeader()) {
                    OXLOGI("[startup] РЕЗОЛВ OK на попытке #%d (PM=0x%llx BP=0x%llx)",
                           i,
                           (unsigned long long)g_playerManagerKlass,
                           (unsigned long long)g_buildingPieceKlass);
                    ox_setStartupStatus("ready");
                    g_startupInProgress = false;
                    g_startupDone = true;
                    // The worker's immediate return enters pthread_exit. On
                    // this emulator that exit path faulted directly after a
                    // successful resolve. Keep the detached worker asleep
                    // until the overlay is shutting down.
                    while (main_thread_flag) sleep(1);
                    return;
                }
                if (i > 0 && i % 100 == 0) {
                    OXLOGI("[startup] жду Class::Init: %d попыток", i);
                }
                // Cadence: жёстко без пауз первые 20, потом 100мс, потом 500мс.
                if (i < 20)      { /* без паузы */ }
                else if (i < 100) usleep(100 * 1000);
                else              usleep(500 * 1000);
            }
            OXLOGW("[startup] fast-seed не сработал за %d попыток. Классы не найдены.", MAX_TRIES);
            ox_setStartupStatus("failed (Class::Init не прогнан)");
            g_startupInProgress = false;
            g_startupDone = true;
            return;
            // === СТАРАЯ scan-based ветка отключена: убивает игру ===
            /*
            ox_setScanDeadline(90);
            ox_logStartupDiagnostics();
            ox_clearScanDeadline();
            g_startupInProgress = false;

            // Если TypeInfo сразу нашлись — работа окончена.
            if (g_playerManagerKlass || g_buildingPieceKlass) {
                ox_setStartupStatus("ready");
                g_startupDone = true;
                OXLOGI("[startup] TypeInfo найдены с первого прохода");
                return;
            }

            // Иначе входим в цикл повторных попыток. UpdatePlayerCache
            // продолжает работать (мы вышли из g_startupInProgress),
            // просто до успеха он видит g_playerManagerKlass=0 и не пытается
            // читать статики. Меню при этом полностью функционально.
            const int MAX_RETRIES = 45;
            const int SLEEP_SEC   = 20;
            for (int attempt = 1; attempt <= MAX_RETRIES; ++attempt) {
                if (!main_thread_flag) { OXLOGI("[startup] main остановлен, retry-loop выходит"); break; }
                for (int i = 0; i < SLEEP_SEC && main_thread_flag; ++i) sleep(1);
                if (!main_thread_flag) break;

                char buf[96];
                snprintf(buf, sizeof(buf), "retry TypeInfo (%d/%d)...", attempt, MAX_RETRIES);
                ox_setStartupStatus(buf);
                OXLOGI("[startup] retry #%d/%d (жду входа в матч)", attempt, MAX_RETRIES);

                g_startupInProgress = true;
                ox_setScanDeadline(60);
                ox_autoResolveTypeInfos(false);   // full=false — тихий лог, без hex-дампов
                ox_clearScanDeadline();
                g_startupInProgress = false;

                if (g_playerManagerKlass || g_buildingPieceKlass) {
                    ox_setStartupStatus("ready (found on retry)");
                    g_startupDone = true;
                    OXLOGI("[startup] TypeInfo найдены на retry #%d: PM=0x%llx BP=0x%llx",
                           attempt,
                           (unsigned long long)g_playerManagerKlass,
                           (unsigned long long)g_buildingPieceKlass);
                    return;
                }
            }
            // Все попытки исчерпаны — сдаёмся, но клиент продолжает работать
            // (меню, dump кнопка). Пользователь может пере-запустить чит уже
            // из матча.
            ox_setStartupStatus("no match yet (retry exhausted)");
            g_startupDone = true;
            OXLOGW("[startup] %d попыток исчерпано — TypeInfo так и не нашлись. "
                   "Зайди в матч и перезапусти чит.", MAX_RETRIES);
            */
            // === конец отключённой scan-based ветки ===
        }).detach();
    }


    // BlueStacks can update managed objects between reads inside one overlay
    // frame. The 256-byte frame cache then returns obsolete list slots and
    // player fields even though direct reads find a populated roster. Keep
    // caching on the phone, where it is known to work, and read PC fields live.
#if defined(__x86_64__)
    vm_cache_enable(false);
    OXLOGI("[memory] PC: прямое чтение памяти игры, кэш выключен");
#else
    vm_cache_enable(true);
    OXLOGI("[memory] кэш чтения на кадр включён (%s)", oxarch::kCur.name);
#endif
    OxPerf perf;
    while (main_thread_flag) {
        // --- Вотчдог: игра закрыта (процесс игры мёртв) → снести оверлей и выйти ---
        //  kill(pid,0) == -1 && errno==ESRCH означает «процесс больше не существует».
        //  Респавн игру НЕ убивает (pid тот же), так что ложных выходов нет — только
        //  реальное закрытие игры. Проверяем раз в ~15 кадров (дёшево).
        {
            static int s_wdCounter = 0;
            if (++s_wdCounter >= 15) {
                s_wdCounter = 0;
                if (game_pid > 0 && kill(game_pid, 0) != 0 && errno == ESRCH) {
                    OXLOGW("[watchdog] процесс игры pid=%d мёртв — закрываю оверлей и выхожу", game_pid);
                    main_thread_flag = false;
                    break;   // выход из цикла → shutdown() уничтожит окно → return 0 → процесс завершится
                }
            }
        }
        vm_cache_new_frame();
        const double perfT0 = ox_nowSec();
        drawBegin();
#if defined(__x86_64__)
        // Report the complete input path on emulators, including while the
        // key screen is open. One line every five seconds is enough to tell
        // whether evdev, the queue, or ImGui lost a click.
        {
            static double lastInputReport = -5.0;
            const double now = ImGui::GetTime();
            if (now - lastInputReport >= 5.0) {
                lastInputReport = now;
                TouchStats ts = Touch_GetStats();
                ImGuiIO &io = ImGui::GetIO();
                oxlog::diagf("[input] dev=%d touch=%d mouse=%d raw=%llu mtpos=%llu mtid=%llu touchkey=%llu mousekey=%llu abs=%llu rel=%llu queued=%llu pumped=%llu last_ev=%d/%d/%d mapped=%.0f,%.0f down=%d ImGui=%.0f,%.0f down=%d display=%.0f,%.0f",
                       ts.sources, ts.touchSources, ts.pointerSources, ts.rawEvents,
                       ts.mtPositionEvents, ts.mtTrackingEvents, ts.touchButtonEvents,
                       ts.mouseButtonEvents, ts.absPointerEvents, ts.relPointerEvents,
                       ts.queuedEvents, ts.pumpedEvents, ts.lastType, ts.lastCode, ts.lastValue, ts.lastX, ts.lastY,
                       (int)ts.lastDown, io.MousePos.x, io.MousePos.y, (int)io.MouseDown[0],
                       io.DisplaySize.x, io.DisplaySize.y);
                const uint64_t slot = il2cpp_base ? ox_readDirect<uint64_t>(il2cpp_base + OX_TI_PLAYERMANAGER) : 0;
                unsigned char elfHeader[20]{};
                int elfMachine = 0;
                if (il2cpp_base && vm_readv(il2cpp_base, elfHeader, sizeof(elfHeader)) &&
                    elfHeader[0] == 0x7f && elfHeader[1] == 'E' && elfHeader[2] == 'L' && elfHeader[3] == 'F')
                    elfMachine = elfHeader[18] | (int(elfHeader[19]) << 8);
                const uint64_t klass = il2cpp_base ? ox_klassFromSlot(OX_TI_PLAYERMANAGER, "PlayerManager") : 0;
                const uint64_t statics = klass ? ox_readDirect<uint64_t>(klass + ox::CLASS_STATIC_FIELDS) : 0;
                const uint64_t list = ox_isPtr(statics) ? ox_readDirect<uint64_t>(statics + ox::STATIC_PLAYER_LIST) : 0;
                const int listSize = ox_isPtr(list) ? ox_readDirect<int>(list + ox::LIST_SIZE) : -1;
                size_t players = 0;
                { std::lock_guard<std::mutex> lock(player_data_mutex); players = cached_players.size(); }
                const int angularCamera = g_localPlayer && ox_buildCameraFromPlayer(g_localPlayer, false).valid ? 1 : 0;
                oxlog::diagf("[pc-core] pid=%d base=0x%llx elfMachine=%d slot=0x%llx klass=0x%llx cachedKlass=0x%llx statics=0x%llx clientList=0x%llx listSize=%d players=%zu local=0x%llx cameraVP=%d cameraAngles=%d cacheFallbacks=%llu startup=%s",
                       game_pid, (unsigned long long)il2cpp_base, elfMachine, (unsigned long long)slot,
                       (unsigned long long)klass, (unsigned long long)g_playerManagerKlass,
                       (unsigned long long)statics, (unsigned long long)list, listSize,
                       players, (unsigned long long)g_localPlayer, (int)g_camVPValid, angularCamera,
                       (unsigned long long)vm_cache_fallbacks(), ox_getStartupStatus().c_str());
                const VmReadFallbackStats readStats=vm_read_fallback_stats();
                if (readStats.attempts)
                    oxlog::diagf("[pc-read] /proc/pid/mem attempted=%llu success=%llu",
                                 (unsigned long long)readStats.attempts,
                                 (unsigned long long)readStats.success);
                if (ts.sources == 0) Touch_Init(displayInfo.width, displayInfo.height, displayInfo.orientation, true);
            }
        }
#endif
        Layout_tick_UI();
        const heal::Sample healSample=ox_healSample((double)ImGui::GetTime());
        static const std::string healPackage=ox_healPackage();
        AutoHealTick(healSample,healPackage.c_str());

        // Без действующего ключа работает только экран ввода ключа: игру не читаем и ничего не рисуем.
        if (!avis::Active()) {
            ox_xrayStop();
            g_chamsEffects.clear();
            drawEnd();
            ox_overlayPace();
            usleep(1000);
            continue;
        }

        // обновляем кэш только раз в N кадров (интервал регулируется в меню)
        // Bug D FIX (respawn drift): если локальный PM протух между обновлениями
        // кэша (респавн + новый PM), форсируем refresh чтобы не строить камеру
        // из мусорной памяти старого умершего PM.
        bool localStale = g_localPlayer && !ox_localPlayerStillValid();
        if (localStale) {
            OXLOGI("[respawn] локальный PM протух между кадрами — форсирую cache refresh");
            g_localPlayer = 0;
            g_localTeamName.clear();
            cache_needs_update = true;
        }
        if (cache_needs_update || (ImGui::GetFrameCount() - last_cache_frame > g_cacheInterval)) {
            const double perfS0 = ox_nowSec();
            UpdatePlayerCache();
            perf.scan((ox_nowSec() - perfS0) * 1000.0);
            last_cache_frame = ImGui::GetFrameCount();

        }

        // LOS-кэш построек — раз в BUILDING_CACHE_INTERVAL кадров (тяжёлый скан
        // статических полей BuildingPiece.saveList). Нужен и для ESP (цвет), и
        // для aimbot (фильтрация через стену).
        ox_ensureWorldWorker();
        ox_memoryTick((double)ImGui::GetTime());
        ox_stretchTick((double)ImGui::GetTime());
        ox_xrayTick((double)ImGui::GetTime());
        
        // Metadata work above can take longer than a render frame. Do not
        // reuse camera/transform blocks read before that work for this draw.
        vm_cache_new_frame();

        // рисуем ESP из кэша
        if (espdraw || chamsOn || aimm || silentAim || oreEsp || animalEsp || baseEsp || cupboardFinder) {
            std::lock_guard<std::mutex> lock(player_data_mutex);
            ImGui::PushFont(verdana);

            // Камеру пересчитываем КАЖДЫЙ кадр из живого трансформа локального
            // игрока — боксы мгновенно следуют за поворотом камеры (0 задержки).
            CameraView liveCam; liveCam.valid = false;
            // Признак смерти нужен и ниже, в блоке чтения матрицы: тот
            // выполняется ПОСЛЕ этой проверки и иначе тут же вернул бы
            // g_camVPValid=true, прочитав камеру трупа.
            bool localDeadThisFrame = false;
            if (g_localPlayer) {
                liveCam = ox_buildCameraFromPlayer(g_localPlayer, false);
                // Страховка: если углы выбранного PM застыли дольше 3 секунд —
                // это труп, а замены в списке нет. Рисовать по замороженному
                // базису нельзя: боксы «прилипнут» к экрану и поедут за
                // камерой. Лучше не показать ничего, чем показать неверно.
                // Прямой признак смерти вместо косвенного (замороженные углы):
                // PM.respawning выставляется игрой на время смерти/респавна, а
                // HP<=0 закрывает случай, когда флаг ещё не поднялся. В режиме
                // наблюдателя углы MouseLook продолжают крутиться, поэтому
                // детектор по заморозке молчал — и ESP летал после КАЖДОЙ
                // смерти, пока список игроков не пересобирался сам.
                // Только PM.respawning. Проверку «HP<=0» убрал: VITALS_HEALTH
                // (0x88) — это m_MaxHealth, а не текущее здоровье (в логах у
                // всех ровно 100). Текущее HP синкается и отдельным полем в
                // дампе не значится, так что та ветка была мёртвой.
                bool localDead = rpm<uint8_t>(g_localPlayer + ox::PM_RESPAWNING) != 0;
                localDeadThisFrame = localDead;
                if (localDead) {
                    static double s_lastDeadLog = 0.0;
                    double nd = (double)ImGui::GetTime();
                    if (nd - s_lastDeadLog > 3.0) {
                        s_lastDeadLog = nd;
                        OXLOGI("[respawn] локальный игрок мёртв/респавнится — ESP скрыт, ждём нового PM");
                    }
                    liveCam.valid = false;
                    // Гасим и матричный путь тоже. Иначе смерть отключает
                    // только угловую проекцию, а матрица (которая читается из
                    // камеры трупа и уже не обновляется) продолжает рисовать
                    // застывшие боксы — тот самый «ESP остаётся при повороте».
                    g_camVPValid  = false;
                    g_camPosValid = false;
                    cache_needs_update = true;   // форсируем пере-выбор владельца
                }

                // A stationary player is valid. Respawn/owner checks, not elapsed
                // mouse movement, decide whether the camera belongs to this view.
            }

            // ── VP-матрица этого кадра, прямо из нативной камеры ──────────
            // Первый успешный заход ищет смещения по подписи и кэширует их.
            // Если не нашлись — g_camVPValid остаётся false и весь ESP молча
            // работает по старому угловому пути.
            // Матрицу ищем НЕ дожидаясь liveCam.valid: нативная камера живёт
            // раньше, чем собирается наш реконструированный базис. Раньше
            // условие требовало liveCam.valid, из-за чего поиск стартовал
            // только через ~18 секунд после захода — всё это время ESP шёл по
            // угловому пути и «плавал».
            {
                static overlaycore::ProjectionLatch s_projection;
                static uint64_t s_lastPm     = 0;  // чей PM обслуживали в прошлый кадр
                static uint64_t s_lastCam    = 0;  // и какая была нативная камера
#if defined(__x86_64__)
                static uint64_t s_trustedCam = 0, s_trustedPm = 0;
                static Vector3 s_trustedEye{};
                static double s_trustedAt = -1.0;
#endif

                // ── СМЕРТЬ/РЕСПАВН ────────────────────────────────────────
                // После смерти g_localPlayer какое-то время указывает на PM
                // трупа. Из него ox_getNativeCamera достаёт КАМЕРУ ТРУПА, и
                // матрица читается из чужого объекта — ESP «улетает». Старый
                // детектор ловил замороженные углы MouseLook, но в режиме
                // наблюдателя углы продолжают меняться, поэтому он молчал.
                // Здесь ловим сам факт подмены: сменился PM или сменился
                // указатель камеры => немедленно выбрасываем кэш.
                uint64_t nativeCam = 0;
                if (espMatrixW2S && g_localPlayer && !localDeadThisFrame)
                    nativeCam = ox_getNativeCamera(g_localPlayer);
#if defined(__x86_64__)
                // A single failed pointer read must not switch projection modes.
                // The old native camera still has to pass a fresh matrix read.
                if (!nativeCam && g_localPlayer == s_lastPm && !localDeadThisFrame)
                    nativeCam = s_lastCam;
#endif

                // Кэш смещений матриц привязан к КАМЕРЕ, а не к игроку.
                // Раньше сюда входила и смена g_localPlayer — а он скакал
                // 0 -> PM -> 0 по несколько раз в секунду из-за карусели выше,
                // и каждый скачок стирал уже найденные смещения. Поиск
                // стартовал заново и снова стирался, матрица не доживала до
                // применения. Теперь сбрасываем ТОЛЬКО когда сменился сам
                // указатель нативной камеры — это и есть настоящий признак
                // того, что мы смотрим на другой объект.
                bool camChanged = (nativeCam && s_lastCam && nativeCam != s_lastCam);
                if (s_lastPm != g_localPlayer || camChanged) s_projection.Clear();
#if defined(__x86_64__)
                if (s_lastPm != g_localPlayer || camChanged || localDeadThisFrame) {
                    s_trustedCam = s_trustedPm = 0;
                    s_trustedAt = -1.0;
                }
#endif
                if (camChanged) {
                    // Гистерезис ниже НЕ должен переживать смену владельца —
                    // иначе он же и удержит протухшую VP на несколько кадров.
                    g_camVPValid  = false;
                    g_camPosValid = false;
                    g_camViewMatOff = -1;      // переискать на новой камере
                    g_camProjMatOff = -1;
                    g_camNativeCached = 0;
                    cache_needs_update = true;
                    OXLOGI("[respawn] нативная камера сменилась 0x%llx -> 0x%llx, кэш матрицы сброшен",
                           (unsigned long long)s_lastCam,
                           (unsigned long long)nativeCam);
                }
                s_lastPm  = g_localPlayer;
                if (nativeCam) s_lastCam = nativeCam;

                const OxMat4 previousVP = g_camVP, previousView = g_camView;
                const Vector3 previousEye = g_camPosFromMatrix;
                const bool previousEyeValid = g_camPosValid;
                bool got = false;
                if (nativeCam) {
                    if (g_camViewMatOff < 0 || g_camProjMatOff < 0 || nativeCam != g_camNativeCached)
                        ox_findCameraMatrices(nativeCam);
                    got = ox_readViewProjection(nativeCam, &g_camVP);

                    // Матрица принимается, только если глаз по ней находится у тела локального игрока. Это отсекает чужую/устаревшую камеру
                    // (лобби, труп после респавна) и не принимает неподвижную камеру за мёртвую: раньше «матрица не менялась 1 с» считалась смертью
                    // камеры, и в прицеле, где игрок стоит неподвижно, ESP переключался между проекцией по матрице и запасной по углам — отсюда мерцание.
                    const char *why = nullptr;
                    if (got) {
                        Vector3 body =
#if defined(__x86_64__)
                            Vector3::Zero();
#else
                            ox_readPos(g_localPlayer, false);
#endif
#if defined(__x86_64__)
                        // The angular camera root can be a stale transform after
                        // respawn. Validate the matrix against the live local
                        // model origin, which follows the rendered player.
                        Vector3 modelOrigin{};
                        if (ox_pcReadVisualOrigin(g_localPlayer, (double)ImGui::GetTime(), modelOrigin))
                            body = modelOrigin;
#endif
                        if (!g_camPosValid) why = "позиция камеры из матрицы не посчитана";
                        else if (!(body == Vector3::Zero())) {
                            const float dxm = g_camPosFromMatrix.x - body.x, dzm = g_camPosFromMatrix.z - body.z, dym = g_camPosFromMatrix.y - body.y;
                            const bool nearBody = sqrtf(dxm * dxm + dzm * dzm) <= 4.0f && dym >= -1.5f && dym <= 3.5f;
#if defined(__x86_64__)
                            // The model-origin sample sometimes lags behind the
                            // camera on BlueStacks. Once a camera was verified,
                            // continuity of its real eye is stronger evidence
                            // than one transient model/camera mismatch.
                            const double nowEye = (double)ImGui::GetTime();
                            const double dtEye = nowEye - s_trustedAt;
                            const bool continuous = s_trustedCam == nativeCam && s_trustedPm == g_localPlayer &&
                                dtEye >= 0.0 && dtEye <= 0.30 &&
                                Vector3::Distance(g_camPosFromMatrix, s_trustedEye) <= 1.0f + (float)dtEye * 35.f;
                            if (!nearBody && !continuous) why = "глаз по матрице далеко от тела (чужая или устаревшая камера)";
#else
                            if (!nearBody) why = "глаз по матрице далеко от тела (чужая или устаревшая камера)";
#endif
                        }
                        if (why) got = false;
#if defined(__x86_64__)
                        if (got) {
                            s_trustedCam = nativeCam;
                            s_trustedPm = g_localPlayer;
                            s_trustedEye = g_camPosFromMatrix;
                            s_trustedAt = (double)ImGui::GetTime();
                        }
#endif
                    }
                    static const char *s_lastWhy = nullptr; static int s_lastGot = -1;
                    if ((int)got != s_lastGot || (!got && why != s_lastWhy)) {
                        s_lastGot = (int)got; s_lastWhy = why;
                        OXLOGI("[cam] проекция по матрице: %s%s%s", got ? "ВКЛ" : "ВЫКЛ (запасная по углам)", why ? " — " : "", why ? why : "");
                    }
                }
                if (!got) {
                    // Validation may reject a read after it decoded a plausible matrix.
                    // Restore every member, not only the validity bit.
                    g_camVP = previousVP; g_camView = previousView;
                    g_camPosFromMatrix = previousEye; g_camPosValid = previousEyeValid;
                }
                const bool matrixSelected = s_projection.Update(nativeCam ? nativeCam : s_lastCam,
                    (double)ImGui::GetTime(), got, localDeadThisFrame || !g_localPlayer || !espMatrixW2S);
                g_camVPValid = matrixSelected;
                if (!matrixSelected) g_camPosValid = false;

            }

            // Диагностика раз в 2 сек. Обёрнута целиком, а не только вывод:
            // внутри реальные чтения памяти игры (ox_getNativeCamera, обход
            // кэша, повторный ox_readModelAnchors) — макрос OXLOG их бы не
            // убрал, они выполнялись бы впустую каждые две секунды.
#ifdef OX_DEEP_CAMERA_DIAG
            {
                static double s_lastDiag = 0.0;
                double nowD = (double)ImGui::GetTime();
                if (nowD - s_lastDiag > 2.0 && g_localPlayer) {
                    s_lastDiag = nowD;
                    int anchored = 0;
                    for (const auto& pl : cached_players)
                        if (pl.usedModelAnchor) anchored++;
                    // nativeCam=0 сразу показывает, что до объекта камеры мы
                    // вообще не дошли (PM пустой / цепочка рвётся), а не что
                    // поиск шёл и не нашёл. Без этого «viewOff=-1» выглядел
                    // одинаково в обоих случаях.
                    uint64_t dbgCam = g_localPlayer ? ox_getNativeCamera(g_localPlayer) : 0;
                    // Подтверждение, что владелец камеры — действительно НАШ
                    // игрок, а не чужой: читаем флаг прямо у выбранного PM.
                    int dbgFlag = -1;
                    if (g_localPlayer) {
                        uint64_t ni = rpm<uint64_t>(g_localPlayer + ox::NB_NET_IDENTITY);
                        if (ox_isPtr(ni)) dbgFlag = rpm<uint8_t>(ni + ox::NI_IS_LOCAL_PLAYER) ? 1 : 0;
                    }
                    OXLOGI("[w2s] matrix=%d cam=%d dead=%d isLocal=%d | viewOff=%d projOff=%d | pm=0x%llx nativeCam=0x%llx | anchors=%d/%d",
                           (int)g_camVPValid, (int)liveCam.valid, (int)localDeadThisFrame,
                           dbgFlag, g_camViewMatOff, g_camProjMatOff,
                           (unsigned long long)g_localPlayer,
                           (unsigned long long)dbgCam,
                           anchored, (int)cached_players.size());

                    // Если ни одного якоря — разбираем ПЕРВУЮ живую цель
                    // по шагам, чтобы точно знать где обрыв.
                    if (anchored == 0 && !cached_players.empty()) {
                        for (const auto& pl : cached_players) {
                            if (!ox_isPtr(pl.address)) continue;
                            OxModelAnchors dbg = ox_readModelAnchors(pl.address);
                            uint64_t rawRef = rpm<uint64_t>(pl.address + ox::PM_KCC_REFERENCE);
                            OXLOGI("[anchor] pm=0x%llx ref=0x%llx kcc=0x%llx stage=%d "
                                   "headTr=0x%llx cached=0x%llx mat=0x%llx cap=%.2f dy=%.2f dxz=%.2f",
                                   (unsigned long long)pl.address,
                                   (unsigned long long)rawRef,
                                   (unsigned long long)dbg.kccPtr,
                                   dbg.failStage,
                                   (unsigned long long)dbg.headTr,
                                   (unsigned long long)dbg.headCached,
                                   (unsigned long long)dbg.headMatrix,
                                   dbg.capsuleH, dbg.lastDy, dbg.lastDxz);
                            break;
                        }
                    }
                }
            }
#endif

            int positionInterval = g_positionInterval < 1 ? 1 : g_positionInterval;
            bool refreshPositions = (ImGui::GetFrameCount() % positionInterval == 0);

            if (aimm && aimDrawFov) {
                getDrawList()->AddCircle(ImVec2(abs_ScreenX * 0.5f, abs_ScreenY * 0.5f),
                                         aimFovPixels, IM_COL32(255, 255, 255, 140), 96, 1.5f);
            }
            if (silentAim && silentDrawFov) {
                // При открытом меню фоновый список перекрыт панелью по центру — рисуем круг поверх,
                // чтобы FOV было видно прямо во время настройки.
                ImDrawList *fovDl = g_menuOpen ? ImGui::GetForegroundDrawList() : getDrawList();
                fovDl->AddCircle(ImVec2(abs_ScreenX * 0.5f, abs_ScreenY * 0.5f), silentFovPx, IM_COL32(255, 170, 60, 170), 128, 1.5f);
            }


            // Список игроков матча нужен и превью меню (ваш ник); попадания — только для полоски HP.
            if (espdraw && ox_isPtr(g_localPlayer)) ox_rosterTick(0, (double)ImGui::GetTime());
            if (aimm) ox_aimCalibTick((double)ImGui::GetTime());
            ox_statusTick((double)ImGui::GetTime(), cached_players.size());
            if (espweapon || espArmor) { const double tNow = (double)ImGui::GetTime(); ox_registryTick(tNow); ox_itemsTick(tNow); ox_learnTick(tNow); }
            ox_statusUpdate(cached_players, (double)ImGui::GetTime());

            struct AnchorSample { OxModelAnchors value; overlaycore::Lease lease; };
            static std::unordered_map<uint64_t,AnchorSample> anchorHistory;
            static uint64_t anchorOwner = 0;
            if (anchorOwner != g_localPlayer || localDeadThisFrame || !espModelAnchor) {
                anchorHistory.clear(); anchorOwner = g_localPlayer;
            }
            const double anchorNow = (double)ImGui::GetTime();
            ox_chamsBegin(anchorNow,!localDeadThisFrame && (liveCam.valid || g_camVPValid));
            auto chamsProject=[&](oxskel::V3 w,ImVec2 &screen) {
                if (localDeadThisFrame) return false;
                if (g_camVPValid) {
                    if (!ox_w2sMatrix(g_camVP,Vector3(w.x,w.y,w.z),(float)abs_ScreenX,(float)abs_ScreenY,&screen)) return false;
                } else {
                    if (!liveCam.valid) return false;
                    bool visible=false;screen=w2s_angular(Vector3(w.x,w.y,w.z),liveCam,&visible);
                    if (!visible) return false;
                }
                return std::isfinite(screen.x) && std::isfinite(screen.y) &&
                    screen.x>=-96 && screen.x<=abs_ScreenX+96 &&
                    screen.y>=-96 && screen.y<=abs_ScreenY+96;
            };
            int chamsDrawn=0;
            for (auto it = anchorHistory.begin(); it != anchorHistory.end();) {
                if (!it->second.lease.Alive(it->first,anchorNow,.050)) it=anchorHistory.erase(it);
                else ++it;
            }
            for (auto& player : cached_players) {
                if (!espdraw && !chamsOn) break;
                // Same authoritative health gate as aim/silent: max HP is not current HP.
                targetlife::Ticket life;
                const auto state=ox_lifeSnapshot(player.address,life);
                if(state==targetlife::State::Dead || state==targetlife::State::Replaced) {
                    anchorHistory.erase(player.address);continue;
                }
                // W2S считаем из СВЕЖЕЙ камеры и СВЕЖЕЙ мировой позиции.
                bool visB = false, visT = false;
                ImVec2 w2sBottom, w2sTop;
                // Точная подгонка бокса: границы силуэта капсулы игрока на экране.
                bool fitOk = false;
                float fitX0 = 0.f, fitX1 = 0.f;
                Vector3 livePos = player.position;
                // Рисуем ТОЛЬКО при живом источнике проекции: либо свежая
                // VP-матрица, либо валидный угловой базис. Иначе — пропуск
                // (см. ветку ниже): любые старые координаты приклеиваются к
                // экрану и едут вместе с поворотом камеры.
                if (liveCam.valid || g_camVPValid) {
                    // Перечитываем позицию игрока КАЖДЫЙ кадр (дёшево: пара чтений
                    // трансформа), чтобы бокс идеально держался на бегущем игроке
                    // без отставания от тяжёлого скана UpdatePlayerCache.
#if defined(__x86_64__)
                    Vector3 modelOrigin{};
                    const bool modelVisual = ox_pcReadVisualOrigin(player.address, anchorNow, modelOrigin);
                    if (modelVisual) player.position = modelOrigin;
                    // A failed model read keeps the last sampled live position.
                    // Re-reading Motor here would snap the target to spawn.
#else
                    if (refreshPositions && ox_isPtr(player.address)) {
                        Vector3 refreshed = ox_readPos(player.address, false);
                        if (refreshed != Vector3::Zero()) player.position = refreshed;
                    }
#endif
                    livePos = player.position;
                    const Vector3 visualEye = (g_camVPValid && g_camPosValid)
                        ? g_camPosFromMatrix : liveCam.pos;
                    player.distance = Vector3::Distance(visualEye, livePos);
#if defined(__x86_64__)
                    static double nextPcVisualLog = 0.0;
                    if (anchorNow >= nextPcVisualLog) {
                        nextPcVisualLog = anchorNow + 5.0;
                        Vector3 motor{};
                        const bool motorRead = ox_pcReadMotorPos(player.address, motor);
                        OXLOGI("[esp-pc] pm=0x%llx model=%d origin=(%.2f %.2f %.2f) target=(%.2f %.2f %.2f) motor=%d/(%.2f %.2f %.2f) eye=(%.2f %.2f %.2f) matrix=%d angular=%d",
                               (unsigned long long)player.address, (int)modelVisual,
                               livePos.x, livePos.y, livePos.z,
                               player.position.x, player.position.y, player.position.z,
                                (int)motorRead, motor.x, motor.y, motor.z,
                               visualEye.x, visualEye.y, visualEye.z,
                               (int)g_camVPValid, (int)liveCam.valid);
                    }
#endif
                    // Скелет читаем только когда он включён и цель не слишком
                    // далеко — на дистанции кости всё равно сливаются в пиксель,
                    // а чтения стоят трафика к процессу игры.
                    // ── Якоря модели: голова и ноги ИЗ ОТРИСОВЫВАЕМОЙ модели ──
                    // Пока espModelAnchor включён, бокс строится по фактическим
                    // габаритам (KCC.head + Motor.LastInterpolatedPosition), а не
                    // по серверному тику с ручным вертикальным оффсетом. Если
                    // цепочка не прочиталась — молча откатываемся на старый путь.
                    OxModelAnchors anch;
#if !defined(__x86_64__)
                    if (espModelAnchor && player.distance < 400.f) {
                        anch = ox_readModelAnchors(player.address);
                        if (anch.valid) {
                            if (anchorHistory.size() >= 512 && !anchorHistory.count(player.address)) anchorHistory.clear();
                            auto &sample = anchorHistory[player.address];
                            sample.value = anch; sample.lease.Fresh(player.address,anchorNow);
                        } else {
                            const auto it = anchorHistory.find(player.address);
                            if (it != anchorHistory.end() && it->second.lease.Alive(player.address,anchorNow,.050) &&
                                Vector3::Distance(it->second.value.feet,livePos) < 2.0f)
                                anch = it->second.value;
                        }
                    }
#endif

                    Vector3 skelFeet = anch.valid
                                     ? anch.feet
                                     : livePos + Vector3(0.f, ox_boxYOffset(), 0.f);

                    if (((espdraw && skeleton) || (chamsOn && chamsDrawn<32 &&
                          player.distance<=chams::Clamp(chamsRange,20,220,180))) && player.distance < 220.f) {
                        ox_readSkeleton(player.address, skelFeet, player,
                                        anch.valid ? anch.capsuleH : 0.f, anch.valid ? anch.normalH : 0.f, player.distance);
#ifdef OX_ENABLE_LOG
                        // Раз в 3 сек показываем, читается ли скелет вообще —
                        // иначе «не рисуется» неотличимо от «не включён».
                        static double s_lastSkelLog = 0.0;
                        double ns = (double)ImGui::GetTime();
                        if (ns - s_lastSkelLog > 3.0) {
                            s_lastSkelLog = ns;
                            OXLOGI("[skel] pm=0x%llx data=%d head=(%.2f %.2f %.2f) feet=(%.2f %.2f %.2f) d=%.1f",
                                   (unsigned long long)player.address,
                                   (int)player.hasSkeletonData,
                                   player.headPos.x, player.headPos.y, player.headPos.z,
                                   skelFeet.x, skelFeet.y, skelFeet.z,
                                   player.distance);
                        }
#endif
                    } else {
                        player.hasSkeletonData = false;
                    }

                    // Проекция: матричная если VP прочиталась, иначе угловая.
                    // Обе ветки дают одинаковые screen-координаты, разница в
                    // точности — матрица учитывает всё, что движок делает с
                    // камерой (шейк, отдача, нестандартный ADS-projection).
                    auto project = [&](const Vector3& wp, bool* vis) -> ImVec2 {
                        if (g_camVPValid) {
                            ImVec2 sp;
                            if (ox_w2sMatrix(g_camVP, wp, (float)abs_ScreenX,
                                             (float)abs_ScreenY, &sp)) {
                                const float M = 64.f;
                                *vis = (sp.x >= -M && sp.x <= abs_ScreenX + M &&
                                        sp.y >= -M && sp.y <= abs_ScreenY + M);
                                return sp;
                            }
                            *vis = false;
                            return ImVec2(-1.f, -1.f);
                        }
                        // Угловой путь оставлен только как запасной. Если
                        // матрица не поднялась, но базис есть — рисуем по нему.
                        return w2s_angular(wp, liveCam, vis);
                    };

                    if (anch.valid) {
                        // Фактические габариты: низ = ноги, верх = голова плюс
                        // небольшой запас на макушку (head — это точка глаз/шеи).
                        player.usedModelAnchor = true;
                        player.anchorFeet = anch.feet;
                        player.anchorHead = anch.head;
                        player.anchorCrouching = anch.crouching;
                        // Скорость от моторa точнее численной производной по
                        // позициям: она не шумит на низком тикрейте.
                        if (anch.velocity.x != 0.f || anch.velocity.y != 0.f ||
                            anch.velocity.z != 0.f)
                            player.motorVelocity = anch.velocity;
                        // Бокс = физическая капсула игрока: низ — ноги, верх —
                        // feet + CapsuleHeight (без запаса над макушкой). Высота
                        // живая, поэтому в приседе бокс садится вместе с игроком.
                        const float capTop = anch.capsuleH > 0.f ? anch.capsuleH : anch.height;
                        const Vector3 topW = Vector3(anch.feet.x, anch.feet.y + capTop, anch.feet.z);
                        w2sBottom = project(anch.feet, &visB);
                        w2sTop    = project(topW, &visT);
                        // Ширина: кольца радиуса тела на трёх высотах, берём
                        // экстремумы по X. Перспектива учтена, а не «0.5 от роста».
                        const float bodyR = ::clamp<float>((anch.radius > 0.f ? anch.radius : 0.30f) * OX_BOX_FIT, 0.16f, 0.36f);
                        float mn = 1e9f, mx = -1e9f; int okn = 0;
                        for (int lv = 0; lv < 3; ++lv) {
                            const float yy = anch.feet.y + capTop * (lv == 0 ? 0.04f : (lv == 1 ? 0.50f : 0.92f));
                            for (int k = 0; k < 8; ++k) {
                                const float ang = (float)k * 0.78539816f;
                                const Vector3 rp(anch.feet.x + cosf(ang) * bodyR, yy, anch.feet.z + sinf(ang) * bodyR);
                                if (!g_camVPValid) break;   // без матрицы точной подгонки нет
                                ImVec2 sp;
                                if (!ox_w2sMatrix(g_camVP, rp, (float)abs_ScreenX, (float)abs_ScreenY, &sp)) continue;
                                if (sp.x < mn) mn = sp.x;
                                if (sp.x > mx) mx = sp.x;
                                ++okn;
                            }
                        }
                        if (okn >= 12 && mx > mn) { fitOk = true; fitX0 = mn; fitX1 = mx; }
                    } else {
                        player.usedModelAnchor = false;
                        Vector3 anchorPos = livePos + Vector3(0.f, ox_boxYOffset(), 0.f);
                        w2sBottom = project(anchorPos - Vector3(0, ox::BOX_FOOT, 0), &visB);
                        w2sTop    = project(anchorPos + Vector3(0, ox::BOX_HEAD, 0), &visT);
                    }
                } else {
                    // КАМЕРЫ НЕТ — НИЧЕГО НЕ РИСУЕМ.
                    //
                    // Здесь раньше подставлялись ЭКРАННЫЕ координаты прошлого
                    // кадра из кэша. Они посчитаны для старого положения
                    // камеры и статичны: поворачиваешь экран — боксы остаются
                    // висеть там же и «плавают» вместе с поворотом. Ровно тот
                    // симптом, что после смерти ESP не уходит за край экрана.
                    //
                    // Пустой экран честнее приклеенных боксов: они не просто
                    // бесполезны, они показывают врагов не там, где те есть.
                    continue;
                }
                if (!visB && !visT) continue;

                player.losBlocked = false;
                player.losUnknown = false;

                // ================= АВТОРСКИЙ ESP (@xohyw) =================
                // Единый фирменный стиль: угловые скобки-боксы, вертикальный
                // хилбар со скруглением/градиентом, аккуратные подписи с тенью.
                ImDrawList* dl = getDrawList();

                // Геометрия бокса из двух W2S-точек (голова/ноги).
                float projectedHeight = fabsf(w2sTop.y - w2sBottom.y);
                float halfW = projectedHeight * 0.20f;   // запасной путь без якорей: уже прежних 0.25
                float bx0 = (w2sTop.x < w2sBottom.x ? w2sTop.x : w2sBottom.x) - halfW;
                float bx1 = (w2sTop.x > w2sBottom.x ? w2sTop.x : w2sBottom.x) + halfW;
                if (fitOk) { bx0 = fitX0; bx1 = fitX1; }
                float by0 = w2sTop.y;      // верх (голова)
                float by1 = w2sBottom.y;   // низ (ноги)
                if (by1 < by0) { float t = by0; by0 = by1; by1 = t; }
                float bw = bx1 - bx0, bh = by1 - by0;
                float cx = (bx0 + bx1) * 0.5f;

                // --- Цвет бокса по видимости (зелёный=видим, синий=за стеной) ---
                // Если espColorByVisibility включён — цвет переопределяется
                // поверх espboxcolor. Зелёный = цель в прямой видимости,
                // синий = путь от камеры перекрыт BuildingPiece. Аккуратно: HP-бар
                // и т.п. остаются со своими цветами — меняется только рамка/фон.
                ImU32 accent;
                if (espColorByVisibility && player.losBlocked) {
                    // Синий — за стеной
                    accent = IM_COL32(80, 150, 255, 255);
                } else if (espColorByVisibility && !player.losUnknown) {
                    // Зелёный — видим напрямую
                    accent = IM_COL32(60, 230, 110, 255);
                } else {
                    accent = ImGui::ColorConvertFloat4ToU32(
                        ImVec4(espboxcolor[0], espboxcolor[1], espboxcolor[2], 1.0f));
                }
                // Цвет по дистанции (переопределяет всё остальное, если включён):
                // 0 m -> красный, radarRange/2 -> жёлтый, дальше -> синий.
                // Даёт мгновенное «кто рядом» без чтения цифр.
                if (espDistColor && player.distance > 0.f) {
                    float t = ::clamp<float>(player.distance / 120.f, 0.f, 1.f);
                    int r, g, b;
                    if (t < 0.5f) {           // красный -> жёлтый
                        float k = t * 2.f;
                        r = 255; g = (int)(60 + 195 * k); b = 55;
                    } else {                  // жёлтый -> синий
                        float k = (t - 0.5f) * 2.f;
                        r = (int)(255 - 175 * k); g = (int)(255 - 120 * k); b = (int)(55 + 200 * k);
                    }
                    accent = IM_COL32(r, g, b, 255);
                }

                // Компоненты акцентного цвета (для свечения).
                int aR = (int)((accent >> 0) & 0xFF);
                int aG = (int)((accent >> 8) & 0xFF);
                int aB = (int)((accent >> 16) & 0xFF);

                // Хелпер: текст по центру на полупрозрачной «таблетке»-чипе.
                auto chip = [&](float cxp, float topY, ImU32 txtCol, ImU32 barCol, const char* s) {
                    ImVec2 ts = ImGui::CalcTextSize(s);
                    float padx = 6.f, pady = 2.f;
                    ImVec2 a(cxp - ts.x * 0.5f - padx, topY);
                    ImVec2 b(cxp + ts.x * 0.5f + padx, topY + ts.y + pady * 2);
                    dl->AddRectFilled(a, b, IM_COL32(10, 8, 18, 180), 4.f);
                    if (barCol) dl->AddRectFilled(a, ImVec2(a.x + 3, b.y), barCol, 4.f,
                                                  ImDrawFlags_RoundCornersLeft);
                    dl->AddText(ImVec2(cxp - ts.x * 0.5f, topY + pady), txtCol, s);
                    return b.y;
                };

                // Procedural silhouette is attached to fresh WORLD-space bones.
                // Draw before box/skeleton/text; it is independent of ESP's master switch.
                if (chamsOn && state==targetlife::State::Alive && chamsDrawn<32 && player.hasSkeletonData &&
                    player.distance<=chams::Clamp(chamsRange,20,220,180)) {
                    const oxskel::Pose pose=ox_chamsPose(player);
                    if (chams::Draw(dl,pose,chamsProject,ox_chamsSettings(),anchorNow)) {
                        ++chamsDrawn;
                        g_chamsEffects.observe(player.address,rpm<uint64_t>(player.address),
                            ox_netIdOf(player.address),pose,anchorNow);
                    }
                }
                if (!espdraw || (espMaxDistance>0.f && player.distance>espMaxDistance)) continue;
                if (espbox)
                    espstyle::BoxEx(dl, ImVec2(bx0, by0), ImVec2(bx1, by1), IM_COL32(aR, aG, aB, 255), espstroke,
                                    espCornerBox, espCornerLength, espfill, espfillp);

                // ── СКЕЛЕТ ──────────────────────────────────────────────
                if (skeleton && player.hasSkeletonData && (liveCam.valid || g_camVPValid)) {
                    // Тот же проектор, что и у бокса: иначе скелет и рамка
                    // разъезжаются, когда матрица есть, а скелет идёт углами.
                    auto W2S = [&](const Vector3 &w, bool *vis) -> ImVec2 {
                        if (g_camVPValid) {
                            ImVec2 sp;
                            if (ox_w2sMatrix(g_camVP, w, (float)abs_ScreenX,
                                             (float)abs_ScreenY, &sp)) {
                                const float M = 64.f;
                                *vis = (sp.x >= -M && sp.x <= abs_ScreenX + M &&
                                        sp.y >= -M && sp.y <= abs_ScreenY + M);
                                return sp;
                            }
                            *vis = false;
                            return ImVec2(-1.f, -1.f);
                        }
                        return w2s_angular(w, liveCam, vis);
                    };
                    using namespace oxskel;
                    const bool live = player.skelLive;
                    Vector3 J[J_COUNT];
                    J[J_HEAD] = player.headPos;        J[J_NECK] = player.neckPos;
                    J[J_CHEST] = player.spine1Pos;     J[J_PELVIS] = player.spine2Pos;
                    J[J_SPINE] = live ? player.spineMidPos
                                      : Vector3((player.spine1Pos.x + player.spine2Pos.x) * 0.5f,
                                                (player.spine1Pos.y + player.spine2Pos.y) * 0.5f,
                                                (player.spine1Pos.z + player.spine2Pos.z) * 0.5f);
                    J[J_SH_R] = player.rshoulderPos;   J[J_SH_L] = player.lshoulderPos;
                    J[J_EL_R] = player.ruparmPos;      J[J_EL_L] = player.luparmPos;
                    J[J_HAND_R] = player.rlowarmPos;   J[J_HAND_L] = player.llowarmPos;
                    J[J_HIP_R] = player.rhipPos;       J[J_HIP_L] = player.lhipPos;
                    J[J_KNEE_R] = player.rkneePos;     J[J_KNEE_L] = player.lkneePos;
                    J[J_FOOT_R] = player.rfootPos;     J[J_FOOT_L] = player.lfootPos;
                    J[J_TOE_R] = live ? player.rtoePos : player.rfootPos;
                    J[J_TOE_L] = live ? player.ltoePos : player.lfootPos;

                    ImVec2 SP[J_COUNT]; bool SV[J_COUNT];
                    for (int jn = 0; jn < J_COUNT; ++jn) SP[jn] = W2S(J[jn], &SV[jn]);
                    ImVec2 FA[oxskel::kMaxEdges], FB[oxskel::kMaxEdges]; bool FV[oxskel::kMaxEdges];
                    const int nFine = live ? std::min<int>(player.fineN, oxskel::kMaxEdges) : 0;
                    for (int fk = 0; fk < nFine; ++fk) {
                        bool va = false, vb = false;
                        FA[fk] = W2S(player.fineA[fk], &va); FB[fk] = W2S(player.fineB[fk], &vb);
                        FV[fk] = va && vb;
                    }

                    // Голова: центр и радиус из проекции (кольцо держит размер на любой дистанции).
                    const Vector3 hc3 = live ? player.headCenter
                                             : Vector3(player.headPos.x, player.headPos.y + 0.05f, player.headPos.z);
                    const float hR = live ? player.headRadius : 0.105f;
                    bool hv = false, hv2 = false, gv = false;
                    ImVec2 hc = W2S(hc3, &hv);
                    ImVec2 hTop = W2S(Vector3(hc3.x, hc3.y + hR, hc3.z), &hv2);
                    float hrPx = fabsf(hTop.y - hc.y);
                    if (hrPx < 2.f) hrPx = 2.f;
                    if (hrPx > 70.f) hrPx = 70.f;
                    ImVec2 gz(0.f, 0.f);
                    if (live) gz = W2S(Vector3(hc3.x + player.faceDir.x * 0.22f,
                                               hc3.y + player.faceDir.y * 0.22f,
                                               hc3.z + player.faceDir.z * 0.22f), &gv);
                    ImU32 skelCol = IM_COL32((int)(skeleton_color[0]*255.f),
                                             (int)(skeleton_color[1]*255.f),
                                             (int)(skeleton_color[2]*255.f), 255);
                    float fade = 1.15f - player.distance / 200.f;
                    if (fade < 0.35f) fade = 0.35f;
                    if (fade > 1.0f) fade = 1.0f;
                    espstyle::Skeleton(dl, SP, SV, FA, FB, FV, nFine, hc, hrPx, hv && hv2, gz, gv && live, skelCol, skeleton_stroke, fade, bh);
                }

                if (ESP3D && (liveCam.valid || g_camVPValid)) {
                    const float halfModelWidth = 0.30f;
                    const Vector3 offsets[8] = {
                        Vector3(-halfModelWidth, -ox::BOX_FOOT, -halfModelWidth),
                        Vector3( halfModelWidth, -ox::BOX_FOOT, -halfModelWidth),
                        Vector3( halfModelWidth, -ox::BOX_FOOT,  halfModelWidth),
                        Vector3(-halfModelWidth, -ox::BOX_FOOT,  halfModelWidth),
                        Vector3(-halfModelWidth,  ox::BOX_HEAD, -halfModelWidth),
                        Vector3( halfModelWidth,  ox::BOX_HEAD, -halfModelWidth),
                        Vector3( halfModelWidth,  ox::BOX_HEAD,  halfModelWidth),
                        Vector3(-halfModelWidth,  ox::BOX_HEAD,  halfModelWidth),
                    };
                    ImVec2 corners[8];
                    bool cornerVisible[8];
                    // База 3D-бокса — ноги модели, если якоря есть.
                    const Vector3 boxAnchor = player.usedModelAnchor
                        ? player.anchorFeet + Vector3(0.f, ox::BOX_FOOT, 0.f)
                        : livePos + Vector3(0.f, ox_boxYOffset(), 0.f);
                    for (int i = 0; i < 8; ++i) {
                        Vector3 wp = boxAnchor + offsets[i];
                        if (g_camVPValid) {
                            ImVec2 sp;
                            if (ox_w2sMatrix(g_camVP, wp, (float)abs_ScreenX,
                                             (float)abs_ScreenY, &sp)) {
                                const float M = 64.f;
                                cornerVisible[i] = (sp.x >= -M && sp.x <= abs_ScreenX + M &&
                                                    sp.y >= -M && sp.y <= abs_ScreenY + M);
                                corners[i] = sp;
                            } else {
                                cornerVisible[i] = false;
                                corners[i] = ImVec2(-1.f, -1.f);
                            }
                        } else {
                            corners[i] = w2s_angular(wp, liveCam, &cornerVisible[i]);
                        }
                    }

                    const int edges[][2] = {
                        {0, 1}, {1, 2}, {2, 3}, {3, 0},
                        {4, 5}, {5, 6}, {6, 7}, {7, 4},
                        {0, 4}, {1, 5}, {2, 6}, {3, 7},
                    };
                    ImU32 box3dCol = IM_COL32((int)(esp3dcolor[0]*255.f),
                                              (int)(esp3dcolor[1]*255.f),
                                              (int)(esp3dcolor[2]*255.f), 255);
                    const float lineWidth = esp3dcornerstroke;
                    for (const auto& edge : edges) {
                        if (cornerVisible[edge[0]] && cornerVisible[edge[1]])
                            dl->AddLine(corners[edge[0]], corners[edge[1]], box3dCol, lineWidth);
                    }
                }

                // Подписи и HP: общий код стиля (esp_style.h) — им же рисует превью в меню.
                ImFont *tFont = ImGui::GetFont();
                const float tBase = espstyle::TextBase((float)abs_ScreenY);

                // [КЛАН] Ник по центру над боксом; метки состояния (спит / наблюдает / прайм) — выше.
                float tagTop = by0 - 5.f;
                {
                    const std::string cleanName = ox_cleanNick(tFont, player.name);
                    const bool showName = espname && !cleanName.empty();
                    const bool showClan = espclan && !player.clan.empty();
                    if (showName || showClan) {
                        auto rgbU32 = [](const float c[3]) {
                            return IM_COL32((int)(::clamp<float>(c[0], 0.f, 1.f) * 255.f + 0.5f),
                                            (int)(::clamp<float>(c[1], 0.f, 1.f) * 255.f + 0.5f),
                                            (int)(::clamp<float>(c[2], 0.f, 1.f) * 255.f + 0.5f), 255);
                        };
                        tagTop = espstyle::Tag(dl, tFont, cx, by0 - 5.f,
                                               showClan ? player.clan.c_str() : nullptr, rgbU32(espclancolor), tBase * espclansize,
                                               showName ? cleanName.c_str() : nullptr, rgbU32(espnamecolor), tBase * espnamesize);
                    }
                }
                if (espFlags) {
                    const char* ftxt = nullptr; ImU32 fcol = 0;
                    if (player.flagSleeping)        { ftxt = "SLEEP"; fcol = IM_COL32(150, 150, 165, 255); }
                    else if (player.flagSpectating) { ftxt = "SPEC";  fcol = IM_COL32(190, 140, 255, 255); }
                    else if (player.flagPrime)      { ftxt = "PRIME"; fcol = IM_COL32(255, 205, 90, 255); }
                    if (ftxt) {
                        ImVec2 fs = ImGui::CalcTextSize(ftxt);
                        chip(cx, tagTop - fs.y - 6.f, fcol, fcol, ftxt);
                    }
                }

                // Оружие в руке и броня текстом (английские названия): по одной строке на предмет, стек вниз под боксом.
                float infoY = by1 + 4.f;
                if (espweapon && !player.weaponLabel.empty())
                    infoY = chip(cx, infoY, IM_COL32(255, 255, 255, 255), IM_COL32(255, 170, 60, 255), player.weaponLabel.c_str()) + 2.f;
                if (espArmor) {
                    // Цветная метка слева — материал: дерево, кожа, кость, металл, хазмат, военный, косметика.
                    static const ImU32 kRankBar[7] = { IM_COL32(230, 120, 200, 255), IM_COL32(150, 110, 70, 255), IM_COL32(190, 140, 80, 255),
                                                       IM_COL32(225, 225, 205, 255), IM_COL32(120, 170, 255, 255), IM_COL32(240, 220, 60, 255),
                                                       IM_COL32(90, 200, 110, 255) };
                    int shown = 0;
                    for (const gear::Worn &w : player.armorWorn) {
                        if (shown++ >= 5) break;
                        const int rk = w.rank < 0 ? 0 : (w.rank > 6 ? 6 : w.rank);
                        infoY = chip(cx, infoY, IM_COL32(215, 220, 235, 255), kRankBar[rk], w.label.c_str()) + 2.f;
                    }
                }

                // --- Дистанция (чипом под оружием / боксом) ---
                if (espdist && player.distance > 0.f) {
                    char distStr[32];
                    snprintf(distStr, sizeof(distStr), "%.0f m", player.distance);
                    chip(cx, infoY, IM_COL32(170, 205, 235, 255), accent, distStr);
                }

                // --- ESP Lines / Tracers ---
                if (esplines_enabled) {
                    ImU32 lineCol = IM_COL32(
                        (int)(esplines_color[0] * 255),
                        (int)(esplines_color[1] * 255),
                        (int)(esplines_color[2] * 255),
                        220);
                    float sx = (float)abs_ScreenX;
                    float sy = (float)abs_ScreenY;
                    float cx_screen = sx * 0.5f;
                    float cy_screen = sy * 0.5f;
                    float originX, originY;
                    if (esplines_position == 0) {
                        // от нижнего центра экрана
                        originX = cx_screen;
                        originY = sy;
                    } else {
                        // от перекрестия (центр экрана)
                        originX = cx_screen;
                        originY = cy_screen;
                    }
                    // Цель — центр низа бокса (ноги), либо верха, если ноги за кадром.
                    ImVec2 target = visB ? ImVec2(cx, by1) : ImVec2(cx, by0);
                    espstyle::Line(dl, ImVec2(originX, originY), target,
                                   (lineCol & ~IM_COL32_A_MASK) | IM_COL32_A_MASK, esplines_thickness);
                }

                // --- BULLET TRACER (v25): линия куда СМОТРИТ/целится враг ---
                // PlayerManager.lookAngle (0x1A8) — реплицируемый горизонтальный
                // угол взгляда. Рисуем от груди игрока луч ~18 м по этому азимуту:
                // видно кто куда целится / линию потенциального выстрела. Дёшево —
                // один float на игрока, никаких сканов памяти.
                if (esptracer && ox_isPtr(player.address)) {
                    float yawDeg = rpm<float>(player.address + ox::PM_LOOK_ANGLE);
                    if (isfinite(yawDeg)) {
                        const float DEG2RAD = 0.01745329252f;
                        float yr = yawDeg * DEG2RAD;
                        // Unity left-handed y-up: forward = (sin yaw, 0, cos yaw).
                        Vector3 fwd(sinf(yr), 0.f, cosf(yr));
                        // Старт — грудь (середина бокса), длина луча 18 м.
                        Vector3 chest = livePos + Vector3(0.f, ox_boxYOffset() + 1.1f, 0.f);
                        Vector3 tip   = chest + fwd * 18.0f;
                        bool vTip = false, vCh = false;
                        ImVec2 sCh, sTip;
                        if (g_camVPValid) {
                            ox_w2sMatrix(g_camVP, chest, (float)abs_ScreenX, (float)abs_ScreenY, &sCh);
                            vTip = ox_w2sMatrix(g_camVP, tip, (float)abs_ScreenX, (float)abs_ScreenY, &sTip);
                            vCh = true;
                        } else {
                            sCh  = w2s_angular(chest, liveCam, &vCh);
                            sTip = w2s_angular(tip,   liveCam, &vTip);
                        }
                        if (vCh && vTip) {
                            dl->AddLine(sCh, sTip, IM_COL32(255, 210, 60, 210), esplines_thickness);
                            dl->AddCircleFilled(sTip, esplines_thickness + 0.6f, IM_COL32(255,150,40,220), 10);
                        }
                    }
                }
            }

            ox_runAimbot(liveCam, cached_players);
            ox_silentFrame(liveCam, cached_players);
            if (aimm && aimDrawTarget && g_aimHasTarget) {
                const ImVec2 c(abs_ScreenX * 0.5f, abs_ScreenY * 0.5f);
                getDrawList()->AddLine(c, g_aimTargetScreen, IM_COL32(255, 70, 70, 200), 1.2f);
                getDrawList()->AddCircleFilled(g_aimTargetScreen, 3.5f, IM_COL32(255, 70, 70, 230), 12);
            }

            ox_drawOres(getDrawList(), liveCam, cached_players);

            ox_drawAnimals(getDrawList(), liveCam, cached_players);

            ox_drawBase(getDrawList(), liveCam, cached_players);

            if (chamsOn && !localDeadThisFrame)
                g_chamsEffects.draw(getDrawList(),chamsProject,anchorNow);

            // Радар-миникарта 360°: рисуется поверх всего, после боксов.
            if (radarEnabled) ox_drawRadar(getDrawList(), liveCam, cached_players);

            ImGui::PopFont();
        }
        
        const double perfT1 = ox_nowSec();
        drawEnd();
        const double perfT2 = ox_nowSec();
        perf.frame((perfT1 - perfT0) * 1000.0, (perfT2 - perfT1) * 1000.0);
        perf.report(perfT2);
        ox_overlayPace();
        usleep(1000);
    }   
    
    ox_xrayStop();
    AutoHealShutdown();
    avis::snd::Shutdown();
    avis::Shutdown();
    Touch_Close();
    shutdown();
    return 0;
} 

// ============================================================================
//  Меню — src/trial (Trial UI). Прежний слой oxui, ui_v3 и legacy-меню удалены.
// ============================================================================
extern void OxDrawTrialMenu();

void Layout_tick_UI() {
    OxDrawTrialMenu();
}

// Зовётся из drawEnd() (draw.cpp) после ImGui::Render(); статистика кадра больше не нужна.
void ox_uiCaptureFrameStats() {}
