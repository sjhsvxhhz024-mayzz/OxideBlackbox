#pragma once
#include <cmath>

// Overlay-only: no renderer/material writes, no LOS rejection.
namespace cupboardfinder {
struct Point { float x, y, z; };
inline bool Valid(Point p) {
    return std::isfinite(p.x) && std::isfinite(p.y) && std::isfinite(p.z) &&
           std::fabs(p.x) <= 50000.f && std::fabs(p.z) <= 50000.f && std::fabs(p.y) <= 5000.f;
}
inline float Radius(float value) {
    if (!std::isfinite(value)) return 100.f;
    return value < 5.f ? 5.f : value > 800.f ? 800.f : value;
}
inline bool Measure(Point player, Point target, float radius, float &distance, float &height) {
    if (!Valid(player) || !Valid(target)) return false;
    const float x = target.x-player.x, y = target.y-player.y, z = target.z-player.z;
    distance = std::sqrt(x*x+y*y+z*z);
    height = y;
    return distance <= Radius(radius);
}
}