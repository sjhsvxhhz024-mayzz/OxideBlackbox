#pragma once
// Ядро наведения без зависимости от игры: самокалибровка полей углов, сглаживание, выбор цели с удержанием.
// Чистые функции — проверяются на хосте (tools/test_aim_core.cpp).
#include <cmath>
#include <cstdint>
#include <cstring>

namespace aimcore {

constexpr float kRadToDeg = 57.2957795131f;

inline float wrapDeg(float a) {
    a = fmodf(a, 360.0f);
    if (a > 180.0f) a -= 360.0f;
    else if (a < -180.0f) a += 360.0f;
    return a;
}

// Направление камеры из матрицы вид-проекция (столбцы, как в Unity): строка w = (m3, m7, m11) — это forward.
// pitch в соглашении MouseLook: положительный — взгляд вниз.
inline bool anglesFromVP(const float m[16], float *yawDeg, float *pitchDeg) {
    float fx = m[3], fy = m[7], fz = m[11];
    const float len = sqrtf(fx * fx + fy * fy + fz * fz);
    if (!(len > 1e-6f) || !std::isfinite(len)) return false;
    fx /= len; fy /= len; fz /= len;
    *yawDeg = atan2f(fx, fz) * kRadToDeg;
    *pitchDeg = -asinf(fy < -1.f ? -1.f : fy > 1.f ? 1.f : fy) * kRadToDeg;
    return true;
}

// Самокалибровка: ищем в объекте MouseLook float-поля, которые повторяют реальные углы камеры.
// Каждое смещение копит очки за совпадения на РАЗНЫХ углах (случайный float так не совпадёт), поэтому
// после нескольких поворотов камеры победитель однозначен, и оффсеты из заголовка нужны только как подсказка.
struct AngleCalib {
    static constexpr int kWords = 128;          // окно в 4-байтных словах (0x200 байт)
    static constexpr int kNeed = 6;             // совпадений на разных углах
    int scoreP[kWords] = {0}, scoreY[kWords] = {0};
    float lastP = 1e9f, lastY = 1e9f;
    int pitchWord = -1, yawWord = -1;
    int hintPitch = -1, hintYaw = -1;           // известные оффсеты (в словах): выигрывают при равенстве
    bool done = false;

    void setHint(int pitchBytes, int yawBytes) { hintPitch = pitchBytes / 4; hintYaw = yawBytes / 4; }

    // w — слова объекта с начала окна (смещение слова i = i*4), trueYaw/truePitch — из матрицы.
    void feed(const float *w, float trueYaw, float truePitch) {
        if (done) return;
        const bool movedP = fabsf(truePitch - lastP) >= 2.0f && fabsf(truePitch) >= 2.0f;
        const bool movedY = fabsf(wrapDeg(trueYaw - lastY)) >= 2.0f && fabsf(trueYaw) >= 2.0f;
        if (!movedP && !movedY) return;
        for (int i = 0; i < kWords; ++i) {
            const float v = w[i];
            if (!std::isfinite(v)) continue;
            if (movedP && fabsf(v - truePitch) < 2.5f) ++scoreP[i];
            if (movedY && fabsf(wrapDeg(v - trueYaw)) < 2.5f) ++scoreY[i];
        }
        if (movedP) lastP = truePitch;
        if (movedY) lastY = trueYaw;
        pitchWord = pick(scoreP, hintPitch);
        yawWord = pick(scoreY, hintYaw);
        done = pitchWord >= 0 && yawWord >= 0;
    }

    bool ready(int *pitchBytes, int *yawBytes) const {
        if (!done) return false;
        *pitchBytes = pitchWord * 4; *yawBytes = yawWord * 4;
        return true;
    }

private:
    static int pick(const int *sc, int hint) {
        int best = -1, bestS = 0, second = 0;
        for (int i = 0; i < kWords; ++i) {
            if (sc[i] > bestS) { second = bestS; bestS = sc[i]; best = i; }
            else if (sc[i] > second) second = sc[i];
        }
        if (bestS < kNeed) return -1;
        if (hint >= 0 && hint < kWords && sc[hint] >= bestS - 1 && sc[hint] >= kNeed) return hint;
        return second * 2 > bestS ? -1 : best;      // двусмысленность — копим дальше
    }
};

// Приближение к цели: не зависит от частоты кадров, с ограничением скорости и мёртвой зоной.
// smooth — шкала меню (1 = мгновенно, больше — плавнее; 6 соответствует шагу 1/6 за кадр при 60 к/с).
// settleDeg — зона «доводки»: ближе неё шаг плавно растёт до полной ошибки, поэтому прицел садится ровно в точку, а не зависает
// в долях градуса от неё (чистое экспоненциальное сглаживание приближается к цели бесконечно).
inline float approachStep(float errDeg, float dt, float smooth, float maxDegPerSec, float deadzoneDeg, float settleDeg = 0.0f) {
    const float ae = fabsf(errDeg);
    if (ae <= deadzoneDeg) return 0.0f;
    if (dt < 1e-4f) dt = 1e-4f;
    if (dt > 0.1f) dt = 0.1f;
    float alpha = 1.0f;
    if (smooth > 1.0f) alpha = 1.0f - powf(1.0f - 1.0f / smooth, dt * 60.0f);
    if (settleDeg > 0.0f && ae < settleDeg) alpha = 1.0f - (1.0f - alpha) * (ae / settleDeg);
    float step = ae * alpha;
    const float cap = maxDegPerSec * dt;
    if (cap > 0.0f && step > cap) step = cap;
    if (step > ae) step = ae;
    return errDeg < 0 ? -step : step;
}

// Плавный старт после захвата новой цели: скорость растёт от 35% до 100% за rampSec секунд.
inline float rampScale(float sinceAcquireSec, float rampSec) {
    if (rampSec <= 0.0f || sinceAcquireSec >= rampSec) return 1.0f;
    if (sinceAcquireSec < 0.0f) sinceAcquireSec = 0.0f;
    return 0.35f + 0.65f * (sinceAcquireSec / rampSec);
}

// Постоянная скорость: smooth задаёт градусов в секунду как maxDegPerSec/smooth (1 — мгновенно).
inline float constStep(float errDeg, float dt, float smooth, float maxDegPerSec, float deadzoneDeg) {
    const float ae = fabsf(errDeg);
    if (ae <= deadzoneDeg) return 0.0f;
    if (smooth <= 1.0f) return errDeg;
    if (dt < 1e-4f) dt = 1e-4f;
    if (dt > 0.1f) dt = 0.1f;
    float step = (maxDegPerSec > 0.0f ? maxDegPerSec : 900.0f) / smooth * dt;
    if (step > ae) step = ae;
    return errDeg < 0 ? -step : step;
}

// Пружина с опережением: критически демпфированное слежение за углом цели.
// • Старт плавный (ускорение растёт от нуля), перелёта нет, остановка мягкая.
// • Скорость цели оценивается по смещению её угла и подаётся вперёд: на равномерно движущейся цели отставание сходится к нулю.
// • Шаг считается точным решением для критического затухания, поэтому устойчив при любом dt (30–144 к/с дают одну и ту же траекторию).
// smooth — шкала меню (1 = мгновенно; постоянная времени = smooth/60 с, время выхода на 2% ≈ 3.9 таких постоянных).
struct Spring1D {
    float v = 0.0f;          // текущая скорость наводки, град/с
    float tvel = 0.0f;       // оценка угловой скорости цели, град/с
    float prevT = 0.0f;
    bool have = false;

    void reset() { v = 0.0f; tvel = 0.0f; have = false; }

    // target — угол цели, cur — текущий угол прицела (оба в градусах, wrap — угол по кругу, как yaw).
    // Возвращает приращение угла за кадр.
    float update(float target, float cur, float dt, float smooth, float rampScale, float maxSpeed, float deadzone, bool wrap) {
        if (dt < 1e-4f) dt = 1e-4f;
        if (dt > 0.1f) dt = 0.1f;
        const float e0 = wrap ? wrapDeg(target - cur) : target - cur;
        if (smooth <= 1.0f) { v = 0.0f; have = false; return fabsf(e0) <= deadzone ? 0.0f : e0; }

        // скорость цели: фильтр первого порядка по смещению угла между кадрами
        if (have) {
            const float raw = (wrap ? wrapDeg(target - prevT) : target - prevT) / dt;
            // Скачок угла (смена цели, телепорт) — не движение цели: в оценку скорости не берём, иначе пружина получила бы рывок.
            if (fabsf(raw) < 450.f) tvel += (raw - tvel) * (1.0f - expf(-dt / 0.045f));
            else tvel *= 0.5f;
        }
        prevT = target; have = true;

        if (fabsf(e0) <= deadzone && fabsf(v - tvel) < 2.0f) { v = tvel; return tvel * dt; }

        float tau = smooth / 60.0f;
        float omega = 1.49f / tau;
        omega *= (rampScale < 0.05f ? 0.05f : rampScale);
        const float u0 = v - tvel;                         // скорость относительно цели
        const float B = -u0 + omega * e0;                  // e(t) = (e0 + B t) e^{-ωt}
        const float ex = expf(-omega * dt);
        const float e1 = (e0 + B * dt) * ex;
        const float de1 = (B - omega * (e0 + B * dt)) * ex;   // de/dt в конце шага
        float dx = tvel * dt - (e1 - e0);
        float vNew = tvel - de1;
        if (maxSpeed > 0.0f) {
            const float cap = maxSpeed * dt;
            if (dx > cap) { dx = cap; vNew = maxSpeed; } else if (dx < -cap) { dx = -cap; vNew = -maxSpeed; }
        }
        v = vNew;
        return dx;
    }
};

// Удержание цели: текущая остаётся, пока не появится заметно более близкая к прицелу.
// fovSqLocked < 0 — цель не в кандидатах. margin — во сколько раз (по квадрату расстояния) новая должна быть ближе.
inline bool keepLocked(float fovSqLocked, float fovSqBest, float margin) {
    return fovSqLocked >= 0.0f && fovSqLocked <= fovSqBest * margin + 4.0f;
}

} // namespace aimcore
