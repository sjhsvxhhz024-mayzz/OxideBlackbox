#pragma once
#include <cmath>
#include <cstdint>
#include <cstring>
#include <algorithm>
#include <string>

// Near-plane camera cut, not spherical world hiding. Only standard OpenGL
// perspective projections are supported. No Unity method calls/injection.
namespace xray {
inline float Distance(float d) {
    return std::isfinite(d) ? std::max(.05f, std::min(60.f, d)) : 5.f;
}
inline bool Planes(const float *p, float &n, float &f) {
    for (int i=0;i<16;++i) if (!std::isfinite(p[i])) return false;
    if (p[0]<=0.f || p[5]<=0.f || std::fabs(p[11]+1.f)>.001f ||
        std::fabs(p[15])>.0001f || p[10]>=-1.f || p[14]>=0.f) return false;
    const int zero[]={1,2,3,4,6,7,12,13};
    for (int i:zero) if (std::fabs(p[i])>.0001f) return false;
    n=p[14]/(p[10]-1.f); f=p[14]/(p[10]+1.f);
    return std::isfinite(n) && std::isfinite(f) && n>.0005f &&
           n<=100.f && f>n && f<=200000.f;
}
class Engine {
public:
    std::string status="X-ray: off";
    template<class Mem>
    void stop(Mem &mem) {
        if (restore(mem)) { reset(); status="X-ray: off"; }
        else { failed_=true; status="X-ray: restore failed"; }
    }
    template<class Mem>
    void tick(Mem &mem, uint64_t owner, uint64_t cam, int proj, int view,
              bool enabled, float requested, double now) {
        if (!enabled) { stop(mem); return; }
        if (cam!=cam_ || owner!=owner_) {
            if (!restore(mem)) { status="X-ray: restore failed"; return; }
            reset(); cam_=cam; owner_=owner;
        }
        if (failed_) return; // Retry only after off/on or a new camera.
        if (!cam || !owner || proj<0) { status="X-ray: waiting for camera"; return; }
        float p[16], n=0.f, f=0.f;
        if (!mem.rd(cam+(uint64_t)proj,p,sizeof(p)) || !Planes(p,n,f)) {
            fail(mem,"X-ray: unsupported projection"); return;
        }
        const float target=std::min(Distance(requested),f*.8f);
        if (target<.05f) { fail(mem,"X-ray: invalid clip range"); return; }
        if (off_<0) {
            // Exclude all known matrices, require ONE adjacent near/far pair.
            uint8_t data[0x600]; bool pages[6]={};
            for (int i=0;i<6;++i) pages[i]=mem.rd(cam+i*0x100,data+i*0x100,0x100);
            int count=0;
            auto overlaps=[](int o,int m) { return m>=0 && o<m+64 && o+8>m; };
            for (int o=0x20;o+8<=0x600;o+=4) {
                if (!pages[o/0x100] || !pages[(o+7)/0x100] ||
                    overlaps(o,proj) || overlaps(o,view) || overlaps(o,proj+64)) continue;
                float a,b; std::memcpy(&a,data+o,4);std::memcpy(&b,data+o+4,4);
                if (!std::isfinite(a) || !std::isfinite(b) ||
                    std::fabs(a-n)>n*.02f+.0001f ||
                    std::fabs(b-f)>f*.02f+.01f) continue;
                ++count;off_=o;original_=a;
            }
            if (count!=1) {
                off_=-1;failed_=true;
                status=count ? "X-ray: ambiguous camera fields" : "X-ray: clip field not found";
                return;
            }
            uint64_t linked=0;
            if (!mem.rd(owner,&ownerClass_,8) || !mem.rd(cam,&nativeHead_,8) ||
                !mem.rd(owner+0x10,&linked,8) || linked!=cam) {
                fail(mem,"X-ray: camera identity unavailable"); return;
            }
        }
        if (!identity(mem)) { fail(mem,"X-ray: camera identity changed"); return; }
        if (verifying_) {
            if (std::fabs(n-last_)<=std::max(.003f,last_*.015f)) {
                if (++good_>=3 && now-start_>=.06) {
                    verifying_=false;status="X-ray: active";
                }
            } else good_=0;
            if (verifying_ && now-start_>.8) {
                fail(mem,"X-ray: projection did not respond"); return;
            }
            if (verifying_) return;
        }
        if (touched_ && std::fabs(last_-target)<=.001f && now<next_) return;
        float current=0.f, farField=0.f;
        if (!mem.rd(cam+off_,&current,4) || !mem.rd(cam+off_+4,&farField,4) ||
            !std::isfinite(current) || !std::isfinite(farField) ||
            std::fabs(farField-f)>f*.02f+.01f) {
            fail(mem,"X-ray: camera fields changed"); return;
        }
        if (touched_ && !same(current,last_) && !same(current,original_)) {
            fail(mem,"X-ray: camera fields changed"); return;
        }
        // No need to overwrite an already-correct field.
        if (same(current,target) && std::fabs(n-target)<=std::max(.003f,target*.015f)) {
            status=touched_ ? "X-ray: active" : "X-ray: distance unchanged";
            next_=now+.2;return;
        }
        const bool ok=mem.wr(cam+off_,&target,4);
        // Track a possibly partial write too, so failed writes can be rolled back.
        touched_=true;last_=target;
        float after=0.f;
        if (!ok || !mem.rd(cam+off_,&after,4) || !same(after,target)) {
            fail(mem,"X-ray: write failed");return;
        }
        verifying_=true;good_=0;start_=now;next_=now+.2;
        status="X-ray: verifying camera";
    }
private:
    uint64_t owner_=0,cam_=0,ownerClass_=0,nativeHead_=0;
    int off_=-1,good_=0;
    float original_=0.f,last_=0.f;
    bool touched_=false,failed_=false,verifying_=false;
    double start_=0.,next_=0.;
    static bool same(float a,float b) { return std::isfinite(a) && std::fabs(a-b)<=std::max(.00001f,std::fabs(b)*.00001f); }
    void reset() {
        owner_=cam_=ownerClass_=nativeHead_=0;off_=-1;good_=0;
        original_=last_=0.f;touched_=failed_=verifying_=false;start_=next_=0.;
    }
    template<class Mem> bool identity(Mem &mem) {
        uint64_t c=0,n=0,h=0;
        return owner_ && cam_ && mem.rd(owner_,&c,8) && c==ownerClass_ &&
            mem.rd(owner_+0x10,&n,8) && n==cam_ &&
            mem.rd(cam_,&h,8) && h==nativeHead_;
    }
    template<class Mem> bool restore(Mem &mem) {
        if (!touched_) return true;
        // Never write the saved value into the current/new camera by accident.
        if (!identity(mem)) { touched_=false;return true; }
        float v=0.f;
        if (!mem.rd(cam_+off_,&v,4)) return false;
        // Another game writer owns a changed value; do not overwrite it.
        if (!same(v,last_)) { touched_=false;return true; }
        if (!mem.wr(cam_+off_,&original_,4) || !mem.rd(cam_+off_,&v,4) ||
            !same(v,original_)) return false;
        touched_=false;return true;
    }
    template<class Mem> void fail(Mem &mem,const char *why) {
        const bool restored=restore(mem);failed_=true;verifying_=false;
        status=restored ? why : "X-ray: restore failed";
    }
};
}