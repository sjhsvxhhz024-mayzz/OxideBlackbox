#pragma once
// Чистая логика Silent aim без обращений к памяти игры: распознавание новой/своей пули, выбор зоны и упреждение.
// Вынесена отдельно, чтобы проверяться на хосте (tools/test_silent_core.cpp).
#include <math.h>

namespace silentcore {

struct V3 { float x = 0.f, y = 0.f, z = 0.f; };
inline V3 operator+(V3 a, V3 b) { return { a.x + b.x, a.y + b.y, a.z + b.z }; }
inline V3 operator-(V3 a, V3 b) { return { a.x - b.x, a.y - b.y, a.z - b.z }; }
inline V3 operator*(V3 a, float k) { return { a.x * k, a.y * k, a.z * k }; }
inline float dot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline float len(V3 a) { return sqrtf(dot(a, a)); }

// Новая ли это пуля. Объекты пуль берутся из пула и переиспользуются, а ShotId/OwnerId в этой версии игры всегда 0, поэтому признаков три:
// указателя не было в прошлом опросе; пуля «телепортировалась» (ушла назад против своей скорости или дальше, чем могла пролететь за dt);
// скорость заметно изменилась (старая пуля умерла и её объект в тот же такт занят новой — позиция у ствола та же, но направление другое).
// Физика игры шагает пули с периодом ~20 мс, поэтому допускаем скачок на dt + 60 мс полёта. Гравитация и сопротивление воздуха меняют
// скорость за шаг на доли процента, поэтому порог смены скорости с запасом.
inline bool isNewBullet(bool havePrev, V3 prev, V3 prevVel, V3 pos, V3 vel, float dt) {
    if (!havePrev) return true;
    const V3 mv = pos - prev;
    const float l = len(mv), sp = len(vel);
    if (dot(mv, vel) < 0.f && l > 0.5f) return true;
    if (l > sp * (dt + 0.06f) + 2.0f) return true;
    return len(vel - prevVel) > 8.f + sp * 0.02f;
}

// Своя ли пуля: она родилась у камеры, впереди неё, на линии взгляда, и летит вперёд. fwd — единичный вектор взгляда.
// Допуск «вдоль» растёт со скоростью: пуля могла успеть пролететь один шаг физики до того, как её увидели.
inline bool isOwnBullet(V3 cam, V3 fwd, V3 pos, V3 vel) {
    const float sp = len(vel);
    if (sp < 1.f) return false;
    const V3 dc = pos - cam;
    const float along = dot(dc, fwd);
    const V3 pr = dc - fwd * along;
    const float perp = len(pr);
    const float fcos = dot(vel, fwd) / sp;
    return along > -1.5f && along < sp * 0.06f + 4.f && perp < 1.2f + (along > 0.f ? along : 0.f) * 0.12f && fcos > 0.8f;
}

// Доля роста капсулы, куда целимся. zone: 0 голова, 1 шея, остальное — центр груди. Грудь — самая большая зона попадания: у головы запас
// по хитбоксу в несколько сантиметров, и любая неточность позиции цели (серверный тик, присед, интерполяция) даёт промах мимо тела.
inline float zoneFrac(int zone) {
    switch (zone) {
        case 0: return 0.93f;
        case 1: return 0.86f;
        default: return 0.68f;
    }
}

// Точка перехвата. from — позиция пули, target — точка цели сейчас, vel — скорость цели, speed — скорость пули, gravity — g пули,
// leadAdj — поправка времени полёта (с), tof — результат. Итерации сходятся за 2–3 шага для скоростей пули порядка сотен м/с.
inline V3 leadPoint(V3 from, V3 target, V3 vel, float speed, float gravity, float leadAdj, bool predict, float *tof) {
    if (speed < 1.f) { if (tof) *tof = 0.f; return target; }
    const float vl = len(vel);
    if (vl > 12.f) vel = vel * (12.f / vl);                                  // шум производной не должен уводить прицел
    float t = len(target - from) / speed;
    V3 aim = target;
    if (predict) {
        for (int i = 0; i < 4; ++i) {
            const float nt = len((target + vel * t) - from) / speed;
            if (fabsf(nt - t) < 0.0005f) { t = nt; break; }
            t = nt;
        }
    }
    float tt = t + leadAdj;
    if (tt < 0.f) tt = 0.f;
    if (tt > 1.5f) tt = 1.5f;
    if (predict) aim = target + vel * tt;
    const float g = fabsf(gravity);
    if (g > 0.01f && g < 50.f) {
        const float drop = 0.5f * g * tt * tt;                               // пуля падает: целимся выше на эту величину
        if (drop < 20.f) aim.y += drop;
    }
    if (tof) *tof = tt;
    return aim;
}

// Ближайшая пара точек луча (o + s*d, s >= 0, d единичный) и отрезка [a, b]. Возвращает расстояние, в cp — точка на отрезке, в rp — на луче.
inline float rayClosest(V3 o, V3 d, V3 a, V3 b, V3 *cp, V3 *rp) {
    const V3 v = b - a, w = o - a;
    const float uu = dot(d, d), uv = dot(d, v), vv = dot(v, v), uw = dot(d, w), vw = dot(v, w);
    const float den = uu * vv - uv * uv;
    float s = 0.f, t = 0.f;
    if (den > 1e-8f) { s = (uv * vw - vv * uw) / den; t = (uu * vw - uv * uw) / den; }
    else { s = 0.f; t = vv > 1e-8f ? vw / vv : 0.f; }
    if (s < 0.f) { s = 0.f; t = vv > 1e-8f ? vw / vv : 0.f; }
    if (t < 0.f) { t = 0.f; s = -uw / uu; if (s < 0.f) s = 0.f; }
    else if (t > 1.f) { t = 1.f; s = dot(b - o, d) / uu; if (s < 0.f) s = 0.f; }
    const V3 pr = o + d * s, pt = a + v * t;
    if (cp) *cp = pt;
    if (rp) *rp = pr;
    return len(pr - pt);
}
inline float rayToSegment(V3 o, V3 d, V3 a, V3 b) { return rayClosest(o, d, a, b, nullptr, nullptr); }

// Зона цели как отрезок оси тела: доли роста от ног и радиус попадания, м. bodyRad — радиус капсулы игрока (для тела).
inline void zoneSpan(int zone, float bodyRad, float *lo, float *hi, float *rad) {
    switch (zone) {
        case 0:  *lo = 0.90f; *hi = 0.97f; *rad = 0.13f; break;      // голова
        case 1:  *lo = 0.80f; *hi = 0.90f; *rad = 0.12f; break;      // шея
        case 2:  *lo = 0.35f; *hi = 0.80f; *rad = bodyRad; break;    // грудь и живот
        default: *lo = 0.12f; *hi = 0.97f; *rad = bodyRad; break;    // ближайшая точка всего тела
    }
}

// План выстрела: исходный луч пули против зоны цели с упреждением и падением. Если луч уже проходит через зону — пулю не трогаем (noop):
// сервер получит ровно тот путь, который клиент заявил при выстреле. Иначе целимся не в центр, а в ближайшую к исходному лучу точку зоны,
// внутри на 45% радиуса от края: так отклонение от заявленного пути минимально (сервер сверяет попадание с этим путём в пределах допуска,
// размер которого в клиенте неизвестен). corr — на сколько метров у цели сдвигается путь пули; tooFar — больше разрешённого maxCorr.
struct Plan { V3 aim; float tof = 0.f, zoneMiss = 0.f, bodyMiss = 0.f, corr = 0.f; bool noop = false, tooFar = false; };
inline Plan planShot(V3 from, V3 dir0, float speed, float gravity, V3 feet, V3 head, V3 vel, float bodyRad, int zone, bool predict, float leadAdj, float maxCorr) {
    Plan p;
    float lo, hi, rad; zoneSpan(zone, bodyRad, &lo, &hi, &rad);
    const V3 ax = head - feet;
    auto P = [&](float f) { return feet + ax * f; };
    float tof = 0.f;
    const V3 mid = P((lo + hi) * 0.5f);
    const V3 aimC = leadPoint(from, mid, vel, speed, gravity, leadAdj, predict, &tof);
    const V3 shift = aimC - mid;                                   // упреждение и падение, одинаковые для всех точек тела
    V3 cp, rp;
    p.zoneMiss = rayClosest(from, dir0, P(lo) + shift, P(hi) + shift, &cp, &rp);
    p.bodyMiss = rayClosest(from, dir0, P(0.12f) + shift, P(0.97f) + shift, nullptr, nullptr);
    p.tof = tof;
    if (p.zoneMiss <= rad * 0.85f) { p.noop = true; p.aim = aimC; return p; }
    const V3 tr = rp - cp; const float l = len(tr);
    const V3 u = l > 1e-4f ? tr * (1.f / l) : V3{ 0.f, 0.f, 0.f };
    p.aim = cp + u * (rad * 0.55f);
    p.corr = p.zoneMiss - rad * 0.55f; if (p.corr < 0.f) p.corr = 0.f;
    p.tooFar = p.corr > maxCorr;
    return p;
}

// Arrow/spear model: dv/dt = -drag*v + (0,-g,0).
// Exact integration for this model avoids accumulated Euler error. Metadata
// exposes gravity/airDrag, NOT native physics: this assumption needs in-game
// verification and must not be presented as a recovered engine equation.
inline bool finite(V3 v) { return isfinite(v.x)&&isfinite(v.y)&&isfinite(v.z); }
struct Travel { double s=0, q=0; }; // position = v0*s + acceleration*q
inline Travel travel(double t,double drag) {
    Travel r;
    const double x=drag*t;
    if(fabs(x)<1e-3) {
        // expm1 cancellation is avoided as drag approaches zero.
        r.s=t*(1-x*.5+x*x/6-x*x*x/24+x*x*x*x/120);
        r.q=t*t*(.5-x/6+x*x/24-x*x*x/120+x*x*x*x/720);
    } else {r.s=-expm1(-x)/drag;r.q=(t-r.s)/drag;}
    return r;
}
inline V3 flightPosition(V3 from,V3 launch,float g,float drag,float t) {
    const Travel f=travel(t,drag);
    return from+launch*(float)f.s+V3{0,-g*(float)f.q,0};
}
struct Flight {float t=0,y=0;bool reached=false;};
inline Flight flyTo(float v0,float pitch,float g,float drag,float range) {
    Flight r;
    if(!isfinite(v0)||!isfinite(pitch)||!isfinite(g)||!isfinite(drag)||
       !isfinite(range)||v0<=0||g<0||drag<0||range<0) return r;
    const double vx=v0*cos(pitch);if(vx<=0) return r;
    double t=range/vx;
    if(drag>1e-6) {const double x=range*drag/vx;if(x>=1) return r;t=-log1p(-x)/drag;}
    if(!isfinite(t)||t>8) return r;
    const Travel f=travel(t,drag);r.t=(float)t;
    r.y=(float)(v0*sin(pitch)*f.s-g*f.q);r.reached=true;return r;
}
inline float heightAt(float v0,float pitch,float g,float drag,float range,float *tOut) {
    const Flight f=flyTo(v0,pitch,g,drag,range);if(tOut)*tOut=f.t;
    return f.reached ? f.y : -1e9f;
}
struct ArrowAim {
    V3 aim, direction;
    float tof=0,pitch=0,miss=0;
    bool ok=false;
};
// Solve the earliest positive interception time, rather than fixed-point
// iterations on angle/time. This also handles targets above/below/near the
// muzzle and moving targets whose time of flight exceeds the old 3 s cap.
// leadAdj shifts TARGET prediction only; it does not add fictitious flight
// time/gravity. No solution -> no forced look-direction write.
inline ArrowAim solveArrow(V3 from,V3 target,V3 vel,float v0,float g,float drag,bool predict,float leadAdj) {
    ArrowAim r;r.aim=target;
    if(!finite(from)||!finite(target)||!finite(vel)||!isfinite(v0)||
       !isfinite(g)||!isfinite(drag)||!isfinite(leadAdj)||v0<=1||v0>3000||
       g<0||g>=60||drag<0||drag>=3||len(target-from)<.02f) return r;
    if(!predict) vel={};
    const float speed=len(vel);if(speed>12) vel=vel*(12/speed);
    leadAdj=fmaxf(-.5f,fminf(.5f,leadAdj));
    auto destination=[&](double t) {return target+vel*(float)fmax(0,t+leadAdj);};
    auto required=[&](double t) {
        const Travel f=travel(t,drag);const V3 d=destination(t)-from;
        return V3{(float)(d.x/f.s),(float)((d.y+g*f.q)/f.s),(float)(d.z/f.s)};
    };
    auto residual=[&](double t) {const V3 v=required(t);return (double)dot(v,v)-(double)v0*v0;};
    double lo=.00001, hi=lo, prev=residual(lo);bool bracket=false;
    // Adaptive bounded search catches the low/fast arc, without thousands of
    // 4 ms simulation steps for each angle. 8 s is an explicit model horizon.
    for(int i=0;i<320 && hi<8;i++) {
        const double next=fmin(8,hi+fmax(.00025,hi*.04));
        const double value=residual(next);
        if(!isfinite(value)) return r;
        if(prev>=0 && value<=0) {lo=hi;hi=next;bracket=true;break;}
        hi=next;prev=value;
    }
    if(!bracket) return r;
    for(int i=0;i<36;i++) {const double mid=(lo+hi)*.5;if(residual(mid)>0)lo=mid;else hi=mid;}
    const double t=(lo+hi)*.5;const V3 launch=required(t);const float l=len(launch);
    if(!finite(launch)||l<=0) return r;
    r.direction=launch*(1/l);r.tof=(float)t;
    const V3 endpoint=flightPosition(from,r.direction*v0,g,drag,r.tof);
    r.miss=len(endpoint-destination(t));
    if(!isfinite(r.miss)||r.miss>.025f) return r;
    r.pitch=atan2f(r.direction.y,sqrtf(r.direction.x*r.direction.x+r.direction.z*r.direction.z));
    r.aim=from+r.direction*fmaxf(1,len(destination(t)-from));r.ok=true;return r;
}
// Velocity sampled at movement updates, not divided by render frame time.
// A reversal resets the filter; no long window carrying the old direction.
struct MotionTrack {
    V3 last,vel;double changed=-1;
    V3 update(V3 p,double now) {
        if(!finite(p)||!isfinite(now)) {changed=-1;vel={};return vel;}
        if(changed<0||now<changed) {last=p;changed=now;vel={};return vel;}
        const V3 d=p-last;const float dist=len(d);const double dt=now-changed;
        if(dist>1e-4f) {
            // At 90/120 FPS a render interval is shorter than 15 ms. Keep
            // the previous sample until enough time has accumulated; moving
            // it forward here made every measured target velocity zero.
            if(dt<.015) return vel;
            if(dt<.25 && dist<3) {
                V3 raw=d*(float)(1/dt);const float sp=len(raw);
                if(sp>12) raw=raw*(12/sp);
                const bool reversal=dot(raw,vel)<0;
                const float blend=(float)(1-exp(-dt/.07));
                vel=reversal ? raw : vel+(raw-vel)*blend;
            } else vel={};
            last=p;changed=now;
        } else if(dt>.12) vel={};
        return vel;
    }
};

} // namespace silentcore
