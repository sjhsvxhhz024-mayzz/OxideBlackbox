#pragma once
#include <array>
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace heal {
constexpr int kSlots=6;
struct Point {float x=-1,y=-1; bool Ready()const{return std::isfinite(x)&&std::isfinite(y)&&x>=0&&x<=1&&y>=0&&y<=1;}};
struct Config {
 bool enabled=false; int medicine=5,attempts=1;
 float threshold=35,delay=2500,cooldown=5000;
 int width=0,height=0,rotation=-1;
 std::array<Point,kSlots+1> points{};
 void Normalize(){
  medicine=std::max(0,std::min(5,medicine));attempts=std::max(1,std::min(3,attempts));
  auto clamp=[](float x,float a,float b,float d){return std::isfinite(x)?std::max(a,std::min(b,x)):d;};
  threshold=clamp(threshold,5,90,35);delay=clamp(delay,500,10000,2500);cooldown=clamp(cooldown,2000,30000,5000);
  for(auto&p:points)if(!p.Ready())p=Point{};
 }
};
struct Sample {
 double now=0; uint64_t owner=0; bool valid=false,allowed=false;
 float percent=-1; int selected=-1,width=0,height=0,rotation=-1;
 std::array<uint64_t,kSlots> items{}; bool medical=false;
};
enum class Action {None,Select,Use,Return};
enum class Phase {Idle,Selecting,WaitSelected,Using,WaitEffect,Returning,Cooldown,Blocked};
struct Request {Action action=Action::None;int point=-1;};
// One low-health episode has a finite dose budget. No HP acknowledgement means
// no unlimited retry. Unknown/dead/other owner/manual input always aborts.
class Controller {
 Phase phase_=Phase::Idle; double deadline_=0,last_=-1;uint64_t owner_=0,original_=0,med_=0;
 int slot_=-1,doses_=0;bool issued_=false;
 void Set(Phase p,double deadline){phase_=p;deadline_=deadline;issued_=false;}
public:
 Phase State()const{return phase_;} int Doses()const{return doses_;}
 void Reset(){*this=Controller{};}
 Request Tick(const Config&c,const Sample&s,int result=-1){
  if(!c.enabled){Reset();return {};}
  if(!std::isfinite(s.now)||s.now<last_){Reset();return {};}
  last_=s.now;
  if(owner_&&owner_!=s.owner){Reset();last_=s.now;}
  owner_=s.owner;
  const bool good=s.valid&&s.owner&&std::isfinite(s.percent)&&s.percent>0&&s.percent<=100&&s.selected>=0&&s.selected<kSlots;
  if(!good||!s.allowed){if(phase_!=Phase::Idle&&phase_!=Phase::Blocked)Set(Phase::Blocked,0);return {};}
  if(s.percent>=std::min(100.f,c.threshold+5)){
   doses_=0;if(phase_==Phase::Blocked||phase_==Phase::Cooldown)Set(Phase::Idle,0);
  }
  if(c.medicine<0||c.medicine>=kSlots||c.attempts<1||c.attempts>3||!std::isfinite(c.threshold)||!std::isfinite(c.delay)||!std::isfinite(c.cooldown)){Set(Phase::Blocked,0);return {};}
  if(c.width!=s.width||c.height!=s.height||c.rotation!=s.rotation){Set(Phase::Blocked,0);return {};}
  if(phase_==Phase::Idle){
   if(s.percent>c.threshold)return {};
   if(!s.medical||!s.items[c.medicine]||!c.points[c.medicine].Ready()||!c.points[kSlots].Ready()||!c.points[s.selected].Ready()||!s.items[s.selected]){Set(Phase::Blocked,0);return {};}
   slot_=s.selected;original_=s.items[slot_];med_=s.items[c.medicine];
   if(slot_==c.medicine)Set(Phase::Using,s.now+3);else Set(Phase::Selecting,s.now+3);
  }
  if(phase_==Phase::Blocked)return {};
  if(phase_==Phase::Cooldown){if(s.now<deadline_)return {};if(doses_>=c.attempts){Set(Phase::Blocked,0);return {};}Set(Phase::Idle,0);return {};}
  if(phase_!=Phase::WaitEffect&&s.now>deadline_){Set(Phase::Blocked,0);return {};}
  if(phase_==Phase::Selecting||phase_==Phase::Using||phase_==Phase::Returning){
   if(!issued_){
    if(phase_==Phase::Using&&(s.selected!=c.medicine||s.items[c.medicine]!=med_||!s.medical)){Set(Phase::Blocked,0);return {};}
    if(phase_==Phase::Returning&&(s.items[slot_]!=original_||s.selected!=c.medicine)){Set(Phase::Blocked,0);return {};}
    issued_=true;
    return {phase_==Phase::Selecting?Action::Select:phase_==Phase::Using?Action::Use:Action::Return,phase_==Phase::Selecting?c.medicine:phase_==Phase::Using?kSlots:slot_};
   }
   if(result<0)return {};
   if(!result){Set(Phase::Blocked,0);return {};}
   if(phase_==Phase::Selecting)Set(Phase::WaitSelected,s.now+2);
   else if(phase_==Phase::Using){++doses_;Set(Phase::WaitEffect,s.now+c.delay/1000.);}
   else Set(Phase::Cooldown,s.now+c.cooldown/1000.);
  }
  if(phase_==Phase::WaitSelected){
   if(s.items[c.medicine]!=med_){Set(Phase::Blocked,0);return {};}
   if(s.selected==c.medicine)Set(Phase::Using,s.now+3);
   else if(s.selected!=slot_){Set(Phase::Blocked,0);return {};}
  }
  if(phase_==Phase::WaitEffect){
   if(s.selected!=c.medicine){Set(Phase::Blocked,0);return {};}
   if(s.now+0.001>=deadline_){
    if(slot_!=c.medicine&&s.items[slot_]==original_)Set(Phase::Returning,s.now+3);
    else Set(Phase::Cooldown,s.now+c.cooldown/1000.);
   }
  }
  return {};
 }
};
}
