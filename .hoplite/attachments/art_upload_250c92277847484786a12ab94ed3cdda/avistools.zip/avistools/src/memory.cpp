#include "memory.h"
#include "utils.h"
#include <string>
#include <fcntl.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#include <algorithm>
#include <atomic>
#include <cerrno>
#include <ctime>
#include <mutex>
#include <string.h>
#include "oxide_arch.h"
#include "oxlog.h"

// Номера системных вызовов зависят от архитектуры (arm64 270/271, x86_64 310/311). Заголовки NDK их определяют сами; если нет — берутся
// из oxide_arch.h, а совпадение с заголовками проверяется при компиляции.
#ifndef SYS_process_vm_readv
#define SYS_process_vm_readv (oxarch::kCur.sysProcessVmReadv)
#define SYS_process_vm_writev (oxarch::kCur.sysProcessVmWritev)
#else
static_assert(SYS_process_vm_readv == oxarch::kCur.sysProcessVmReadv && SYS_process_vm_writev == oxarch::kCur.sysProcessVmWritev,
              "номера process_vm_readv/writev в oxide_arch.h не совпадают с заголовками NDK");
#endif

// глобальные переменные из main.cpp
extern int game_pid;
extern uint64_t il2cpp_base;
extern int abs_ScreenX, abs_ScreenY;

pid_t get_pid(const char *pkgname) {
    pid_t ret(0);
    for(;ret<99999;ret++) {
        char buffer[255]={0};
        sprintf(buffer,"/proc/%d/cmdline",ret);
        int fd = open(buffer,O_RDONLY);
        char pkg[255]={0};
        read(fd,pkg,255);
        close(fd);
        if(!strcmp(pkg,pkgname))break;
    }
    if(ret == 99999)return 0;
    return ret;
}

int open_proccess_memory(const pid_t pid) {
    char name[255]={0};
    sprintf(name,"/proc/%d/mem",pid);
    return open(name,O_RDWR);
}

namespace {
std::atomic<uint64_t> g_reads{0}, g_hits{0}, g_syscalls{0}, g_writes{0}, g_bytes{0};
std::atomic<uint64_t> g_cacheFallbacks{0};
std::atomic<uint64_t> g_procReadAttempts{0}, g_procReadSuccess{0};

#if defined(__x86_64__)
std::mutex g_procMemMutex;
int g_procMemFd = -1, g_procMemPid = -1;
time_t g_procMemRetryAt = 0;

bool readProcMem(int pid, void *address, void *buffer, size_t size) {
    std::lock_guard<std::mutex> lock(g_procMemMutex);
    if (g_procMemPid != pid) {
        if (g_procMemFd >= 0) close(g_procMemFd);
        g_procMemFd = -1;
        g_procMemPid = pid;
        g_procMemRetryAt = 0;
    }
    if (g_procMemFd < 0) {
        const time_t now=time(nullptr);
        if (now<g_procMemRetryAt) return false;
        char path[64];
        snprintf(path, sizeof(path), "/proc/%d/mem", pid);
        g_procMemFd = open(path, O_RDONLY | O_CLOEXEC);
        if (g_procMemFd < 0) g_procMemRetryAt=now+1;
    }
    if (g_procMemFd < 0) return false;
    const ssize_t readBytes = pread(g_procMemFd, buffer, size,
                                   static_cast<off_t>(reinterpret_cast<uintptr_t>(address)));
    return readBytes == static_cast<ssize_t>(size);
}
#endif

constexpr int kBlock = 256, kSlots = 512, kMaxSmall = 64;
struct Slot { uint64_t tag; uint32_t epoch; bool ok; uint8_t data[kBlock]; };
struct ThreadCache {
    bool on = false;
    uint32_t epoch = 1;
    int pid = -1;
    Slot *slots = nullptr;
    uint64_t reads = 0, hits = 0, syscalls = 0;
};
thread_local ThreadCache t_cache;

ThreadCache &cache() { return t_cache; }
}  // namespace

void vm_cache_enable(bool on) {
    ThreadCache &c = cache();
    if (on && !c.slots) {
        c.slots = new Slot[kSlots];
        for (int i = 0; i < kSlots; ++i) { c.slots[i].tag = ~0ULL; c.slots[i].epoch = 0; c.slots[i].ok = false; }
    }
    // Enable only after the backing array exists. A corrupted or incomplete
    // cache state must never turn an otherwise valid remote read into SIGSEGV.
    c.on = on && c.slots != nullptr;
}
void vm_cache_new_frame() {
    ThreadCache &c = cache();
    if (++c.epoch == 0) c.epoch = 1;
}
VmStats vm_stats() {
    const ThreadCache &c = cache();
    return { g_reads.load(std::memory_order_relaxed), g_hits.load(std::memory_order_relaxed), g_syscalls.load(std::memory_order_relaxed),
             g_writes.load(std::memory_order_relaxed), g_bytes.load(std::memory_order_relaxed), c.reads, c.hits, c.syscalls };
}
uint64_t vm_cache_fallbacks() { return g_cacheFallbacks.load(std::memory_order_relaxed); }
VmReadFallbackStats vm_read_fallback_stats() {
    return {g_procReadAttempts.load(std::memory_order_relaxed),
            g_procReadSuccess.load(std::memory_order_relaxed)};
}

bool pvm(void *address, void *buffer, size_t size, bool iswrite) {
    struct iovec local[1];
    struct iovec remote[1];
    local[0].iov_base = buffer;
    local[0].iov_len = size;
    remote[0].iov_base = address;
    remote[0].iov_len = size;
    if (game_pid < 0) {
        return false;
    }
    const int pid = game_pid;
    long syscallNumber = iswrite ? SYS_process_vm_writev : SYS_process_vm_readv;
    ssize_t bytes = syscall(syscallNumber, pid, local, 1, remote, 1, 0);
    g_syscalls.fetch_add(1, std::memory_order_relaxed);
    ++t_cache.syscalls;
    if (iswrite) g_writes.fetch_add(1, std::memory_order_relaxed);
    else if (bytes > 0) g_bytes.fetch_add((uint64_t)bytes, std::memory_order_relaxed);
    if (bytes == (ssize_t)size) return true;
#if defined(__x86_64__)
    if (!iswrite && pid > 0 && address && buffer && size) {
        g_procReadAttempts.fetch_add(1, std::memory_order_relaxed);
        if (readProcMem(pid, address, buffer, size)) {
            g_procReadSuccess.fetch_add(1, std::memory_order_relaxed);
            g_bytes.fetch_add((uint64_t)size, std::memory_order_relaxed);
            return true;
        }
    }
#endif
    return false;
}

bool vm_readv(unsigned long address, void *buffer, size_t size) {
    g_reads.fetch_add(1, std::memory_order_relaxed);
    ThreadCache &c = cache();
    ++c.reads;
    if (c.on && !c.slots) {
        c.on = false;
        g_cacheFallbacks.fetch_add(1, std::memory_order_relaxed);
    }
    if (c.on && size > 0 && size <= (size_t)kMaxSmall && game_pid >= 0) {
        if (c.pid != game_pid) {                                        // игра перезапущена: прежние блоки чужие
            c.pid = game_pid;
            if (++c.epoch == 0) c.epoch = 1;
        }
        const uint64_t base = (uint64_t)address & ~(uint64_t)(kBlock - 1);
        const uint64_t off = (uint64_t)address - base;
        if (off + size <= (uint64_t)kBlock) {
            Slot &s = c.slots[(base / kBlock) & (kSlots - 1)];
            if (s.epoch == c.epoch && s.tag == base) {
                ++c.hits; g_hits.fetch_add(1, std::memory_order_relaxed);
                // A whole 256-byte block may be unreadable at a mapping edge
                // even though the requested field itself is readable.
                if (!s.ok) return pvm(reinterpret_cast<void *>(address), buffer, size, false);
                memcpy(buffer, s.data + off, size);
                return true;
            }
            const bool ok = pvm(reinterpret_cast<void *>(base), s.data, (size_t)kBlock, false);
            s.tag = base; s.epoch = c.epoch; s.ok = ok;
            if (!ok) return pvm(reinterpret_cast<void *>(address), buffer, size, false);
            memcpy(buffer, s.data + off, size);
            return true;
        }
    }
    return pvm(reinterpret_cast<void *>(address), buffer, size, false);
}

bool vm_readv_multi(const uint64_t *addrs, int n, size_t each, void *out) {
    if (n <= 0 || n > 256 || each == 0 || game_pid < 0) return false;
    struct iovec local[256], remote[256];
    for (int i = 0; i < n; ++i) {
        local[i].iov_base = (uint8_t *)out + (size_t)i * each;
        local[i].iov_len = each;
        remote[i].iov_base = (void *)addrs[i];
        remote[i].iov_len = each;
    }
    const ssize_t bytes = syscall(SYS_process_vm_readv, game_pid, local, (unsigned long)n, remote, (unsigned long)n, 0UL);
    g_reads.fetch_add(1, std::memory_order_relaxed); g_syscalls.fetch_add(1, std::memory_order_relaxed); ++t_cache.syscalls;
    if (bytes > 0) g_bytes.fetch_add((uint64_t)bytes, std::memory_order_relaxed);
    if (bytes == (ssize_t)((size_t)n * each)) return true;
#if defined(__x86_64__)
    // BlueStacks may reject a scatter read even when individual fields are
    // readable. Retry each range through the checked single-range path.
    for (int i = 0; i < n; ++i)
        if (!pvm((void*)addrs[i], (uint8_t*)out + (size_t)i * each, each, false))
            return false;
    return true;
#else
    return false;
#endif
}

bool vm_writev(unsigned long address, const void *buffer, size_t size) {
    bool ok = pvm(reinterpret_cast<void *>(address), const_cast<void *>(buffer), size, true);
#if defined(__x86_64__)
    if (!ok && game_pid > 0 && address >= 0x1000 && buffer && size) {
        const int vmErrno = errno;
        // Do not retain a thread_local descriptor here. Its destructor runs
        // through pthread_exit when a short-lived worker finishes; that path
        // faults on the tested x86_64 emulator. A single failed write pays for
        // one open/close pair and has no thread-exit cleanup state.
        char path[64];
        snprintf(path, sizeof(path), "/proc/%d/mem", game_pid);
        const int memFd = open(path, O_RDWR | O_CLOEXEC);
        int memErrno = 0;
        if (memFd >= 0) {
            const ssize_t written = pwrite(memFd, buffer, size, (off_t)address);
            ok = written == (ssize_t)size;
            if (!ok) memErrno = errno;
            close(memFd);
        } else {
            memErrno = errno;
        }
        static std::atomic<unsigned> reported{0};
        const unsigned bit = ok ? 1u : 2u;
        if ((reported.fetch_or(bit, std::memory_order_relaxed) & bit) == 0)
            oxlog::diagf("[pc-write] process_vm_writev failed errno=%d; /proc/pid/mem %s errno=%d",
                         vmErrno, ok ? "worked" : "failed", memErrno);
    }
#endif
    if (t_cache.on && ++t_cache.epoch == 0) t_cache.epoch = 1;           // запись видна следующему чтению этого же потока
    return ok;
}

bool mem_addr_virtophy(unsigned long vaddr) {
    static int pageSize = getpagesize();
    static char filename[32];
    static int fd = -1;
    if (fd < 0) {
        snprintf(filename, sizeof(filename), "/proc/%d/pagemap", game_pid);
        fd = open(filename, O_RDONLY);
        if (fd < 0) {
            return false;
        }
    }
    unsigned long v_pageIndex = vaddr / pageSize;
    unsigned long pfn_item_offset = v_pageIndex * sizeof(uint64_t);
    uint64_t item;
    if (lseek(fd, pfn_item_offset, SEEK_SET) < 0) {
        return false;
    }
    if (read(fd, &item, sizeof(uint64_t)) != sizeof(uint64_t)) {
        return false;
    }
    if (!(item & (1ULL << 63))) {
        return false;
    }
    return true;
}

// реализации игровых функций
std::string String::Get() {
    int safeLength = std::max(0, std::min(length, (int)(sizeof(first_char) / sizeof(char16_t))));
    // упрощенная конвертация, можно использовать твою utf16le_to_utf8
    std::string result;
    for (int i = 0; i < safeLength; i++) {
        char16_t c = ((char16_t*)first_char)[i];
        if (c < 0x80) {
            result += (char)c;
        }
    }
    return result;
}

