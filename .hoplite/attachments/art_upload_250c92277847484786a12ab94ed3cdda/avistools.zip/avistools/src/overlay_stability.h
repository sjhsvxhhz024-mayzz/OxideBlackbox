#pragma once
#include <cmath>
#include <cstdint>

namespace overlaycore {
// Leases use elapsed time, never a number of frames. A different owner or a
// backwards/invalid clock cannot inherit a previous object's world sample.
struct Lease {
    uint64_t owner = 0;
    double stamp = -1;
    void Clear() { owner = 0; stamp = -1; }
    void Fresh(uint64_t id, double now) {
        if (!id || !std::isfinite(now)) { Clear(); return; }
        owner = id; stamp = now;
    }
    bool Alive(uint64_t id, double now, double ttl) const {
        return id && owner == id && std::isfinite(now) && stamp >= 0 &&
               now >= stamp && now - stamp <= ttl;
    }
};
// Only an explicit local-player flag can acquire a camera owner. Unknown
// reads retain identity but never certify a new owner or a new world sample.
enum class OwnerStatus { Unknown, Verified, Rejected };
inline uint64_t SelectOwner(uint64_t current, uint64_t confirmed, OwnerStatus status) {
    if (confirmed) return confirmed;
    return status == OwnerStatus::Rejected ? 0 : current;
}
// A complete roster can retire a disappeared owner, but a partial read cannot.
// Short list rebuilds get 250 ms; a newly verified owner can replace it sooner.
struct OwnerRosterGuard {
    uint64_t owner=0;
    double missingSince=-1.;
    bool Missing(uint64_t id,bool complete,bool present,double now) {
        if (id!=owner) {owner=id;missingSince=-1.;}
        if (!id || !complete || present || !std::isfinite(now)) {missingSince=-1.;return false;}
        if (missingSince<0. || now<missingSince) missingSince=now;
        return now-missingSince>=.250;
    }
};
// A fresh validated matrix recovers immediately. The old 50 ms quarantine
// after a dropout forced needless matrix/angular oscillations. The 35 ms
// maximum lease is unchanged: no 1-2 second frozen screen-coordinate cache.
struct ProjectionLatch {
    uint64_t owner = 0;
    Lease fresh;
    bool acquired = false;
    void Clear() { *this = ProjectionLatch{}; }
    bool Update(uint64_t id, double now, bool good, bool dead) {
        if (dead || !id || !std::isfinite(now)) { Clear(); return false; }
        if (id != owner) { Clear(); owner = id; }
        if (good) { fresh.Fresh(id,now); acquired=true; return true; }
        if (acquired && fresh.Alive(id,now,.035)) return true;
        acquired=false; return false;
    }
};
// Column-major P*V. Never publish a partial/NaN matrix.
inline bool Compose(const float *view, const float *projection, float *out) {
    float candidate[16];
    for (int c=0;c<4;++c) for (int r=0;r<4;++r) {
        float sum=0;
        for (int k=0;k<4;++k) sum += projection[k*4+r] * view[c*4+k];
        if (!std::isfinite(sum)) return false;
        candidate[c*4+r]=sum;
    }
    for (int i=0;i<16;++i) out[i]=candidate[i];
    return true;
}
} // namespace overlaycore
