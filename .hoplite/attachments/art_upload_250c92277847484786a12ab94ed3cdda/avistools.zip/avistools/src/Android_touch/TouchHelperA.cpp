#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <cmath>
#include <cerrno>
#include <cstring>
#include <linux/input.h>
#include <linux/uinput.h>
#include <atomic>
#include <mutex>
#include <poll.h>
#include <algorithm>
#include "touch_input_queue.h"
#include "Android_touch/TouchHelperA.h"

#include "imgui.h"

#define maxE 16
#define maxF 10
#define UNGRAB 0
#define GRAB 1


bool other_touch; //其他触摸


static uint32_t orientation = 0;
static float screenHeight = 0, screenWidth = 0;

//TODO 触摸穿透

struct touchObj {
    bool isDown = false;
    int x = 0;
    int y = 0;
    int id = 0;
};

struct targ {
    int fdNum;
    float S2TX;
    float S2TY;
    bool pointer = false;
    bool relative = false;
    bool mouseButton = false;
    bool rotateToLandscape = false;
    int minX = 0, maxX = 0, minY = 0, maxY = 0;
};

static struct {
    input_event downEvent[2]{{{}, EV_KEY, BTN_TOUCH,       1},
                             {{}, EV_KEY, BTN_TOOL_FINGER, 1}};
    input_event event[512]{0};
} input;

static targ targF[maxE];

static touchObj Finger[maxE][maxF];

static int fdNum = 0, origfd[maxE], nowfd;

static float scale_x, scale_y;

static std::atomic<bool> Touch_initialized{false};
static std::recursive_mutex stateMutex;
static pthread_t touchThreads[maxE];
static bool threadStarted[maxE]{};
static touchinput::Queue mouseEvents;
static int mouseDevice = -1, primaryFinger[maxE]{};
static int touchMaxX=0,touchMaxY=0;
static float viewWidth=0,viewHeight=0;
static std::atomic<unsigned long long> rawEvents{0}, queuedEvents{0}, pumpedEvents{0};
static std::atomic<unsigned long long> mtPositionEvents{0}, mtTrackingEvents{0};
static std::atomic<unsigned long long> touchButtonEvents{0}, mouseButtonEvents{0};
static std::atomic<unsigned long long> absPointerEvents{0}, relPointerEvents{0};
static std::atomic<int> lastType{0}, lastCode{0}, lastValue{0};
static std::atomic<float> lastX{-1}, lastY{-1};
static std::atomic<bool> lastDown{false};
static int touchSources=0,pointerSources=0;
void Touch_Close();
void UpdateScreenData(int,int,uint32_t);
static void PushMouse(float x, float y, bool down) {
    mouseEvents.Push({x,y,down});
    ++queuedEvents;
    if (x >= 0 && y >= 0) { lastX=x; lastY=y; }
    lastDown=down;
}
void Touch_PumpInput() {
    for (const auto &e : mouseEvents.Take()) {
        ++pumpedEvents;
        ImGuiIO &io=ImGui::GetIO();
        if (e.x >= 0 && e.y >= 0) io.AddMousePosEvent(e.x,e.y);
        io.AddMouseButtonEvent(0,e.down);
    }
}
TouchStats Touch_GetStats() {
    return {fdNum,touchSources,pointerSources,rawEvents.load(),queuedEvents.load(),pumpedEvents.load(),
            mtPositionEvents.load(),mtTrackingEvents.load(),touchButtonEvents.load(),
            mouseButtonEvents.load(),absPointerEvents.load(),relPointerEvents.load(),
            lastType.load(),lastCode.load(),lastValue.load(),lastX.load(),lastY.load(),lastDown.load()};
}

static bool Touch_readOnly = false;

static bool checkDeviceIsTouch(int fd);
static bool checkDeviceIsPointer(int fd, targ &target);
static void genRandomString(char *string, int length) {
    int flag, i;
    srand((unsigned) time(NULL) + length);
    for (i = 0; i < length - 1; i++) {
        flag = rand() % 3;
        switch (flag) {
            case 0:
                string[i] = 'A' + rand() % 26;
                break;
            case 1:
                string[i] = 'a' + rand() % 26;
                break;
            case 2:
                string[i] = '0' + rand() % 10;
                break;
            default:
                string[i] = 'x';
                break;
        }
    }
    string[length - 1] = '\0';
}


static void Upload() {
    std::lock_guard<std::recursive_mutex> guard(stateMutex);
    static bool isFirstDown = true;
    int tmpCnt = 0, tmpCnt2 = 0, i, j;
    for (i = 0; i < fdNum; i++) {
        for (j = 0; j < maxF; j++) {
            if (Finger[i][j].isDown) {
                if (tmpCnt2++ > 10) {
                    goto finish;
                }
                input.event[tmpCnt].type = EV_ABS;
                input.event[tmpCnt].code = ABS_X;
                input.event[tmpCnt].value = Finger[i][j].x;
                tmpCnt++;

                input.event[tmpCnt].type = EV_ABS;
                input.event[tmpCnt].code = ABS_Y;
                input.event[tmpCnt].value = Finger[i][j].y;
                tmpCnt++;

                input.event[tmpCnt].type = EV_ABS;
                input.event[tmpCnt].code = ABS_MT_POSITION_X;
                input.event[tmpCnt].value = Finger[i][j].x;
                tmpCnt++;

                input.event[tmpCnt].type = EV_ABS;
                input.event[tmpCnt].code = ABS_MT_POSITION_Y;
                input.event[tmpCnt].value = Finger[i][j].y;
                tmpCnt++;

                input.event[tmpCnt].type = EV_ABS;
                input.event[tmpCnt].code = ABS_MT_TRACKING_ID;
                input.event[tmpCnt].value = Finger[i][j].id;
                tmpCnt++;

                input.event[tmpCnt].type = EV_SYN;
                input.event[tmpCnt].code = SYN_MT_REPORT;
                input.event[tmpCnt].value = 0;
                tmpCnt++;
            }
        }
    }
    finish:
    bool is = false;
    if (tmpCnt == 0) {
        input.event[tmpCnt].type = EV_SYN;
        input.event[tmpCnt].code = SYN_MT_REPORT;
        input.event[tmpCnt].value = 0;
        tmpCnt++;
        if (!isFirstDown) {
            isFirstDown = true;
            input.event[tmpCnt].type = EV_KEY;
            input.event[tmpCnt].code = BTN_TOUCH;
            input.event[tmpCnt].value = 0;
            tmpCnt++;
            input.event[tmpCnt].type = EV_KEY;
            input.event[tmpCnt].code = BTN_TOOL_FINGER;
            input.event[tmpCnt].value = 0;
            tmpCnt++;
        }
    } else {
        is = true;
    }
    input.event[tmpCnt].type = EV_SYN;
    input.event[tmpCnt].code = SYN_REPORT;
    input.event[tmpCnt].value = 0;
    tmpCnt++;

    if (is && isFirstDown) {
        isFirstDown = false;
        write(nowfd, &input, sizeof(struct input_event) * (tmpCnt + 2));
    } else {
        write(nowfd, input.event, sizeof(struct input_event) * tmpCnt);
    }


}

static void *TypeA(void *arg) {
    targ tmp = *(targ *) arg;
    int i = tmp.fdNum;
    float S2TX = tmp.S2TX;
    float S2TY = tmp.S2TY;
    int latest = 0;
    bool hasTrackingId = false;
    bool hasTouchKey = false;
    bool frameHasPosition = false;
    input_event inputEvent[64]{0};

    while (Touch_initialized.load(std::memory_order_acquire)) {
        pollfd ready{origfd[i],POLLIN,0};
        int polled=poll(&ready,1,50);
        if (polled<=0) continue;
        if (ready.revents & (POLLHUP|POLLERR|POLLNVAL)) break;
        auto readSize = (int32_t) read(origfd[i], inputEvent, sizeof(inputEvent));
        if (readSize <= 0 || (readSize % sizeof(input_event)) != 0) {
            continue;
        }
        std::lock_guard<std::recursive_mutex> guard(stateMutex);
        size_t count = size_t(readSize) / sizeof(input_event);
        rawEvents += count;
        for (size_t j = 0; j < count; j++) {
            input_event &ie = inputEvent[j];
            if (ie.type != EV_SYN) { lastType=ie.type; lastCode=ie.code; lastValue=ie.value; }
            if (ie.type == EV_ABS) {
                if (ie.code == ABS_MT_SLOT) {
                    latest = touchinput::ValidSlot(ie.value) ? ie.value : -1;
                    continue;
                }
                if (!touchinput::ValidSlot(latest)) continue;
                if (ie.code == ABS_MT_TRACKING_ID) {
                    ++mtTrackingEvents;
                    hasTrackingId = true;
                    if (ie.value == -1) {
                        Finger[i][latest].isDown = false;
                    } else {
                        Finger[i][latest].id = (i * 2 + 1) * maxF + latest;
                        Finger[i][latest].isDown = true;
                    }
                    continue;
                }
                if (ie.code == ABS_MT_POSITION_X) {
                    ++mtPositionEvents; frameHasPosition = true;
                    Finger[i][latest].id = (i * 2 + 1) * maxF + latest;
                    Finger[i][latest].x = (int) ((ie.value - tmp.minX) * S2TX);
                    continue;
                }
                if (ie.code == ABS_MT_POSITION_Y) {
                    ++mtPositionEvents; frameHasPosition = true;
                    Finger[i][latest].id = (i * 2 + 1) * maxF + latest;
                    Finger[i][latest].y = (int) ((ie.value - tmp.minY) * S2TY);
                    continue;
                }
            }
            if (ie.type == EV_KEY && (ie.code == BTN_TOUCH || ie.code == BTN_TOOL_FINGER)) {
                ++touchButtonEvents;
                hasTouchKey = true;
                if (!hasTrackingId) {
                    Finger[i][0].isDown = ie.value != 0;
                    Finger[i][0].id = (i * 2 + 1) * maxF;
                }
            }
            if (ie.type == EV_SYN && ie.code == SYN_REPORT) {
                // Legacy type-A MT devices report coordinates per frame but
                // have neither a tracking ID nor BTN_TOUCH. An empty frame
                // then marks the release.
                if (!hasTrackingId && !hasTouchKey) {
                    Finger[i][0].isDown = frameHasPosition;
                    Finger[i][0].id = (i * 2 + 1) * maxF;
                }
                frameHasPosition = false;
                int &chosen = primaryFinger[i];
                if (touchinput::ValidSlot(chosen) && !Finger[i][chosen].isDown) {
                    chosen=-2; // Never transfer an active drag to another finger.
                    if (mouseDevice==i) {PushMouse(-1,-1,false);mouseDevice=-1;}
                }
                if (chosen==-2) {
                    bool any=false;for(int f=0;f<maxF;++f)any=any||Finger[i][f].isDown;
                    if(!any)chosen=-1;
                }
                if (chosen==-1) for(int f=0;f<maxF;++f) if(Finger[i][f].isDown){chosen=f;break;}
                if (chosen>=0 && mouseDevice<0) mouseDevice=i;
                if (chosen>=0 && mouseDevice==i && scale_x>0 && scale_y>0) {
                    float x = Finger[i][chosen].x, y = Finger[i][chosen].y;
                    float xt = x / scale_x;
                    float yt = y / scale_y;
                    /* 
                    LOGD("orien %d orig x%.1f y%.1f\n", orientation, x, y);
                    LOGD("xt %.1f yt %.1f\n", xt, yt);
                    */
                    #if defined(__x86_64__)
                    // Some emulators report portrait touch axes for a
                    // landscape overlay. Use the selected device's axes,
                    // not the first touchscreen discovered in /dev/input.
                    const float nx = x / touchMaxX;
                    const float ny = y / touchMaxY;
                    if (tmp.rotateToLandscape) {
                        x = viewWidth * (1.0f - ny);
                        y = viewHeight * nx;
                    } else {
                        x = viewWidth * nx;
                        y = viewHeight * ny;
                    }
                    #else
                    if (other_touch) {
                        switch (orientation) {
                            case 1:
                                x = xt;
                                y = yt;
                                break;
                            case 2:
                                y = yt;
                                x = screenHeight - xt;
                                break;
                            case 3:
                                x = screenHeight - xt;
                                y = screenWidth - yt;
                                break;
                            default:
                                y = xt;
                                x = screenHeight - yt;
                                break;
                        }
                    } else {
                        switch (orientation) {
                            case 1:
                                x = yt;
                                y = screenHeight - xt;
                                break;
                            case 2:
                                x = screenHeight - xt;
                                y = screenWidth - yt;
                                break;
                            case 3:
                                y = xt;
                                x = screenWidth - yt;
                                break;
                            default:
                                x = xt;
                                y = yt;
                                break;
                        }
                    }
                    #endif
                    PushMouse(std::max(0.0f,std::min(x,viewWidth-1.0f)),
                              std::max(0.0f,std::min(y,viewHeight-1.0f)),true);
                } else if (mouseDevice==i && chosen<0) {
                    PushMouse(-1,-1,false); mouseDevice=-1;
                }
                if (!Touch_readOnly) {
                    Upload();
                }
                continue;
            }
        }
    }
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex);
        if (mouseDevice==i) {PushMouse(-1,-1,false);mouseDevice=-1;}
    }
    return nullptr;
}

// Android emulators often expose the host mouse as EV_KEY/EV_ABS or EV_REL,
// without ABS_MT_POSITION_* events. Feed those events into the same ImGui queue.
static void *TypePointer(void *arg) {
    const targ target = *(targ *)arg;
    const int i = target.fdNum;
    float x = viewWidth * 0.5f, y = viewHeight * 0.5f;
    float axisX = 0.5f, axisY = 0.5f;
    bool down = false, changed = false;
    input_event events[64]{};
    while (Touch_initialized.load(std::memory_order_acquire)) {
        pollfd ready{origfd[i], POLLIN, 0};
        const int polled = poll(&ready, 1, 50);
        if (polled <= 0) continue;
        if (ready.revents & (POLLHUP | POLLERR | POLLNVAL)) break;
        const ssize_t bytes = read(origfd[i], events, sizeof(events));
        if (bytes <= 0 || bytes % sizeof(input_event) != 0) continue;
        rawEvents += (size_t)bytes / sizeof(input_event);
        std::lock_guard<std::recursive_mutex> guard(stateMutex);
        for (size_t j = 0; j < (size_t)bytes / sizeof(input_event); ++j) {
            const input_event &e = events[j];
            if (e.type != EV_SYN) { lastType=e.type; lastCode=e.code; lastValue=e.value; }
            if (e.type == EV_ABS && target.maxX > target.minX && target.maxY > target.minY) {
                if (e.code == ABS_X) {
                    ++absPointerEvents;
                    axisX = float(e.value - target.minX) / float(target.maxX - target.minX);
                    changed = true;
                } else if (e.code == ABS_Y) {
                    ++absPointerEvents;
                    axisY = float(e.value - target.minY) / float(target.maxY - target.minY);
                    changed = true;
                }
            } else if (e.type == EV_REL && target.relative) {
                if (e.code == REL_X) { ++relPointerEvents; x += e.value; changed = true; }
                else if (e.code == REL_Y) { ++relPointerEvents; y += e.value; changed = true; }
            } else if (e.type == EV_KEY && (e.code == BTN_LEFT || e.code == BTN_TOUCH)) {
                if (e.code == BTN_LEFT) ++mouseButtonEvents; else ++touchButtonEvents;
                const bool next = e.value != 0;
                if (next != down) { down = next; changed = true; }
            }
            if (e.type != EV_SYN || e.code != SYN_REPORT || !changed) continue;
            if (!target.relative && target.maxX > target.minX && target.maxY > target.minY) {
                x = viewWidth * (target.rotateToLandscape ? 1.0f - axisY : axisX);
                y = viewHeight * (target.rotateToLandscape ? axisX : axisY);
            }
            x = std::max(0.0f, std::min(x, viewWidth - 1.0f));
            y = std::max(0.0f, std::min(y, viewHeight - 1.0f));
            if (down && mouseDevice < 0) mouseDevice = i;
            if (mouseDevice == i || (!down && mouseDevice < 0)) PushMouse(x, y, down);
            if (!down && mouseDevice == i) mouseDevice = -1;
            changed = false;
        }
    }
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex);
        if (mouseDevice == i) { PushMouse(-1, -1, false); mouseDevice = -1; }
    }
    return nullptr;
}


bool Touch_Init(int w, int h, uint32_t orientation_, bool readOnly) {
    Touch_Close();
    touchSources=pointerSources=0;
    for (int &fd : origfd) fd=-1;
    char temp[128];
    DIR *dir = opendir("/dev/input/");
    if (!dir) {
        fprintf(stderr, "Touch: cannot open /dev/input: %s\n", strerror(errno));
        return false;
    }
    dirent *ptr = NULL;
    struct input_absinfo absX[maxE]{}, absY[maxE]{};
    int fd, i;
    int screenX = 0, screenY = 0, minCnt = 99999;
    fdNum = 0;
    while ((ptr = readdir(dir)) != NULL) {
        if (strncmp(ptr->d_name, "event", 5) != 0 || fdNum >= maxE) continue;
        char *end = nullptr;
        const long eventNumber = strtol(ptr->d_name + 5, &end, 10);
        if (!end || *end || eventNumber < 0 || eventNumber > 99999) continue;
        snprintf(temp, sizeof(temp), "/dev/input/%s", ptr->d_name);
        fd = open(temp, (readOnly ? O_RDONLY : O_RDWR) | O_NONBLOCK | O_CLOEXEC);
        if (fd < 0) continue;
        bool isTouch = checkDeviceIsTouch(fd) &&
            ioctl(fd, EVIOCGABS(ABS_MT_POSITION_X), &absX[fdNum]) == 0 &&
            ioctl(fd, EVIOCGABS(ABS_MT_POSITION_Y), &absY[fdNum]) == 0;
        targ candidate{};
        const bool pointerCapable = readOnly && checkDeviceIsPointer(fd, candidate);
        const bool isPointer = pointerCapable && (!isTouch || candidate.mouseButton);
        if (isPointer) isTouch = false;
        else candidate.pointer = false; // MT touchscreen may also expose ABS_X/Y + BTN_TOUCH.
        if (isTouch || isPointer) {
                origfd[fdNum] = fd;
                targF[fdNum] = candidate;
                targF[fdNum].fdNum = fdNum;
                if (isTouch) {
                    targF[fdNum].minX = absX[fdNum].minimum;
                    targF[fdNum].maxX = absX[fdNum].maximum;
                    targF[fdNum].minY = absY[fdNum].minimum;
                    targF[fdNum].maxY = absY[fdNum].maximum;
                }
                const int axisW=targF[fdNum].maxX-targF[fdNum].minX;
                const int axisH=targF[fdNum].maxY-targF[fdNum].minY;
#if defined(__x86_64__)
                targF[fdNum].rotateToLandscape = axisW > 0 && axisH > 0 &&
                    axisW < axisH && std::max(w,h) > std::min(w,h);
#else
                targF[fdNum].rotateToLandscape = false;
#endif
                if (!readOnly) {
                    ioctl(fd, EVIOCGRAB, GRAB);
                }
                if (isTouch && eventNumber < minCnt) {
                    screenX = absX[fdNum].maximum;
                    screenY = absY[fdNum].maximum;
                    minCnt = (int)eventNumber;
                }
                fprintf(stderr, "Touch: input %s (%s, axes=%d..%d/%d..%d, rotate=%d)\n",
                        temp, isTouch ? "multitouch" : "mouse/pointer",
                        targF[fdNum].minX,targF[fdNum].maxX,
                        targF[fdNum].minY,targF[fdNum].maxY,
                        (int)targF[fdNum].rotateToLandscape);
                if (isTouch) ++touchSources; else ++pointerSources;
                fdNum++;
        } else close(fd);
    }
    closedir(dir);

    if (fdNum == 0 || (!readOnly && minCnt == 99999)) {
        fprintf(stderr, "Touch: no readable touchscreen or pointer in /dev/input\n");
        return false;
    }
    if (screenX <= 0) screenX = std::max(w, h);
    if (screenY <= 0) screenY = std::min(w, h);

    if (!readOnly) {
        struct uinput_user_dev ui_dev;
        nowfd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
        if (nowfd <= 0) {
            return false;
        }

        int string_len = rand() % 10 + 5;
        char string[16];
        memset(&ui_dev, 0, sizeof(ui_dev));

        genRandomString(string, string_len);
        strncpy(ui_dev.name, string, UINPUT_MAX_NAME_SIZE);

        ui_dev.id.bustype = 0;
        ui_dev.id.vendor = rand() % 10 + 5;
        ui_dev.id.product = rand() % 10 + 5;
        ui_dev.id.version = rand() % 10 + 5;

        ioctl(nowfd, UI_SET_PROPBIT, INPUT_PROP_DIRECT);

        ioctl(nowfd, UI_SET_EVBIT, EV_ABS);
        ioctl(nowfd, UI_SET_ABSBIT, ABS_X);
        ioctl(nowfd, UI_SET_ABSBIT, ABS_Y);
        ioctl(nowfd, UI_SET_ABSBIT, ABS_MT_POSITION_X);
        ioctl(nowfd, UI_SET_ABSBIT, ABS_MT_POSITION_Y);
        ioctl(nowfd, UI_SET_ABSBIT, ABS_MT_TRACKING_ID);
        ioctl(nowfd, UI_SET_EVBIT, EV_SYN);
        ioctl(nowfd, UI_SET_EVBIT, EV_KEY);
        ioctl(nowfd, UI_SET_KEYBIT, BTN_TOOL_FINGER);
        ioctl(nowfd, UI_SET_KEYBIT, BTN_TOUCH);

        genRandomString(string, string_len);
        ioctl(nowfd, UI_SET_PHYS, string);

        sprintf(temp, "/dev/input/event%d", minCnt);
        fd = open(temp, O_RDWR);
        if (fd) {
            struct input_id id;
            if (!ioctl(fd, EVIOCGID, &id)) {
                ui_dev.id.bustype = id.bustype;
                ui_dev.id.vendor = id.vendor;
                ui_dev.id.product = id.product;
                ui_dev.id.version = id.version;
            }
            uint8_t *bits = NULL;
            ssize_t bits_size = 0;
            int res, j, k;
            while (1) {
                res = ioctl(fd, EVIOCGBIT(EV_KEY, bits_size), bits);
                if (res < bits_size)
                    break;
                bits_size = res + 16;
                bits = (uint8_t *) realloc(bits, bits_size * 2);
            }
            for (j = 0; j < res; j++) {
                for (k = 0; k < 8; k++)
                    if (bits[j] & 1 << k) {
                        if (j * 8 + k == BTN_TOUCH || j * 8 + k == BTN_TOOL_FINGER)
                            continue;
                        ioctl(nowfd, UI_SET_KEYBIT, j * 8 + k);
                    }
            }
            free(bits);
        }
        ui_dev.absmin[ABS_MT_POSITION_X] = 0;
        ui_dev.absmax[ABS_MT_POSITION_X] = screenX;
        ui_dev.absmin[ABS_MT_POSITION_Y] = 0;
        ui_dev.absmax[ABS_MT_POSITION_Y] = screenY;
        ui_dev.absmin[ABS_X] = 0;
        ui_dev.absmax[ABS_X] = screenX;
        ui_dev.absmin[ABS_Y] = 0;
        ui_dev.absmax[ABS_Y] = screenY;
        ui_dev.absmin[ABS_MT_TRACKING_ID] = 0;
        ui_dev.absmax[ABS_MT_TRACKING_ID] = 65535;
        write(nowfd, &ui_dev, sizeof(ui_dev));

        if (ioctl(nowfd, UI_DEV_CREATE)) {
            return false;
        }
    }
    Touch_readOnly = readOnly;
    touchMaxX=screenX; touchMaxY=screenY;
    UpdateScreenData(w,h,orientation_);
    mouseDevice=-1; for(int &f:primaryFinger) f=-1;
    Touch_initialized.store(true,std::memory_order_release);
    for (i=0;i<fdNum;++i) {
        if (!targF[i].pointer) {
            const int rangeX=absX[i].maximum-absX[i].minimum;
            const int rangeY=absY[i].maximum-absY[i].minimum;
            if (rangeX<=0 || rangeY<=0) { Touch_Close(); return false; }
            targF[i].S2TX = (float)screenX / (float)rangeX;
            targF[i].S2TY = (float)screenY / (float)rangeY;
        }
        if (pthread_create(&touchThreads[i],nullptr,targF[i].pointer ? TypePointer : TypeA,&targF[i])!=0) {Touch_Close();return false;}
        threadStarted[i]=true;
    }
    /*   
    LOGD("scale %.2f %.2f ", scale_x, scale_x);
    LOGD("screen %d %d ", screenX, screenY);
    LOGD("screenSize %.1f %.1f ", x, y);
    */
    return true;
}
void UpdateScreenData(int w,int h,uint32_t orientation_) {
    std::lock_guard<std::recursive_mutex> guard(stateMutex);
    screenWidth=w;screenHeight=h;orientation=orientation_;
    viewWidth=(float)std::max(w,h);
    viewHeight=(float)std::min(w,h);
    const bool rotated=orientation==1 || orientation==3;
    scale_x=(float)touchMaxX/(float)(rotated?h:w);
    scale_y=(float)touchMaxY/(float)(rotated?w:h);
}

static bool checkDeviceIsPointer(int fd, targ &target) {
    uint8_t keys[(KEY_MAX + 8) / 8]{}, axes[(ABS_MAX + 8) / 8]{}, rel[(REL_MAX + 8) / 8]{};
    if (ioctl(fd, EVIOCGBIT(EV_KEY, sizeof(keys)), keys) < 0) return false;
    auto has = [](const uint8_t *bits, int code) { return (bits[code / 8] & (1u << (code % 8))) != 0; };
    target.mouseButton = has(keys, BTN_LEFT);
    if (!target.mouseButton && !has(keys, BTN_TOUCH)) return false;
    ioctl(fd, EVIOCGBIT(EV_ABS, sizeof(axes)), axes);
    ioctl(fd, EVIOCGBIT(EV_REL, sizeof(rel)), rel);
    const bool absolute = has(axes, ABS_X) && has(axes, ABS_Y);
    const bool relative = has(rel, REL_X) && has(rel, REL_Y);
    if (!absolute && !relative) return false;
    target.pointer = true;
    target.relative = !absolute && relative;
    if (absolute) {
        input_absinfo x{}, y{};
        if (ioctl(fd, EVIOCGABS(ABS_X), &x) != 0 || ioctl(fd, EVIOCGABS(ABS_Y), &y) != 0) return false;
        target.minX = x.minimum; target.maxX = x.maximum;
        target.minY = y.minimum; target.maxY = y.maximum;
    }
    return true;
}



static bool checkDeviceIsTouch(int fd) {
    uint8_t *bits = NULL;
    ssize_t bits_size = 0;
    int res, j, k;
    bool itmp = false, itmp2 = false, itmp3 = false;
    struct input_absinfo abs{};
    while (true) {
        res = ioctl(fd, EVIOCGBIT(EV_ABS, bits_size), bits);
        if (res < bits_size)
            break;
        bits_size = res + 16;
        bits = (uint8_t *) realloc(bits, bits_size * 2);
    }
    for (j = 0; j < res; j++) {
        for (k = 0; k < 8; k++)
            if (bits[j] & 1 << k && ioctl(fd, EVIOCGABS(j * 8 + k), &abs) == 0) {
                if (j * 8 + k == ABS_MT_SLOT) {
                    itmp = true;
                    continue;
                }
                if (j * 8 + k == ABS_MT_POSITION_X) {
                    itmp2 = true;
                    continue;
                }
                if (j * 8 + k == ABS_MT_POSITION_Y) {
                    itmp3 = true;
                    continue;
                }
            }
    }
    free(bits);
    // Some Android 12 and virtual/cloud touch devices expose tracking IDs and
    // coordinates but no slot axis. The reader already supports slot 0.
    return itmp2 && itmp3;
}

void Touch_Close() {
    Touch_initialized.store(false,std::memory_order_release);
    // poll has a bounded timeout. Stop and join BEFORE descriptors/arrays/ImGui die.
    for (int i=0;i<maxE;++i) if(threadStarted[i]) {
        pthread_join(touchThreads[i],nullptr);threadStarted[i]=false;
    }
    std::lock_guard<std::recursive_mutex> guard(stateMutex);
    for (int i=0;i<fdNum;++i) if(origfd[i]>=0) {
        if(!Touch_readOnly)ioctl(origfd[i],EVIOCGRAB,UNGRAB);
        close(origfd[i]);origfd[i]=-1;
    }
    if(!Touch_readOnly && nowfd>0) {ioctl(nowfd,UI_DEV_DESTROY);close(nowfd);nowfd=0;}
    fdNum=0;memset(Finger,0,sizeof(Finger));memset(input.event,0,sizeof(input.event));
    touchSources=pointerSources=0;
    mouseEvents.Clear();mouseDevice=-1;
}
void Touch_Down(float xt, float yt) {
    std::lock_guard<std::recursive_mutex> guard(stateMutex);
    if (!Touch_initialized || Touch_readOnly) return;
    static int x, y;
    x = 0, y = 0;
    switch (orientation) {
        case 1: {
            x = screenHeight - yt;
            y = xt;
            break;
        }                          
        case 2: {
            x = screenWidth - xt;
            y = screenHeight - yt;
            break;
        }
        case 3: {
            y = screenWidth - xt;
            x = yt;
            break;
        }
        default: {
            x = xt;
            y = yt;
            break;
        }
    }
    touchObj &touch = Finger[0][9];
    touch.id = 19;
    touch.x = (int) (x * ::scale_x);
    touch.y = (int) (y * ::scale_y);        
    touch.isDown = true;
    Upload();
}
/*
void Touch_Down(float x, float y) {
    touchObj &touch = Finger[0][9];
    touch.id = 19;
    touch.x = (int) (x * scale_x);
    touch.y = (int) (y * scale_y);
    touch.isDown = true;
    Upload();
}
*/
void Touch_Move(float x, float y) {
    Touch_Down(x, y);
}

void Touch_Up() {
    std::lock_guard<std::recursive_mutex> guard(stateMutex);
    if (!Touch_initialized || Touch_readOnly) return;
    touchObj &touch = Finger[0][9];
    touch.isDown = false;
    Upload();
}
