#include "trial_ui.h"
#include <algorithm>
#include <string>
#include <stdio.h>

namespace UI {

ImDrawList *DL = nullptr;
ImVec2 O(0, 0);
float U = 1.0f;
bool Block = false;
ImFont *FText = nullptr, *FMed = nullptr, *FTitle = nullptr;
float WinW = 868.0f, WinH = 580.0f;

struct PixelParticle {
    ImVec2 pos, velocity;
    float age, life, size;
    int sprite;
};
struct PixelPulse { ImVec2 pos; float age, life; };
static std::vector<PixelParticle> s_PixelParticles;
static std::vector<PixelPulse> s_PixelPulses;
static uint32_t s_PixelRng = 0x71A1C0DEu;
static uint32_t PixelRand() { s_PixelRng ^= s_PixelRng << 13; s_PixelRng ^= s_PixelRng >> 17; s_PixelRng ^= s_PixelRng << 5; return s_PixelRng; }
static float PixelRand01() { return (PixelRand() & 0x00FFFFFF) / 16777215.0f; }

// ===================== Цвета =====================
static const int kAccents[5][3] = {
    {25, 103, 210},
    {37, 91, 176},
    {121, 76, 187},
    {25, 127, 94},
    {195, 57, 83},
};

ImU32 Col(int r, int g, int b, float a) {
    int ai = (int)(ImSaturate(a) * 255.0f + 0.5f);
    return IM_COL32(r, g, b, ai);
}

ImU32 Acc(float a) {
    const int *c = kAccents[ImClamp(g_cfg.accent, 0, 4)];
    return Col(c[0], c[1], c[2], a);
}

ImU32 AccLight(float a) {
    const int *c = kAccents[ImClamp(g_cfg.accent, 0, 4)];
    return Col((c[0] + 255 * 2) / 3, (c[1] + 255 * 2) / 3, (c[2] + 255 * 2) / 3, a);
}

ImU32 LerpCol(ImU32 a, ImU32 b, float t) {
    ImVec4 ca = ImGui::ColorConvertU32ToFloat4(a);
    ImVec4 cb = ImGui::ColorConvertU32ToFloat4(b);
    return ImGui::ColorConvertFloat4ToU32(ImLerp(ca, cb, ImSaturate(t)));
}

// Экспоненциальное сглаживание, состояние хранится в ImGuiStorage текущего окна
float Anim(ImGuiID id, float target, float speed) {
    ImGuiStorage *st = ImGui::GetStateStorage();
    float *v = st->GetFloatRef(id, target);
    if (!g_cfg.anim) { *v = target; return target; }
    float dt = ImMin(ImGui::GetIO().DeltaTime, 0.1f);
    float k = 1.0f - expf(-speed * g_cfg.animSpeed * dt);
    *v += (target - *v) * k;
    if (fabsf(target - *v) < 0.001f) *v = target;
    return *v;
}

// ===================== Текст =====================
void Text(ImFont *f, float size, ImVec2 pos, ImU32 col, const char *t) {
    DL->AddText(f, size * U, pos, col, t);
}

ImVec2 TextSize(ImFont *f, float size, const char *t) {
    return f->CalcTextSizeA(size * U, FLT_MAX, 0.0f, t);
}

void TextV(ImFont *f, float size, ImVec2 lc, ImU32 col, const char *t) {
    DL->AddText(f, size * U, ImVec2(lc.x, lc.y - size * U * 0.5f), col, t);
}

void FitText(ImFont *f, float size, ImVec2 lc, ImU32 col, const char *t, float maxW) {
    if (!t || !*t) return;
    float sz = size;
    ImVec2 ts = f->CalcTextSizeA(sz * U, FLT_MAX, 0.0f, t);
    if (maxW > 0 && ts.x > maxW) { sz = size * ImMax(0.80f, maxW / ts.x); ts = f->CalcTextSizeA(sz * U, FLT_MAX, 0.0f, t); }
    const ImVec2 pos(lc.x, lc.y - sz * U * 0.5f);
    if (maxW > 0 && ts.x > maxW) {                       // всё ещё длинно: режем по символам UTF-8 и ставим многоточие
        std::string str(t);
        while (!str.empty()) {
            size_t i = str.size() - 1;
            while (i > 0 && ((unsigned char)str[i] & 0xC0) == 0x80) --i;
            str.resize(i);
            const std::string cut = str + "...";
            if (f->CalcTextSizeA(sz * U, FLT_MAX, 0.0f, cut.c_str()).x <= maxW) { str = cut; break; }
        }
        DL->AddText(f, sz * U, pos, col, str.c_str());
        return;
    }
    DL->AddText(f, sz * U, pos, col, t);
}

// ===================== Ролик =====================
// 286 кадров 384x216 в 7 атласах по 5x9 (tools/make_banner.py). Константы сверяет сама нарезка.
static const int   kVidFrames = 286, kVidTiles = 7, kVidCols = 5, kVidPerTile = 45;
static const float kVidW = 384.0f, kVidH = 216.0f, kVidFps = 286.0f / 9.567f;

void VideoRect(ImVec2 a, ImVec2 b, float r, ImDrawFlags flags, float time) {
    DL->AddRectFilled(a, b, Col(0, 0, 0), r, flags);
    int ready = 0;
    while (ready < kVidTiles && GetTexture(TEX_BANNER + ready)) ++ready;    // атласы грузятся по одному в кадр: пока крутим готовое
    if (!ready) return;
    const int avail = ready >= kVidTiles ? kVidFrames : ready * kVidPerTile;
    const int fi = (int)(time * kVidFps) % avail;
    ImVec2 tex(0, 0);
    ImTextureID img = GetTexture(TEX_BANNER + fi / kVidPerTile, &tex);
    if (!img || tex.x < 8) return;
    const int cell = fi % kVidPerTile, col = cell % kVidCols, row = cell / kVidCols;
    const float aspect = (b.x - a.x) / ImMax(b.y - a.y, 1.0f), frameAspect = kVidW / kVidH;
    float vw = 1.0f, vh = 1.0f;                                              // «cover»: заполняем без полос, лишнее срезаем
    if (aspect > frameAspect) vh = frameAspect / aspect; else vw = aspect / frameAspect;
    const float pad = 0.75f;                                                 // чтобы фильтрация не подмешивала соседний кадр
    const float x0 = col * kVidW + kVidW * (0.5f - vw * 0.5f) + pad, x1 = col * kVidW + kVidW * (0.5f + vw * 0.5f) - pad;
    const float y0 = row * kVidH + kVidH * (0.5f - vh * 0.5f) + pad, y1 = row * kVidH + kVidH * (0.5f + vh * 0.5f) - pad;
    DL->AddImageRounded(img, a, b, ImVec2(x0 / tex.x, y0 / tex.y), ImVec2(x1 / tex.x, y1 / tex.y), IM_COL32_WHITE, r, flags);
}

// ===================== Пост-обработка =====================
void TransformVerts(ImDrawList *dl, int start, ImVec2 pivot, float scale, float rot, float alphaMul) {
    float cs = cosf(rot) * scale, sn = sinf(rot) * scale;
    bool doPos = !(scale == 1.0f && rot == 0.0f);
    alphaMul = ImSaturate(alphaMul);
    for (int i = start; i < dl->VtxBuffer.Size; i++) {
        ImDrawVert &v = dl->VtxBuffer.Data[i];
        if (doPos) {
            ImVec2 d = v.pos - pivot;
            v.pos = ImVec2(pivot.x + d.x * cs - d.y * sn, pivot.y + d.x * sn + d.y * cs);
        }
        if (alphaMul < 1.0f) {
            ImU32 a = (v.col >> IM_COL32_A_SHIFT) & 0xFF;
            a = (ImU32)(a * alphaMul);
            v.col = (v.col & ~IM_COL32_A_MASK) | (a << IM_COL32_A_SHIFT);
        }
    }
}

void Shimmer(ImDrawList *dl, int start, float cx, float width, ImU32 col, float strength) {
    for (int i = start; i < dl->VtxBuffer.Size; i++) {
        ImDrawVert &v = dl->VtxBuffer.Data[i];
        float d = (v.pos.x - cx) / width;
        float f = expf(-d * d) * strength;
        if (f < 0.01f) continue;
        ImU32 a = v.col & IM_COL32_A_MASK;
        v.col = (LerpCol(v.col, col, f) & ~IM_COL32_A_MASK) | a;
    }
}

// ===================== Иконки =====================
// Четырёхлучевая звезда с вогнутыми сторонами
static void StarPath(ImVec2 c, float r, float thin) {
    DL->PathClear();
    for (int k = 0; k < 4; k++) {
        float a0 = -IM_PI * 0.5f + k * IM_PI * 0.5f;
        float a1 = a0 + IM_PI * 0.5f;
        float am = (a0 + a1) * 0.5f;
        ImVec2 tip0(c.x + cosf(a0) * r, c.y + sinf(a0) * r);
        ImVec2 tip1(c.x + cosf(a1) * r, c.y + sinf(a1) * r);
        ImVec2 ctrl(c.x + cosf(am) * r * thin, c.y + sinf(am) * r * thin);
        if (k == 0) DL->PathLineTo(tip0);
        DL->PathBezierQuadraticCurveTo(ctrl, tip1, 10);
    }
}

void StarFilled(ImVec2 c, float r, ImU32 col, float thin) {
    if (r < 0.5f) return;
    StarPath(c, r, thin);
    ImVector<ImVec2> pts;
    pts.swap(DL->_Path);
    DL->PathClear();
    // Веер из центра (фигура звёздная относительно центра) без AA, затем AA-контур
    ImDrawListFlags old = DL->Flags;
    DL->Flags &= ~ImDrawListFlags_AntiAliasedFill;
    for (int i = 0; i + 1 < pts.Size; i++) DL->AddTriangleFilled(c, pts[i], pts[i + 1], col);
    DL->Flags = old;
    DL->AddPolyline(pts.Data, pts.Size, col, ImDrawFlags_Closed, ImMax(1.0f, U * 0.9f));
}

void StarOutline(ImVec2 c, float r, ImU32 col, float thick, float thin) {
    StarPath(c, r, thin);
    DL->PathStroke(col, ImDrawFlags_Closed, thick);
}

void IconEye(ImVec2 c, float s, ImU32 col) {
    float w = s * 0.5f, h = s * 0.30f, t = ImMax(1.2f, s * 0.075f);
    DL->PathClear();
    DL->PathLineTo(ImVec2(c.x - w, c.y));
    DL->PathBezierCubicCurveTo(ImVec2(c.x - w * 0.45f, c.y - h * 1.45f), ImVec2(c.x + w * 0.45f, c.y - h * 1.45f), ImVec2(c.x + w, c.y));
    DL->PathBezierCubicCurveTo(ImVec2(c.x + w * 0.45f, c.y + h * 1.45f), ImVec2(c.x - w * 0.45f, c.y + h * 1.45f), ImVec2(c.x - w, c.y));
    DL->PathStroke(col, ImDrawFlags_Closed, t);
    DL->AddCircle(c, s * 0.18f, col, 0, t);
    DL->AddCircleFilled(c, s * 0.075f, col);
}

void IconSparkles(ImVec2 c, float s, ImU32 col) {
    float t = ImMax(1.2f, s * 0.07f);
    StarOutline(ImVec2(c.x - s * 0.08f, c.y + s * 0.06f), s * 0.40f, col, t, 0.22f);
    StarFilled(ImVec2(c.x + s * 0.32f, c.y - s * 0.30f), s * 0.16f, col, 0.25f);
}

void IconSliders(ImVec2 c, float s, ImU32 col, ImU32 bg) {
    float t = ImMax(1.2f, s * 0.07f);
    const float ys[3] = {-0.30f, 0.0f, 0.30f};
    const float ks[3] = {0.18f, -0.20f, 0.08f};
    for (int i = 0; i < 3; i++) {
        float y = c.y + ys[i] * s;
        DL->AddLine(ImVec2(c.x - s * 0.46f, y), ImVec2(c.x + s * 0.46f, y), col, t);
        ImVec2 k(c.x + ks[i] * s, y);
        DL->AddCircleFilled(k, s * 0.11f, bg);
        DL->AddCircle(k, s * 0.11f, col, 0, t);
    }
}

void IconGear(ImVec2 c, float s, ImU32 col) {
    float t = ImMax(1.2f, s * 0.07f);
    const int teeth = 8;
    float ro = s * 0.46f, ri = s * 0.35f;
    DL->PathClear();
    for (int i = 0; i < teeth; i++) {
        float a = i * IM_PI * 2.0f / teeth;
        float hw = IM_PI / teeth * 0.45f;   // полуширина зуба
        float step = IM_PI / teeth;
        DL->PathLineTo(ImVec2(c.x + cosf(a - step + hw) * ri, c.y + sinf(a - step + hw) * ri));
        DL->PathLineTo(ImVec2(c.x + cosf(a - hw) * ri, c.y + sinf(a - hw) * ri));
        DL->PathLineTo(ImVec2(c.x + cosf(a - hw * 0.7f) * ro, c.y + sinf(a - hw * 0.7f) * ro));
        DL->PathLineTo(ImVec2(c.x + cosf(a + hw * 0.7f) * ro, c.y + sinf(a + hw * 0.7f) * ro));
        DL->PathLineTo(ImVec2(c.x + cosf(a + hw) * ri, c.y + sinf(a + hw) * ri));
    }
    DL->PathStroke(col, ImDrawFlags_Closed, t);
    DL->AddCircle(c, s * 0.15f, col, 0, t);
}

void IconCrosshair(ImVec2 c, float s, ImU32 col) {
    const float th = ImMax(1.4f, s * 0.075f), r = s * 0.29f, in = r * 0.55f, out = s * 0.47f;
    DL->AddCircle(c, r, col, 28, th);
    DL->AddLine(ImVec2(c.x - out, c.y), ImVec2(c.x - in, c.y), col, th);
    DL->AddLine(ImVec2(c.x + in, c.y), ImVec2(c.x + out, c.y), col, th);
    DL->AddLine(ImVec2(c.x, c.y - out), ImVec2(c.x, c.y - in), col, th);
    DL->AddLine(ImVec2(c.x, c.y + in), ImVec2(c.x, c.y + out), col, th);
    DL->AddCircleFilled(c, th * 0.95f, col, 12);
}

void IconChip(ImVec2 c, float s, ImU32 col) {
    const float th = ImMax(1.4f, s * 0.075f), h = s * 0.24f, pin = s * 0.12f;
    DL->AddRect(ImVec2(c.x - h, c.y - h), ImVec2(c.x + h, c.y + h), col, s * 0.05f, 0, th);
    DL->AddRectFilled(ImVec2(c.x - h * 0.42f, c.y - h * 0.42f), ImVec2(c.x + h * 0.42f, c.y + h * 0.42f), col, s * 0.03f);
    for (int k = -1; k <= 1; ++k) {
        const float o = k * h * 0.58f;
        DL->AddLine(ImVec2(c.x + o, c.y - h), ImVec2(c.x + o, c.y - h - pin), col, th);
        DL->AddLine(ImVec2(c.x + o, c.y + h), ImVec2(c.x + o, c.y + h + pin), col, th);
        DL->AddLine(ImVec2(c.x - h, c.y + o), ImVec2(c.x - h - pin, c.y + o), col, th);
        DL->AddLine(ImVec2(c.x + h, c.y + o), ImVec2(c.x + h + pin, c.y + o), col, th);
    }
}

void IconChevron(ImVec2 c, float s, ImU32 col, bool up) {
    float d = up ? -1.0f : 1.0f;
    ImVec2 pts[3] = {
        ImVec2(c.x - s * 0.5f, c.y - s * 0.25f * d),
        ImVec2(c.x,            c.y + s * 0.25f * d),
        ImVec2(c.x + s * 0.5f, c.y - s * 0.25f * d),
    };
    DL->AddPolyline(pts, 3, col, 0, ImMax(1.2f, U * 1.6f));
}

// ===================== Взаимодействие =====================
bool Hit(const char *id, ImVec2 a, ImVec2 b, bool *held) {
    if (held) *held = false;
    if (Block) return false;
    ImGui::SetCursorScreenPos(a);
    bool clicked = ImGui::InvisibleButton(id, ImVec2(ImMax(b.x - a.x, 1.0f), ImMax(b.y - a.y, 1.0f)));
    if (held) *held = ImGui::IsItemActive();
    if (clicked) SpawnBurst(ImGui::GetIO().MousePos);
    return clicked;
}

void SpawnBurst(ImVec2 pos) {
    const int count = g_cfg.quality == 0 ? 18 + (int)(PixelRand()%9)
                    : g_cfg.quality == 2 ? 40 + (int)(PixelRand()%9)
                    : 30 + (int)(PixelRand()%11);
    const size_t limit = g_cfg.quality == 0 ? 320 : g_cfg.quality == 2 ? 720 : 520;
    if (s_PixelParticles.size() + count > limit) {
        size_t remove = s_PixelParticles.size() + count - limit;
        s_PixelParticles.erase(s_PixelParticles.begin(), s_PixelParticles.begin() + remove);
    }
    for (int i=0; i<count; ++i) {
        float angle = (2.0f*IM_PI*i/count) + (PixelRand01()-0.5f)*0.38f;
        float speed = 45.0f + PixelRand01()*185.0f;
        float s = (2.5f + PixelRand01()*8.5f) * U;
        s_PixelParticles.push_back({
            ImVec2(pos.x+(PixelRand01()-0.5f)*8.0f*U, pos.y+(PixelRand01()-0.5f)*8.0f*U),
            ImVec2(cosf(angle)*speed, sinf(angle)*speed-24.0f),
            0.0f, 0.34f+PixelRand01()*0.52f, s, (int)(PixelRand()%1024)
        });
    }
    if (s_PixelPulses.size() >= 18) s_PixelPulses.erase(s_PixelPulses.begin());
    s_PixelPulses.push_back({pos,0.0f,0.38f});
}

void RenderEffects() {
    ImDrawList *fx = ImGui::GetForegroundDrawList();
    ImVec2 atlasSize;
    ImTextureID atlas = GetTexture(TEX_PARTICLE_ATLAS, &atlasSize);
    const float dt = ImMin(ImGui::GetIO().DeltaTime, 0.05f);
    const float cell = 36.0f, inset = 2.0f, atlasPixels = 32.0f*cell;
    for (PixelParticle &p : s_PixelParticles) {
        p.age += dt;
        p.velocity.y += 38.0f*dt;
        p.velocity.x *= expf(-0.32f*dt);
        p.pos += p.velocity*dt;
        float t = ImSaturate(1.0f-p.age/p.life);
        if (t <= 0.0f) continue;
        float size = p.size*(0.72f+0.42f*(1.0f-t));
        if (atlas && atlasSize.x >= atlasPixels && atlasSize.y >= atlasPixels) {
            int col=p.sprite%32, row=p.sprite/32;
            ImVec2 uv0((col*cell+inset)/atlasPixels,(row*cell+inset)/atlasPixels);
            ImVec2 uv1((col*cell+inset+32.0f)/atlasPixels,(row*cell+inset+32.0f)/atlasPixels);
            fx->AddImage(atlas,ImVec2(p.pos.x-size,p.pos.y-size),ImVec2(p.pos.x+size,p.pos.y+size),
                         uv0,uv1,IM_COL32(255,255,255,(int)(255*t*t)));
        } else {
            fx->AddRectFilled(ImVec2(p.pos.x-size,p.pos.y-size),ImVec2(p.pos.x+size,p.pos.y+size),
                              Acc(0.92f*t*t),1.0f*U);
        }
    }
    s_PixelParticles.erase(std::remove_if(s_PixelParticles.begin(),s_PixelParticles.end(),
        [](const PixelParticle &p){ return p.age>=p.life; }),s_PixelParticles.end());
    for (PixelPulse &p : s_PixelPulses) {
        p.age += dt;
        float t=ImSaturate(1.0f-p.age/p.life);
        float r=(12.0f+(1.0f-t)*66.0f)*U;
        if (t>0.0f) {
            fx->AddCircle(p.pos,r,Acc(0.42f*t),0,ImMax(1.0f,1.6f*U));
            fx->AddCircle(p.pos,r*0.76f,Acc(0.15f*t),0,ImMax(1.0f,U));
        }
    }
    s_PixelPulses.erase(std::remove_if(s_PixelPulses.begin(),s_PixelPulses.end(),
        [](const PixelPulse &p){ return p.age>=p.life; }),s_PixelPulses.end());
}

// ===================== Виджеты =====================
void Label(const char *text, float x, float y, float maxW) {
    FitText(FText, 20.0f, P(x, y), Col(30, 41, 59), T(text), maxW > 0 ? maxW * U : 0.0f);
}

// Где начинается дорожка слайдера: не левее заданного и не под подписью (подпись длиннее — дорожка уезжает правее).
static float TrackFor(const char *label, float trackStart, float x0, float x1) {
    const float need = TextSize(FText, 20.0f, T(label)).x / U + 25.0f + 18.0f;
    return trackStart < need ? ImMin(need, (x1 - x0) * 0.60f) : trackStart;
}

// Переключатель-«таблетка» 40×22, t — анимация 0..1
void Switch(ImVec2 p, float t) {
    float w = 40.0f * U, h = 22.0f * U, r = h * 0.5f;
    ImVec2 b(p.x + w, p.y + h);
    DL->AddRectFilled(p, b, LerpCol(Col(203, 213, 225), Acc(1.0f), t), r);
    if (t < 0.99f) DL->AddRect(p, b, Col(148, 163, 184, 1.0f - t), r, 0, ImMax(1.0f, U));
    ImVec2 k(p.x + r + t * (w - h), p.y + r);
    float kr = r - 2.6f * U;
    DL->AddCircleFilled(ImVec2(k.x, k.y + 1.2f * U), kr + 0.8f * U, Col(15, 23, 42, 0.22f));
    DL->AddCircleFilled(k, kr, Col(255, 255, 255));
}

void RowToggle(const char *id, const char *label, bool *v, float x0, float x1, float y) {
    const float hover = Anim(ImGui::GetID(id) + 7, !Block && ImGui::IsMouseHoveringRect(P(x0 + 10,y - 21),P(x1 - 10,y + 21)) ? 1.0f : 0.0f);
    if (hover > .01f) DL->AddRectFilled(P(x0 + 10,y - 21),P(x1 - 10,y + 21),Acc(.045f * hover),6 * U);
    Label(label, x0 + 25, y, (x1 - 25 - 40) - (x0 + 25) - 14);
    if (Hit(id, P(x0 + 10, y - 21), P(x1 - 10, y + 21))) *v = !*v;
    float t = Anim(ImGui::GetID(id), *v ? 1.0f : 0.0f, 14.0f);
    Switch(P(x1 - 25 - 40, y - 11), t);
}

void RowSlider(const char *id, const char *label, float *v, float mn, float mx, const char *fmt,
               float x0, float x1, float y, float trackStart, const char *zeroText) {
    trackStart = TrackFor(label, trackStart, x0, x1);
    Label(label, x0 + 25, y, trackStart - 25 - 12);
    ImVec2 a = P(x0 + trackStart, y), b = P(x1 - 70, y);
    bool held = false;
    Hit(id, ImVec2(a.x - 14 * U, a.y - 20 * U), ImVec2(b.x + 14 * U, b.y + 20 * U), &held);
    if (held) {
        float f = ImSaturate((ImGui::GetIO().MousePos.x - a.x) / ImMax(b.x - a.x, 1.0f));
        *v = mn + (mx - mn) * f;
    }
    float f = ImSaturate((*v - mn) / (mx - mn));
    float fa = Anim(ImGui::GetID(id), f, held ? 40.0f : 16.0f);
    float th = 1.6f * U;
    DL->AddRectFilled(ImVec2(a.x, a.y - th), ImVec2(b.x, b.y + th), Col(203, 213, 225), th);
    ImVec2 k(a.x + (b.x - a.x) * fa, a.y);
    DL->AddRectFilled(ImVec2(a.x, a.y - th), ImVec2(k.x, a.y + th), Acc(1.0f), th);
    float hold = Anim(ImGui::GetID(id) + 1, held ? 1.0f : 0.0f, 16.0f);
    if (hold > 0.01f) DL->AddCircleFilled(k, (9.0f + 7.0f * hold) * U, Acc(0.14f * hold));
    DL->AddCircleFilled(ImVec2(k.x, k.y + U), 8.2f * U, Col(15, 23, 42, 0.20f));
    DL->AddCircleFilled(k, 7.5f * U, Col(255, 255, 255));
    DL->AddCircle(k, 7.5f * U, Col(148, 163, 184), 0, ImMax(1.0f, 1.1f * U));

    char buf[32];
    if (zeroText && *v < mn + (mx - mn) * 0.01f) snprintf(buf, sizeof(buf), "%s", T(zeroText));
    else snprintf(buf, sizeof(buf), fmt, *v);
    ImVec2 ts = TextSize(FText, 19.0f, buf);
    TextV(FText, 19.0f, ImVec2(P(x1 - 22, y).x - ts.x, P(0, y).y), Col(51, 65, 85), T(buf));
}

void RowGradient(const char *id, const char *label, float *v, int mode, float hue, const float rgb[3],
                 float x0, float x1, float y, float trackStart, float sat) {
    trackStart = TrackFor(label, trackStart, x0, x1);
    Label(label, x0 + 25, y, trackStart - 25 - 12);
    ImVec2 a = P(x0 + trackStart, y), b = P(x1 - 70, y);
    bool held = false;
    Hit(id, ImVec2(a.x - 14 * U, a.y - 20 * U), ImVec2(b.x + 14 * U, b.y + 20 * U), &held);
    if (held) *v = ImSaturate((ImGui::GetIO().MousePos.x - a.x) / ImMax(b.x - a.x, 1.0f));
    float fa = Anim(ImGui::GetID(id), ImSaturate(*v), held ? 40.0f : 16.0f);

    auto colAt = [&](float t) {
        float r, g, bl;
        if (mode == 0)      ImGui::ColorConvertHSVtoRGB(t, 1.0f, 1.0f, r, g, bl);
        else if (mode == 1) ImGui::ColorConvertHSVtoRGB(hue, t, 1.0f, r, g, bl);
        else                ImGui::ColorConvertHSVtoRGB(hue, sat, t, r, g, bl);
        return IM_COL32((int)(r * 255.0f + 0.5f), (int)(g * 255.0f + 0.5f), (int)(bl * 255.0f + 0.5f), 255);
    };
    const float th = 2.2f * U;
    const int N = 24;
    for (int i = 0; i < N; ++i) {
        float t0 = (float)i / N, t1 = (float)(i + 1) / N;
        float xa = a.x + (b.x - a.x) * t0, xb = a.x + (b.x - a.x) * t1;
        ImU32 c0 = colAt(t0), c1 = colAt(t1);
        DL->AddRectFilledMultiColor(ImVec2(xa, a.y - th), ImVec2(xb, a.y + th), c0, c1, c1, c0);
    }
    DL->AddCircleFilled(a, th, colAt(0.0f));
    DL->AddCircleFilled(b, th, colAt(1.0f));

    ImVec2 k(a.x + (b.x - a.x) * fa, a.y);
    float hold = Anim(ImGui::GetID(id) + 1, held ? 1.0f : 0.0f, 16.0f);
    if (hold > 0.01f) DL->AddCircleFilled(k, (9.0f + 7.0f * hold) * U, Acc(0.14f * hold));
    DL->AddCircleFilled(ImVec2(k.x, k.y + U), 8.2f * U, Col(15, 23, 42, 0.20f));
    DL->AddCircleFilled(k, 7.5f * U, Col(255, 255, 255));
    DL->AddCircleFilled(k, 5.0f * U, colAt(ImSaturate(*v)));

    ImVec2 right = P(x1 - 22, y);
    if (mode == 0 && rgb) {
        float rr = 10.0f * U;
        ImVec2 c(right.x - rr, right.y);
        DL->AddCircleFilled(c, rr, Col((int)(ImSaturate(rgb[0]) * 255.0f), (int)(ImSaturate(rgb[1]) * 255.0f),
                                       (int)(ImSaturate(rgb[2]) * 255.0f)));
        DL->AddCircle(c, rr, Col(148, 163, 184, 0.80f), 0, ImMax(1.0f, 1.1f * U));
    } else {
        char buf[16];
        snprintf(buf, sizeof(buf), "%d%%", (int)(*v * 100.0f + 0.5f));
        ImVec2 ts = TextSize(FText, 19.0f, buf);
        TextV(FText, 19.0f, ImVec2(right.x - ts.x, right.y), Col(51, 65, 85), buf);
    }
}

// ----- Выпадающий список -----
struct ComboState {
    ImGuiID id = 0;
    int *value = nullptr;
    const char *items[32] = {};
    int count = 0;
    int offset = 0;
    ImVec2 a, b;       // рамка поля
    bool up = false;
    bool justOpened = false;
};
static ComboState s_Combo;

bool ComboOpen() { return s_Combo.id != 0; }
void CloseCombo() { s_Combo.id = 0; }

void RowCombo(const char *id, const char *label, int *v, const char *const *items, int n,
              float x0, float x1, float y, float w) {
    Label(label, x0 + 25, y, (x1 - 22 - w) - (x0 + 25) - 10);
    ImVec2 a = P(x1 - 22 - w, y - 18), b = P(x1 - 22, y + 18);
    ImGuiID gid = ImGui::GetID(id);
    bool open = s_Combo.id == gid;
    if (Hit(id, a, b)) {
        s_Combo.id = gid;
        s_Combo.value = v;
        s_Combo.count = ImMin(n, 32);
        s_Combo.offset = s_Combo.count > 8 ? (ImClamp(*v, 0, s_Combo.count - 1) / 8) * 8 : 0;
        for (int i = 0; i < s_Combo.count; i++) s_Combo.items[i] = items[i];
        s_Combo.a = a;
        s_Combo.b = b;
        float listH = (ImMin(s_Combo.count, 8) * 38.0f + 10.0f + (s_Combo.count > 8 ? 34.0f : 0.0f)) * U;
        s_Combo.up = b.y + 6.0f * U + listH > O.y + (WinH - 10.0f) * U;
        s_Combo.justOpened = true;
        open = true;
    }
    if (open) {   // обновляем подписи (язык мог смениться) и позицию (окно могло сдвинуться)
        for (int i = 0; i < s_Combo.count; i++) s_Combo.items[i] = items[i];
        s_Combo.a = a;
        s_Combo.b = b;
    }
    float r = g_cfg.rounding * 0.6f * U;
    float t = Anim(gid, open ? 1.0f : 0.0f, 16.0f);
    DL->AddRectFilled(a, b, Col(244, 248, 253), r);
    DL->AddRect(a, b, LerpCol(Col(186, 204, 224), Acc(0.85f), t), r, 0, ImMax(1.0f, U * 1.1f));
    int idx = ImClamp(*v, 0, n - 1);
    FitText(FText, 19.0f, ImVec2(a.x + 13 * U, (a.y + b.y) * 0.5f), Col(30, 41, 59), T(items[idx]), (w - 13 - 32) * U);
    IconChevron(ImVec2(b.x - 18 * U, (a.y + b.y) * 0.5f), 10.0f * U, LerpCol(Col(100, 116, 139), Acc(1.0f), t), open);
}

void ComboPopup() {
    if (!s_Combo.id) return;
    ImGuiIO &io = ImGui::GetIO();
    float rowH = 38.0f * U, pad = 5.0f * U;
    const bool paged = s_Combo.count > 8;
    s_Combo.offset = ImClamp(s_Combo.offset, 0, ImMax(0, ((s_Combo.count - 1) / 8) * 8));
    const int visible = ImMin(8, s_Combo.count - s_Combo.offset);
    const float footer = paged ? 34.0f * U : 0.0f;
    float h = visible * rowH + pad * 2 + footer;
    ImVec2 pa, pb;
    if (s_Combo.up) { pb = ImVec2(s_Combo.b.x, s_Combo.a.y - 6 * U); pa = ImVec2(s_Combo.a.x, pb.y - h); }
    else            { pa = ImVec2(s_Combo.a.x, s_Combo.b.y + 6 * U); pb = ImVec2(s_Combo.b.x, pa.y + h); }
    // A long list can fit on neither side of its field. Keep it inside the
    // menu's clip rectangle instead of hiding its first rows above the window.
    const float minY = ImMax(4.f, O.y + 4.f * U);
    const float maxY = ImMin(io.DisplaySize.y - 4.f, O.y + (WinH - 4.f) * U);
    pa.y = ImClamp(pa.y, minY, ImMax(minY, maxY - h));
    pb.y = pa.y + h;
    float r = ImMax(g_cfg.rounding * 0.7f, 4.0f) * U;

    // Тень + подложка
    for (int i = 1; i <= 5; i++) {
        float e = i * 2.0f * U;
        DL->AddRectFilled(ImVec2(pa.x - e, pa.y - e + 3 * U), ImVec2(pb.x + e, pb.y + e + 3 * U), Col(30, 60, 110, 0.045f), r + e);
    }
    DL->AddRectFilled(pa, pb, Col(255, 255, 255), r);
    DL->AddRect(pa, pb, Acc(0.60f), r, 0, ImMax(1.0f, U));

    int hovered = -1;
    ImVec2 m = io.MousePos;
    if (m.x >= pa.x && m.x <= pb.x && m.y >= pa.y + pad && m.y < pb.y - pad - footer)
        hovered = (int)((m.y - pa.y - pad) / rowH);

    for (int i = 0; i < visible; i++) {
        ImVec2 ra(pa.x + pad, pa.y + pad + i * rowH), rb(pb.x - pad, pa.y + pad + (i + 1) * rowH);
        const int index = s_Combo.offset + i;
        bool sel = *s_Combo.value == index;
        if (sel) DL->AddRectFilled(ra, rb, Acc(0.18f), r * 0.7f);
        else if (i == hovered && io.MouseDown[0]) DL->AddRectFilled(ra, rb, Col(15, 23, 42, 0.06f), r * 0.7f);
        FitText(FText, 19.0f, ImVec2(ra.x + 10 * U, (ra.y + rb.y) * 0.5f), sel ? Acc(1.0f) : Col(51, 65, 85), T(s_Combo.items[index]), (rb.x - ra.x) - 34 * U);
        if (sel) DL->AddCircleFilled(ImVec2(rb.x - 14 * U, (ra.y + rb.y) * 0.5f), 3.5f * U, Acc(1.0f));
    }

    // Кнопка-подложка ловит тап по списку и не даёт тащить окно
    ImGui::SetCursorScreenPos(pa);
    if (ImGui::InvisibleButton("##combo_popup", ImVec2(pb.x - pa.x, pb.y - pa.y - footer))) {
        if (hovered >= 0 && hovered < visible) *s_Combo.value = s_Combo.offset + hovered;
        s_Combo.id = 0;
    } else if (!s_Combo.justOpened && ImGui::IsMouseClicked(0) &&
               !(m.x >= pa.x && m.x <= pb.x && m.y >= pa.y && m.y <= pb.y)) {
        s_Combo.id = 0;   // тап мимо — закрываем
    }
    if (paged && s_Combo.id) {
        const float cy = pb.y - footer * .5f;
        char range[24]; snprintf(range, sizeof(range), "%d-%d / %d", s_Combo.offset + 1, s_Combo.offset + visible, s_Combo.count);
        const ImVec2 ts = TextSize(FText, 14.f, range);
        TextV(FText, 14.f, ImVec2((pa.x + pb.x - ts.x) * .5f, cy), Col(100, 116, 139), range);
        const float buttonW = 36.f * U;
        ImGui::SetCursorScreenPos(ImVec2(pa.x + pad, cy - footer * .5f));
        if (ImGui::InvisibleButton("##combo_previous", ImVec2(buttonW, footer))) s_Combo.offset = ImMax(0, s_Combo.offset - 8);
        IconChevron(ImVec2(pa.x + pad + buttonW * .5f, cy), 10.f * U, Acc(1.f), true);
        ImGui::SetCursorScreenPos(ImVec2(pb.x - pad - buttonW, cy - footer * .5f));
        if (ImGui::InvisibleButton("##combo_next", ImVec2(buttonW, footer)))
            s_Combo.offset = ImMin(((s_Combo.count - 1) / 8) * 8, s_Combo.offset + 8);
        IconChevron(ImVec2(pb.x - pad - buttonW * .5f, cy), 10.f * U, Acc(1.f), false);
    }
    s_Combo.justOpened = false;
}

bool RowButton(const char *id, const char *label, const char *btn, float x0, float x1, float y) {
    btn = T(btn);
    ImVec2 ts = TextSize(FMed, 18.0f, btn);
    float w = ts.x + 36 * U;
    Label(label, x0 + 25, y, (x1 - 22) - w / U - (x0 + 25) - 12);
    ImVec2 b = P(x1 - 22, y + 17);
    ImVec2 a(b.x - w, b.y - 34 * U);
    bool held = false;
    bool clicked = Hit(id, a, b, &held);
    float t = Anim(ImGui::GetID(id), held ? 1.0f : 0.0f, 20.0f);
    DL->AddRectFilled(a, b, LerpCol(Acc(0.08f), Acc(1.0f), t), 17 * U);
    DL->AddRect(a, b, Acc(0.7f), 17 * U, 0, ImMax(1.0f, 1.2f * U));
    DL->AddText(FMed, 18.0f * U, ImVec2(a.x + 18 * U, (a.y + b.y) * 0.5f - 9 * U), LerpCol(Acc(1.0f), Col(255, 255, 255), t), btn);
    return clicked;
}

void RowAccent(const char *id, const char *label, int *v, float x0, float x1, float y) {
    const float r = 10.0f, gap = 12.0f, total = 5 * 2 * r + 4 * gap;
    Label(label, x0 + 25, y, (x1 - 22 - total) - (x0 + 25) - 10);
    for (int i = 0; i < 5; ++i) {
        const float cx = x1 - 22 - r - (4 - i) * (2 * r + gap);
        char hid[32];
        snprintf(hid, sizeof(hid), "%s%d", id, i);
        bool held = false;
        if (Hit(hid, P(cx - r - gap * 0.5f, y - 20), P(cx + r + gap * 0.5f, y + 20), &held)) *v = i;
        const float hv = Anim(ImGui::GetID(hid), held ? 1.0f : 0.0f, 22.0f);
        const float sel = Anim(ImGui::GetID(hid) + 7, *v == i ? 1.0f : 0.0f, 16.0f);
        const ImVec2 c = P(cx, y);
        const int *k = kAccents[i];
        if (sel > 0.01f) DL->AddCircle(c, (r + 5.0f + 1.5f * (1.0f - sel)) * U, Col(k[0], k[1], k[2], 0.9f * sel), 0, ImMax(1.0f, 1.8f * U));
        DL->AddCircleFilled(c, (r - 1.5f * hv) * U, Col(k[0], k[1], k[2]), 24);
        DL->AddCircleFilled(ImVec2(c.x - 2.5f * U, c.y - 3.0f * U), 3.2f * U, Col(255, 255, 255, 0.35f), 12);   // блик
    }
}

// ===================== Карточка =====================
void Card(float x0, float y0, float x1, float y1, int icon, const char *title, float hl) {
    ImVec2 a = P(x0, y0), b = P(x1, y1);
    float r = g_cfg.rounding * U;
    if (g_cfg.shadows) {
        for (int i = 1; i <= 5; i++) {
            float e = i * 2.0f * U;
            DL->AddRectFilled(ImVec2(a.x - e, a.y - e + 3 * U), ImVec2(b.x + e, b.y + e + 3 * U), Col(15, 23, 42, 0.006f), r + e);
        }
    }
    DL->AddRectFilled(a, b, Col(255, 255, 255), r);
    DL->AddRect(a, b, Col(222, 227, 233), r, 0, ImMax(1.0f, 1.2f * U));
    if (hl > 0.01f) DL->AddRect(a, b, Acc(0.12f * hl), r, 0, ImMax(1.0f, 1.6f * U));

    if (!title) return;   // карточка без заголовка
    ImVec2 ic = P(x0 + 40, y0 + 32);
    ImU32 icCol = Acc(1.0f);
    ImU32 bg = Col(255, 255, 255);
    switch (icon) {
        case 0: IconEye(ic, 30 * U, icCol); break;
        case 1: IconSparkles(ic, 30 * U, icCol); break;
        case 2: IconSliders(ic, 28 * U, Col(100, 116, 139), bg); break;
        default: IconGear(ic, 30 * U, Col(100, 116, 139)); break;
    }
    TextV(FMed, 23.0f, P(x0 + 76, y0 + 32), Col(15, 23, 42), T(title));
}

} // namespace UI
