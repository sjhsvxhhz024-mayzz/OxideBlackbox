#pragma once
// Единый стиль ESP «Prism»: им рисуют и оверлей в игре (main.cpp), и превью в меню,
// поэтому превью показывает ровно то, что будет на экране.
//
// ImGui не рисует линии тоньше 1 px (толщина < 1 приравнивается к 1), поэтому
// «тоньше» здесь — это прозрачность: th < 1 оставляет 1 px, но ослабляет линию.
#include "imgui.h"
#include "skeleton.h"
#include <math.h>
#include <stdio.h>

namespace espstyle {

inline ImU32 WithA(ImU32 c, float a) {
    int al = (int)(((c >> IM_COL32_A_SHIFT) & 0xFF) * a + 0.5f);
    if (al < 0) al = 0;
    if (al > 255) al = 255;
    return (c & ~IM_COL32_A_MASK) | ((ImU32)al << IM_COL32_A_SHIFT);
}

// th -> (толщина в px, множитель яркости)
inline void Weight(float th, float &px, float &k) {
    if (th >= 1.0f) { px = th; k = 1.0f; return; }
    px = 1.0f;
    k = th < 0.30f ? 0.30f : th;
}

// Бокс: тонкий контур, яркие угловые скобки, гаснущие вдоль граней, едва заметная
// заливка снизу вверх и тёмная кромка для читаемости на любом фоне.
inline void Box(ImDrawList *dl, ImVec2 a, ImVec2 b, ImU32 col, float th) {
    const float w = b.x - a.x, h = b.y - a.y;
    if (w < 3.0f || h < 3.0f) return;
    float px, k; Weight(th, px, k);
    const float m = w < h ? w : h;

    dl->AddRectFilledMultiColor(a, b, WithA(col, 0.0f), WithA(col, 0.0f), WithA(col, 0.075f * k), WithA(col, 0.075f * k));

    // кромка: снаружи и внутри контура
    dl->AddRect(ImVec2(a.x - 1.0f, a.y - 1.0f), ImVec2(b.x + 1.0f, b.y + 1.0f), IM_COL32(0, 0, 0, (int)(78 * k)), 0, 0, 1.0f);
    dl->AddRect(ImVec2(a.x + 1.0f, a.y + 1.0f), ImVec2(b.x - 1.0f, b.y - 1.0f), IM_COL32(0, 0, 0, (int)(52 * k)), 0, 0, 1.0f);
    // основной тонкий контур
    dl->AddRect(a, b, WithA(col, 0.50f * k), 0, 0, px);

    // угловые скобки: яркие у вершины, плавно затухают
    float L = m * 0.30f;
    if (L < 6.0f) L = 6.0f;
    if (L > 34.0f) L = 34.0f;
    if (L > m * 0.48f) L = m * 0.48f;
    const int steps = 6;
    const ImVec2 cs[4] = { a, ImVec2(b.x, a.y), b, ImVec2(a.x, b.y) };
    for (int i = 0; i < 4; ++i) {
        const float sx = (i == 0 || i == 3) ? 1.0f : -1.0f;
        const float sy = (i < 2) ? 1.0f : -1.0f;
        for (int s = 0; s < steps; ++s) {
            const float t0 = (float)s / steps, t1 = (float)(s + 1) / steps;
            const float f = 1.0f - t0 * 0.78f;
            const ImU32 c = WithA(col, f * k);
            const float tw = px * (1.0f + 0.35f * (1.0f - t0));
            dl->AddLine(ImVec2(cs[i].x + sx * L * t0, cs[i].y), ImVec2(cs[i].x + sx * L * t1, cs[i].y), c, tw);
            dl->AddLine(ImVec2(cs[i].x, cs[i].y + sy * L * t0), ImVec2(cs[i].x, cs[i].y + sy * L * t1), c, tw);
        }
        dl->AddCircleFilled(cs[i], 1.5f + 0.4f * px, WithA(col, k), 8);
    }
}

// Бокс с режимами: corner — только угловые скобки длиной cornerLen от меньшей стороны, fill — ровная заливка с прозрачностью fillA.
inline void BoxEx(ImDrawList *dl, ImVec2 a, ImVec2 b, ImU32 col, float th, bool corner, float cornerLen, bool fill, float fillA) {
    const float w = b.x - a.x, h = b.y - a.y;
    if (w < 3.0f || h < 3.0f) return;
    if (fill) dl->AddRectFilled(a, b, WithA(col, fillA < 0.02f ? 0.02f : fillA > 1.0f ? 1.0f : fillA));
    if (!corner) { Box(dl, a, b, col, th); return; }
    float px, k; Weight(th, px, k);
    const float m = w < h ? w : h;
    float L = m * (cornerLen < 0.08f ? 0.08f : cornerLen > 0.5f ? 0.5f : cornerLen);
    if (L < 4.0f) L = 4.0f;
    const ImVec2 cs[4] = { a, ImVec2(b.x, a.y), b, ImVec2(a.x, b.y) };
    for (int pass = 0; pass < 2; ++pass) {
        const ImU32 c = pass == 0 ? IM_COL32(0, 0, 0, (int)(140 * k)) : WithA(col, k);
        const float tw = pass == 0 ? px + 2.0f : px;
        for (int i = 0; i < 4; ++i) {
            const float sx = (i == 0 || i == 3) ? 1.0f : -1.0f, sy = (i < 2) ? 1.0f : -1.0f;
            dl->AddLine(cs[i], ImVec2(cs[i].x + sx * L, cs[i].y), c, tw);
            dl->AddLine(cs[i], ImVec2(cs[i].x, cs[i].y + sy * L), c, tw);
        }
    }
}


// Линия: растёт в яркости от начала к цели, тёмная подложка, кольцо на конце.
inline void Line(ImDrawList *dl, ImVec2 from, ImVec2 to, ImU32 col, float th) {
    const float dx = to.x - from.x, dy = to.y - from.y;
    const float len = sqrtf(dx * dx + dy * dy);
    if (len < 3.0f) return;
    float px, k; Weight(th, px, k);
    const int N = len > 700.0f ? 28 : (len > 250.0f ? 20 : 12);

    auto at = [&](int i) { const float t = (float)i / N; return ImVec2(from.x + dx * t, from.y + dy * t); };
    auto al = [&](int i) { const float t = (float)i / N; return (0.06f + 0.94f * t * sqrtf(t)) * k; };

    for (int i = 0; i < N; ++i)
        dl->AddLine(at(i), at(i + 1), IM_COL32(0, 0, 0, (int)(70 * al(i + 1))), px + 1.4f);
    for (int i = 0; i < N; ++i)
        dl->AddLine(at(i), at(i + 1), WithA(col, al(i + 1)), px);

    const float r = 3.4f + 0.6f * px;
    dl->AddCircle(to, r, IM_COL32(0, 0, 0, (int)(80 * k)), 20, px + 1.6f);
    dl->AddCircle(to, r, WithA(col, k), 20, px);
    dl->AddCircleFilled(to, 1.1f + 0.3f * px, WithA(col, k), 10);
}

// Скелет: конечности — сужающиеся к концам «капсулы» с круглыми стыками, тёмная обводка для читаемости на любом фоне, суставы и
// кисти/стопы с отдельными маркерами, голова — кольцо с мягкой заливкой и коротким лучом взгляда. Толщина следует за размером игрока
// на экране (bodyPx — высота его бокса в пикселях): вблизи линии плотные, вдали тонкие, но не тоньше 1 px.
// th — множитель толщины (th < 1 даёт те же 1 px, но слабее), P/V — экранные точки и видимость суставов, fade — затухание по дальности.
inline void Skeleton(ImDrawList *dl, const ImVec2 *P, const bool *V,
                     const ImVec2 *FA, const ImVec2 *FB, const bool *FV, int nFine,
                     ImVec2 headC, float headRpx, bool headV, ImVec2 gaze, bool gazeV,
                     ImU32 col, float th, float fade, float bodyPx = 0.0f) {
    using namespace oxskel;
    float scale = 1.0f;
    if (bodyPx > 1.0f) { scale = bodyPx / 165.0f; if (scale < 0.55f) scale = 0.55f; if (scale > 1.9f) scale = 1.9f; }
    float w = th * scale, k = 1.0f;
    if (w < 1.35f) { k = w < 0.40f ? 0.40f : (w < 1.0f ? w : 1.0f); w = 1.35f; }
    k *= fade;
    if (k < 0.04f) return;

    // относительная толщина в суставе: торс плотнее, к кистям и стопам сужается
    static const float jw[J_COUNT] = {
        0.90f, 0.95f, 1.45f, 1.40f, 1.40f,                   // HEAD NECK CHEST SPINE PELVIS
        1.20f, 1.20f, 1.00f, 1.00f, 0.78f, 0.78f,            // SH EL HAND
        1.25f, 1.25f, 1.05f, 1.05f, 0.85f, 0.85f, 0.62f, 0.62f,   // HIP KNEE FOOT TOE
    };
    // яркость сустава: торс — полная, конечности убывают
    static const float jb[J_COUNT] = {
        0.95f, 0.98f, 1.00f, 1.00f, 1.00f,
        0.95f, 0.95f, 0.85f, 0.85f, 0.70f, 0.70f,
        0.95f, 0.95f, 0.85f, 0.85f, 0.72f, 0.72f, 0.55f, 0.55f,
    };
    struct Bone { int a, b; };
    static const Bone bones[] = {
        { J_PELVIS, J_SPINE }, { J_SPINE, J_CHEST }, { J_CHEST, J_NECK }, { J_NECK, J_HEAD },
        { J_SH_R, J_CHEST }, { J_CHEST, J_SH_L }, { J_HIP_R, J_PELVIS }, { J_PELVIS, J_HIP_L },
        { J_SH_R, J_EL_R }, { J_EL_R, J_HAND_R }, { J_SH_L, J_EL_L }, { J_EL_L, J_HAND_L },
        { J_HIP_R, J_KNEE_R }, { J_KNEE_R, J_FOOT_R }, { J_FOOT_R, J_TOE_R },
        { J_HIP_L, J_KNEE_L }, { J_KNEE_L, J_FOOT_L }, { J_FOOT_L, J_TOE_L },
    };
    const int nb = (int)(sizeof(bones) / sizeof(bones[0]));

    // шея упирается в кольцо головы, а не проходит сквозь него
    const bool ring = headV && headRpx > 1.5f;
    ImVec2 end[18];
    for (int i = 0; i < nb; ++i) {
        end[i] = P[bones[i].b];
        if (ring && bones[i].b == J_HEAD) {
            const float dx = P[bones[i].a].x - headC.x, dy = P[bones[i].a].y - headC.y, d = sqrtf(dx * dx + dy * dy);
            if (d > headRpx) end[i] = ImVec2(headC.x + dx / d * headRpx, headC.y + dy / d * headRpx);
        }
    }

    // капсула: четырёхугольник со сужением + круглые торцы (точки обхода по часовой стрелке — нужно для сглаживания краёв)
    auto limb = [&](ImVec2 a, ImVec2 b, float wa, float wb, ImU32 c) {
        const float dx = b.x - a.x, dy = b.y - a.y, d = sqrtf(dx * dx + dy * dy);
        if (d < 0.6f) { dl->AddCircleFilled(a, wa * 0.5f, c, 10); return; }
        const float nx = -dy / d, ny = dx / d;
        const ImVec2 q[4] = { ImVec2(a.x - nx * wa * 0.5f, a.y - ny * wa * 0.5f), ImVec2(b.x - nx * wb * 0.5f, b.y - ny * wb * 0.5f),
                              ImVec2(b.x + nx * wb * 0.5f, b.y + ny * wb * 0.5f), ImVec2(a.x + nx * wa * 0.5f, a.y + ny * wa * 0.5f) };
        dl->AddConvexPolyFilled(q, 4, c);
        dl->AddCircleFilled(a, wa * 0.5f, c, 10);
        dl->AddCircleFilled(b, wb * 0.5f, c, 10);
    };
    const float rim = 0.9f + 0.25f * w;

    // 1) мягкое свечение вблизи и тёмная обводка
    for (int i = 0; i < nb; ++i) {
        const Bone &bn = bones[i];
        if (!V[bn.a] || !V[bn.b]) continue;
        const float wa = w * jw[bn.a], wb = w * jw[bn.b], wm = 0.5f * (jb[bn.a] + jb[bn.b]);
        if (scale > 0.8f) limb(P[bn.a], end[i], wa + 4.5f, wb + 4.5f, WithA(col, 0.055f * k * wm));
        limb(P[bn.a], end[i], wa + rim * 2.0f, wb + rim * 2.0f, IM_COL32(0, 0, 0, (int)(92 * k * wm)));
    }
    // 2) мелкие кости (пальцы, носки): тоньше и тусклее основных, только когда игрок достаточно крупный
    if (scale > 0.62f) {
        for (int i = 0; i < nFine; ++i) {
            if (!FV[i]) continue;
            const float dx = FB[i].x - FA[i].x, dy = FB[i].y - FA[i].y;
            if (dx * dx + dy * dy < 0.8f) continue;
            dl->AddLine(FA[i], FB[i], IM_COL32(0, 0, 0, (int)(56 * k)), w * 0.5f + 1.2f);
            dl->AddLine(FA[i], FB[i], WithA(col, 0.60f * k), w * 0.5f > 1.0f ? w * 0.5f : 1.0f);
        }
    }
    // 3) основные кости
    for (int i = 0; i < nb; ++i) {
        const Bone &bn = bones[i];
        if (!V[bn.a] || !V[bn.b]) continue;
        const float wm = 0.5f * (jb[bn.a] + jb[bn.b]);
        limb(P[bn.a], end[i], w * jw[bn.a], w * jw[bn.b], WithA(col, (0.58f + 0.42f * wm) * k));
    }
    // 4) суставы: яркие точки в локтях, коленях, плечах и бёдрах, кольца на кистях и стопах
    static const int dots[] = { J_SH_R, J_SH_L, J_EL_R, J_EL_L, J_HIP_R, J_HIP_L, J_KNEE_R, J_KNEE_L };
    for (int j : dots) {
        if (!V[j]) continue;
        dl->AddCircleFilled(P[j], w * jw[j] * 0.62f + 0.25f, WithA(col, k), 10);
    }
    static const int ends[] = { J_HAND_R, J_HAND_L, J_FOOT_R, J_FOOT_L };
    for (int j : ends) {
        if (!V[j]) continue;
        const float r = w * 0.78f + 0.9f;
        dl->AddCircleFilled(P[j], r, WithA(col, 0.22f * k), 12);
        dl->AddCircle(P[j], r + 0.7f, IM_COL32(0, 0, 0, (int)(70 * k)), 12, w * 0.7f + 1.2f);
        dl->AddCircle(P[j], r, WithA(col, 0.92f * jb[j] * k), 12, w * 0.7f > 1.0f ? w * 0.7f : 1.0f);
    }
    // 5) голова: мягкая заливка, обводка, кольцо, короткий луч взгляда
    if (ring) {
        const float rw = w * 0.95f > 1.0f ? w * 0.95f : 1.0f;
        dl->AddCircleFilled(headC, headRpx, WithA(col, 0.10f * k), 32);
        dl->AddCircle(headC, headRpx, IM_COL32(0, 0, 0, (int)(90 * k)), 32, rw + 2.2f);
        dl->AddCircle(headC, headRpx, WithA(col, k), 32, rw);
        if (gazeV) {
            const float dx = gaze.x - headC.x, dy = gaze.y - headC.y, d = sqrtf(dx * dx + dy * dy);
            if (d > 1.0f) {
                const float ux = dx / d, uy = dy / d;
                const ImVec2 e(headC.x + ux * headRpx, headC.y + uy * headRpx);
                const ImVec2 t(headC.x + ux * headRpx * 1.75f, headC.y + uy * headRpx * 1.75f);
                dl->AddLine(e, t, IM_COL32(0, 0, 0, (int)(80 * k)), rw + 2.0f);
                dl->AddLine(e, t, WithA(col, 0.95f * k), rw);
                dl->AddCircleFilled(t, rw * 0.75f + 0.5f, WithA(col, k), 8);
            }
        }
    }
}


// ── Значения стиля по умолчанию (одни и те же в оверлее и в кнопках Reset меню) ─────────────────────
inline constexpr float kBoxStroke = 0.85f;
inline constexpr float kLineStroke = 0.75f;
inline constexpr float kSkelStroke = 1.90f;     // множитель толщины: в пикселях зависит от размера игрока на экране
inline constexpr float kBoxColor[3] = { 1.0f, 1.0f, 1.0f };
inline constexpr float kLineColor[3] = { 1.0f, 1.0f, 1.0f };
inline constexpr float kSkelColor[3] = { 0.42f, 0.88f, 1.00f };   // холодный голубой: отличим от белого бокса
inline constexpr float kNameColor[3] = { 1.0f, 1.0f, 1.0f };
inline constexpr float kClanColor[3] = { 0.55f, 0.80f, 1.0f };
inline constexpr float kTextSize = 1.0f;     // множитель TextBase()
inline constexpr int   kHpStyle = 0;         // 0 слева, 1 справа, 2 снизу
inline constexpr float kHpWidth = 4.0f;      // px
inline constexpr float kHpDamage = 0.0f;     // урон одного попадания для оценки HP: 0 = авто (оружие в руках)
inline constexpr float kHpCrit = 2.0f;       // множитель попадания в голову

// ── Текст ──────────────────────────────────────────────────────────────────────────────────────────
// Базовый размер подписей: 20 px на экране высотой 1080, дальше пропорционально.
inline float TextBase(float screenH) {
    const float s = 20.0f * screenH / 1080.0f;
    return s < 11.0f ? 11.0f : (s > 40.0f ? 40.0f : s);
}

// Текст с тёмным контуром: читается на любом фоне без плашки.
inline void ShadowText(ImDrawList *dl, ImFont *font, float size, ImVec2 p, ImU32 col, const char *t) {
    const float o = size < 24.0f ? 1.0f : 1.5f;
    const ImU32 sh = IM_COL32(0, 0, 0, 185);
    dl->AddText(font, size, ImVec2(p.x - o, p.y), sh, t);
    dl->AddText(font, size, ImVec2(p.x + o, p.y), sh, t);
    dl->AddText(font, size, ImVec2(p.x, p.y - o), sh, t);
    dl->AddText(font, size, ImVec2(p.x, p.y + o), sh, t);
    dl->AddText(font, size, p, col, t);
}

// Строка «[КЛАН] Ник» по центру над боксом. bottom — нижняя кромка текста; возвращает верхнюю
// (над ней можно ставить следующую строку). Пустые клан/ник пропускаются.
inline float Tag(ImDrawList *dl, ImFont *font, float cx, float bottom,
                 const char *clan, ImU32 clanCol, float clanPx, const char *name, ImU32 nameCol, float namePx) {
    const bool hc = clan && clan[0], hn = name && name[0];
    if (!hc && !hn) return bottom;
    char tag[112];
    if (hc) snprintf(tag, sizeof(tag), "[%s]", clan);
    const ImVec2 sc = hc ? font->CalcTextSizeA(clanPx, 100000.0f, 0.0f, tag) : ImVec2(0, 0);
    const ImVec2 sn = hn ? font->CalcTextSizeA(namePx, 100000.0f, 0.0f, name) : ImVec2(0, 0);
    const float gap = (hc && hn) ? 0.30f * namePx : 0.0f;
    const float w = sc.x + gap + sn.x, h = sc.y > sn.y ? sc.y : sn.y;
    float x = cx - w * 0.5f;
    const float y = bottom - h;
    if (hc) { ShadowText(dl, font, clanPx, ImVec2(x, y + (h - sc.y) * 0.5f), clanCol, tag); x += sc.x + gap; }
    if (hn) ShadowText(dl, font, namePx, ImVec2(x, y + (h - sn.y) * 0.5f), nameCol, name);
    return y;
}

// ── HP ─────────────────────────────────────────────────────────────────────────────────────────────
// Цвет по доле здоровья: красный -> жёлтый -> зелёный.
inline ImU32 HpColor(float f, float alpha = 1.0f) {
    float r, g, b;
    ImGui::ColorConvertHSVtoRGB(0.34f * f, 0.78f, 0.96f, r, g, b);
    return IM_COL32((int)(r * 255.0f + 0.5f), (int)(g * 255.0f + 0.5f), (int)(b * 255.0f + 0.5f), (int)(alpha * 255.0f + 0.5f));
}

// Полоса HP у бокса [a, b]: style 0 слева, 1 справа, 2 снизу. width — толщина в px, number — цифра рядом,
// armor > 0 — синяя цифра брони под HP (только у вертикальных полос). Высота стека под боксом при
// style 2 — HpBottomExtent().
inline float HpBottomExtent(float width) { return width + 8.0f; }

inline void HpBar(ImDrawList *dl, ImFont *font, float textPx, ImVec2 a, ImVec2 b, float hp, float hpMax,
                  int style, float width, bool number, int armor) {
    if (b.x - a.x < 3.0f || b.y - a.y < 3.0f) return;
    const float mx = hpMax > 1.0f ? hpMax : 100.0f;
    float f = hp / mx;
    const bool over = f > 1.001f;
    f = f < 0.0f ? 0.0f : (f > 1.0f ? 1.0f : f);
    const ImU32 col = over ? IM_COL32(90, 160, 255, 255) : HpColor(f);
    const float w = width < 2.0f ? 2.0f : (width > 14.0f ? 14.0f : width);
    const bool vertical = style != 2;
    ImVec2 t0, t1;
    if (style == 0)      { t1 = ImVec2(a.x - 4.0f, b.y); t0 = ImVec2(t1.x - w, a.y); }
    else if (style == 1) { t0 = ImVec2(b.x + 4.0f, a.y); t1 = ImVec2(t0.x + w, b.y); }
    else                 { t0 = ImVec2(a.x, b.y + 4.0f); t1 = ImVec2(b.x, t0.y + w); }
    const float r = (w < 6.0f ? w : 6.0f) * 0.5f;

    dl->AddRectFilled(ImVec2(t0.x - 1.5f, t0.y - 1.5f), ImVec2(t1.x + 1.5f, t1.y + 1.5f), IM_COL32(0, 0, 0, 150), r + 1.5f);
    dl->AddRectFilled(t0, t1, IM_COL32(18, 22, 32, 215), r);
    ImVec2 f0 = t0, f1 = t1;
    if (vertical) f0.y = t1.y - (t1.y - t0.y) * f; else f1.x = t0.x + (t1.x - t0.x) * f;
    if (f > 0.0f) {
        dl->AddRectFilled(ImVec2(f0.x - 2.0f, f0.y - 1.0f), ImVec2(f1.x + 2.0f, f1.y + 1.0f), WithA(col, 0.20f), r + 1.0f);
        dl->AddRectFilled(f0, f1, col, r);
        if (vertical) dl->AddRectFilled(ImVec2(f0.x, f0.y), ImVec2(f0.x + (f1.x - f0.x) * 0.35f, f1.y), IM_COL32(255, 255, 255, 38), r);
        else          dl->AddRectFilled(ImVec2(f0.x, f0.y), ImVec2(f1.x, f0.y + (f1.y - f0.y) * 0.35f), IM_COL32(255, 255, 255, 38), r);
    }
    if (vertical && (t1.y - t0.y) > 70.0f) {                      // деления 25 / 50 / 75 %
        for (int i = 1; i <= 3; ++i) {
            const float y = t1.y - (t1.y - t0.y) * 0.25f * i;
            dl->AddLine(ImVec2(t0.x, y), ImVec2(t1.x, y), IM_COL32(0, 0, 0, 95), 1.0f);
        }
    }
    if (!number && armor <= 0) return;
    const float tp = textPx * 0.9f;
    char buf[16];
    if (number) {
        snprintf(buf, sizeof(buf), "%d", (int)(hp + 0.5f));
        const ImVec2 sz = font->CalcTextSizeA(tp, 100000.0f, 0.0f, buf);
        ImVec2 p;
        if (style == 0)      p = ImVec2(t0.x - 4.0f - sz.x, f0.y - sz.y * 0.5f);
        else if (style == 1) p = ImVec2(t1.x + 4.0f, f0.y - sz.y * 0.5f);
        else                 p = ImVec2(t1.x + 5.0f, (t0.y + t1.y - sz.y) * 0.5f);
        if (vertical) { if (p.y < a.y) p.y = a.y; if (p.y > b.y - sz.y) p.y = b.y - sz.y; }
        ShadowText(dl, font, tp, p, IM_COL32(255, 255, 255, 255), buf);
    }
    if (armor > 0 && vertical) {
        snprintf(buf, sizeof(buf), "%d", armor);
        const ImVec2 sz = font->CalcTextSizeA(tp, 100000.0f, 0.0f, buf);
        ShadowText(dl, font, tp, ImVec2(style == 0 ? t0.x - 4.0f - sz.x : t1.x + 4.0f, b.y - sz.y), IM_COL32(120, 190, 255, 255), buf);
    }
}

} // namespace espstyle
