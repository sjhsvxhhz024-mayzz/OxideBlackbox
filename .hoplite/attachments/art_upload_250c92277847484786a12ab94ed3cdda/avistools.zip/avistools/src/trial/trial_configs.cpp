// Конфиги: реестр настроек, готовые пресеты, пользовательские слоты в /sdcard/Download/AvisTools/configs.
#include "trial_config.h"
#include "trial_configs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string>
#include <vector>

#include "trial_cfg_externs.inc"

namespace {

// type: b bool, i int, f float, c цвет из трёх float. scope 1 — только автосохранение (включатели): в пресеты, слоты и сброс не входят.
struct Entry { const char *key; char type; void *p; float *def; int scope; };
std::vector<Entry> g_reg;
std::string g_msg;
bool g_ready = false;

#define B(n) { #n, 'b', (void *)&n, nullptr }
#define I(n) { #n, 'i', (void *)&n, nullptr }
#define F(n) { #n, 'f', (void *)&n, nullptr }
#define C(n) { #n, 'c', (void *)n, nullptr }

void BuildRegistry() {
    if (!g_reg.empty()) return;
    const Entry all[] = {
        // ESP игроков
        B(espdraw), B(espbox), B(espCornerBox), B(espfill), B(esplines_enabled), B(skeleton), B(espname), B(espclan), B(espdist), B(espFlags),
        B(espDistColor), B(espweapon), B(espArmor), B(radarEnabled),
        F(espstroke), F(espfillp), F(espCornerLength), F(esplines_thickness), F(skeleton_stroke), F(espnamesize), F(espclansize), F(espMaxDistance),
        I(esplines_position), C(espboxcolor), C(esplines_color), C(skeleton_color), C(espnamecolor), C(espclancolor),
        F(radarRange), F(radarSize), F(radarAlpha),
        // руда
        B(oreEsp), B(oreStone), B(oreMetal), B(oreSulfur), B(oreCoal), B(oreDistText), F(oreMaxDist),
        // животные
        B(animalEsp), B(animalBear), B(animalBoar), B(animalDeer), B(animalRabbit), B(animalHare), B(animalChicken), B(animalFish), B(animalRat),
        B(animalCannibal), B(animalDistText), F(animalMaxDist),
        // база
        B(baseEsp), B(baseCupboard), B(baseTurret), B(baseBag), B(baseSleeper), B(baseDistText), F(baseMaxDist),
        B(cupboardFinder), B(cupboardGuide), F(cupboardRadius),
        F(xrayDistance), // X-ray enable is deliberately not persisted.
        B(chamsOn), B(chamsAnimated), B(chamsDissolve), I(chamsStyle),
        F(chamsOpacity), F(chamsGlow), F(chamsSpeed), F(chamsDuration), F(chamsRange),
        // аим (включатель aimm в конфиг не входит: пресет не должен сам включать наводку)
        B(aimPrediction), B(aimDrawFov), B(aimDrawTarget), B(aimSticky), B(aimHoriz), B(aimVert), B(aimSkipSleeping), B(aimSkipSpectating), B(aimvisible),
        B(aimSmoothConst), B(aimRecoilComp),
        I(aimTriggerMode), I(aimcurbone),
        F(aimFovPixels), F(aimSmooth), F(aimMaxDistance), F(aimMaxSpeed), F(aimDeadzone), F(aimSwitchMargin), F(aimFireHold), F(aimSettleDeg), F(aimRampMs),
        F(aimProjectileSpeed), F(aimLatencyMs), F(aimMaxLeadTime), F(aimProjectileGravity), F(aimPredictIters),
        B(silentPredict), B(silentSkipSleeping), B(silentSkipSpectating), B(silentDrawFov), { "silentZone2", 'i', (void *)&silentZone, nullptr, 0 }, F(silentFovPx), F(silentRange), F(silentLeadMs), F(silentMaxCorr), B(silentOnlyFiring),
        { "accent", 'i', (void *)&g_cfg.accent, nullptr, 0 },
        { "aimm", 'b', (void *)&aimm, nullptr, 1 },
        { "silentAim", 'b', (void *)&silentAim, nullptr, 1 },
        { "noRecoil", 'b', (void *)&noRecoil, nullptr, 1 },
        { "noSpread", 'b', (void *)&noSpread, nullptr, 1 },
        { "stretchOn", 'b', (void *)&stretchOn, nullptr, 1 },
        { "stretchMode", 'i', (void *)&stretchMode, nullptr, 0 },
        { "stretchCustom", 'f', (void *)&stretchCustom, nullptr, 0 },
        { "boostDraw", 'b', (void *)&boostDraw, nullptr, 1 },
        { "boostDrawDist", 'f', (void *)&boostDrawDist, nullptr, 1 },
        { "boostGrass", 'b', (void *)&boostGrass, nullptr, 1 },
        { "boostTrees", 'b', (void *)&boostTrees, nullptr, 1 },
        { "boostFpsMode", 'i', (void *)&boostFpsMode, nullptr, 1 },
        { "boostNoLog", 'b', (void *)&boostNoLog, nullptr, 1 },
    };
    for (const Entry &e : all) g_reg.push_back(e);
}
#undef B
#undef I
#undef F
#undef C

int ElemCount(const Entry &e) { return e.type == 'c' ? 3 : 1; }
float ReadF(const Entry &e, int k) {
    switch (e.type) {
        case 'b': return *(bool *)e.p ? 1.f : 0.f;
        case 'i': return (float)*(int *)e.p;
        default:  return ((float *)e.p)[k];
    }
}
void WriteF(const Entry &e, int k, float v) {
    switch (e.type) {
        case 'b': *(bool *)e.p = v > 0.5f; break;
        case 'i': *(int *)e.p = (int)lroundf(v); break;
        default:  ((float *)e.p)[k] = v; break;
    }
}

// Заводские значения = значения на момент первого обращения (инициализаторы из main.cpp).
void Snapshot() {
    if (g_ready) return;
    BuildRegistry();
    for (Entry &e : g_reg) {
        const int n = ElemCount(e);
        e.def = (float *)malloc(sizeof(float) * n);
        for (int k = 0; k < n; ++k) e.def[k] = ReadF(e, k);
    }
    g_ready = true;
}

Entry *Find(const char *key) {
    for (Entry &e : g_reg) if (!strcmp(e.key, key)) return &e;
    return nullptr;
}

void Set(const char *key, float a, float b = 0.f, float c = 0.f) {
    Entry *e = Find(key);
    if (!e) return;
    WriteF(*e, 0, a);
    if (e->type == 'c') { WriteF(*e, 1, b); WriteF(*e, 2, c); }
}

// ── Пресеты ──────────────────────────────────────────────────────────────────
struct KV { const char *key; float v[3]; };
struct Preset { CfgPresetInfo info; const KV *kv; int n; };

#define BOX(r, g, b) { "espboxcolor", { r, g, b } }
#define SKL(r, g, b) { "skeleton_color", { r, g, b } }
#define LIN(r, g, b) { "esplines_color", { r, g, b } }
#define NAM(r, g, b) { "espnamecolor", { r, g, b } }
#define CLN(r, g, b) { "espclancolor", { r, g, b } }
#define ON(k) { #k, { 1, 0, 0 } }
#define OFF(k) { #k, { 0, 0, 0 } }
#define VAL(k, x) { #k, { x, 0, 0 } }

const KV kPrism[] = { VAL(accent, 1) };                                           // заводской вид; остальное — сброс к значениям по умолчанию

const KV kNeon[] = {
    VAL(accent, 2), BOX(0.20f, 0.95f, 1.00f), SKL(1.00f, 0.25f, 0.85f), LIN(0.62f, 0.30f, 1.00f), NAM(0.92f, 1.00f, 1.00f), CLN(0.20f, 0.95f, 1.00f),
    ON(espCornerBox), ON(espfill), VAL(espfillp, 0.10f), VAL(espstroke, 1.40f), VAL(skeleton_stroke, 2.10f), VAL(esplines_thickness, 1.0f),
    ON(espdist), ON(espFlags), ON(espname), ON(espclan),
};
const KV kCrimson[] = {
    VAL(accent, 4), BOX(1.00f, 0.22f, 0.28f), SKL(1.00f, 0.58f, 0.25f), LIN(1.00f, 0.30f, 0.30f), NAM(1.00f, 0.95f, 0.95f), CLN(1.00f, 0.70f, 0.35f),
    OFF(espCornerBox), ON(espfill), VAL(espfillp, 0.07f), VAL(espstroke, 1.20f), VAL(skeleton_stroke, 1.9f), VAL(esplines_thickness, 0.9f),
    ON(espname), ON(espdist),
};
const KV kToxic[] = {
    VAL(accent, 3), BOX(0.55f, 1.00f, 0.25f), SKL(0.85f, 1.00f, 0.35f), LIN(0.35f, 1.00f, 0.55f), NAM(0.92f, 1.00f, 0.75f), CLN(0.40f, 1.00f, 0.60f),
    ON(espCornerBox), OFF(espfill), VAL(espstroke, 1.30f), VAL(skeleton_stroke, 2.0f), VAL(esplines_thickness, 0.9f), ON(espname), ON(espclan),
};
const KV kArctic[] = {
    VAL(accent, 0), BOX(0.85f, 0.95f, 1.00f), SKL(0.55f, 0.80f, 1.00f), LIN(0.70f, 0.88f, 1.00f), NAM(1.00f, 1.00f, 1.00f), CLN(0.60f, 0.85f, 1.00f),
    ON(espCornerBox), ON(espfill), VAL(espfillp, 0.05f), VAL(espstroke, 1.00f), VAL(skeleton_stroke, 1.7f), VAL(esplines_thickness, 0.8f), ON(espname),
};
const KV kGold[] = {
    VAL(accent, 4), BOX(1.00f, 0.82f, 0.30f), SKL(1.00f, 0.93f, 0.65f), LIN(1.00f, 0.75f, 0.20f), NAM(1.00f, 0.96f, 0.82f), CLN(1.00f, 0.70f, 0.30f),
    ON(espCornerBox), ON(espfill), VAL(espfillp, 0.08f), VAL(espstroke, 1.30f), VAL(skeleton_stroke, 2.0f), VAL(esplines_thickness, 1.0f),
    ON(espname), ON(espclan), ON(espdist),
};
const KV kGhost[] = {
    VAL(accent, 0), BOX(0.92f, 0.92f, 0.96f), SKL(0.88f, 0.90f, 0.96f), LIN(0.80f, 0.80f, 0.85f), NAM(0.92f, 0.92f, 0.96f), CLN(0.70f, 0.75f, 0.85f),
    ON(espCornerBox), OFF(espfill), VAL(espstroke, 0.60f), VAL(skeleton_stroke, 1.3f), OFF(esplines_enabled), VAL(espnamesize, 0.85f), VAL(espclansize, 0.80f),
    ON(espname), OFF(espdist), OFF(espFlags),
};
const KV kLegit[] = {
    VAL(accent, 0), BOX(0.90f, 0.93f, 0.98f), SKL(0.62f, 0.82f, 1.00f), LIN(0.75f, 0.85f, 1.00f), NAM(0.95f, 0.95f, 0.98f), CLN(0.60f, 0.80f, 1.00f),
    ON(espCornerBox), OFF(espfill), VAL(espstroke, 0.70f), VAL(skeleton_stroke, 1.5f), OFF(esplines_enabled), ON(espname), OFF(espFlags),
    // аим: узкий FOV, плавно, только при прицеливании или стрельбе, без рисования цели
    VAL(aimFovPixels, 110), VAL(aimSmooth, 14), VAL(aimTriggerMode, 4), VAL(aimcurbone, 2), VAL(aimMaxDistance, 160), OFF(aimDrawFov), OFF(aimDrawTarget),
    ON(aimSticky), VAL(aimMaxSpeed, 260), VAL(aimRampMs, 220), VAL(aimSettleDeg, 1.2f),
};
const KV kRage[] = {
    VAL(accent, 4), BOX(1.00f, 0.30f, 0.40f), SKL(1.00f, 1.00f, 1.00f), LIN(1.00f, 0.40f, 0.40f), NAM(1.00f, 1.00f, 1.00f), CLN(1.00f, 0.75f, 0.40f),
    ON(espbox), OFF(espCornerBox), ON(espfill), VAL(espfillp, 0.12f), VAL(espstroke, 1.5f), ON(skeleton), VAL(skeleton_stroke, 2.2f), ON(esplines_enabled),
    VAL(esplines_thickness, 1.1f), ON(espname), ON(espclan), ON(espdist), ON(espFlags), ON(espweapon), ON(espArmor), ON(radarEnabled),
    VAL(aimFovPixels, 420), VAL(aimSmooth, 2.5f), VAL(aimTriggerMode, 0), VAL(aimcurbone, 3), VAL(aimMaxDistance, 500), ON(aimDrawFov), ON(aimDrawTarget),
    VAL(aimMaxSpeed, 1800), VAL(aimRampMs, 60), VAL(aimSettleDeg, 0.6f),
};

const Preset kPresets[] = {
    { { "Prism",      "Заводской вид: белый бокс, голубой скелет",              { 1.00f, 1.00f, 1.00f }, { 0.42f, 0.88f, 1.00f }, { 1.00f, 1.00f, 1.00f } }, kPrism,   (int)(sizeof(kPrism) / sizeof(KV)) },
    { { "Neon Cyber", "Циан и маджента, угловой бокс, лёгкая заливка",           { 0.20f, 0.95f, 1.00f }, { 1.00f, 0.25f, 0.85f }, { 0.62f, 0.30f, 1.00f } }, kNeon,    (int)(sizeof(kNeon) / sizeof(KV)) },
    { { "Crimson",    "Красный бокс и оранжевый скелет",                         { 1.00f, 0.22f, 0.28f }, { 1.00f, 0.58f, 0.25f }, { 1.00f, 0.30f, 0.30f } }, kCrimson, (int)(sizeof(kCrimson) / sizeof(KV)) },
    { { "Toxic",      "Кислотно-зелёный, угловой бокс",                          { 0.55f, 1.00f, 0.25f }, { 0.85f, 1.00f, 0.35f }, { 0.35f, 1.00f, 0.55f } }, kToxic,   (int)(sizeof(kToxic) / sizeof(KV)) },
    { { "Arctic",     "Холодный белый и голубой, тонкие линии",                  { 0.85f, 0.95f, 1.00f }, { 0.55f, 0.80f, 1.00f }, { 0.70f, 0.88f, 1.00f } }, kArctic,  (int)(sizeof(kArctic) / sizeof(KV)) },
    { { "Gold Rush",  "Золото и тёплый белый, угловой бокс с заливкой",          { 1.00f, 0.82f, 0.30f }, { 1.00f, 0.93f, 0.65f }, { 1.00f, 0.75f, 0.20f } }, kGold,    (int)(sizeof(kGold) / sizeof(KV)) },
    { { "Ghost",      "Минимализм: тонкие углы, без линий",                      { 0.92f, 0.92f, 0.96f }, { 0.88f, 0.90f, 0.96f }, { 0.80f, 0.80f, 0.85f } }, kGhost,   (int)(sizeof(kGhost) / sizeof(KV)) },
    { { "Legit",      "Неброский вид и аккуратный аим: узкий FOV, плавно",       { 0.90f, 0.93f, 0.98f }, { 0.62f, 0.82f, 1.00f }, { 0.75f, 0.85f, 1.00f } }, kLegit,   (int)(sizeof(kLegit) / sizeof(KV)) },
    { { "Rage",       "Всё включено, широкий FOV, быстрая наводка",              { 1.00f, 0.30f, 0.40f }, { 1.00f, 1.00f, 1.00f }, { 1.00f, 0.40f, 0.40f } }, kRage,    (int)(sizeof(kRage) / sizeof(KV)) },
};
const int kPresetN = (int)(sizeof(kPresets) / sizeof(kPresets[0]));

// ── Файлы ────────────────────────────────────────────────────────────────────
const char *kDir = "/sdcard/Download/AvisTools/configs";
static const char *ConfigDir() {
#ifdef AVIS_PREVIEW
    static std::string path;path=g_DataDir+"/configs";return path.c_str();
#else
    return kDir;
#endif
}

bool MkDirs(const char *path) {
    std::string cur;
    for (const char *p = path; *p; ++p) {
        cur.push_back(*p);
        if (*p == '/' && cur.size() > 1) mkdir(cur.c_str(), 0777);
    }
    return mkdir(path, 0777) == 0 || errno == EEXIST;
}
std::string SlotPath(int slot) { char b[96]; snprintf(b, sizeof(b), "%s/custom_%d.cfg", ConfigDir(), slot + 1); return b; }
#ifndef AVIS_PREVIEW
// Одноразовая совместимость с настройками, сохранёнными до переименования.
std::string LegacySlotPath(int slot) {
    char b[104];
    snprintf(b, sizeof(b), "/sdcard/Download/EclipsOxide/configs/custom_%d.cfg", slot + 1);
    return b;
}
#endif

} // namespace

int Cfg_PresetCount() { return kPresetN; }
const CfgPresetInfo &Cfg_PresetInfo(int i) { return kPresets[i < 0 ? 0 : i >= kPresetN ? kPresetN - 1 : i].info; }
const char *Cfg_Dir() { return ConfigDir(); }
const char *Cfg_LastMessage() { return g_msg.c_str(); }
void Cfg_Snapshot() { Snapshot(); }

void Cfg_ResetDefaults() {
    Snapshot();
    for (Entry &e : g_reg) { if (e.scope) continue; for (int k = 0; k < ElemCount(e); ++k) WriteF(e, k, e.def[k]); }
}

void Cfg_ApplyPreset(int i) {
    if (i < 0 || i >= kPresetN) return;
    Cfg_ResetDefaults();                                    // пресет описывает отличия от заводского вида
    const Preset &p = kPresets[i];
    for (int k = 0; k < p.n; ++k) Set(p.kv[k].key, p.kv[k].v[0], p.kv[k].v[1], p.kv[k].v[2]);
    g_msg = std::string("Применён пресет: ") + p.info.name;
}

bool Cfg_SlotExists(int slot) {
    if (slot < 0 || slot >= kCfgSlots) return false;
    if (access(SlotPath(slot).c_str(), R_OK) == 0) return true;
#ifndef AVIS_PREVIEW
    return access(LegacySlotPath(slot).c_str(), R_OK) == 0;
#else
    return false;
#endif
}

namespace {

std::string Serialize(bool all) {
    std::string out = "# Avis tools config v1\n";
    char buf[160];
    for (const Entry &e : g_reg) {
        if (e.scope && !all) continue;
        if (e.type == 'c') snprintf(buf, sizeof(buf), "%s=%.4f,%.4f,%.4f\n", e.key, ((float *)e.p)[0], ((float *)e.p)[1], ((float *)e.p)[2]);
        else if (e.type == 'f') snprintf(buf, sizeof(buf), "%s=%.5g\n", e.key, ReadF(e, 0));
        else snprintf(buf, sizeof(buf), "%s=%d\n", e.key, (int)lroundf(ReadF(e, 0)));
        out += buf;
    }
    return out;
}

bool WriteText(const std::string &path, const std::string &text) {
    const size_t slash = path.find_last_of('/');
    if (slash != std::string::npos && !MkDirs(path.substr(0, slash).c_str())) return false;
    const std::string tmp = path + ".tmp";
    FILE *f = fopen(tmp.c_str(), "w");
    if (!f) return false;
    const bool wrote = fwrite(text.data(), 1, text.size(), f) == text.size();
    const bool closed = fclose(f) == 0;
    if (wrote && closed && rename(tmp.c_str(), path.c_str()) == 0) return true;
    unlink(tmp.c_str());
    return false;
}

// Читает файл «ключ=значение»; значения проверяются и ограничиваются диапазоном, битые строки пропускаются. Возвращает число применённых.
int ReadFile(const char *path, bool all, bool *existed) {
    FILE *f = fopen(path, "r");
    if (existed) *existed = f != nullptr;
    if (!f) return 0;
    char line[256];
    int applied = 0;
    while (fgets(line, sizeof(line), f)) {
        if (line[0] == '#' || line[0] == '\n') continue;
        char *eq = strchr(line, '=');
        if (!eq) continue;
        *eq = 0;
        Entry *e = Find(line);
        if (!e || (e->scope && !all)) continue;
        const char *val = eq + 1;
        float v[3] = { 0, 0, 0 };
        const int n = e->type == 'c' ? 3 : 1;
        char *end = nullptr;
        bool ok = true;
        for (int k = 0; k < n && ok; ++k) {
            v[k] = strtof(val, &end);
            if (end == val || !isfinite(v[k])) ok = false;
            val = end;
            if (k + 1 < n) { if (*val != ',') ok = false; else ++val; }
        }
        if (!ok) continue;
        for (int k = 0; k < n; ++k) {
            float x = v[k];
            if (e->type == 'c') x = x < 0.f ? 0.f : x > 1.f ? 1.f : x;
            else if (e->type == 'i') x = x < 0.f ? 0.f : x > 99.f ? 99.f : x;
            else if (e->type == 'f') x = x < -1e5f ? -1e5f : x > 1e5f ? 1e5f : x;
            WriteF(*e, k, x);
        }
        ++applied;
    }
    fclose(f);
    return applied;
}

static const char *AutoPath() {
#ifdef AVIS_PREVIEW
    static std::string path;path=g_DataDir+"/settings.cfg";return path.c_str();
#else
    return "/sdcard/Download/AvisTools/settings.cfg";
#endif
}
std::string g_lastSaved;
bool g_autoReady = false;
float g_autoAcc = 0.f, g_autoDebounce = -1.f;

} // namespace

bool Cfg_SaveSlot(int slot) {
    Snapshot();
    if (slot < 0 || slot >= kCfgSlots) return false;
    const std::string path = SlotPath(slot);
    const bool ok = WriteText(path, Serialize(false));
    g_msg = ok ? "Сохранено: custom_" + std::to_string(slot + 1) + ".cfg" : std::string("Не удалось записать ") + path + " (" + strerror(errno) + ")";
    return ok;
}

bool Cfg_LoadSlot(int slot) {
    Snapshot();
    if (slot < 0 || slot >= kCfgSlots) return false;
    bool existed = false;
    int applied = ReadFile(SlotPath(slot).c_str(), false, &existed);
#ifndef AVIS_PREVIEW
    if (!existed) {
        applied = ReadFile(LegacySlotPath(slot).c_str(), false, &existed);
        if (applied > 0) WriteText(SlotPath(slot), Serialize(false));
    }
#endif
    g_msg = !existed ? "Слот " + std::to_string(slot + 1) + " пуст"
                     : "Загружено: custom_" + std::to_string(slot + 1) + ".cfg (" + std::to_string(applied) + " параметров)";
    return applied > 0;
}

// Автосохранение: все настройки (и включатели) в settings.cfg. Загружается при старте, пишется через 0.8 с после последнего изменения.
void Cfg_AutoLoad() {
    Snapshot();
    bool existed = false;
    int n = ReadFile(AutoPath(), true, &existed);
#ifndef AVIS_PREVIEW
    if (!existed) {
        n = ReadFile("/sdcard/Download/EclipsOxide/settings.cfg", true, &existed);
        if (n > 0) WriteText(AutoPath(), Serialize(true));
    }
#endif
    g_lastSaved = Serialize(true);
    g_autoReady = true;
    g_msg = existed ? "Настройки восстановлены (" + std::to_string(n) + ")" : "";
}

bool Cfg_AutoSaveNow() {
    if (!g_autoReady) return false;
    const std::string cur = Serialize(true);
    if (cur == g_lastSaved) return true;
    if (!WriteText(AutoPath(), cur)) return false;
    g_lastSaved = cur;
    return true;
}

void Cfg_AutoTick(float dt) {
    if (!g_autoReady) return;
    g_autoAcc += dt;
    if (g_autoAcc < 0.25f) return;
    const float step = g_autoAcc; g_autoAcc = 0.f;
    if (Serialize(true) == g_lastSaved) { g_autoDebounce = -1.f; return; }
    if (g_autoDebounce < 0.f) g_autoDebounce = 0.8f; else g_autoDebounce -= step;
    if (g_autoDebounce <= 0.f) { Cfg_AutoSaveNow(); g_autoDebounce = -1.f; }
}

bool Cfg_DeleteSlot(int slot) {
    if (slot < 0 || slot >= kCfgSlots) return false;
    bool ok = unlink(SlotPath(slot).c_str()) == 0;
#ifndef AVIS_PREVIEW
    ok = unlink(LegacySlotPath(slot).c_str()) == 0 || ok;
#endif
    g_msg = ok ? "Удалён слот " + std::to_string(slot + 1) : "Слот " + std::to_string(slot + 1) + " уже пуст";
    return ok;
}
