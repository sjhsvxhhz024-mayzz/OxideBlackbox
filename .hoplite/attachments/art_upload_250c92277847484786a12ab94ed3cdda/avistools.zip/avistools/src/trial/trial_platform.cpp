// Текстуры меню Trial: декодирование встроенных PNG/JPEG и загрузка в GL.
#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_JPEG
#define STBI_ONLY_PNG
#define STBI_NO_STDIO
#define STBI_NO_FAILURE_STRINGS
#include "stb_image.h"

#include "trial_config.h"
#include <GLES3/gl3.h>
#include "oxlog.h"
#include <unordered_map>
#include <atomic>
#include <thread>
#include <vector>

extern "C" {
#define DECL(n) extern const unsigned char n##_start[], n##_end[];
DECL(trial_mark) DECL(trial_person) DECL(trial_atlas) DECL(trial_logo)
DECL(trial_banner0) DECL(trial_banner1) DECL(trial_banner2) DECL(trial_banner3) DECL(trial_banner4) DECL(trial_banner5) DECL(trial_banner6)
#undef DECL
}

namespace {

struct Tex { GLuint id = 0; int w = 0, h = 0; };
Tex g_tex[TEX_COUNT];

struct Asset { int slot; const unsigned char *b, *e; };
// Порядок = приоритет загрузки: сначала то, что видно сразу.
const Asset kAssets[] = {
    { TEX_STAR,            trial_mark_start,   trial_mark_end },
    { TEX_LOGO_ATLAS,      trial_logo_start,   trial_logo_end },
    { TEX_ESP_PERSON,      trial_person_start, trial_person_end },
    { TEX_PARTICLE_ATLAS,  trial_atlas_start,  trial_atlas_end },
};
// Атласы фона экрана ключа (серые): декодируются в фоновом потоке (каждый ~3.7 Мпикс), в GL уходят по одному в кадр.
const unsigned char *const kBannerB[TEX_BANNER_COUNT] = {trial_banner0_start, trial_banner1_start, trial_banner2_start, trial_banner3_start,
                                                          trial_banner4_start, trial_banner5_start, trial_banner6_start};
const unsigned char *const kBannerE[TEX_BANNER_COUNT] = {trial_banner0_end, trial_banner1_end, trial_banner2_end, trial_banner3_end,
                                                          trial_banner4_end, trial_banner5_end, trial_banner6_end};
struct BannerJob {
    std::vector<unsigned char> px;
    int w = 0, h = 0;
    std::atomic<bool> done{false};
    bool uploaded = false;
};
BannerJob g_banner[TEX_BANNER_COUNT];   // статические: поток может пережить вызывающего
std::atomic<bool> g_bannerStarted{false};

void DecodeBanners() {
    for (int i = 0; i < TEX_BANNER_COUNT; ++i) {
        int w = 0, h = 0, n = 0;
        unsigned char *px = stbi_load_from_memory(kBannerB[i], (int)(kBannerE[i] - kBannerB[i]), &w, &h, &n, 1);
        if (px) {
            g_banner[i].px.assign(px, px + (size_t)w * h);
            g_banner[i].w = w;
            g_banner[i].h = h;
            stbi_image_free(px);
        }
        g_banner[i].done.store(true, std::memory_order_release);   // и при неудаче: загрузчик пропустит этот атлас
    }
}

void UploadBanner(int i) {
    BannerJob &j = g_banner[i];
    j.uploaded = true;
    if (j.px.empty()) return;
    Tex &t = g_tex[TEX_BANNER + i];
    if (!t.id) glGenTextures(1, &t.id);
    glBindTexture(GL_TEXTURE_2D, t.id);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, j.w, j.h, 0, GL_LUMINANCE, GL_UNSIGNED_BYTE, j.px.data());   // один канал: в 4 раза меньше видеопамяти
    t.w = j.w; t.h = j.h;
    std::vector<unsigned char>().swap(j.px);
}

const int kAssetCount = (int)(sizeof(kAssets) / sizeof(kAssets[0]));

void Upload(const Asset &a) {
    int w = 0, h = 0, n = 0;
    unsigned char *px = stbi_load_from_memory(a.b, (int)(a.e - a.b), &w, &h, &n, 4);
    if (!px) return;
    Tex &t = g_tex[a.slot];
    if (!t.id) glGenTextures(1, &t.id);
    glBindTexture(GL_TEXTURE_2D, t.id);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
    t.w = w; t.h = h;
    stbi_image_free(px);
}

} // namespace

ImTextureID GetTexture(int slot, ImVec2 *size) {
    if (slot < 0 || slot >= TEX_COUNT) return (ImTextureID)0;
    const Tex &t = g_tex[slot];
    if (size) *size = ImVec2((float)t.w, (float)t.h);
    return (ImTextureID)(intptr_t)t.id;
}

// По два ассета за кадр: декодирование не даёт заметного хитча при старте.
void TrialUploadTextures() {
    if (!g_bannerStarted.exchange(true)) std::thread(DecodeBanners).detach();
    for (int i = 0; i < TEX_BANNER_COUNT; ++i) {        // один готовый атлас фона за кадр, по порядку
        if (g_banner[i].uploaded) continue;
        if (g_banner[i].done.load(std::memory_order_acquire)) UploadBanner(i);
        break;
    }
    static int next = 0;
    for (int i = 0; i < 2 && next < kAssetCount; ++i) Upload(kAssets[next++]);
}
