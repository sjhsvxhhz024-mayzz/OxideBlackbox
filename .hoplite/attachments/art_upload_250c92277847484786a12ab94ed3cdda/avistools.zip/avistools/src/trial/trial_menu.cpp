// Меню Trial (вкладки, подвкладки, ESP) и счётчик врагов — он же кнопка меню.
#include "trial_ui.h"
#include "auth/auth_client.h"
#include "auth/auth_config.h"
#include "auth/auth_sound.h"
#include "trial_configs.h"
#include "quick_actions.h"
#include "auto_heal.h"
#include "esp_style.h"
#include "chams_overlay.h"
#include <stdio.h>
#include <time.h>
#include <sys/stat.h>

using namespace UI;

// Мост к состоянию чита (объявлено в main.cpp).
extern bool  espdraw, espbox, espfill, espCornerBox, esplines_enabled, g_menuOpen, skeleton;
extern bool  espname, espclan, espweapon, espArmor, espdist, espFlags, espDistColor, radarEnabled;
extern bool  oreEsp, oreStone, oreMetal, oreSulfur, oreCoal, oreDistText;
extern bool  animalEsp, animalBear, animalBoar, animalDeer, animalRabbit, animalHare, animalChicken, animalFish, animalRat, animalCannibal, animalDistText;
extern bool  baseEsp, baseCupboard, baseTurret, baseBag, baseSleeper, baseDistText;
extern bool cupboardFinder, cupboardGuide;
extern float cupboardRadius;
extern bool xrayOn;
extern float xrayDistance;
extern std::string g_xrayStatus;
extern bool chamsOn, chamsAnimated, chamsDissolve;
extern int chamsStyle;
extern float chamsOpacity, chamsGlow, chamsSpeed, chamsDuration, chamsRange;
extern float oreMaxDist, animalMaxDist, baseMaxDist, espMaxDistance, espCornerLength, radarRange, radarSize, radarAlpha;
extern bool  aimm, aimPrediction, aimDrawFov, aimDrawTarget, aimSticky, aimHoriz, aimVert, aimSkipSleeping, aimSkipSpectating, aimvisible, aimSmoothConst, aimRecoilComp;
extern int   aimTriggerMode, aimcurbone;
extern float aimFovPixels, aimSmooth, aimMaxDistance, aimMaxSpeed, aimDeadzone, aimSwitchMargin, aimFireHold, aimSettleDeg, aimRampMs;
extern float aimProjectileSpeed, aimLatencyMs, aimMaxLeadTime, aimProjectileGravity, aimPredictIters;
extern bool  noRecoil, noSpread;
extern bool  stretchOn;
extern int   stretchMode;
extern float stretchCustom;
extern std::string g_stretchStatus;
extern bool  boostDraw, boostGrass, boostTrees, boostNoLog;
extern float boostDrawDist;
extern int   boostFpsMode;
extern std::string g_boostStatus[5];
extern std::string g_memStatus;
extern bool  silentAim, silentPredict, silentSkipSleeping, silentSkipSpectating, silentDrawFov;
extern int   silentZone, silentMode;
extern bool  silentOnlyFiring;
extern float silentFovPx, silentRange, silentLeadMs, silentMaxCorr;
extern std::string g_silentStatus;   // две строки: счётчики выстрелов и состояние (ox_silentTick)
extern int   esplines_position;
extern float espstroke, espfillp, esplines_thickness;
extern float espboxcolor[3], esplines_color[3], skeleton_color[3], skeleton_stroke;
extern float espnamecolor[3], espclancolor[3], espnamesize, espclansize;
extern std::string g_selfNick, g_selfClan;   // ник и клан локального игрока (из списка игроков матча), для превью
extern std::string g_espStatus;               // две короткие строки: откуда ники и выстрелы (см. ox_statusUpdate)
extern int   g_enemyCount;   // живые игроки в кэше, без локального

int TrialLang() { return g_cfg.lang; }   // язык меню для подписей животных в main.cpp

ImFont *g_trialFontText = nullptr, *g_trialFontMed = nullptr, *g_trialFontTitle = nullptr;
std::string g_DataDir;


Settings g_cfg;

void ResetSettings(Settings &s) {
    memset(&s, 0, sizeof(s));   // обнуляем и байты выравнивания — важно для memcmp
    s.version = SETTINGS_VERSION;
    s.wmEnabled = true;  s.wmStyle = 1;  s.wmFps = true;  s.wmTime = true;  s.wmPulse = true;
    s.borderMode = 0;    s.grid = false; s.particles = false; s.stars = false; s.shimmer = false;
    s.shadows = true;    s.glow = true;
    s.anim = true;       s.transition = 0; s.accent = 0; s.backgroundIndex = 0; s.animSpeed = 1.0f;
    s.particleCount = 60; s.particleSpeed = 40; s.particleSize = 3.0f; s.glowStrength = 25;
    s.rounding = 16;     s.cardAlpha = 62; s.bgBright = 30; s.twinkle = true;
    s.wmPos = 1;         s.wmCompact = false; s.fpsGraph = true; s.lockMenu = false;
    s.dimScreen = false; s.menuOnStart = true;
    s.lang = 1;          s.quality = 1; s.uiScale = 100;
}

// ===================== Сохранение =====================
static Settings s_Saved;
static float s_SaveTimer = -1.0f;

static std::string SettingsPath() { return g_DataDir.empty() ? std::string() : g_DataDir + "/trial_settings.bin"; }

static void LoadSettings() {
    ResetSettings(g_cfg);
    g_cfg.lang = DetectSystemLang();         // первый запуск: язык по локали телефона (сохранённые настройки перекроют)
#ifdef AVIS_PREVIEW
    if (const char *lg = getenv("AVIS_LANG")) g_cfg.lang = atoi(lg);   // хост-превью: язык из окружения
#endif
    std::string path = SettingsPath();
    if (path.empty()) return;
    FILE *f = fopen(path.c_str(), "rb");
    if (!f) return;
    Settings tmp;
    size_t n = fread(&tmp, 1, sizeof(tmp), f);
    fclose(f);
    if (n == sizeof(tmp) && tmp.version == SETTINGS_VERSION) memcpy(&g_cfg, &tmp, sizeof(tmp));
}

static void SaveSettings() {
    std::string path = SettingsPath();
    if (path.empty()) return;
    std::string tmpPath = path + ".tmp";
    FILE *f = fopen(tmpPath.c_str(), "wb");
    if (!f) return;
    bool ok = fwrite(&g_cfg, 1, sizeof(g_cfg), f) == sizeof(g_cfg);
    fclose(f);
    if (ok && rename(tmpPath.c_str(), path.c_str()) == 0) {
        memcpy(&s_Saved, &g_cfg, sizeof(g_cfg));
    } else {
        unlink(tmpPath.c_str());
    }
}

// Санитизация после загрузки/правок
static void ClampSettings(Settings &s) {
    s.wmStyle = ImClamp(s.wmStyle, 0, 2);       s.borderMode = ImClamp(s.borderMode, 0, 2);
    s.transition = ImClamp(s.transition, 0, 2); s.accent = ImClamp(s.accent, 0, 4);
    s.backgroundIndex = ImClamp(s.backgroundIndex, 0, 7);
    s.wmPos = ImClamp(s.wmPos, 0, 1);           s.lang = ImClamp(s.lang, 0, 1);
    s.quality = ImClamp(s.quality, 0, 2);
    s.animSpeed = ImClamp(s.animSpeed, 0.5f, 3.0f);
    s.particleCount = ImClamp(s.particleCount, 10.0f, 150.0f);
    s.particleSpeed = ImClamp(s.particleSpeed, 0.0f, 100.0f);
    s.particleSize = ImClamp(s.particleSize, 1.0f, 6.0f);
    s.glowStrength = ImClamp(s.glowStrength, 0.0f, 100.0f);
    s.rounding = ImClamp(s.rounding, 0.0f, 24.0f);
    s.cardAlpha = ImClamp(s.cardAlpha, 30.0f, 100.0f);
    s.bgBright = ImClamp(s.bgBright, 0.0f, 80.0f);
    s.uiScale = ImClamp(s.uiScale, 80.0f, 120.0f);
}

// ===================== Состояние меню =====================
static float s_Base = 1.0f;           // масштаб «под экран»
static bool  s_MenuOpen = true;
static float s_OpenT = 0.0f;
static int   s_Tab = 0;
static int   s_SubSel[8] = {0};   // выбранная подвкладка у каждой вкладки
static float s_Time = 0.0f;

struct Particle { float x, y, vx, vy, r, a, seed; };
static std::vector<Particle> s_Particles;

static float s_FpsHist[48] = {0};
static int   s_FpsHead = 0;
static float s_FpsTimer = 0.0f;

static inline float Rand01() { return (float)rand() / (float)RAND_MAX; }


// ===================== Инициализация =====================
void Menu::Init(int screenLong, int screenShort) {
    if (!g_DataDir.empty()) mkdir(g_DataDir.c_str(), 0777);
    LoadSettings();
    Cfg_Snapshot();
    Cfg_AutoLoad();                         // ESP, аим, руда, Touch Aim: всё, что менялось в прошлый раз
    QuickActionsInit(g_DataDir.c_str());
    AutoHealInit(g_DataDir.c_str());
    ClampSettings(g_cfg);
    memcpy(&s_Saved, &g_cfg, sizeof(g_cfg));

    // Окно 1580×805 дизайн-единиц должно влезать в альбомный экран.
    // Масштаб от высоты экрана (1.2 на 1080 px), а не «на весь экран»: меню компактное.
    s_Base = ImMin(screenShort / 1080.0f * 1.2f, ImMin(screenLong * 0.94f / WinW, screenShort * 0.92f / WinH));
    s_Base = ImClamp(s_Base, 0.35f, 3.0f);

    ImGuiStyle &st = ImGui::GetStyle();
    st.WindowPadding = ImVec2(0, 0);
    st.WindowBorderSize = 0;
    st.WindowRounding = 0;
    st.ItemSpacing = ImVec2(0, 0);
    st.AntiAliasedLines = true;
    st.AntiAliasedFill = true;

    ImFont *def = ImGui::GetIO().Fonts->Fonts.Size ? ImGui::GetIO().Fonts->Fonts[0] : nullptr;
    FText  = g_trialFontText  ? g_trialFontText  : def;
    FMed   = g_trialFontMed   ? g_trialFontMed   : FText;
    FTitle = g_trialFontTitle ? g_trialFontTitle : FMed;

    s_MenuOpen = g_cfg.menuOnStart;
    s_OpenT = s_MenuOpen ? 1.0f : 0.0f;
    s_Particles.clear();
    srand((unsigned)time(nullptr));
}

void Menu::Shutdown() {
    if (memcmp(&s_Saved, &g_cfg, sizeof(g_cfg)) != 0) SaveSettings();
    Cfg_AutoSaveNow();
    QuickActionsShutdown();
    AutoHealShutdown();
}

// ===================== Фон меню =====================
static void UpdateParticles(float dt) {
    int want = (int)g_cfg.particleCount;
    while ((int)s_Particles.size() < want) {
        Particle p;
        p.x = Rand01() * WinW; p.y = Rand01() * WinH;
        p.vx = (Rand01() - 0.5f) * 8.0f; p.vy = -(12.0f + Rand01() * 30.0f);
        p.r = 0.45f + Rand01() * 0.75f; p.a = 0.18f + Rand01() * 0.45f; p.seed = Rand01() * 100.0f;
        s_Particles.push_back(p);
    }
    if ((int)s_Particles.size() > want) s_Particles.resize(want);
    float sp = g_cfg.particleSpeed / 40.0f;
    for (Particle &p : s_Particles) {
        p.x += (p.vx + sinf(s_Time * 0.9f + p.seed) * 6.0f) * dt * sp;
        p.y += p.vy * dt * sp;
        if (p.y < -10) { p.y = WinH + 10; p.x = Rand01() * WinW; }
        if (p.x < -10) p.x = WinW + 10;
        if (p.x > WinW + 10) p.x = -10;
    }
}

static void DrawParticles() {
    for (const Particle &p : s_Particles) {
        // плавное затухание у краёв
        float edge = ImMin(ImMin(p.x, WinW - p.x), ImMin(p.y, WinH - p.y));
        float fade = ImSaturate(edge / 60.0f);
        if (fade <= 0.0f) continue;
        float tw = 0.75f + 0.25f * sinf(s_Time * 2.2f + p.seed);
        float r = g_cfg.particleSize * p.r * U;
        ImVec2 c = P(p.x, p.y);
        DL->AddCircleFilled(c, r * 2.6f, Acc(p.a * 0.12f * fade * tw));
        DL->AddCircleFilled(c, r, Acc(p.a * fade * tw));
    }
}

// Самоцвет: белый ромб с голубой гранью и мягким ореолом.
static void Gem(ImVec2 c, float sz, bool wide) {
    const float sx = wide ? sz * 1.9f : sz, sy = sz;
    DL->AddCircleFilled(c, sz * 2.4f, Col(56, 189, 255, 0.16f));
    const ImVec2 o[4] = { ImVec2(c.x, c.y - sy), ImVec2(c.x + sx, c.y), ImVec2(c.x, c.y + sy), ImVec2(c.x - sx, c.y) };
    const ImVec2 n[4] = { ImVec2(c.x, c.y - sy * 0.55f), ImVec2(c.x + sx * 0.55f, c.y), ImVec2(c.x, c.y + sy * 0.55f), ImVec2(c.x - sx * 0.55f, c.y) };
    DL->AddConvexPolyFilled(o, 4, Col(255, 255, 255));
    DL->AddConvexPolyFilled(n, 4, Col(56, 189, 255));
    DL->AddPolyline(o, 4, Col(10, 110, 235), ImDrawFlags_Closed, ImMax(1.2f, 1.5f * U));
}

// Рамка меню: непрозрачная белая подложка и «легендарный» голубой контур —
// переливающийся градиент по периметру, бегущий блик, двойная линия, самоцветы.
static void DrawWindowFrame(ImVec2 a, ImVec2 b) {
    const float R = ImClamp(g_cfg.rounding, 8.0f, 20.0f) * U;
    if (g_cfg.shadows) {
        for (int i = 4; i >= 1; --i) {
            float e = i * 3.0f * U;
            DL->AddRectFilled(a - ImVec2(e, e * .4f) + ImVec2(0, 6 * U),
                              b + ImVec2(e, e) + ImVec2(0, 6 * U), Col(0, 0, 0, .025f), R + e);
        }
    }
    DL->AddRectFilled(a, b, Col(249, 250, 252), R);
    DL->AddRect(a, b, Col(203, 210, 220), R, 0, ImMax(1.0f, U));
    if (g_cfg.glow) DL->AddRect(a - ImVec2(U, U), b + ImVec2(U, U),
        Acc(.10f * g_cfg.glowStrength / 100.0f), R + U, 0, 2 * U);
}

// ===================== Вкладки и подвкладки =====================
// Новая вкладка = одна запись в kTabs (имя, иконка, СВОИ подвкладки) + case в DrawCards().
// Иконка: 0 глаз, 1 искры, 2 слайдеры, 3 шестерня, 4 прицел, 5 чип.
struct TabDef { const char *name; int icon; int subCount; const char *subs[8]; };
static const TabDef kTabs[] = {
    { "Visual",   0, 8, { "Players", "Gear", "Ore", "Animals", "Base", "More", "Style", "Chams" } },
    { "Aim",      4, 1, { "Main" } },
    { "Configs",  2, 2, { "Presets", "Custom" } },
    { "Memory",   5, 5, { "Weapon", "Stretch", "Boost", "Auto heal", "X-ray" } },
    { "Silent",   1, 1, { "Main" } },
    { "Settings", 3, 3, { "Interface", "Account", "Quick actions" } },
};
static const int kTabCount = (int)(sizeof(kTabs) / sizeof(kTabs[0]));
static inline int &CurSub() { return s_SubSel[ImClamp(s_Tab, 0, kTabCount - 1)]; }

// ===================== Логотип в круглой рамке =====================
// Анимация из видео: 56 кадров в атласе 8x7 (ячейка 128 px), кадры сменяют друг друга
// с плавным наплывом. Вокруг — рамка: белый зазор, голубое кольцо с переливом и бегущим
// бликом, мягкое свечение и четыре самоцвета.
static void DrawLogo(ImVec2 c, float R) {
    ImVec2 ts;
    ImTextureID tex = GetTexture(TEX_LOGO_ATLAS, &ts);
    DL->AddCircleFilled(c, R + 2 * U, Col(255, 255, 255, .18f), 48);
    DL->AddCircleFilled(c, R, Col(11, 17, 26), 48);
    if (tex && ts.x > 0 && ts.y > 0) {
        const float t = g_cfg.anim ? s_Time * 11.0f * g_cfg.animSpeed : 12.0f;
        const int i0 = (int)floorf(t) % 56, i1 = (i0 + 1) % 56;
        const float f = g_cfg.anim ? t - floorf(t) : 0;
        auto draw = [&](int idx, float alpha) {
            const float ix = .75f / ts.x, iy = .75f / ts.y;
            ImVec2 uv0(idx % 8 / 8.0f + ix, idx / 8 / 7.0f + iy);
            ImVec2 uv1((idx % 8 + 1) / 8.0f - ix, (idx / 8 + 1) / 7.0f - iy);
            DL->AddImageRounded(tex, c - ImVec2(R,R), c + ImVec2(R,R), uv0, uv1, Col(255,255,255,alpha), R);
        };
        draw(i0, 1); if (f > .01f) draw(i1, f);
    }
    DL->AddCircle(c, R + 2 * U, Col(255,255,255,.28f), 48, ImMax(1.0f,U));
}

// ===================== Шапка: баннер с нашим роликом =====================
// Ролик играет внутри скруглённой плашки, поверх — затемнение (слева плотнее: там название), логотип, язык и закрытие.
static const float kSideTop = 102.0f;               // верх боковой панели
static float kBodyTop = 102.0f;                     // верх карточек: ниже, если у вкладки есть ряд подвкладок (плавно меняется)
static inline float BodyBottom() { return WinH - 22.0f; }
static const float kHeaderDragW = 690.0f;           // ширина зоны, за которую меню тянется

static void DrawHeader() {
    const ImVec2 a = P(16, 14), b = P(WinW - 16, 84);
    const float r = 12.0f * U;
    DL->AddRectFilled(a, b, Col(19, 29, 44), r);
    VideoRect(P(WinW * .48f, 14), b, r, ImDrawFlags_RoundCornersRight, g_cfg.anim ? s_Time : 0.0f);
    RoundFill(a, b, r, [&](ImVec2 p) {
        const float f = ImSaturate((p.x - a.x) / (b.x - a.x));
        return Col(3, 7, 15, 0.98f - 0.48f * f);
    });
    DL->AddRect(a, b, Col(255, 255, 255, 0.10f), r, 0, ImMax(1.0f, 1.2f * U));

    DrawLogo(P(60, 49), 26.0f * U);

    {   // название: белое, с мягкой тенью; блик пробегает по буквам
        const float fs = 29.0f;
        const ImVec2 tsz = TextSize(FTitle, fs, AVIS_BRAND);
        const ImVec2 tp = P(102, 49);
        const float ty = tp.y - tsz.y * 0.52f;
        DL->AddText(FTitle, fs * U, ImVec2(tp.x + 1.5f * U, ty + 1.8f * U), Col(0, 0, 0, 0.55f), AVIS_BRAND);
        const int v0 = DL->VtxBuffer.Size;
        DL->AddText(FTitle, fs * U, ImVec2(tp.x, ty), Col(255, 255, 255), AVIS_BRAND);
        if (g_cfg.shimmer && g_cfg.anim) {
            const float cycle = fmodf(s_Time * 0.45f * g_cfg.animSpeed, 1.6f);   // блик пробегает, потом пауза
            Shimmer(DL, v0, tp.x - 60 * U + (tsz.x + 120 * U) * cycle, 38 * U, AccLight(1.0f), 0.85f);
        }
    }

    // Закрыть
    const ImVec2 cc = P(WinW - 48, 49);
    const float cr = 19.0f * U;
    bool held = false;
    if (Hit("##close", ImVec2(cc.x - cr - 4 * U, cc.y - cr - 4 * U), ImVec2(cc.x + cr + 4 * U, cc.y + cr + 4 * U), &held)) s_MenuOpen = false;
    const float hc = Anim(ImGui::GetID("##close_a"), held ? 1.0f : 0.0f, 20.0f);
    DL->AddCircleFilled(cc, cr, Col(255, 255, 255, 0.16f + 0.26f * hc), 32);
    DL->AddCircle(cc, cr, Col(255, 255, 255, 0.40f), 32, ImMax(1.0f, 1.2f * U));
    {
        const float k = 6.0f * U, lw = ImMax(1.5f, 2.0f * U);
        DL->AddLine(ImVec2(cc.x - k, cc.y - k), ImVec2(cc.x + k, cc.y + k), Col(255, 255, 255), lw);
        DL->AddLine(ImVec2(cc.x + k, cc.y - k), ImVec2(cc.x - k, cc.y + k), Col(255, 255, 255), lw);
    }

    // Язык: RU | EN, бегунок плавно переезжает
    {
        const float w = 84, h = 34, lx1 = WinW - 48 - 19 - 12, lx0 = lx1 - w;
        const ImVec2 la = P(lx0, 49 - h * 0.5f), lb = P(lx1, 49 + h * 0.5f);
        bool lheld = false;
        if (Hit("##lang", la, lb, &lheld)) g_cfg.lang = g_cfg.lang == 0 ? 1 : 0;
        const float t = Anim(ImGui::GetID("##lang_t"), g_cfg.lang == 0 ? 0.0f : 1.0f, 16.0f);
        const float rr = h * 0.5f * U, half = (lb.x - la.x) * 0.5f, pad = 3.0f * U;
        DL->AddRectFilled(la, lb, Col(255, 255, 255, 0.14f + 0.10f * (lheld ? 1.0f : 0.0f)), rr);
        DL->AddRect(la, lb, Col(255, 255, 255, 0.38f), rr, 0, ImMax(1.0f, 1.2f * U));
        const ImVec2 ta(la.x + pad + t * half, la.y + pad), tb(la.x - pad + half + t * half, lb.y - pad);
        DL->AddRectFilled(ta, tb, Col(255, 255, 255), rr - pad);
        const char *names[2] = { "RU", "EN" };
        for (int i = 0; i < 2; ++i) {
            const ImVec2 ts = TextSize(FMed, 15.0f, names[i]);
            const float cx = la.x + half * (i + 0.5f);
            const float on = 1.0f - ImClamp(fabsf(t - (float)i), 0.0f, 1.0f);
            DL->AddText(FMed, 15.0f * U, ImVec2(cx - ts.x * 0.5f, (la.y + lb.y) * 0.5f - ts.y * 0.5f), LerpCol(Col(255, 255, 255, 0.88f), Acc(1.0f), on), names[i]);
        }
    }
}

// ===================== Ряд подвкладок =====================
// Чипы по ширине текста (не сжимаются и не накладываются), бегунок плавно переезжает с вкладки на вкладку.
static void DrawSubTabs() {
    const TabDef &td = kTabs[ImClamp(s_Tab, 0, kTabCount - 1)];
    const int cnt = td.subCount;
    const float vis = ImSaturate((kBodyTop - kSideTop) / 52.0f);        // ряд проявляется, пока карточки уезжают вниз
    if (cnt <= 1 || vis < 0.02f) return;
    const float padX = 17.0f, gap = 6.0f, avail = 850.0f - 180.0f;
    float fs = 17.0f, w[8], tot = 0;
    auto measure = [&](float f) {
        tot = gap * (cnt - 1);
        for (int i = 0; i < cnt; ++i) { w[i] = TextSize(FMed, f, T(td.subs[i])).x / U + 2 * padX; tot += w[i]; }
    };
    measure(fs);
    if (tot > avail) {
        const float fixed=gap*(cnt-1)+2*padX*cnt;
        fs *= ImMax(1.f,avail-fixed)/ImMax(1.f,tot-fixed);
        measure(fs);
        for (int retry=0;retry<4 && tot>avail+.1f;++retry) {fs-=.1f;measure(fs);}
    }
    float cx[8], xx = 180.0f;
    for (int i = 0; i < cnt; ++i) { cx[i] = xx; xx += w[i] + gap; }
    int &sel = CurSub();
    sel = ImClamp(sel, 0, cnt - 1);
    const float y0 = 108.0f, y1 = 144.0f, rr = (y1 - y0) * 0.5f * U;
    const int v0 = DL->VtxBuffer.Size;
    const float tl = Anim(ImGui::GetID("##sub_l"), cx[sel], 15.0f), tr = Anim(ImGui::GetID("##sub_r"), cx[sel] + w[sel], 15.0f);
    DL->AddRectFilled(P(176, y0 - 4), P(ImMin(854.0f, xx - gap + 4), y1 + 4), Col(237, 241, 246), 10 * U);
    DL->AddRectFilled(P(tl, y0), P(tr, y1), Col(255, 255, 255), 8 * U);
    DL->AddRect(P(tl, y0), P(tr, y1), Col(216, 223, 233), 8 * U, 0, ImMax(1.0f, U));
    for (int i = 0; i < cnt; ++i) {
        char id[24];
        snprintf(id, sizeof(id), "##sub%d", i);
        bool h = false;
        if (vis > 0.5f && Hit(id, P(cx[i], y0 - 3), P(cx[i] + w[i], y1 + 3), &h)) sel = i;
        const float on = ImSaturate(1.0f - fabsf((cx[i] + w[i] * 0.5f) - (tl + tr) * 0.5f) / (w[i] * 0.5f + 12.0f));
        const float hv = Anim(ImGui::GetID(id), h ? 1.0f : 0.0f, 20.0f);
        if (hv > 0.01f && on < 0.5f) DL->AddRectFilled(P(cx[i], y0), P(cx[i] + w[i], y1), Acc(0.10f * hv), rr);
        const ImVec2 ts = TextSize(FMed, fs, T(td.subs[i]));
        DL->AddText(FMed, fs * U, ImVec2(P(cx[i] + w[i] * 0.5f, 0).x - ts.x * 0.5f, P(0, (y0 + y1) * 0.5f).y - ts.y * 0.5f),
                    LerpCol(Col(92, 103, 120), Acc(1.0f), on), T(td.subs[i]));
    }
    if (vis < 1.0f) TransformVerts(DL, v0, ImVec2(0, 0), 1.0f, 0.0f, vis);
}

// ===================== Боковая панель =====================
// Бегунок-«пилюля» плавно скользит к выбранной вкладке; иконка и подпись светлеют по мере его приближения.
static void DrawSidebar() {
    const float r = g_cfg.rounding * U;
    const ImVec2 a = P(18, kSideTop), b = P(166, BodyBottom());
    DL->AddRectFilled(a, b, Col(243, 245, 248), r);
    DL->AddRect(a, b, Col(222, 227, 233), r, 0, ImMax(1.0f, 1.2f * U));

    const float item = 66.0f, y0 = kSideTop + 14.0f + 30.0f;
    const float pos = Anim(ImGui::GetID("##tabpill"), (float)s_Tab, 14.0f);
    const float py = y0 + pos * item;
    const float pr = g_cfg.rounding * 0.8f * U;
    DL->AddRectFilled(P(26, py - 28), P(158, py + 28), Acc(.10f), pr);
    DL->AddRectFilled(P(26, py - 15), P(29, py + 15), Acc(1.0f), 1.5f * U);

    for (int i = 0; i < kTabCount; ++i) {
        const float y = y0 + i * item;
        char id[16];
        snprintf(id, sizeof(id), "##tab%d", i);
        bool held = false;
        if (Hit(id, P(26, y - 30), P(158, y + 30), &held)) s_Tab = i;
        const float hv = Anim(ImGui::GetID(id), held ? 1.0f : 0.0f, 20.0f);
        const float near = ImSaturate(1.0f - fabsf(pos - (float)i));
        if (near < 0.5f && hv > 0.01f) DL->AddRectFilled(P(26, y - 28), P(158, y + 28), Acc(0.09f * hv), pr);
        const ImU32 c = LerpCol(Col(81, 92, 110), Acc(1.0f), near);
        const ImVec2 ic = P(47, y);
        switch (kTabs[i].icon) {
            case 0: IconEye(ic, 28 * U, c); break;
            case 1: IconSparkles(ic, 28 * U, c); break;
            case 2: IconSliders(ic, 26 * U, c, Col(243, 245, 248)); break;
            case 4: IconCrosshair(ic, 28 * U, c); break;
            case 5: IconChip(ic, 28 * U, c); break;
            default: IconGear(ic, 28 * U, c); break;
        }
        FitText(FMed, 17.0f, P(68, y), c, T(kTabs[i].name), 84.0f * U);
    }
}

// ===================== Вкладка Visual =====================
static ImU32 RgbCol(const float c[3], float a = 1.0f) {
    return Col((int)(ImSaturate(c[0]) * 255.0f + 0.5f), (int)(ImSaturate(c[1]) * 255.0f + 0.5f),
               (int)(ImSaturate(c[2]) * 255.0f + 0.5f), a);
}

// Элементы стиля (вкладка Style); порядок = порядок в выпадающем списке.
enum { EL_BOX, EL_LINE, EL_SKEL, EL_NAME, EL_CLAN, EL_COUNT };

// forceEl — выбранный в Style элемент: показываем его в превью, даже если он выключен тумблером.
static void DrawEspPreview(int forceEl) {
    // Превью рисует ровно то, что оверлей рисует в игре: тот же код стиля (esp_style.h),
    // те же тумблеры, цвета и размеры. Сцена тёмная — как игровой фон, на котором ESP и живёт.
    ImVec2 panelA = P(510, kBodyTop + 16), panelB = P(834, BodyBottom() - 16);
    const float pr = 16 * U;
    DL->AddRectFilled(panelA, panelB, Col(24, 34, 52), pr);
    DL->AddRectFilledMultiColor(ImVec2(panelA.x + pr * 0.5f, panelA.y + 2 * U), ImVec2(panelB.x - pr * 0.5f, panelB.y - 2 * U),
        Col(40, 56, 82), Col(40, 56, 82), Col(18, 26, 42), Col(18, 26, 42));
    DL->AddRect(panelA, panelB, Col(120, 170, 225, 0.55f), pr, 0, ImMax(1.0f, 1.3f * U));
    ImVec2 pc((panelA.x + panelB.x) * 0.5f, (panelA.y + panelB.y) * 0.5f);
    DL->AddCircleFilled(pc, 140 * U, Acc(0.10f));

    const bool dBox  = espdraw && (espbox || forceEl == EL_BOX);
    const bool dLine = espdraw && (esplines_enabled || forceEl == EL_LINE);
    const bool dSkel = espdraw && (skeleton || forceEl == EL_SKEL);
    const bool dName = espdraw && (espname || forceEl == EL_NAME);
    const bool dClan = espdraw && (espclan || forceEl == EL_CLAN);

    ImVec2 tex(0, 0);
    ImTextureID image = GetTexture(TEX_ESP_PERSON, &tex);
    const float ratio = (tex.y > 0) ? tex.x / tex.y : 0.747f;
    const float figH = (panelB.y - panelA.y) - 56 * U, figW = figH * ratio;
    ImVec2 figA(pc.x - figW * 0.5f, panelA.y + 28 * U), figB(figA.x + figW, figA.y + figH);
    if (image) DL->AddImage(image, figA, figB, ImVec2(0, 0), ImVec2(1, 1),
                            Col(255, 255, 255, dSkel ? 0.12f : 0.98f));

    const float w = figB.x - figA.x, h = figB.y - figA.y;
    auto pt = [&](float x, float y) { return ImVec2(figA.x + x * w, figA.y + y * h); };
    // Границы силуэта фигуры по альфе PNG (x 42..598 из 640, y 69..788 из 857).
    const ImVec2 boxA = pt(0.0656f, 0.0805f), boxB = pt(0.9344f, 0.9195f);

    // Всё, что вылезает за карточку превью (широкая полоса HP, длинная подпись), обрезается по её краю.
    DL->PushClipRect(panelA, panelB, true);
    if (dLine) {
        ImVec2 from = esplines_position == 1 ? pc : ImVec2(pc.x, panelB.y - 3 * U);
        ImVec2 to = ImVec2((boxA.x + boxB.x) * 0.5f, boxB.y);
        espstyle::Line(DL, from, to, RgbCol(esplines_color, 1.0f), esplines_thickness);
    }
    if (dBox)
        espstyle::BoxEx(DL, boxA, boxB, RgbCol(espboxcolor, 1.0f), espstroke, espCornerBox, espCornerLength, espfill, espfillp);

    if (dSkel) {
        // Превью скелета: статичная поза (живой скелет рисуется только в игре, по костям настоящего игрока).
        // Тот же espstyle::Skeleton, что и в игре, вид 3/4. Манекен приглушён, чтобы линии читались.
        using namespace oxskel;
        static Pose pose;
        static bool have = false;
        if (!have) { StaticPose(1.66f, pose); have = true; }
        const float ppm = (boxB.y - boxA.y) / 1.78f;                    // пикселей на метр: голова у верха рамки
        const float cx = (boxA.x + boxB.x) * 0.5f, fy = boxB.y;
        const float ca = cosf(0.62f), sa = sinf(0.62f);                 // поворот на 3/4
        auto scr = [&](V3 v) { return ImVec2(cx + (v.x * ca + v.z * sa) * ppm, fy - v.y * ppm); };
        ImVec2 SP[J_COUNT]; bool SV[J_COUNT];
        for (int k = 0; k < J_COUNT; ++k) { SP[k] = scr(pose.j[k]); SV[k] = true; }
        ImVec2 FA[kMaxEdges], FB[kMaxEdges]; bool FV[kMaxEdges];
        for (int k = 0; k < pose.ne; ++k) { FA[k] = scr(pose.e[k].a); FB[k] = scr(pose.e[k].b); FV[k] = true; }
        const ImVec2 hc = scr(pose.headC);
        const float hr = pose.headR * ppm;
        espstyle::Skeleton(DL, SP, SV, FA, FB, FV, pose.ne, hc, hr, true, scr(pose.headC + pose.face * 0.24f), true,
                           RgbCol(skeleton_color, 1.0f), skeleton_stroke, 1.0f, boxB.y - boxA.y);
    }

    // Подпись и HP — тем же кодом и теми же размерами в пикселях, что и в игре.
    ImFont *font = ImGui::GetFont();
    const float base = espstyle::TextBase(ImGui::GetIO().DisplaySize.y);
    if (dName || dClan)
        espstyle::Tag(DL, font, (boxA.x + boxB.x) * 0.5f, boxA.y - 5.0f,
                      dClan ? (g_selfClan.empty() ? "CLAN" : g_selfClan.c_str()) : nullptr, RgbCol(espclancolor, 1.0f), base * espclansize,
                      dName ? (g_selfNick.empty() ? "Nickname" : g_selfNick.c_str()) : nullptr, RgbCol(espnamecolor, 1.0f), base * espnamesize);
    DL->PopClipRect();
}

static void DrawVisualPlayers();   // после PanelRow

// ===================== Style: цвет, толщина, размер =====================
struct ElDef {
    const char  *name;
    float       *col;          // RGB; nullptr — у HP цвет по здоровью
    float       *val;          // толщина линий / размер текста / ширина полосы
    const char  *valName;
    float        mn, mx;
    const char  *fmt;
    float        defVal;
    const float *defCol;
};
static const ElDef kEl[EL_COUNT] = {
    { "Box",      espboxcolor,    &espstroke,          "Width", 0.30f,  4.0f, "%.2f", espstyle::kBoxStroke,  espstyle::kBoxColor  },
    { "Line",     esplines_color, &esplines_thickness, "Width", 0.30f,  4.0f, "%.2f", espstyle::kLineStroke, espstyle::kLineColor },
    { "Skeleton", skeleton_color, &skeleton_stroke,    "Width", 0.30f,  4.0f, "%.2f", espstyle::kSkelStroke, espstyle::kSkelColor },
    { "Name",     espnamecolor,   &espnamesize,        "Size",  0.60f,  2.0f, "%.2f", espstyle::kTextSize,   espstyle::kNameColor },
    { "Clan",     espclancolor,   &espclansize,        "Size",  0.60f,  2.0f, "%.2f", espstyle::kTextSize,   espstyle::kClanColor },
};

// HSV хранится отдельно от RGB: у серого оттенок не определён и при пересчёте из RGB терялся бы.
static float s_hsv[EL_COUNT][3];
static float s_hsvRgb[EL_COUNT][3];
static bool  s_hsvInit[EL_COUNT];

static void SyncHsv(int el, const float *rgb) {
    float *last = s_hsvRgb[el];
    if (s_hsvInit[el] && fabsf(rgb[0] - last[0]) + fabsf(rgb[1] - last[1]) + fabsf(rgb[2] - last[2]) < 1e-4f) return;
    float h, sat, v;
    ImGui::ColorConvertRGBtoHSV(rgb[0], rgb[1], rgb[2], h, sat, v);
    if (!s_hsvInit[el] || (sat > 0.002f && v > 0.002f)) s_hsv[el][0] = h;
    s_hsv[el][1] = sat; s_hsv[el][2] = v;
    memcpy(last, rgb, sizeof(float) * 3);
    s_hsvInit[el] = true;
}

static void WriteHsv(int el, float *rgb) {
    ImGui::ColorConvertHSVtoRGB(ImSaturate(s_hsv[el][0]), ImSaturate(s_hsv[el][1]), ImSaturate(s_hsv[el][2]), rgb[0], rgb[1], rgb[2]);
    memcpy(s_hsvRgb[el], rgb, sizeof(float) * 3);
}

// Ряд цветных кружков: тап ставит цвет целиком. Возвращает true, если цвет сменился.
static bool PaletteRow(const char *id, float *rgb, float x0, float x1, float y) {
    static const float kPal[8][3] = {
        { 1.00f, 1.00f, 1.00f }, { 1.00f, 0.30f, 0.30f }, { 1.00f, 0.62f, 0.20f }, { 1.00f, 0.90f, 0.25f },
        { 0.35f, 0.90f, 0.45f }, { 0.30f, 0.85f, 0.95f }, { 0.35f, 0.55f, 1.00f }, { 0.95f, 0.45f, 0.85f },
    };
    const int n = 8;
    const float left = x0 + 25 + 11, right = x1 - 25 - 11, pitch = (right - left) / (n - 1);
    bool changed = false;
    for (int i = 0; i < n; ++i) {
        const float cx = left + pitch * i;
        char hid[32]; snprintf(hid, sizeof(hid), "%s%d", id, i);
        bool held = false;
        if (Hit(hid, P(cx - pitch * 0.5f, y - 22), P(cx + pitch * 0.5f, y + 22), &held)) {
            memcpy(rgb, kPal[i], sizeof(float) * 3);
            changed = true;
        }
        const float hv = Anim(ImGui::GetID(hid), held ? 1.0f : 0.0f, 20.0f);
        const bool sel = fabsf(rgb[0] - kPal[i][0]) + fabsf(rgb[1] - kPal[i][1]) + fabsf(rgb[2] - kPal[i][2]) < 0.02f;
        const ImVec2 c = P(cx, y);
        const float r = (11.0f - 1.5f * hv) * U;
        if (sel) DL->AddCircle(c, r + 5.0f * U, Acc(0.95f), 0, ImMax(1.0f, 1.8f * U));
        DL->AddCircleFilled(c, r, Col((int)(kPal[i][0] * 255), (int)(kPal[i][1] * 255), (int)(kPal[i][2] * 255)));
        DL->AddCircle(c, r, Col(100, 116, 139, 0.55f), 0, ImMax(1.0f, U));
    }
    return changed;
}

static int s_StyleEl = 0;

static void DrawVisualStyle() {
    const float x0 = 180, x1 = 480, y0 = kBodyTop, rowH = 52, padY = 12;
    Card(x0, y0, x1, BodyBottom(), 0, nullptr, 1.0f);
    auto Y = [&](int k) { return y0 + padY + rowH * (k + 0.5f); };
    int rows = 0;                                            // сколько строк занято: между ними — разделители
    auto Sep = [&](int k) {
        DL->AddLine(P(x0 + 24, Y(k) + rowH * 0.5f), P(x1 - 24, Y(k) + rowH * 0.5f), Col(231, 235, 240), ImMax(1.0f, U));
    };

    static const char *kNames[EL_COUNT] = { "Box", "Line", "Skeleton", "Name", "Clan" };
    s_StyleEl = ImClamp(s_StyleEl, 0, EL_COUNT - 1);
    RowCombo("sty_el", "Element", &s_StyleEl, kNames, EL_COUNT, x0, x1, Y(rows), 150);
    const int el = s_StyleEl;
    const ElDef &d = kEl[el];
    Sep(rows++);

    bool reset = false;
    RowSlider("sty_val", d.valName, d.val, d.mn, d.mx, d.fmt, x0, x1, Y(rows), 100);
    Sep(rows++);
    SyncHsv(el, d.col);
    if (PaletteRow("sty_pal", d.col, x0, x1, Y(rows))) SyncHsv(el, d.col);
    Sep(rows++);
    float *hsv = s_hsv[el];
    RowGradient("sty_h", "Hue", &hsv[0], 0, 0.0f, d.col, x0, x1, Y(rows), 100);
    Sep(rows++);
    RowGradient("sty_s", "Sat", &hsv[1], 1, hsv[0], nullptr, x0, x1, Y(rows), 100);
    Sep(rows++);
    RowGradient("sty_v", "Bright", &hsv[2], 2, hsv[0], nullptr, x0, x1, Y(rows), 100, hsv[1]);
    Sep(rows++);
    // Ползунки правят HSV; в RGB пишем только когда сработал один из них (тап по кружку уже записал RGB сам).
    static float prev[EL_COUNT][3];
    if (memcmp(prev[el], hsv, sizeof(float) * 3) != 0) { WriteHsv(el, d.col); memcpy(prev[el], hsv, sizeof(float) * 3); }
    if (el == EL_LINE) {
        static const char *kOrigin[2] = { "Bottom", "Center" };
        RowCombo("sty_org", "Origin", &esplines_position, kOrigin, 2, x0, x1, Y(rows), 150);
        Sep(rows++);
    }
    reset = RowButton("sty_reset", "Defaults", "Reset", x0, x1, Y(rows));
    if (reset) {
        memcpy(d.col, d.defCol, sizeof(float) * 3);
        SyncHsv(el, d.col);
        memcpy(prev[el], s_hsv[el], sizeof(float) * 3);
        if (el == EL_LINE) esplines_position = 0;
    }
    if (reset) *d.val = d.defVal;

    Card(494, kBodyTop, 850, BodyBottom(), 0, nullptr, 0.0f);
    DrawEspPreview(el);
}

// Простая карточка из строк-тумблеров и ползунков: описание строк — в массиве.
struct PanelRow { const char *id, *label; bool *toggle; float *val; float mn, mx; const char *fmt; int *combo = nullptr; const char *const *items = nullptr; int nItems = 0; int kind = 0; };   // kind 1 — выбор акцента
// Строки-настройки в карточке по горизонтали [x0..x1]; высота строки подбирается под их число.
static void DrawRowsAt(const PanelRow *rows, int n, float x0, float x1, float highlight) {
    const float avail = BodyBottom() - kBodyTop - 20.0f;
    float rowH = avail / (float)n;
    if (rowH > 62.0f) rowH = 62.0f;
    const float padY = 20.0f, y1 = kBodyTop + padY + rowH * 0.5f;
    // Общий старт дорожек слайдеров в карточке: по самой длинной подписи (перевод длиннее оригинала), чтобы дорожки стояли ровно.
    float track = 100.0f;
    for (int i = 0; i < n; ++i)
        if (rows[i].val) track = ImMax(track, TextSize(FText, 20.0f, T(rows[i].label)).x / U + 25.0f + 18.0f);
    track = ImMin(track, (x1 - x0) * 0.60f);
    Card(x0, kBodyTop, x1, BodyBottom(), 0, nullptr, highlight);
    for (int i = 0; i < n; ++i) {
        const float y = y1 + rowH * i;
        if (i + 1 < n)
            DL->AddLine(P(x0 + 24, y + rowH * 0.5f), P(x1 - 24, y + rowH * 0.5f), Col(231, 235, 240), ImMax(1.0f, U));
        if (rows[i].kind == 1) RowAccent(rows[i].id, rows[i].label, rows[i].combo, x0, x1, y);
        else if (rows[i].combo) RowCombo(rows[i].id, rows[i].label, rows[i].combo, rows[i].items, rows[i].nItems, x0, x1, y, 150);
        else if (rows[i].toggle) RowToggle(rows[i].id, rows[i].label, rows[i].toggle, x0, x1, y);
        else RowSlider(rows[i].id, rows[i].label, rows[i].val, rows[i].mn, rows[i].mx, rows[i].fmt, x0, x1, y, track);
    }
}

// Строки в карточках. С превью — слева строки, справа превью ESP. Без превью и строк от 4 — две равные колонки (без пустой карточки);
// совсем короткие списки остаются слева.
static void DrawRowsCard(const PanelRow *rows, int n, bool preview = false) {
    if (!preview && n >= 4) {
        const int h = (n + 1) / 2;
        DrawRowsAt(rows, h, 180, 508, 1.0f);
        DrawRowsAt(rows + h, n - h, 522, 850, 0.0f);
        return;
    }
    if (!preview) { DrawRowsAt(rows, n, 180, 850, 0.0f); return; }
    DrawRowsAt(rows, n, 180, 480, 1.0f);
    Card(494, kBodyTop, 850, BodyBottom(), 0, nullptr, 0.0f);
    DrawEspPreview(-1);
}

static void DrawVisualGear() {
    const PanelRow rows[] = {
        { "gear_armor",  "Armor ESP",  &espArmor, nullptr, 0, 0, nullptr },
        { "gear_weapon", "Held item ESP", &espweapon,     nullptr, 0, 0, nullptr },
    };
    DrawRowsCard(rows, 2, true);
}

static void DrawVisualOre() {
    const PanelRow rows[] = {
        { "ore_on",    "Ore ESP",   &oreEsp,       nullptr,     0,   0,   nullptr },
        { "ore_stone", "Stone",     &oreStone,     nullptr,     0,   0,   nullptr },
        { "ore_metal", "Metal",     &oreMetal,     nullptr,     0,   0,   nullptr },
        { "ore_sulf",  "Sulfur",    &oreSulfur,    nullptr,     0,   0,   nullptr },
        { "ore_coal",  "Coal",      &oreCoal,      nullptr,     0,   0,   nullptr },
        { "ore_dist",  "Distance",  &oreDistText,  nullptr,     0,   0,   nullptr },
        { "ore_range", "Range m",   nullptr,       &oreMaxDist, 30,  400, "%.0f" },
    };
    DrawRowsCard(rows, 7);
}


// Подвкладка ESP «Animals»: каждый вид включается отдельно, дальность общая. Показ — подписью (вид + дистанция), без иконок.
static void DrawVisualAnimals() {
    const PanelRow left[] = {
        { "ani_on",   "Animal ESP", &animalEsp,    nullptr, 0, 0, nullptr },
        { "ani_bear", "Bear",       &animalBear,   nullptr, 0, 0, nullptr },
        { "ani_boar", "Boar",       &animalBoar,   nullptr, 0, 0, nullptr },
        { "ani_deer", "Deer",       &animalDeer,   nullptr, 0, 0, nullptr },
        { "ani_rab",  "Rabbit",     &animalRabbit, nullptr, 0, 0, nullptr },
        { "ani_hare", "Hare",       &animalHare,   nullptr, 0, 0, nullptr },
    };
    const PanelRow right[] = {
        { "ani_chk",  "Chicken",    &animalChicken,  nullptr, 0, 0, nullptr },
        { "ani_fish", "Fish",       &animalFish,     nullptr, 0, 0, nullptr },
        { "ani_rat",  "Rat",        &animalRat,      nullptr, 0, 0, nullptr },
        { "ani_can",  "Cannibal",   &animalCannibal, nullptr, 0, 0, nullptr },
        { "ani_dist", "Distance",   &animalDistText, nullptr, 0, 0, nullptr },
        { "ani_rng",  "Range m",    nullptr,         &animalMaxDist, 30, 500, "%.0f" },
    };
    DrawRowsAt(left, 6, 180, 480, 1.0f);
    DrawRowsAt(right, 6, 494, 850, 0.0f);
}

// Подвкладка ESP «Base»: чужие базы (шкафы, турели и ловушки), спальники и отключившиеся игроки. Подписью, без иконок.
static void DrawVisualBase() {
    const PanelRow left[] = {
        { "base_on",  "Base ESP",     &baseEsp,      nullptr, 0, 0, nullptr },
        { "base_cup", "Cupboards",    &baseCupboard, nullptr, 0, 0, nullptr },
        { "base_tur", "Turrets/traps", &baseTurret,  nullptr, 0, 0, nullptr },
        { "cup_find", "Cupboard through walls", &cupboardFinder, nullptr, 0, 0, nullptr },
        { "cup_radius", "Search radius m", nullptr, &cupboardRadius, 5, 800, "%.0f" },
        { "cup_guide", "Guide to cupboards", &cupboardGuide, nullptr, 0, 0, nullptr },
    };
    const PanelRow right[] = {
        { "base_bag", "Sleeping bags", &baseBag,      nullptr,      0,  0,   nullptr },
        { "base_slp", "Sleepers",      &baseSleeper,  nullptr,      0,  0,   nullptr },
        { "base_dst", "Distance",      &baseDistText, nullptr,      0,  0,   nullptr },
        { "base_rng", "Range m",       nullptr,       &baseMaxDist, 50, 800, "%.0f" },
    };
    DrawRowsAt(left, 6, 180, 480, 1.0f);
    DrawRowsAt(right, 4, 494, 850, 0.0f);
}

static double s_ChamsDemoStart=-10;
#ifdef AVIS_PREVIEW
static float s_ChamsForcedPhase=-1.f;
#endif
static void DrawVisualChams() {
    static const char *const styles[]={"Aurora","Cyber","Ember","Frost"};
    const PanelRow rows[]={
        {"chams_on","Overlay Chams",&chamsOn,nullptr,0,0,nullptr},
        {"chams_style","Effect style",nullptr,nullptr,0,0,nullptr,&chamsStyle,styles,4},
        {"chams_alpha","Opacity",nullptr,&chamsOpacity,.15f,.95f,"%.2f"},
        {"chams_glow","Glow",nullptr,&chamsGlow,0,1,"%.2f"},
        {"chams_anim","Animate Chams",&chamsAnimated,nullptr,0,0,nullptr},
        {"chams_speed","Flow speed",nullptr,&chamsSpeed,.2f,3.f,"%.1fx"},
        {"chams_range","Range m",nullptr,&chamsRange,20,220,"%.0f"},
        {"chams_death","Death dissolve",&chamsDissolve,nullptr,0,0,nullptr},
        {"chams_time","Dissolve time s",nullptr,&chamsDuration,.5f,2.8f,"%.1f"},
    };
    DrawRowsAt(rows,9,180,480,1.f);
    Card(494,kBodyTop,850,BodyBottom(),0,nullptr,0);
    ImVec2 a=P(510,kBodyTop+16),b=P(834,BodyBottom()-100);
    DL->AddRectFilled(a,b,Col(13,22,39),14*U);
    DL->PushClipRect(a,b,true);
    const float center=(a.x+b.x)*.5f,feet=b.y-18*U;
    const float ppm=(b.y-a.y-38*U)/1.78f;
    const float ca=cosf(.45f),sa=sinf(.45f);
    auto project=[&](oxskel::V3 p,ImVec2 &out) {
        out=ImVec2(center+(p.x*ca+p.z*sa)*ppm,feet-p.y*ppm);return true;
    };
    oxskel::Pose pose{};oxskel::StaticPose(1.66f,pose);
    chams::Settings s;s.style=chamsStyle;s.opacity=chamsOpacity;s.glow=chamsGlow;
    s.speed=chamsSpeed;s.duration=chamsDuration;s.animated=chamsAnimated;
    const double now=ImGui::GetTime();
    const float duration=chams::Clamp(chamsDuration,.5f,2.8f,1.4f);
    float phase=now>=s_ChamsDemoStart && now-s_ChamsDemoStart<duration ? (float)((now-s_ChamsDemoStart)/duration) : -1.f;
#ifdef AVIS_PREVIEW
    if (s_ChamsForcedPhase>=0) phase=s_ChamsForcedPhase;
#endif
    chams::Draw(DL,pose,project,s,now,phase,42);
    if (phase>=0) {
        chams::Burst burst{pose,s_ChamsDemoStart,duration,42,s};
        chams::Particles(DL,burst,project,now);
    }
    DL->PopClipRect();
    if (RowButton("chams_demo","Preview dissolve","Play",510,834,BodyBottom()-68)) s_ChamsDemoStart=now;
    FitText(FText,16.f,P(526,BodyBottom()-30),Col(100,116,139),T("Bone silhouette, not the original mesh"),292*U);
}
#ifdef AVIS_PREVIEW
void MenuPreviewChamsDissolve(float phase) {
    s_ChamsForcedPhase=ImClamp(phase,0.f,1.f);
    s_ChamsDemoStart=ImGui::GetTime()-ImClamp(phase,0.f,.999f)*chams::Clamp(chamsDuration,.5f,2.8f,1.4f);
}
#endif

static void DrawVisualPlayers() {
    const PanelRow rows[] = {
        { "vis_box",   "ESP Box",     &espbox,         nullptr, 0, 0, nullptr },
        { "vis_corn",  "Corner box",  &espCornerBox,   nullptr, 0, 0, nullptr },
        { "vis_fill",  "Box fill",    &espfill,        nullptr, 0, 0, nullptr },
        { "vis_line",  "ESP Line",    &esplines_enabled, nullptr, 0, 0, nullptr },
        { "vis_skel",  "Skeleton",    &skeleton,       nullptr, 0, 0, nullptr },
        { "vis_name",  "ESP Name",    &espname,        nullptr, 0, 0, nullptr },
        { "vis_clan",  "ESP Clan",    &espclan,        nullptr, 0, 0, nullptr },
        { "vis_dist",  "Distance",    &espdist,        nullptr, 0, 0, nullptr },
        { "vis_flags", "Status flags", &espFlags,      nullptr, 0, 0, nullptr },
    };
    DrawRowsCard(rows, 9, true);
}

static void DrawVisualMore() {
    static const char *const kOrigin[2] = { "Bottom", "Center" };
    const PanelRow rows[] = {
        { "more_range", "Range m",     nullptr,         &espMaxDistance,  50, 1500, "%.0f" },
        { "more_dcol",  "Dist color",  &espDistColor,   nullptr, 0, 0, nullptr },
        { "more_fillp", "Fill alpha",  nullptr,         &espfillp,        0,  1,    "%.2f" },
        { "more_clen",  "Corner len",  nullptr,         &espCornerLength, 0.1f, 0.5f, "%.2f" },
        { "more_org",   "Line origin", nullptr,         nullptr, 0, 0, nullptr, &esplines_position, kOrigin, 2 },
        { "more_radar", "Radar",       &radarEnabled,   nullptr, 0, 0, nullptr },
        { "more_rrng",  "Radar range", nullptr,         &radarRange,      30, 400,  "%.0f" },
        { "more_rsz",   "Radar size",  nullptr,         &radarSize,       100, 320, "%.0f" },
        { "more_ralp",  "Radar alpha", nullptr,         &radarAlpha,      0.1f, 1,  "%.2f" },
    };
    DrawRowsCard(rows, 9);
}

static void DrawAimMain() {
    static const char *const kModes[5] = { "Always", "ADS", "Fire", "ADS or Fire", "ADS + Fire" };
    static const char *const kBones[4] = { "Head", "Neck", "Body", "Closest" };
    const PanelRow left[] = {
        { "aim_on",   "Aimbot",        &aimm,           nullptr,          0,   0,    nullptr },
        { "aim_mode", "Trigger",       nullptr,         nullptr,          0,   0,    nullptr, &aimTriggerMode, kModes, 5 },
        { "aim_bone", "Target",        nullptr,         nullptr,          0,   0,    nullptr, &aimcurbone,     kBones, 4 },
        { "aim_fov",  "FOV px",        nullptr,         &aimFovPixels,    20,  700,  "%.0f" },
        { "aim_smth", "Smooth",        nullptr,         &aimSmooth,       1,   30,   "%.1f" },
        { "aim_dist", "Range m",       nullptr,         &aimMaxDistance,  20,  800,  "%.0f" },
        { "aim_stk",  "Sticky target", &aimSticky,      nullptr,          0,   0,    nullptr },
        { "aim_draw", "Draw FOV",      &aimDrawFov,     nullptr,          0,   0,    nullptr },
        { "aim_dtgt", "Draw target",   &aimDrawTarget,  nullptr,          0,   0,    nullptr },
    };
    const PanelRow right[] = {
        { "adv_rec",  "Recoil comp",   &aimRecoilComp,  nullptr,              0,    0,    nullptr },
        { "adv_lin",  "Linear speed",  &aimSmoothConst, nullptr,              0,    0,    nullptr },
        { "adv_spd",  "Max speed",     nullptr,         &aimMaxSpeed,         60,   3000, "%.0f" },
        { "adv_dz",   "Dead zone",     nullptr,         &aimDeadzone,         0,    1,    "%.2f" },
        { "adv_ramp", "Ramp ms",       nullptr,         &aimRampMs,           0,    400,  "%.0f" },
        { "adv_hold", "Fire hold s",   nullptr,         &aimFireHold,         0,    1,    "%.2f" },
        { "adv_swm",  "Switch ratio",  nullptr,         &aimSwitchMargin,     1,    4,    "%.2f" },
        { "adv_pred", "Prediction",    &aimPrediction,  nullptr,              0,    0,    nullptr },
        { "adv_bsp",  "Bullet speed",  nullptr,         &aimProjectileSpeed,  50,   1200, "%.0f" },
        { "adv_lat",  "Latency ms",    nullptr,         &aimLatencyMs,        0,    300,  "%.0f" },
        { "adv_grv",  "Gravity",       nullptr,         &aimProjectileGravity, 0,   20,   "%.1f" },
    };
    DrawRowsAt(left, 9, 180, 480, 1.0f);
    DrawRowsAt(right, 11, 494, 850, 0.0f);
}

// Memory: правка памяти игры. Подвкладки: Weapon (конфиги оружия; оригиналы возвращаются при выключении) и Stretch (соотношение сторон камеры).
static void DrawDiagnostics(const char *id,const std::string *lines,int count) {
    if (RowButton(id,"Diagnostics","Details",CurSub()==2?522:180,850,BodyBottom()-38)) ImGui::OpenPopup(id);
    ImGui::PushStyleColor(ImGuiCol_PopupBg,ImVec4(1,1,1,1));
    ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(.12f,.16f,.22f,1));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(18*U,16*U));
    ImGui::PushStyleVar(ImGuiStyleVar_PopupRounding,10*U);
    ImGui::SetNextWindowSize(ImVec2(400*U,0),ImGuiCond_Always);
    if(ImGui::BeginPopup(id)) {
        ImGui::TextUnformatted(T("Diagnostics"));ImGui::Separator();
        for(int i=0;i<count;++i)if(!lines[i].empty())ImGui::TextWrapped("%s",T(lines[i].c_str()));
        ImGui::EndPopup();
    }
    ImGui::PopStyleVar(2);ImGui::PopStyleColor(2);
}

static void DrawMemoryWeapon() {
    const PanelRow rows[] = {
        { "mem_rec", "No Recoil", &noRecoil, nullptr, 0, 0, nullptr },
        { "mem_spr", "No Spread", &noSpread, nullptr, 0, 0, nullptr },
    };
    DrawRowsCard(rows,2);
    DrawDiagnostics("mem_status",&g_memStatus,1);
}

static void DrawMemoryStretch() {
    static const char *const kRatios[7] = { "16:9", "16:10", "3:2", "4:3", "5:4", "1:1", "Custom" };
    const PanelRow rows[] = {
        { "str_on",   "Stretch",      &stretchOn,   nullptr,        0,   0,   nullptr },
        { "str_mode", "Aspect ratio", nullptr,      nullptr,        0,   0,   nullptr, &stretchMode, kRatios, 7 },
        { "str_cust", "Custom ratio", nullptr,      &stretchCustom, 0.5f, 3.0f, "%.2f" },
    };
    DrawRowsCard(rows,3);
    DrawDiagnostics("stretch_status",&g_stretchStatus,1);
}

static void DrawMemoryBoost() {
    static const char *const kFps[5] = { "Auto (PC 60)", "90", "60", "45", "30" };
    const PanelRow rows[] = {
        { "bst_draw",  "Draw distance", &boostDraw,      nullptr,        0,   0,    nullptr },
        { "bst_dist",  "Distance m",    nullptr,         &boostDrawDist, 100, 1500, "%.0f" },
        { "bst_grass", "Hide grass",    &boostGrass,     nullptr,        0,   0,    nullptr },
        { "bst_trees", "Hide trees",    &boostTrees,     nullptr,        0,   0,    nullptr },
        { "bst_fps",   "Overlay FPS",   nullptr,         nullptr,        0,   0,    nullptr, &boostFpsMode, kFps, 5 },
        { "bst_log",   "Disable logs",  &boostNoLog,     nullptr,        0,   0,    nullptr },
    };
    DrawRowsCard(rows,6);
    DrawDiagnostics("boost_status",g_boostStatus,5);
}

static void DrawMemoryXray() {
    const PanelRow rows[] = {
        { "xray_on", "X-ray", &xrayOn, nullptr, 0, 0, nullptr },
        { "xray_distance", "Clip distance m", nullptr, &xrayDistance, .05f, 60.f, "%.2f" },
    };
    DrawRowsCard(rows,2);
    Text(FText,17.f,P(205,320),Col(100,116,139),T("Camera cut, not a radius"));
    Text(FText,17.f,P(205,352),Col(100,116,139),T("Nearby players and items are also clipped"));
    DrawDiagnostics("xray_status",&g_xrayStatus,1);
}
static void DrawMemory() {
    switch (CurSub()) { case 1: DrawMemoryStretch(); break; case 2: DrawMemoryBoost(); break; case 3: AutoHealSettings(); break; case 4: DrawMemoryXray(); break; default: DrawMemoryWeapon(); break; }
}

// Silent aim: направление пули подменяется при выстреле, камера не двигается (логика — ox_silentTick в main.cpp).
static void DrawSilentAim() {
    static const char *const kZones[4] = { "Head", "Neck", "Body", "Closest" };
    static const char *const kModes[1] = { "Look direction" };
    const PanelRow rows[] = {
        { "sil_on",   "Silent aim",  &silentAim,      nullptr,      0,  0,   nullptr },
        { "sil_mode", "Type",        nullptr,         nullptr,      0,  0,   nullptr, &silentMode, kModes, 1 },
        { "sil_zone", "Target bone", nullptr,         nullptr,      0,  0,   nullptr, &silentZone, kZones, 4 },
        { "sil_dfov", "Draw FOV",    &silentDrawFov,  nullptr,      0,  0,   nullptr },
        { "sil_fov",  "FOV",         nullptr,         &silentFovPx, 20, 2000, "%.0f" },
        { "sil_rng",  "Distance m",  nullptr,         &silentRange, 20, 800, "%.0f" },
    };
    DrawRowsCard(rows, 6);
}

// ===================== Конфиги =====================
static int  s_CfgActive = 0;            // последний применённый пресет (для подсветки)
static int  s_CfgSlot = 0;              // выбранный пользовательский слот
static double s_CfgDeleteArm = -10.0;   // удаление подтверждается повторным нажатием

static void DrawCfgPresets() {
    const int n = Cfg_PresetCount();
    const float x0 = 180, x1 = 480;
    const float avail = BodyBottom() - kBodyTop - 20.0f;
    float rowH = avail / (float)n; if (rowH > 62.0f) rowH = 62.0f;
    Card(x0, kBodyTop, x1, BodyBottom(), 0, nullptr, 1.0f);
    for (int i = 0; i < n; ++i) {
        const CfgPresetInfo &pi = Cfg_PresetInfo(i);
        const float y = kBodyTop + 20.0f + rowH * 0.5f + rowH * i;
        if (i == s_CfgActive) DL->AddRectFilled(P(x0 + 8, y - rowH * 0.5f + 3), P(x1 - 8, y + rowH * 0.5f - 3), Acc(0.08f), 10 * U);
        if (i + 1 < n) DL->AddLine(P(x0 + 24, y + rowH * 0.5f), P(x1 - 24, y + rowH * 0.5f), Col(231, 235, 240), ImMax(1.0f, U));
        char id[24]; snprintf(id, sizeof(id), "cfg_pre%d", i);
        if (RowButton(id, pi.name, i == s_CfgActive ? "Active" : "Apply", x0, x1, y)) { Cfg_ApplyPreset(i); s_CfgActive = i; }
    }
    Card(494, kBodyTop, 850, BodyBottom(), 0, nullptr, 0.0f);
    DrawEspPreview(-1);

}

static void DrawCfgCustom() {
    const float x0 = 180, x1 = 480;
    static char names[kCfgSlots][24];
    static const char *items[kCfgSlots];
    for (int i = 0; i < kCfgSlots; ++i) { snprintf(names[i], sizeof(names[i]), "%s %d%s", T("Slot"), i + 1, Cfg_SlotExists(i) ? "  \xe2\x80\xa2" : ""); items[i] = names[i]; }
    const int n = 5;
    const float avail = BodyBottom() - kBodyTop - 20.0f - 60.0f;
    float rowH = avail / (float)n; if (rowH > 62.0f) rowH = 62.0f;
    Card(x0, kBodyTop, x1, BodyBottom(), 0, nullptr, 1.0f);
    float y = kBodyTop + 20.0f + rowH * 0.5f;
    auto sep = [&]() { DL->AddLine(P(x0 + 24, y + rowH * 0.5f), P(x1 - 24, y + rowH * 0.5f), Col(231, 235, 240), ImMax(1.0f, U)); };
    RowCombo("cfg_slot", "Config slot", &s_CfgSlot, items, kCfgSlots, x0, x1, y, 150); sep(); y += rowH;
    if (RowButton("cfg_save", "Current", "Save", x0, x1, y)) Cfg_SaveSlot(s_CfgSlot); sep(); y += rowH;
    if (RowButton("cfg_load", "Load slot", "Load", x0, x1, y)) { if (Cfg_LoadSlot(s_CfgSlot)) s_CfgActive = -1; } sep(); y += rowH;
    const bool armed = ImGui::GetTime() - s_CfgDeleteArm < 3.0;
    if (RowButton("cfg_del", "Delete slot", armed ? "Confirm" : "Delete", x0, x1, y)) {
        if (armed) { Cfg_DeleteSlot(s_CfgSlot); s_CfgDeleteArm = -10.0; } else s_CfgDeleteArm = ImGui::GetTime();
    }
    sep(); y += rowH;
    if (RowButton("cfg_reset", "Factory defaults", "Reset", x0, x1, y)) { Cfg_ResetDefaults(); s_CfgActive = 0; }
    TextV(FText, 15.0f, P(x0 + 25, BodyBottom() - 36), Col(100, 116, 139), Cfg_LastMessage());
    Card(494, kBodyTop, 850, BodyBottom(), 0, nullptr, 0.0f);
    DrawEspPreview(-1);
}

// ===================== Настройки =====================
static void DrawSettingsInterface() {
    static const char *const kLang[2] = { "Русский", "English" };
    static bool sndOn = true;
    sndOn = avis::snd::Enabled();
    const PanelRow left[] = {
        { "set_lang",  "Language",      nullptr,       nullptr,           0,  0,   nullptr, &g_cfg.lang, kLang, 2 },
        { "set_acc",   "Accent color",  nullptr,       nullptr,           0,  0,   nullptr, &g_cfg.accent, nullptr, 0, 1 },
        { "set_scale", "UI scale",      nullptr,       &g_cfg.uiScale,    80, 120, "%.0f%%" },
        { "set_round", "Rounding",      nullptr,       &g_cfg.rounding,   6,  26,  "%.0f" },
        { "set_glow",  "Glow",          &g_cfg.glow,   nullptr,           0,  0,   nullptr },
        { "set_glows", "Glow strength", nullptr,       &g_cfg.glowStrength, 0, 100, "%.0f%%" },
    };
    const PanelRow right[] = {
        { "set_anim",  "Animations",      &g_cfg.anim,      nullptr,           0,   0,  nullptr },
        { "set_aspd",  "Animation speed", nullptr,          &g_cfg.animSpeed,  0.5f, 3, "%.1fx" },
        { "set_part",  "Particles",       &g_cfg.particles, nullptr,           0,   0,  nullptr },
        { "set_shim",  "Shimmer",         &g_cfg.shimmer,   nullptr,           0,   0,  nullptr },
        { "set_dim",   "Dim screen",      &g_cfg.dimScreen, nullptr,           0,   0,  nullptr },
        { "set_lock",  "Lock menu",       &g_cfg.lockMenu,  nullptr,           0,   0,  nullptr },
        { "set_snd",   "Sound",           &sndOn,           nullptr,           0,   0,  nullptr },
    };
    DrawRowsAt(left, 6, 180, 508, 1.0f);
    DrawRowsAt(right, 7, 522, 850, 0.0f);
    if (sndOn != avis::snd::Enabled()) avis::snd::SetEnabled(sndOn);
}

static void DrawSettingsAccount() {
    const float x0 = 180, x1 = 508;
    Card(x0, kBodyTop, x1, BodyBottom(), 0, nullptr, 1.0f);
    const bool localKey = avis::Get().localKey;
    const long rem = (long)avis::RemainingSec();
    const float frac = Anim(ImGui::GetID("##key_ring"), localKey ? 1.0f : ImSaturate((float)rem / 86400.0f), 6.0f);
    const ImVec2 c = P((x0 + x1) * 0.5f, kBodyTop + (BodyBottom() - 92.0f - kBodyTop) * 0.5f);
    const float R = 78.0f * U, th = 9.0f * U;
    DL->AddCircle(c, R, Col(214, 226, 242), 72, th);
    DL->PathClear();
    DL->PathArcTo(c, R, -IM_PI * 0.5f, -IM_PI * 0.5f + 2.0f * IM_PI * frac, 72);
    DL->PathStroke(!localKey && rem < 3600 ? Col(235, 64, 82) : Acc(1.0f), 0, th);
    char tbuf[24];
    if (localKey) snprintf(tbuf, sizeof(tbuf), "%s", g_cfg.lang == 0 ? "Локальный" : "Local");
    else snprintf(tbuf, sizeof(tbuf), "%02ld:%02ld:%02ld", rem / 3600, rem % 3600 / 60, rem % 60);
    const ImVec2 ts = TextSize(FMed, 34.0f, tbuf);
    DL->AddText(FMed, 34.0f * U, ImVec2(c.x - ts.x * 0.5f, c.y - ts.y * 0.5f - 7 * U), Col(15, 23, 42), tbuf);
    const char *label = localKey ? (g_cfg.lang == 0 ? "Без срока действия" : "No expiration") : T("Key valid for");
    const ImVec2 ls = TextSize(FText, 14.0f, label);
    DL->AddText(FText, 14.0f * U, ImVec2(c.x - ls.x * 0.5f, c.y + 18 * U), Col(100, 116, 139), label);

    // «Выйти»: широкая красноватая кнопка внизу карточки
    const ImVec2 ba = P(x0 + 24, BodyBottom() - 66), bb = P(x1 - 24, BodyBottom() - 22);
    bool held = false;
    const bool hit = Hit("##signout", ba, bb, &held);
    const float hv = Anim(ImGui::GetID("##signout"), held ? 1.0f : 0.0f, 22.0f);
    DL->AddRectFilled(ba, bb, LerpCol(Col(235, 64, 82, 0.10f), Col(235, 64, 82), hv), 22 * U);
    DL->AddRect(ba, bb, Col(235, 64, 82, 0.65f), 22 * U, 0, ImMax(1.0f, 1.3f * U));
    const char *so = T("Sign out");
    const ImVec2 ss = TextSize(FMed, 19.0f, so);
    DL->AddText(FMed, 19.0f * U, ImVec2((ba.x + bb.x) * 0.5f - ss.x * 0.5f, (ba.y + bb.y) * 0.5f - ss.y * 0.5f), LerpCol(Col(235, 64, 82), Col(255, 255, 255), hv), so);
    if (hit) avis::Logout();

    Card(522, kBodyTop, 850, BodyBottom(), 0, nullptr, 0.0f);
    const float rowH = 62.0f, y = kBodyTop + 20.0f + rowH * 0.5f;
    if (RowButton("acc_bot", "Get key", "Open", 522, 850, y)) avis::OpenBot();
    DL->AddLine(P(546, y + rowH * 0.5f), P(826, y + rowH * 0.5f), Col(231, 235, 240), ImMax(1.0f, U));
    if (RowButton("acc_chan", "Channel", "Open", 522, 850, y + rowH)) avis::OpenChannel();
}

static void DrawSettings() {
    if (CurSub() == 2) QuickActionsSettings();
    else if (CurSub() == 1) DrawSettingsAccount(); else DrawSettingsInterface();
}

static void DrawVisualCard() {
    switch (CurSub()) {
        case 0:  DrawVisualPlayers(); break;
        case 1:  DrawVisualGear(); break;
        case 2:  DrawVisualOre(); break;
        case 3:  DrawVisualAnimals(); break;
        case 4:  DrawVisualBase(); break;
        case 5:  DrawVisualMore(); break;
        case 6:  DrawVisualStyle(); break;
        case 7:  DrawVisualChams(); break;
        default: Card(180, kBodyTop, 850, BodyBottom(), 0, nullptr, 0.0f); break;
    }
}

static void DrawCards() {
    // Рендерится только содержимое выбранной вкладки.
    switch (s_Tab) {
        case 1:
            DrawAimMain();
            break;
        case 2:  if (CurSub() == 1) DrawCfgCustom(); else DrawCfgPresets(); break;
        case 3:  DrawMemory(); break;
        case 4:  DrawSilentAim(); break;
        case 5:  DrawSettings(); break;
        default: DrawVisualCard(); break;
    }
}

// ===================== Окно меню =====================
static float EaseOutCubic(float t) { t = 1 - t; return 1 - t * t * t; }
static float EaseOutBack(float t) { const float c1 = 1.70158f, c3 = c1 + 1; float x = t - 1; return 1 + c3 * x * x * x + c1 * x * x; }

static ImVec2 s_MenuPos(-1, -1), s_MenuTarget(-1, -1), s_MenuSize(0, 0);

static void DrawMenu() {
    ImGuiIO &io = ImGui::GetIO();
    float dt = ImMin(io.DeltaTime, 0.1f);

    // Анимация появления
    float target = s_MenuOpen ? 1.0f : 0.0f;
    if (!g_cfg.anim || g_cfg.transition == 2) s_OpenT = target;
    else {
        const float step = dt * 4.5f * g_cfg.animSpeed;
        // Equal means settled, not "close". The old +/- expression bounced
        // 1 -> .925 -> 1 every frame, repeatedly setting Block on an open menu.
        if (s_OpenT < target) s_OpenT = ImMin(target, s_OpenT + step);
        else if (s_OpenT > target) s_OpenT = ImMax(target, s_OpenT - step);
    }

    if (s_OpenT <= 0.001f) { CloseCombo(); s_MenuSize = ImVec2(0, 0); return; }

    ImVec2 size(WinW * U, WinH * U);
    ImVec2 disp = io.DisplaySize;
    if (s_MenuPos.x < 0) {
        s_MenuPos = ImVec2((disp.x - size.x) * 0.5f, (disp.y - size.y) * 0.5f);
        s_MenuTarget = s_MenuPos;
    }
    // Custom drag target is updated from a dedicated header handle below.
    if (g_cfg.lockMenu) s_MenuTarget = s_MenuPos;
    s_MenuTarget.x = ImClamp(s_MenuTarget.x, 0.0f, ImMax(0.0f, disp.x - size.x));
    s_MenuTarget.y = ImClamp(s_MenuTarget.y, 0.0f, ImMax(0.0f, disp.y - size.y));
    float follow = 1.0f - expf(-24.0f * dt);
    s_MenuPos = ImLerp(s_MenuPos, s_MenuTarget, follow);
    // Доводим позицию до точной цели — иначе окно вечно «дышит»
    // из-за незатухающего lerp и гуляющего dt (видимое дрожание).
    if (fabsf(s_MenuPos.x - s_MenuTarget.x) < 0.5f) s_MenuPos.x = s_MenuTarget.x;
    if (fabsf(s_MenuPos.y - s_MenuTarget.y) < 0.5f) s_MenuPos.y = s_MenuTarget.y;

    if (g_cfg.dimScreen)
        ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(0, 0), disp, Col(10, 5, 8, 0.30f * s_OpenT));

    // Окно ImGui больше меню на поля M, чтобы тень и свечение не обрезались
    const ImVec2 M(30 * U, 30 * U);
    ImGui::SetNextWindowPos(s_MenuPos - M, ImGuiCond_Always);
    ImGui::SetNextWindowSize(size + M * 2.0f, ImGuiCond_Always);
    ImGuiWindowFlags fl = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBackground |
                          ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollWithMouse |
                          ImGuiWindowFlags_NoNav;
    fl |= ImGuiWindowFlags_NoMove;
    if (!s_MenuOpen) fl |= ImGuiWindowFlags_NoInputs;   // закрывается — касания игнорируем

    ImGui::Begin("##trial_menu", nullptr, fl);
    ImGuiWindow *win = ImGui::GetCurrentWindow();
    DL = ImGui::GetWindowDrawList();
    O = win->Pos + M;
    Block = ComboOpen() || !s_MenuOpen || s_OpenT < .98f;
    int v0 = DL->VtxBuffer.Size;

    ImVec2 a = O, b = O + size;
    DrawWindowFrame(a, b);
    // Верх карточек плавно переезжает: ниже, если у вкладки есть ряд подвкладок.
    kBodyTop = Anim(ImGui::GetID("##body_top"), kTabs[ImClamp(s_Tab, 0, kTabCount - 1)].subCount > 1 ? 154.0f : kSideTop, 16.0f);
    DrawHeader();
    // Drag handle lives in the clear title-bar area and uses a smoothed target position.
    if (!g_cfg.lockMenu && s_MenuOpen && !ComboOpen()) {
        ImGui::SetCursorScreenPos(P(0, 0));
        ImGui::InvisibleButton("##floating_drag", ImVec2(kHeaderDragW * U, 88 * U));
        if (ImGui::IsItemActive()) s_MenuTarget = s_MenuTarget + io.MouseDelta;
    }
    DrawSidebar();
    DrawSubTabs();
    {   // смена вкладки/подвкладки: содержимое всплывает снизу и проявляется
        static int lastTab = -1, lastSub = -1;
        static float swap = 1.0f;
        if (lastTab != s_Tab || lastSub != CurSub()) { if (lastTab >= 0 && g_cfg.anim) swap = 0.0f; lastTab = s_Tab; lastSub = CurSub(); }
        swap = ImMin(1.0f, swap + dt * 5.5f * g_cfg.animSpeed);
        const int vc = DL->VtxBuffer.Size;
        DrawCards();
        if (swap < 1.0f) {
            const float e = EaseOutCubic(swap);
            const float dy = 0.0f;
            for (int i = vc; i < DL->VtxBuffer.Size; i++) {
                ImDrawVert &v = DL->VtxBuffer.Data[i];
                v.pos.y += dy;
                ImU32 al = (v.col >> IM_COL32_A_SHIFT) & 0xFF;
                v.col = (v.col & ~IM_COL32_A_MASK) | ((ImU32)(al * e) << IM_COL32_A_SHIFT);
            }
        }
    }
    Block = false;
    if (s_MenuOpen) ComboPopup();

    // Применяем анимацию открытия ко всем вершинам окна
    if (s_OpenT < 1.0f) {
        float t = s_OpenT, sc;
        if (g_cfg.transition == 1) sc = 0.86f + 0.14f * EaseOutBack(t);
        else                        sc = 0.94f + 0.06f * EaseOutCubic(t);
        TransformVerts(DL, v0, O + size * 0.5f, sc, 0.0f, EaseOutCubic(t));
    }

    s_MenuSize = size;
    ImGui::End();
}

// ===================== Капсула счётчика =====================
static void CometBorder(ImVec2 a, ImVec2 b, float r, ImU32 base, float th) {
    DL->PathRect(a, b, r, 0);
    ImVector<ImVec2> pts; pts.swap(DL->_Path); DL->PathClear();
    int n = pts.Size;
    if (n < 2) return;
    float head = fmodf(s_Time * 0.32f * g_cfg.animSpeed, 1.0f);
    for (int i = 0; i < n; i++) {
        float p = (float)i / n;
        float best = 0;
        for (int k = 0; k < 2; k++) {        // две «кометы» навстречу друг другу по кругу
            float h = fmodf(head + k * 0.5f, 1.0f);
            float d = fmodf(h - p + 1.0f, 1.0f);   // хвост позади головы
            best = ImMax(best, expf(-d * 9.0f));
        }
        ImU32 c = LerpCol(base, best > 0.85f ? AccLight(1.0f) : Acc(1.0f), best);
        DL->AddLine(pts[i], pts[(i + 1) % n], c, th * (1.0f + best * 0.9f));
    }
}

// Белая капсула счётчика: тень, белая подложка, лёгкий голубой отлив
// сверху, голубой контур (бегущий блик, если live) и мягкое свечение.
static void PillBack(ImVec2 a, ImVec2 b, bool live, float on) {
    const float h = b.y - a.y, r = h * 0.5f;
    const float gs = g_cfg.glow ? g_cfg.glowStrength / 100.0f : 0.0f;
    const float pulse = (g_cfg.wmPulse && g_cfg.anim) ? 0.55f + 0.45f * sinf(s_Time * 2.4f * g_cfg.animSpeed) : 0.7f;
    for (int i = 6; i >= 1; i--) {
        float e = i * 2.2f * U;
        DL->AddRectFilled(ImVec2(a.x - e, a.y - e + 3 * U), ImVec2(b.x + e, b.y + e + 3 * U), Col(30, 80, 140, 0.016f), r + e);
    }
    for (int i = 5; i >= 1; i--) {
        float e = i * 2.0f * U;
        DL->AddRect(ImVec2(a.x - e, a.y - e), ImVec2(b.x + e, b.y + e),
                    Col(40, 160, 255, 0.13f * gs * pulse * on * (6 - i) / 5.0f), r + e, 0, 2.2f * U);
    }
    DL->AddRectFilled(a, b, Col(255, 255, 255), r);
    DL->AddRectFilledMultiColor(ImVec2(a.x + r * 0.8f, a.y + 1.5f * U), ImVec2(b.x - r * 0.8f, a.y + h * 0.5f),
        Col(226, 241, 255), Col(226, 241, 255), Col(255, 255, 255), Col(255, 255, 255));
    if (live) {
        DL->AddRect(a, b, Col(10, 96, 224, 0.85f), r, 0, 2.0f * U);
        CometBorder(a, b, r, Col(10, 100, 232, 0.9f), 2.0f * U);
    } else {
        DL->AddRect(a, b, Col(222, 227, 233), r, 0, 1.6f * U);
    }
}

// Длина UTF-8 символа по первому байту (для посимвольной отрисовки с разрядкой).
static inline int Utf8Len(const char *c) { const unsigned char b = (unsigned char)*c; return b < 0x80 ? 1 : b < 0xE0 ? 2 : b < 0xF0 ? 3 : 4; }

// ===================== Счётчик врагов =====================
// Одна капсула вместо двух раздельных: глаз, число, подпись, «живая» точка.
// Число — реальное g_enemyCount (живые игроки без локального).
static void DrawEnemyCounter() {
    ImGuiIO &io = ImGui::GetIO();
    const int n = g_enemyCount < 0 ? 0 : (g_enemyCount > 99 ? 99 : g_enemyCount);
    char num[8];
    snprintf(num, sizeof(num), "%d", n);

    const float h = 40 * U, pad = 15 * U, margin = 14 * U, glowPad = 20 * U;
    const float numSize = 22.0f, labSize = 12.0f, letter = 2.4f * U;
    const char *lab = T("ENEMIES");
    float labW = 0;
    for (const char *c = lab; *c;) { char s[5] = {0}; int n = Utf8Len(c); memcpy(s, c, n); c += n; labW += TextSize(FText, labSize, s).x + letter; }
    labW -= letter;
    // Ширина числа фиксирована по «00»: капсула не дёргается при смене счёта.
    const float numW = ImMax(TextSize(FMed, numSize, "00").x, TextSize(FMed, numSize, num).x);
    const float dotR = 3.6f * U;
    const float w = pad + 22 * U + 10 * U + numW + 11 * U + labW + 12 * U + dotR * 2 + pad;

    const ImVec2 pill((io.DisplaySize.x - w) * 0.5f, margin);

    ImGui::SetNextWindowPos(ImVec2(pill.x - glowPad, pill.y - glowPad), ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(w + glowPad * 2, h + glowPad * 2), ImGuiCond_Always);
    ImGui::Begin("##trial_enemies", nullptr,
        ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBackground |
        ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing |
        ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollWithMouse);
    DL = ImGui::GetWindowDrawList();

    const ImVec2 a = pill, b(pill.x + w, pill.y + h);
    const float cy = a.y + h * 0.5f;

    // Тап по счётчику открывает и закрывает меню.
    ImGui::SetCursorScreenPos(a);
    if (ImGui::InvisibleButton("##en_btn", ImVec2(w, h))) {
        SpawnBurst(io.MousePos);
        s_MenuOpen = !s_MenuOpen;
        CloseCombo();
    }
    const bool held = ImGui::IsItemActive();
    const float press = Anim(ImGui::GetID("##en_press"), held ? 1.0f : 0.0f, 22.0f);
    const int vStart = DL->VtxBuffer.Size;
    const bool live = n > 0;
    const float on = Anim(ImGui::GetID("##en_on"), live ? 1.0f : 0.0f, 8.0f);
    const float pulse = (g_cfg.wmPulse && g_cfg.anim) ? 0.55f + 0.45f * sinf(s_Time * 2.6f * g_cfg.animSpeed) : 0.7f;

    // Всплеск числа при смене счёта.
    static int s_prev = -1;
    static float s_pop = 0.0f;
    if (s_prev != n) { if (s_prev >= 0) s_pop = 1.0f; s_prev = n; }
    s_pop = ImMax(0.0f, s_pop - ImMin(io.DeltaTime, 0.1f) * 4.0f);

    PillBack(a, b, live, on);

    float x = a.x + pad;
    IconEye(ImVec2(x + 11 * U, cy), 22 * U, LerpCol(Col(148, 163, 184), Acc(1.0f), on));
    x += 22 * U + 10 * U;

    {
        const int v0 = DL->VtxBuffer.Size;
        ImVec2 ts = TextSize(FMed, numSize, num);
        ImVec2 np(x + (numW - ts.x) * 0.5f, cy - ts.y * 0.5f);
        DL->AddText(FMed, numSize * U, np, LerpCol(Col(148, 163, 184), Col(15, 23, 42), on), num);
        if (s_pop > 0.001f && g_cfg.anim)
            TransformVerts(DL, v0, ImVec2(np.x + ts.x * 0.5f, cy), 1.0f + 0.26f * s_pop * s_pop, 0.0f, 1.0f);
        x += numW + 11 * U;
    }

    for (const char *c = lab; *c;) {
        char s[5] = {0};
        { int n = Utf8Len(c); memcpy(s, c, n); c += n; }
        TextV(FText, labSize, ImVec2(x, cy), Col(71, 85, 105), s);
        x += TextSize(FText, labSize, s).x + letter;
    }
    x += 12 * U - letter;

    const ImVec2 dc(x + dotR, cy);
    const ImU32 dotCol = LerpCol(Col(148, 163, 184), Acc(1.0f), on);
    DL->AddCircleFilled(dc, dotR * (1.8f + 0.5f * pulse * on), (dotCol & ~IM_COL32_A_MASK) | IM_COL32(0, 0, 0, (int)(50 * on)));
    DL->AddCircleFilled(dc, dotR, dotCol);

    if (press > 0.001f) TransformVerts(DL, vStart, (a + b) * 0.5f, 1.0f - 0.07f * press, 0.0f, 1.0f);
    ImGui::End();
}

// ===================== Кадр =====================
void Menu::Render() {
    ImGuiIO &io = ImGui::GetIO();
    float dt = ImMin(io.DeltaTime, 0.1f);
    s_Time += dt;
    ClampSettings(g_cfg);
    U = ImMin(s_Base * g_cfg.uiScale / 100.0f, ImMin(io.DisplaySize.x * .94f / WinW, io.DisplaySize.y * .92f / WinH));

    // История FPS для графика
    s_FpsTimer += dt;
    if (s_FpsTimer >= 0.1f) {
        s_FpsTimer = 0;
        s_FpsHist[s_FpsHead] = io.Framerate;
        s_FpsHead = (s_FpsHead + 1) % 48;
    }
    if (g_cfg.particles) UpdateParticles(dt);

    AutoHealCapture(s_MenuOpen);
    QuickActionsFrame(s_MenuOpen);
    DrawMenu();
    DrawEnemyCounter();   // после меню — кнопка всегда поверх
    UI::RenderEffects();
    g_menuOpen = s_MenuOpen;

    MenuAutosaveTick(dt);
}

// Автосохранение через 0.8 с после последнего изменения (зовёт и экран ключа: язык меняют до входа).
void MenuAutosaveTick(float dt) {
    Cfg_AutoTick(dt);
    QuickActionsSaveTick(dt);
    if (memcmp(&s_Saved, &g_cfg, sizeof(g_cfg)) != 0) {
        if (s_SaveTimer < 0) s_SaveTimer = 0.8f;
        s_SaveTimer -= dt;
        if (s_SaveTimer <= 0) { SaveSettings(); s_SaveTimer = -1.0f; }
    } else {
        s_SaveTimer = -1.0f;
    }
}

float MenuBaseScale() { return s_Base; }

// Та же анимация в кружке, что в шапке меню, для экрана ключа (там Menu::Render не идёт, поэтому время передаём сами).
void MenuDrawLogo(ImVec2 c, float R, float time) {
    const float saved = s_Time;
    s_Time = time;
    DrawLogo(c, R);
    s_Time = saved;
}

#ifdef AVIS_PREVIEW
void MenuPreviewSelect(int tab, int sub) { s_Tab = tab; s_SubSel[tab] = sub; s_MenuOpen = true; s_OpenT = 1.0f; }
int MenuPreviewTab() { return s_Tab; }
bool MenuPreviewOpen() { return s_MenuOpen; }
float MenuPreviewOpenFraction() { return s_OpenT; }
#endif

// Точка входа для main.cpp: ленивая инициализация + подгрузка текстур по кадрам.
void OxDrawTrialMenu() {
    static bool inited = false;
    ImGuiIO &io = ImGui::GetIO();
    if (io.DisplaySize.x < 2.0f || io.DisplaySize.y < 2.0f) return;
    if (!inited) {
        inited = true;
        if (g_DataDir.empty()) g_DataDir = "/sdcard/Download/AvisTools";
        float lo = ImMin(io.DisplaySize.x, io.DisplaySize.y), hi = ImMax(io.DisplaySize.x, io.DisplaySize.y);
        Menu::Init((int)hi, (int)lo);
    }
    TrialUploadTextures();
    if (AuthScreenRender()) return;   // пока нет действующего ключа — только экран ввода ключа
    Menu::Render();
}
