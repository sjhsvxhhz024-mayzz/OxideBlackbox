// Перевод интерфейса: ключ — английская строка, язык выбирается g_cfg.lang (0 русский, 1 English).
// Строка, которой нет в таблице, выводится как есть (так безопасно показывать и динамические надписи).
#include "trial_ui.h"

#include <algorithm>
#include <string.h>
#include <vector>

#if defined(__ANDROID__)
#include <sys/system_properties.h>
#endif

namespace {

struct Entry { const char *en, *ru; };

const Entry kRaw[] = {
    {"Chams","Чамсы"}, {"Overlay Chams","Оверлейные чамсы"}, {"Effect style","Стиль эффекта"},
    {"Aurora","Аврора"}, {"Cyber","Кибер"}, {"Ember","Пламя"}, {"Frost","Лёд"},
    {"Opacity","Прозрачность"}, {"Animate Chams","Анимация чамсов"}, {"Flow speed","Скорость перелива"},
    {"Death dissolve","Распад при смерти"}, {"Dissolve time s","Время распада, с"},
    {"Preview dissolve","Превью распада"}, {"Play","Показать"},
    {"Bone silhouette, not the original mesh","Силуэт по костям, не оригинальная модель"},
    {"X-ray", "Иксрей"}, {"Clip distance m", "Дистанция среза, м"},
    {"Camera cut, not a radius", "Срез камеры, не радиус"},
    {"Nearby players and items are also clipped", "Близкие игроки и предметы тоже исчезают"},
    {"X-ray: off", "Иксрей: выключен"}, {"X-ray: active", "Иксрей: активен"},
    {"X-ray: waiting for camera", "Иксрей: ожидание камеры"},
    {"X-ray: restore failed", "Иксрей: ошибка восстановления"},
    {"X-ray: unsupported projection", "Иксрей: неподдерживаемая проекция"},
    {"X-ray: invalid clip range", "Иксрей: неверная дистанция"},
    {"X-ray: ambiguous camera fields", "Иксрей: неоднозначное поле камеры"},
    {"X-ray: clip field not found", "Иксрей: поле среза не найдено"},
    {"X-ray: camera identity unavailable", "Иксрей: камера не подтверждена"},
    {"X-ray: camera identity changed", "Иксрей: камера изменилась"},
    {"X-ray: projection did not respond", "Иксрей: проекция не отреагировала"},
    {"X-ray: camera fields changed", "Иксрей: параметры камеры изменились"},
    {"X-ray: distance unchanged", "Иксрей: дистанция уже задана"},
    {"X-ray: write failed", "Иксрей: ошибка записи"},
    {"X-ray: verifying camera", "Иксрей: подтверждение поля камеры"},
    {"Slot 1", "Слот 1"}, {"Slot 2", "Слот 2"}, {"Slot 3", "Слот 3"},
    {"Slot 4", "Слот 4"}, {"Slot 5", "Слот 5"}, {"Slot 6", "Слот 6"},
    {"Auto heal", "Автохил"}, {"HP threshold", "Порог HP"}, {"Medicine slot", "Слот лечения"},
    {"Use time ms", "Лечение, мс"}, {"Cooldown ms", "Пауза, мс"}, {"Dose limit", "Лимит доз"},
    {"Game control", "Кнопка игры"}, {"Use button", "Использовать"}, {"Position", "Позиция"},
    {"Calibration", "Калибровка"}, {"Set", "Задать"}, {"Change", "Изменить"},
    {"Auto heal: off", "Автохил выключен"}, {"Heal paused", "Автохил на паузе"},
    {"Selecting medicine", "Выбор лечения"}, {"Healing", "Лечение"}, {"Returning item", "Возврат предмета"},
    {"Heal cooldown", "Пауза между дозами"}, {"Heal stopped", "Остановлен · включи заново"},
    {"Waiting for low HP", "Ожидание низкого HP"}, {"Game must be foreground", "Открой игру на переднем плане"},
    {"Android input unavailable", "Ввод Android недоступен"}, {"Only bandage or medkit", "Только бинт или аптечка"},
    {"Returns the previous slot", "Возвращает предыдущий слот"},
    {"Tap the game control · Esc to cancel", "Нажми кнопку игры · Esc — отмена"},

    {"Current", "Текущие"}, {"Diagnostics", "Диагностика"}, {"Details", "Открыть"},
    {"Stretch: off", "Растяжка: выкл."}, {"Logs: on", "Логи: вкл."}, {"Logs: off", "Логи: выкл."},
    {"Quick actions", "Быстрые действия"}, {"Quick slot", "Быстрый слот"}, {"Function", "Функция"},
    {"Enable binding", "Включить бинд"}, {"Show button", "Показать кнопку"}, {"Bind key", "Клавиша"},
    {"Remove binding", "Удалить бинд"}, {"Menu key", "Клавиша меню"}, {"Press a key", "Нажми клавишу"},
    {"Unassigned", "Не назначено"}, {"Clear", "Очистить"}, {"Button size", "Размер кнопки"},
    {"Button opacity", "Прозрачность"}, {"Button positions", "Позиции кнопок"},
    {"Keyboard shortcuts", "Клавиши быстрого доступа"}, {"Floating buttons", "Плавающие кнопки"},
    {"Keyboard devices", "Клавиатуры"}, {"Quick controls could not be saved", "Не удалось сохранить быстрые действия"},
    {"This key is reserved for the menu", "Эта клавиша занята меню"}, {"ESP", "ESP"},
    // вкладки и подвкладки
    {"Visual", "Визуал"}, {"Aim", "Прицел"}, {"Configs", "Конфиги"}, {"Memory", "Память"}, {"Silent", "Сайлент"}, {"Settings", "Настройки"},
    {"Players", "Игроки"}, {"Gear", "Снаряжение"}, {"Ore", "Руда"}, {"Animals", "Животные"}, {"Base", "Базы"}, {"More", "Ещё"}, {"Style", "Стиль"},
    {"Main", "Основное"}, {"Presets", "Пресеты"}, {"Custom", "Свои"}, {"Weapon", "Оружие"}, {"Stretch", "Растяжка"}, {"Boost", "Буст"},
    {"Interface", "Интерфейс"}, {"Account", "Аккаунт"},
    // визуал
    {"ESP Box", "Бокс"}, {"Corner box", "Угловой бокс"}, {"Box fill", "Заливка бокса"}, {"ESP Line", "Линия"}, {"Skeleton", "Скелет"},
    {"ESP Name", "Имя"}, {"ESP Clan", "Клан"}, {"ESP HP", "Здоровье"}, {"Distance", "Дистанция"}, {"Status flags", "Статусы"},
    {"Armor ESP", "Броня"}, {"Held item ESP", "Предмет в руке"}, {"Ore ESP", "Руда"}, {"Stone", "Камень"}, {"Metal", "Металл"},
    {"Sulfur", "Сера"}, {"Coal", "Уголь"}, {"Range m", "Дальность, м"}, {"Distance m", "Дистанция, м"},
    {"Animal ESP", "Животные"}, {"Bear", "Медведь"}, {"Boar", "Кабан"}, {"Deer", "Олень"}, {"Rabbit", "Кролик"}, {"Hare", "Заяц"},
    {"Chicken", "Курица"}, {"Fish", "Рыба"}, {"Rat", "Крыса"}, {"Cannibal", "Каннибал"},
    {"Base ESP", "Базы"}, {"Cupboards", "Шкафы"}, {"Turrets/traps", "Турели и ловушки"}, {"Sleeping bags", "Спальники"}, {"Sleepers", "Спящие"},
    {"Cupboard through walls", "Просвет шкафов"}, {"Search radius m", "Радиус поиска, м"}, {"Guide to cupboards", "Линия к шкафам"},
    {"Dist color", "Цвет по дистанции"}, {"Fill alpha", "Прозр. заливки"}, {"Corner len", "Длина углов"}, {"Line origin", "Старт линии"},
    {"Radar", "Радар"}, {"Radar range", "Дальность радара"}, {"Radar size", "Размер радара"}, {"Radar alpha", "Прозр. радара"},
    // стиль
    {"Element", "Элемент"}, {"Box", "Бокс"}, {"Line", "Линия"}, {"Name", "Имя"}, {"Clan", "Клан"}, {"HP", "Здоровье"},
    {"Width", "Толщина"}, {"Size", "Размер"}, {"Hue", "Оттенок"}, {"Sat", "Насыщ."}, {"Bright", "Яркость"},
    {"Bottom", "Снизу"}, {"Center", "Центр"}, {"Origin", "Начало"}, {"Defaults", "По умолчанию"}, {"Reset", "Сброс"},
    // прицел
    {"Always", "Всегда"}, {"ADS", "Прицеливание"}, {"Fire", "Стрельба"}, {"ADS or Fire", "Прицел или огонь"}, {"ADS + Fire", "Прицел + огонь"},
    {"Head", "Голова"}, {"Neck", "Шея"}, {"Body", "Тело"}, {"Closest", "Ближайшая"},
    {"Aimbot", "Аимбот"}, {"Trigger", "Активация"}, {"Target", "Цель"}, {"FOV px", "FOV, пкс"}, {"FOV", "FOV"}, {"Smooth", "Плавность"},
    {"Sticky target", "Липкая цель"}, {"Draw FOV", "Круг FOV"}, {"Draw target", "Метка цели"}, {"Recoil comp", "Компенсация отдачи"},
    {"Linear speed", "Линейная скорость"}, {"Max speed", "Макс. скорость"}, {"Dead zone", "Мёртвая зона"}, {"Ramp ms", "Разгон, мс"},
    {"Fire hold s", "Удержание, с"}, {"Switch ratio", "Порог смены"}, {"Prediction", "Упреждение"}, {"Bullet speed", "Скорость пули"},
    {"Latency ms", "Задержка, мс"}, {"Gravity", "Гравитация"},
    // память
    {"No Recoil", "Без отдачи"}, {"No Spread", "Без разброса"}, {"Aspect ratio", "Соотношение"}, {"Custom ratio", "Своё значение"},
    {"Auto", "Авто"}, {"Draw distance", "Дальность прорисовки"}, {"Hide grass", "Скрыть траву"}, {"Hide trees", "Скрыть деревья"},
    {"Overlay FPS", "FPS оверлея"}, {"Disable logs", "Без логов"},
    // silent
    {"Look direction", "По взгляду"}, {"Silent aim", "Сайлент-аим"}, {"Type", "Тип"}, {"Target bone", "Кость цели"},
    // конфиги
    {"Config slot", "Слот конфига"}, {"Slot", "Слот"}, {"Save current", "Текущие"}, {"Save", "Сохранить"}, {"Load slot", "Загрузить слот"},
    {"Load", "Загрузить"}, {"Delete slot", "Удалить слот"}, {"Confirm", "Точно?"}, {"Delete", "Удалить"}, {"Factory defaults", "По умолчанию"},
    {"Active", "Активен"}, {"Apply", "Применить"},
    // настройки
    {"Language", "Язык"}, {"Accent color", "Цвет акцента"}, {"UI scale", "Масштаб"}, {"Rounding", "Скругление"}, {"Glow", "Свечение"},
    {"Glow strength", "Сила свечения"}, {"Animations", "Анимации"}, {"Animation speed", "Темп анимаций"}, {"Particles", "Частицы"},
    {"Shimmer", "Блик"}, {"Dim screen", "Затемнять фон"}, {"Lock menu", "Закрепить окно"}, {"Open on start", "Открывать при старте"},
    {"Sound", "Звук"}, {"Sign out", "Выйти"}, {"Key valid for", "Ключ действует"}, {"Get key", "Получить ключ"}, {"Channel", "Канал"},
    {"Open", "Открыть"}, {"Key", "Ключ"},
    // экран ключа
    {"Paste", "Вставить"}, {"Reading...", "Читаю..."},
    {"ENEMIES", "ВРАГИ"},
};

struct Table {
    std::vector<Entry> v;
    Table() {
        v.assign(kRaw, kRaw + sizeof(kRaw) / sizeof(kRaw[0]));
        std::sort(v.begin(), v.end(), [](const Entry &a, const Entry &b) { return strcmp(a.en, b.en) < 0; });
    }
};

}  // namespace

namespace UI {

const char *T(const char *en) {
    if (!en || g_cfg.lang != 0) return en;
    static const Table table;
    const auto it = std::lower_bound(table.v.begin(), table.v.end(), en, [](const Entry &e, const char *k) { return strcmp(e.en, k) < 0; });
    return it != table.v.end() && strcmp(it->en, en) == 0 ? it->ru : en;
}

}  // namespace UI

// Язык по умолчанию при первом запуске: русский для русскоязычных локалей СНГ, иначе английский.
int DetectSystemLang() {
#if defined(__ANDROID__)
    char v[PROP_VALUE_MAX] = {0};
    const char *props[] = {"persist.sys.locale", "ro.product.locale", "persist.sys.language"};
    for (const char *p : props) {
        __system_property_get(p, v);
        if (v[0]) break;
    }
    static const char *ru[] = {"ru", "uk", "be", "kk", "ky", "uz", "tg", "hy", "az", "ka"};
    for (const char *r : ru) if (!strncmp(v, r, strlen(r))) return 0;
#endif
    return 1;
}
