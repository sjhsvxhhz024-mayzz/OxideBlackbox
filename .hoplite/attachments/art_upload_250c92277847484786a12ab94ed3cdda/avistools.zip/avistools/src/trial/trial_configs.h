#pragma once
// Конфиги: готовые пресеты и пользовательские слоты. Файлы лежат в /sdcard/Download/AvisTools/configs/custom_N.cfg
// (текст «ключ=значение», можно править руками).

struct CfgPresetInfo {
    const char *name;
    const char *desc;
    float box[3], skeleton[3], line[3];     // цвета для плашки-образца в меню
};

int  Cfg_PresetCount();
const CfgPresetInfo &Cfg_PresetInfo(int i);
void Cfg_ApplyPreset(int i);                // применяет пресет к настройкам (визуал и аим)

constexpr int kCfgSlots = 8;
bool Cfg_SlotExists(int slot);              // slot 0..kCfgSlots-1
bool Cfg_SaveSlot(int slot);                // true при успехе
bool Cfg_LoadSlot(int slot);
bool Cfg_DeleteSlot(int slot);
const char *Cfg_Dir();
const char *Cfg_LastMessage();              // результат последней операции для строки состояния в меню
void Cfg_ResetDefaults();
void Cfg_Snapshot();                        // запомнить заводские значения (вызывается при инициализации меню)

// Автосохранение всех настроек (включая включатели) в Download/AvisTools/settings.cfg.
void Cfg_AutoLoad();                        // при старте: восстановить сохранённое
void Cfg_AutoTick(float dt);                // каждый кадр: запись через 0.8 с после последнего изменения
bool Cfg_AutoSaveNow();                     // немедленно (выход)
