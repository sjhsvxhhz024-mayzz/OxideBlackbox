// Экран ввода ключа Avis tools: показывается сразу после запуска, пока нет действующего ключа.
//
// Светлая карточка с анимацией в кружке, поле ввода с кнопкой «Вставить» и своя QWERTY-клавиатура (у оверлея нет системной).
// Позади — наш видеобаннер (покадровый атлас) на весь экран. Нажатие срабатывает сразу при касании: клавиша вдавливается,
// над ней всплывает увеличенный символ, расходится рябь и играет звук (auth/auth_sound). Всё сетевое — в фоновом потоке.
#include "trial_ui.h"
#include "auth/auth_client.h"
#include "auth/auth_config.h"
#include "auth/auth_proto.h"
#include "auth/auth_sound.h"

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>

using namespace UI;

namespace {

// ----- геометрия карточки (дизайн-единицы) -----
float CW = 640.0f, CH = 530.0f;
constexpr float CR = 24.0f;
constexpr float KB_X = 16.0f, KB_GAP = 6.0f, KEY_H = 46.0f, KB_Y = 256.0f;
float KB_W = 608.0f;
constexpr float FIELD_Y = 158.0f, FIELD_H = 50.0f;

// Серверный алфавит без 0/O/1/I. I/O и знаки нужны только локальному ключу.
const char kAlphabet[] = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
bool KeyValid(char c) { return c && strchr(kAlphabet, c) != nullptr; }

enum Kind { K_CHAR, K_CLEAR, K_BACK, K_GETKEY, K_BAR, K_ENTER };
struct Key { Kind kind; char ch; float x, y, w, h; };
std::vector<Key> s_keys;

void BuildKeys() {
    s_keys.clear();
    if (CW < 500) {
        float y=KB_Y;
        auto row=[&](const char *chars,int columns) {
            const float w=(KB_W-(columns-1)*KB_GAP)/columns;
            const int n=(int)strlen(chars);
            const float start=KB_X+(KB_W-(n*w+(n-1)*KB_GAP))*.5f;
            for(int i=0;i<n;++i)s_keys.push_back({K_CHAR,chars[i],start+i*(w+KB_GAP),y,w,KEY_H});
            y+=KEY_H+KB_GAP;
        };
        row("23456789",8);
        row("QWERTYU",7);row("IOPASDF",7);row("GHJKLZX",7);row("CVBNM./",7);
        const float small=44, enter=72, get=KB_W-2*small-enter-3*KB_GAP;
        s_keys.push_back({K_CLEAR,0,KB_X,y,small,KEY_H});
        s_keys.push_back({K_BACK,0,KB_X+small+KB_GAP,y,small,KEY_H});
        s_keys.push_back({K_GETKEY,0,KB_X+2*(small+KB_GAP),y,get,KEY_H});
        s_keys.push_back({K_ENTER,0,KB_X+KB_W-enter,y,enter,KEY_H});
        return;
    }
    const float w = (KB_W - 9 * KB_GAP) / 10.0f;
    float y = KB_Y;
    auto row = [&](const char *chars, float x0) {
        for (int i = 0; chars[i]; ++i) s_keys.push_back({K_CHAR, chars[i], x0 + i * (w + KB_GAP), y, w, KEY_H});
    };
    row("1234567890", KB_X);                       y += KEY_H + KB_GAP;
    row("QWERTYUIOP", KB_X);                       y += KEY_H + KB_GAP;
    row("ASDFGHJKL", KB_X + (KB_W - (9 * w + 8 * KB_GAP)) * 0.5f);   y += KEY_H + KB_GAP;
    const float sp = 86.0f;
    s_keys.push_back({K_CLEAR, 0, KB_X, y, sp, KEY_H});
    const char *lastRow = "ZXCVBNM./";
    const int lastCount = (int)strlen(lastRow);
    const float lastW = (KB_W - 2 * sp - (lastCount + 1) * KB_GAP) / lastCount;
    for (int i = 0; i < lastCount; ++i)
        s_keys.push_back({K_CHAR, lastRow[i], KB_X + sp + KB_GAP + i * (lastW + KB_GAP), y, lastW, KEY_H});
    s_keys.push_back({K_BACK, 0, KB_X + KB_W - sp, y, sp, KEY_H});
    y += KEY_H + KB_GAP;
    const float gw = 190.0f, ew = 118.0f;
    s_keys.push_back({K_GETKEY, 0, KB_X, y, gw, KEY_H});
    s_keys.push_back({K_BAR, 0, KB_X + gw + KB_GAP, y, KB_W - gw - ew - 2 * KB_GAP, KEY_H});
    s_keys.push_back({K_ENTER, 0, KB_X + KB_W - ew, y, ew, KEY_H});
}

// ----- состояние -----
char  s_chars[sizeof(avis::kLocalKey)] = {0};
int   s_len = 0;
float s_enter = 0, s_time = 0, s_appear = 0, s_success = -1.0f, s_noteT = 0, s_shake = 0, s_backHeld = 0, s_repeatT = 0;
bool  s_burst = false, s_wasActive = false, s_prefilled = false, s_soundInit = false, s_errShown = false;
char  s_note[128] = {0};
int   s_heldKey = -1;                      // клавиша, которую держат сейчас (для пузыря-превью)
char  s_previewHold = 0;                   // только для хост-превью
struct Ripple { ImVec2 p; float t; int key; };
std::vector<Ripple> s_ripples;

// ----- цвета (светлая тема, как на образце) -----
ImU32 Ink(float a = 1.0f)    { return Col(17, 24, 39, a); }
ImU32 Grey(float a = 1.0f)   { return Col(142, 142, 147, a); }
ImU32 Bad(float a = 1.0f)    { return Col(235, 64, 82, a); }
ImU32 Good(float a = 1.0f)   { return Col(24, 143, 90, a); }
float Clamp01(float v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
float EaseOutBack(float t) { const float c1 = 1.70158f, c3 = c1 + 1; float u = t - 1; return 1 + c3 * u * u * u + c1 * u * u; }

void CText(ImFont *f, float size, float cx, float cy, ImU32 col, const char *t) {   // текст по центру (дизайн-единицы)
    const ImVec2 ts = TextSize(f, size, t);
    const ImVec2 p = P(cx, cy);
    DL->AddText(f, size * U, ImVec2(p.x - ts.x * 0.5f, p.y - ts.y * 0.5f), col, t);
}

// ----- иконки (контурные, как на образце) -----
void IconBackspace(ImVec2 c, float s, ImU32 col) {
    const float w = s * 0.5f, h = s * 0.32f, th = ImMax(1.5f, s * 0.085f);
    ImVec2 pts[5] = {ImVec2(c.x - w, c.y), ImVec2(c.x - w * 0.5f, c.y - h), ImVec2(c.x + w, c.y - h), ImVec2(c.x + w, c.y + h), ImVec2(c.x - w * 0.5f, c.y + h)};
    DL->AddPolyline(pts, 5, col, ImDrawFlags_Closed | ImDrawFlags_RoundCornersAll, th);
    const float q = h * 0.5f;
    DL->AddLine(ImVec2(c.x - q * 0.1f, c.y - q), ImVec2(c.x + q * 1.7f, c.y + q), col, th);
    DL->AddLine(ImVec2(c.x + q * 1.7f, c.y - q), ImVec2(c.x - q * 0.1f, c.y + q), col, th);
}
void IconCheck(ImVec2 c, float s, ImU32 col) {
    const float th = ImMax(1.8f, s * 0.11f);
    ImVec2 p[3] = {ImVec2(c.x - s * 0.30f, c.y + s * 0.02f), ImVec2(c.x - s * 0.07f, c.y + s * 0.24f), ImVec2(c.x + s * 0.32f, c.y - s * 0.20f)};
    DL->AddPolyline(p, 3, col, 0, th);
}
void IconClear(ImVec2 c, float s, ImU32 col) {            // круг с крестиком: «стереть всё»
    const float th = ImMax(1.5f, s * 0.085f), r = s * 0.40f, q = r * 0.42f;
    DL->AddCircle(c, r, col, 28, th);
    DL->AddLine(ImVec2(c.x - q, c.y - q), ImVec2(c.x + q, c.y + q), col, th);
    DL->AddLine(ImVec2(c.x + q, c.y - q), ImVec2(c.x - q, c.y + q), col, th);
}
void IconPlane(ImVec2 c, float s, ImU32 col) {            // бумажный самолётик Telegram
    ImVec2 p[4] = {ImVec2(c.x - s * 0.5f, c.y - s * 0.05f), ImVec2(c.x + s * 0.5f, c.y - s * 0.46f), ImVec2(c.x + s * 0.18f, c.y + s * 0.46f), ImVec2(c.x - s * 0.04f, c.y + s * 0.12f)};
    DL->AddConvexPolyFilled(p, 4, col);
}
void IconSpeaker(ImVec2 c, float s, ImU32 col, bool on) {
    const float th = ImMax(1.5f, s * 0.085f);
    ImVec2 p[6] = {ImVec2(c.x - s * 0.34f, c.y - s * 0.13f), ImVec2(c.x - s * 0.17f, c.y - s * 0.13f), ImVec2(c.x + s * 0.04f, c.y - s * 0.32f),
                   ImVec2(c.x + s * 0.04f, c.y + s * 0.32f), ImVec2(c.x - s * 0.17f, c.y + s * 0.13f), ImVec2(c.x - s * 0.34f, c.y + s * 0.13f)};
    DL->AddPolyline(p, 6, col, ImDrawFlags_Closed | ImDrawFlags_RoundCornersAll, th);
    if (on) {
        for (int k = 0; k < 2; ++k) {
            DL->PathClear();
            DL->PathArcTo(ImVec2(c.x + s * 0.04f, c.y), s * (0.20f + 0.17f * k), -0.75f, 0.75f, 12);
            DL->PathStroke(col, 0, th);
        }
    } else {
        DL->AddLine(ImVec2(c.x + s * 0.14f, c.y - s * 0.16f), ImVec2(c.x + s * 0.42f, c.y + s * 0.16f), col, th);
        DL->AddLine(ImVec2(c.x + s * 0.42f, c.y - s * 0.16f), ImVec2(c.x + s * 0.14f, c.y + s * 0.16f), col, th);
    }
}
void IconPaste(ImVec2 c, float s, ImU32 col) {            // планшет с листом
    const float w = s * 0.62f, h = s * 0.78f, th = ImMax(1.3f, s * 0.10f);
    DL->AddRect(ImVec2(c.x - w * 0.5f, c.y - h * 0.40f), ImVec2(c.x + w * 0.5f, c.y + h * 0.56f), col, s * 0.12f, 0, th);
    DL->AddRectFilled(ImVec2(c.x - w * 0.24f, c.y - h * 0.56f), ImVec2(c.x + w * 0.24f, c.y - h * 0.24f), col, s * 0.07f);
}
void Spinner(ImVec2 c, float r, float th) {
    DL->PathClear();
    const float a0 = g_cfg.anim ? s_time * 5.0f : -.5f * IM_PI;
    const float sweep = g_cfg.anim ? 4.2f + 1.2f * sinf(s_time * 2.2f) : 4.7f;
    DL->PathArcTo(c, r, a0, a0 + sweep, 40);
    DL->PathStroke(Acc(1.0f), 0, th);
}

// ----- затемнение игры за окном (ролик живёт внутри самой карточки, см. DrawVideoRect) -----
void DrawDim(ImVec2 disp, float alpha) {
    ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(0, 0), disp, Col(0, 0, 0, 0.30f * alpha));
}

// ----- ввод -----
char UpperAscii(char c) { return c >= 'a' && c <= 'z' ? (char)(c - 'a' + 'A') : c; }
bool LocalPrefix() {
    for (int i = 0; i < s_len; ++i)
        if (UpperAscii(s_chars[i]) != UpperAscii(avis::kLocalKey[i])) return false;
    return true;
}
bool LocalMode() { return s_len >= 2 && s_chars[1] == '.'; }
bool CanAppend(char c) {
    if (s_len < (int)sizeof(avis::kLocalKey) - 1 && LocalPrefix() &&
        UpperAscii(c) == UpperAscii(avis::kLocalKey[s_len])) return true;
    return !LocalMode() && s_len < 12 && KeyValid(c);
}
void FillFrom(const std::string &raw) {
    s_len = 0;
    if (avis::IsLocalKey(raw)) {
        for (char ch : std::string(avis::kLocalKey)) s_chars[s_len++] = ch;
    } else {
        std::string body = raw;
        if (body.compare(0, 5, "AVIS-") == 0) body.erase(0, 5);
        for (char ch : body) if (ch != '-' && s_len < 12) s_chars[s_len++] = UpperAscii(ch);
    }
    s_chars[s_len] = 0;
}
std::string TypedKey() {
    if (s_len == (int)sizeof(avis::kLocalKey) - 1 && avis::IsLocalKey(std::string(s_chars, s_len)))
        return avis::kLocalKey;
    if (s_len != 12) return "";
    for (int i = 0; i < s_len; ++i) if (!KeyValid(s_chars[i])) return "";
    return std::string("AVIS-") + std::string(s_chars, 4) + "-" + std::string(s_chars + 4, 4) + "-" + std::string(s_chars + 8, 4);
}
void Note(const char *t) { snprintf(s_note, sizeof(s_note), "%s", t); s_noteT = 3.6f; s_shake = 1.0f; avis::snd::Play(avis::snd::Sfx::Error); }

// channel — имя канала с сервера (без @); пока сервер не ответил, берётся запасное из auth_config.h.
const char *MsgText(avis::Msg m, const std::string &channel) {
    static char unsub[96];
    switch (m) {
        case avis::Msg::BadFormat: return L("Проверьте ключ", "Check your key");
        case avis::Msg::Invalid:   return L("Неверный ключ", "Invalid key");
        case avis::Msg::Expired:   return L("Срок ключа истёк", "Key expired");
        case avis::Msg::Revoked:   return L("Ключ отозван", "Key revoked");
        case avis::Msg::Banned:    return L("Доступ закрыт", "Access denied");
        case avis::Msg::Hwid:      return L("Ключ уже привязан к другому устройству", "The key is bound to another device");
        case avis::Msg::Unsub:     snprintf(unsub, sizeof(unsub), "%s t.me/%s", L("Подпишитесь на канал", "Subscribe to"), channel.empty() ? AVIS_CHANNEL_DEFAULT : channel.c_str()); return unsub;
        case avis::Msg::Network:   return L("Нет связи с сервером", "No connection to the server");
        case avis::Msg::BadServer: return L("Ответ сервера не прошёл проверку подписи", "The server reply failed signature check");
        case avis::Msg::NoServer:  return L("Адрес сервера не задан (server.txt)", "Server address is not set (server.txt)");
        default: return "";
    }
}

// ----- кнопки -----
// Круглая кнопка в углу (звук).
bool CircleButton(const char *id, ImVec2 c, float r) {
    bool held = false;
    ImGui::SetCursorScreenPos(ImVec2(c.x - r * 1.3f, c.y - r * 1.3f));
    const bool hit = ImGui::InvisibleButton(id, ImVec2(r * 2.6f, r * 2.6f));
    held = ImGui::IsItemActive();
    const float hv = Anim(ImGui::GetID(id), held ? 1.0f : 0.0f, 24.0f);
    DL->AddCircleFilled(c, r, LerpCol(Col(255, 255, 255), Col(222, 224, 230), hv), 32);
    DL->AddCircle(c, r, Col(205, 208, 216), 32, ImMax(1.0f, U));
    return hit;
}

// Плашка-ссылка / вторичная кнопка. style: 0 — залитая акцентом, 1 — светлая с акцентным текстом, 2 — белая с серым текстом.
bool Pill(const char *id, float x0, float y0, float x1, float y1, const char *label, int style, float fs, float hitPad = 0.0f, bool enabled = true) {
    const ImVec2 a = P(x0, y0), b = P(x1, y1);
    ImGui::SetCursorScreenPos(ImVec2(a.x, a.y - hitPad * U));
    const bool hit = enabled && ImGui::InvisibleButton(id, ImVec2(b.x - a.x, b.y - a.y + 2 * hitPad * U));
    const bool held = enabled && ImGui::IsItemActive();
    const float hv = Anim(ImGui::GetID(id), held ? 1.0f : 0.0f, 24.0f);
    const float r = 8.0f * U;
    const int v0 = DL->VtxBuffer.Size;
    ImU32 txt;
    if (style == 0) { DL->AddRectFilled(a, b, LerpCol(Acc(1.0f), Col(10, 60, 160), 0.35f * hv), r); txt = Col(255, 255, 255); }
    else if (style == 1) { DL->AddRectFilled(a, b, Acc(0.07f + 0.08f * hv), r); DL->AddRect(a, b, Acc(0.16f), r, 0, ImMax(1.0f, 1.2f * U)); txt = Acc(1.0f); }
    else { DL->AddRectFilled(a, b, LerpCol(Col(255, 255, 255), Col(226, 228, 234), hv), r); DL->AddRect(a, b, Col(205, 208, 216), r, 0, ImMax(1.0f, U)); txt = Grey(); }
    if (!enabled) txt = Grey(0.6f);
    CText(FMed, fs, (x0 + x1) * 0.5f, (y0 + y1) * 0.5f, txt, label);
    if (hv > 0.001f) TransformVerts(DL, v0, (a + b) * 0.5f, 1.0f - 0.04f * hv, 0.0f, 1.0f);
    return hit;
}

// ----- клавиатура -----
// Нажатие срабатывает при касании (а не при отпускании): так печатать быстрее и «живее».
void DrawKey(const Key &k, int idx, bool locked, bool ready, bool &pressedNow, bool &activated, float dt) {
    const ImVec2 a = P(k.x, k.y), b = P(k.x + k.w, k.y + k.h);
    const int vAll = DL->VtxBuffer.Size;
    char id[16];
    snprintf(id, sizeof(id), "##k%d", idx);
    const bool charOk = k.kind != K_CHAR || CanAppend(k.ch);
    const bool inert = k.kind == K_BAR || locked;
    bool active = false;
    activated = false;
    if (!inert) {
        ImGui::SetCursorScreenPos(a);
        ImGui::InvisibleButton(id, ImVec2(b.x - a.x, b.y - a.y));
        active = ImGui::IsItemActive();
        activated = ImGui::IsItemActivated();
    }
    if (s_previewHold && k.kind == K_CHAR && k.ch == s_previewHold) active = true;
    pressedNow = active;
    const float hv = Anim(ImGui::GetID(id), active ? 1.0f : 0.0f, 34.0f);
    const float r = 10.0f * U;
    const ImVec2 c((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f);
    const int v0 = DL->VtxBuffer.Size;

    const bool blue = (k.kind == K_ENTER && ready);
    if (k.kind != K_BAR) DL->AddRectFilled(ImVec2(a.x, a.y + 2.0f * U), ImVec2(b.x, b.y + 2.0f * U), Col(60, 70, 90, 0.20f), r);   // тень под клавишей
    ImU32 fill;
    if (k.kind == K_BAR) fill = Col(235,239,245);
    else if (blue) fill = LerpCol(Acc(1.0f), Col(8, 50, 150), 0.38f * hv);
    else if (k.kind == K_ENTER) fill = Col(226, 228, 234);
    else if (!charOk) fill = Col(225,230,237);
    else if (k.kind == K_GETKEY || k.kind == K_CLEAR) fill = LerpCol(Acc(.10f),Acc(.18f),hv);
    else fill = LerpCol(Col(255, 255, 255), Col(206, 211, 221), hv);
    DL->AddRectFilled(a, b, fill, r);

    const float iconS = 30.0f * U;
    switch (k.kind) {
        case K_CHAR: {
            char t[2] = {k.ch, 0};
            const ImVec2 ts = TextSize(FMed, 23.0f, t);
            DL->AddText(FMed, 23.0f * U, ImVec2(c.x - ts.x * 0.5f, c.y - ts.y * 0.5f), charOk ? Ink() : Col(17, 24, 39, 0.20f), t);
            break;
        }
        case K_BACK:  IconBackspace(c, iconS, Ink(.72f)); break;
        case K_CLEAR: IconClear(c, iconS, Acc(1.0f)); break;
        case K_ENTER: IconCheck(c, iconS * 1.05f, ready ? Col(255, 255, 255) : Grey(0.9f)); break;
        case K_GETKEY: {
            const char *lab = L("Получить ключ", "Get key");
            const float fs=CW<500?14.0f:17.0f;
            const ImVec2 ts = TextSize(FMed,fs,lab);
            const float gap = (CW<500?6.0f:10.0f)*U, iw = (CW<500?16.0f:20.0f)*U, total = iw + gap + ts.x;
            const float x0 = c.x - total * 0.5f;
            IconPlane(ImVec2(x0 + iw * 0.5f, c.y), iw, Acc(1.0f));
            DL->AddText(FMed, fs * U, ImVec2(x0 + iw + gap, c.y - ts.y * 0.5f), Acc(1.0f), lab);
            break;
        }
        case K_BAR: {                                         // «пробел» показывает прогресс ввода
            const float tw = (k.w - 44.0f) * U, th = 5.0f * U;
            const ImVec2 t0(c.x - tw * 0.5f, c.y - th * 0.5f), t1(c.x + tw * 0.5f, c.y + th * 0.5f);
            DL->AddRectFilled(t0, t1, Col(188, 192, 202, 0.8f), th);
            const float f = Anim(ImGui::GetID("##prog"), s_len / (LocalMode() ? 14.0f : 12.0f), 14.0f);
            if (f > 0.01f) DL->AddRectFilled(t0, ImVec2(t0.x + tw * f, t1.y), TypedKey().empty() ? Acc(1.0f) : Good(), th);
            break;
        }
        default: break;
    }
    if (hv > 0.001f && !inert) TransformVerts(DL, v0, c, 1.0f - 0.055f * hv, 0.0f, 1.0f);

    // рябь от касания: расходится внутри клавиши
    for (const Ripple &rp : s_ripples) {
        if (!g_cfg.anim || rp.key != idx) continue;
        const float f = rp.t / 0.38f;
        DL->PushClipRect(a, b, true);
        DL->AddCircleFilled(rp.p, (6.0f + 74.0f * f) * U, blue ? Col(255, 255, 255, 0.30f * (1.0f - f)) : Acc(0.22f * (1.0f - f)), 28);
        DL->PopClipRect();
    }
    {   // появление: клавиши выпрыгивают по очереди (идут вслед за самой карточкой)
        const float e = g_cfg.anim ? Clamp01((s_enter - 0.12f - idx * 0.006f) / 0.22f) : 1.0f;
        if (e < 1.0f) TransformVerts(DL, vAll, c, 0.92f + 0.08f * e, 0.0f, e);
    }
    (void)dt;
}

// Увеличенный символ над нажатой клавишей, как на экранной клавиатуре телефона.
void DrawBubble(const Key &k) {
    const float bw = k.w * 1.5f, bh = k.h * 1.55f;
    const float cx = ImClamp(k.x + k.w * 0.5f, KB_X + bw * 0.5f, KB_X + KB_W - bw * 0.5f);
    const float y1 = k.y + 4.0f, y0 = y1 - bh;
    const ImVec2 a = P(cx - bw * 0.5f, y0), b = P(cx + bw * 0.5f, y1);
    const float r = 10.0f * U;
    DL->AddRectFilled(ImVec2(a.x, a.y + 3.0f * U), ImVec2(b.x, b.y + 3.0f * U), Col(30, 40, 60, 0.25f), r);
    DL->AddRectFilled(a, b, Col(255, 255, 255), r);
    DL->AddRect(a, b, Acc(0.16f), r, 0, ImMax(1.0f, 1.4f * U));
    char t[2] = {k.ch, 0};
    CText(FMed, 36.0f, cx, y0 + bh * 0.5f, Acc(1.0f), t);
}

// ----- карточка -----
// Ролик играется внутри карточки (фон самого окна): родной темп, без тонировки; «cover» — кадр заполняет карточку, лишнее срезается.
// Атласы декодируются в фоне и грузятся по одному в кадр; пока готовы не все, крутится то, что уже есть.
void DrawField(bool locked) {
    const float x0 = 16, x1 = CW - 16, y0 = FIELD_Y, y1 = FIELD_Y + FIELD_H;
    const ImVec2 a = P(x0, y0), b = P(x1, y1);
    const float r = 14.0f * U;
    const bool full = !TypedKey().empty();
    const float shake = (g_cfg.anim ? s_shake * sinf(s_time * 40.0f) * 3.0f * U : 0.0f);
    DL->AddRectFilled(ImVec2(a.x + shake, a.y), ImVec2(b.x + shake, b.y), Col(255, 255, 255), r);
    const bool err = s_noteT > 0 || s_errShown;
    const ImU32 border = LerpCol(Col(185,199,219), Good(0.95f), Anim(ImGui::GetID("##fullb"), full ? 1.0f : 0.0f, 12.0f));
    DL->AddRect(ImVec2(a.x + shake, a.y), ImVec2(b.x + shake, b.y), err ? Bad(0.9f) : border, r, 0, ImMax(1.0f, 1.7f * U));

    // Серверный ключ показываем группами по 4; локальный — как ссылку.
    const float fs = CW < 500 ? 19.0f : 26.0f;
    const float ty = (a.y + b.y) * 0.5f - TextSize(FMed, fs, "A").y * 0.5f;
    const float tx = a.x + 20.0f * U + shake;
    std::string body;
    for (int i = 0; i < s_len; ++i) {
        if (LocalMode()) body += avis::kLocalKey[i];
        else { if (i && i % 4 == 0) body += '-'; body += s_chars[i]; }
    }
    if (!body.empty()) DL->AddText(FMed, fs * U, ImVec2(tx, ty), Ink(), body.c_str());
    if (!locked && !full && fmodf(s_time, 1.0f) < 0.55f) {
        const float cx = tx + (body.empty() ? 0.0f : TextSize(FMed, fs, body.c_str()).x + 2.0f * U);
        DL->AddLine(ImVec2(cx, (a.y + b.y) * 0.5f - 12.0f * U), ImVec2(cx, (a.y + b.y) * 0.5f + 12.0f * U), Acc(1.0f), 2.0f * U);
    }

    // «Вставить» внутри поля
    const bool busy = avis::PasteBusy();
    if (Pill("##paste", x1 - 9 - (CW < 500 ? 78 : 100), y0 + 8, x1 - 9, y1 - 8, busy ? L("Читаю...", "Reading...") : L("Вставить", "Paste"), 1, CW < 500 ? 14.0f : 16.0f, 4.0f, !locked && !busy)) {
        avis::snd::Play(avis::snd::Sfx::Paste);
        avis::RequestPaste();
        s_noteT = 0;
    }
}

// Единственная надпись на экране — сообщение об ошибке, и только пока она есть. На тёмной плашке: читается и на чёрных, и на белых кадрах.
void DrawStatus(const avis::Snapshot &s) {
    static char last[128] = {0};
    const char *msg = nullptr;
    if (s_noteT > 0) msg = s_note;
    else if (s.msg != avis::Msg::None) msg = MsgText(s.msg, s.channel);
    s_errShown = msg != nullptr;
    if (msg) snprintf(last, sizeof(last), "%s", msg);
    const float on = Anim(ImGui::GetID("##msg"), msg ? 1.0f : 0.0f, 14.0f);
    if (on < 0.01f || !last[0]) return;
    float fs = 15.5f;
    ImVec2 ts = TextSize(FMed, fs, last);
    const float maxW = (CW - 64) * U;
    if (ts.x > maxW) { fs *= maxW / ts.x; ts = TextSize(FMed, fs, last); }
    const ImVec2 c = P(CW * 0.5f, 232.0f);
    const float px = 14.0f * U, py = 7.0f * U;
    DL->AddRectFilled(ImVec2(c.x - ts.x * 0.5f - px, c.y - ts.y * 0.5f - py), ImVec2(c.x + ts.x * 0.5f + px, c.y + ts.y * 0.5f + py),
                      Col(8, 10, 16, 0.80f * on), ts.y * 0.5f + py);
    DL->AddText(FMed, fs * U, ImVec2(c.x - ts.x * 0.5f, c.y - ts.y * 0.5f), Col(255, 125, 138, on), last);
}

void DrawHeader(float time, bool soundOn) {
    MenuDrawLogo(P(CW * 0.5f, 58), 32.0f * U, time);

    float fs = 30.0f;
    ImVec2 bs = TextSize(FTitle, fs, AVIS_BRAND);
    const float maxW = (CW - 190) * U;
    if (bs.x > maxW) { fs *= maxW / bs.x; bs = TextSize(FTitle, fs, AVIS_BRAND); }
    const ImVec2 bp = P(CW * 0.5f, 118);
    const float px = 18.0f * U, py = 6.0f * U;                    // тёмная подложка: название читается на любом кадре ролика
    DL->AddRectFilled(ImVec2(bp.x - bs.x * 0.5f - px, bp.y - bs.y * 0.5f - py), ImVec2(bp.x + bs.x * 0.5f + px, bp.y + bs.y * 0.5f + py),
                      Col(8, 10, 16, 0.62f), bs.y * 0.5f + py);
    const int v0 = DL->VtxBuffer.Size;
    DL->AddText(FTitle, fs * U, ImVec2(bp.x - bs.x * 0.5f, bp.y - bs.y * 0.52f), Col(255, 255, 255), AVIS_BRAND);
    if (g_cfg.anim && g_cfg.shimmer) Shimmer(DL, v0, bp.x - bs.x * 0.5f - 50 * U + (bs.x + 100 * U) * fmodf(s_time * 0.42f, 1.7f), 34 * U, Acc(1.0f), 0.9f);

    // язык: круг слева вверху (RU/EN), как кнопка звука справа; выбор запоминается
    {
        const ImVec2 lc = P(40, 40);
        if (CircleButton("##lang", lc, 17.0f * U)) {
            g_cfg.lang = g_cfg.lang == 0 ? 1 : 0;
            avis::snd::Play(avis::snd::Sfx::Toggle);
        }
        const char *ln = g_cfg.lang == 0 ? "RU" : "EN";
        const ImVec2 ts = TextSize(FMed, 13.0f, ln);
        DL->AddText(FMed, 13.0f * U, ImVec2(lc.x - ts.x * 0.5f, lc.y - ts.y * 0.5f), Acc(1.0f), ln);
    }
    // звук вкл/выкл — в углу, как кнопка закрытия на образце
    const ImVec2 sc = P(CW - 40, 40);
    if (CircleButton("##snd", sc, 17.0f * U)) {
        avis::snd::SetEnabled(!avis::snd::Enabled());
        if (avis::snd::Enabled()) avis::snd::Play(avis::snd::Sfx::Toggle);
    }
    IconSpeaker(sc, 22.0f * U, soundOn ? Acc(1.0f) : Grey(), soundOn);
}

// A temporary outage keeps checking; show the retry timer and an explicit
// cancel control instead of turning a timeout into a false key verdict.
void DrawChecking(float lockT, const avis::Snapshot &s) {
    const ImVec2 a = P(10, 150), b = P(CW - 10, CH - 10);
    DL->AddRectFilled(a, b, Col(247, 249, 252, 0.94f * lockT), 22.0f * U);
    const float cy = 150 + (CH - 160) * 0.5f;
    Spinner(P(CW * 0.5f, cy - 22), 28.0f * U, 4.0f * U);
    char status[160];
    if (s.retrying && s.retryInSec > 0)
        snprintf(status, sizeof(status), L("Повтор через %d с", "Retry in %d s"), s.retryInSec);
    else snprintf(status, sizeof(status), "%s", L("Проверяем ключ…", "Checking key…"));
    CText(FMed, CW < 500 ? 16.f : 18.f, CW * .5f, cy + 36, Ink(), status);
    if (s.phase == avis::Phase::Checking &&
        Pill("##cancel_verify", CW * .5f - 52, CH - 76, CW * .5f + 52, CH - 40,
             L("Отмена", "Cancel"), 1, 16.f)) avis::CancelCheck();
}

void DrawSuccess(float t) {
    const ImVec2 a = P(10, 150), b = P(CW - 10, CH - 10);
    DL->AddRectFilled(a, b, Col(247, 249, 252, 0.96f * Clamp01(t / 0.2f)), 22.0f * U);
    const float pop = g_cfg.anim ? EaseOutBack(Clamp01(t / 0.45f)) : 1.0f;
    const ImVec2 c = P(CW * 0.5f, 150 + (CH - 160) * 0.5f);
    const float R = 56.0f * U * pop;
    DL->AddCircleFilled(c, R + 16 * U * pop, Good(0.14f), 48);
    DL->AddCircleFilled(c, R, Good(0.22f), 48);
    DL->AddCircle(c, R, Good(1.0f), 48, 3.6f * U);
    const float k = g_cfg.anim ? Clamp01((t - 0.15f) / 0.35f) : 1.0f;          // галочка дорисовывается
    const ImVec2 p0(c.x - R * 0.42f, c.y + R * 0.02f), p1(c.x - R * 0.10f, c.y + R * 0.34f), p2(c.x + R * 0.46f, c.y - R * 0.30f);
    if (k > 0) {
        const float k1 = Clamp01(k * 2.0f), k2 = Clamp01(k * 2.0f - 1.0f);
        DL->AddLine(p0, ImLerp(p0, p1, k1), Good(), 6.0f * U);
        if (k2 > 0) DL->AddLine(p1, ImLerp(p1, p2, k2), Good(), 6.0f * U);
    }
}

// Рамка карточки: свечение, ролик внутри, акцентный контур.
void DrawFrame(ImVec2 a, ImVec2 b, float R, float pulse) {
    (void)pulse;
    if (g_cfg.shadows) for (int i = 4; i >= 1; --i) {
        float e = i * 3.0f * U;
        DL->AddRectFilled(a - ImVec2(e, e * .5f) + ImVec2(0, 6 * U),
                          b + ImVec2(e, e) + ImVec2(0, 6 * U), Col(0,0,0,.035f), R + e);
    }
    DL->AddRectFilled(a, b, Col(247,249,252), R);
    // The animation is confined to the header. Input contrast never depends on a video frame.
    DL->AddRectFilled(a, P(CW,144), Col(18,28,43), R, ImDrawFlags_RoundCornersTop);
    DL->AddRect(a, b, Col(202,211,224), R, 0, ImMax(1.0f,U));
    DL->AddLine(P(0,144), P(CW,144), Col(222,228,237), ImMax(1.0f,U));
    DL->AddRectFilled(P(10,248),P(CW-10,CH-10),Col(235,239,245),16 * U);
}
}  // namespace

// Возвращает true, пока экран ключа занимает дисплей (главное меню в это время не рисуется).
bool AuthScreenRender() {
    ImGuiIO &io = ImGui::GetIO();
    const float dt = ImMin(io.DeltaTime, 0.1f);
    const bool active = avis::Active();
    static bool handoffDone = false;
    if (!active) handoffDone = false;
    const bool portrait=io.DisplaySize.x<io.DisplaySize.y && io.DisplaySize.x<800;
    const float nextW=portrait?390.0f:640.0f,nextH=portrait?590.0f:530.0f;
    if(CW!=nextW || CH!=nextH){s_keys.clear();s_ripples.clear();s_heldKey=-1;}
    CW=nextW;CH=nextH;KB_W=CW-32;
    if (s_keys.empty()) BuildKeys();
    if (!s_soundInit) { s_soundInit = true; avis::snd::Init(AVIS_DATA_DIR); }
    avis::snd::Tick();

    if (active && !s_wasActive) { s_success = 0.0f; avis::snd::Play(avis::snd::Sfx::Success); s_burst = true; }
    if (!active && s_wasActive) { s_success = -1.0f; s_appear = 0.0f; s_enter = 0.0f; s_len = 0; s_chars[0] = 0; s_prefilled = true; }
    s_wasActive = active;

    if (active && s_success >= 1.35f) {
        if (!handoffDone) {
            // A key/paste button may still own ActiveId while the worker
            // switches phases. Never carry auth ownership or a stale combo
            // into the main menu. Focus the next (menu) window once.
            CloseCombo();
            Block = false;
            ImGui::ClearActiveID();
            ImGui::FocusWindow(nullptr);
            ImGui::SetNextWindowFocus();
            handoffDone = true;
        }
        return false;
    }
    s_time += dt;
    s_enter += dt;
    if (s_noteT > 0) s_noteT -= dt;
    if (s_shake > 0) s_shake = ImMax(0.0f, s_shake - dt * 3.2f);
    if (active) s_success += dt;
    for (Ripple &r : s_ripples) r.t += dt;
    for (size_t i = s_ripples.size(); i-- > 0;) if (s_ripples[i].t > 0.38f) s_ripples.erase(s_ripples.begin() + (long)i);

    const avis::Snapshot s = avis::Get();
    const ImVec2 disp = io.DisplaySize;
    U = ImMax(0.2f, ImMin(disp.y * 0.94f / CH, disp.x * 0.94f / CW));
    s_appear = g_cfg.anim ? ImMin(1.0f, s_appear + dt * 4.0f * g_cfg.animSpeed) : 1.0f;

    if (!s_prefilled && !s.savedKey.empty() && s.phase == avis::Phase::NeedKey && s_len == 0) {
        FillFrom(s.savedKey);
        s_prefilled = true;
    }
    {   // результат вставки из буфера обмена
        avis::PasteResult pr;
        if (avis::TakePaste(pr)) {
            if (pr.kind == avis::PasteResult::Found) {
                FillFrom(pr.key);
                s_prefilled = true;
                avis::Submit(TypedKey());
            } else if (pr.kind == avis::PasteResult::NoKey) {
                Note(L("В буфере нет ключа", "No key in clipboard"));
            } else {
                Note(L("Буфер недоступен", "Clipboard unavailable"));
            }
        }
    }
    static avis::Msg lastMsg = avis::Msg::None;
    if (s.msg != lastMsg) { if (s.msg != avis::Msg::None && s.phase == avis::Phase::NeedKey) { s_shake = 1.0f; avis::snd::Play(avis::snd::Sfx::Error); } lastMsg = s.msg; }

    const bool succeeding = active && s_success >= 0;
    const float fade = succeeding && g_cfg.anim ? 1.0f - Clamp01((s_success - 1.0f) / 0.35f) : 1.0f;
    DrawDim(disp, s_appear * fade);

    const ImVec2 size(CW * U, CH * U);
    const ImVec2 M(34 * U, 34 * U);
    const ImVec2 pos((disp.x - size.x) * 0.5f, (disp.y - size.y) * 0.5f);
    ImGui::SetNextWindowPos(pos - M, ImGuiCond_Always);
    ImGui::SetNextWindowSize(size + M * 2.0f, ImGuiCond_Always);
    ImGuiWindowFlags authFlags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoSavedSettings |
                 ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoMove;
    // The success animation is visual only; its transparent window must not
    // keep capturing input as the main menu becomes available.
    if (active) authFlags |= ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoFocusOnAppearing;
    ImGui::Begin("##avis_key", nullptr, authFlags);
    DL = ImGui::GetWindowDrawList();
    O = ImGui::GetCurrentWindow()->Pos + M;
    Block = false;
    const int v0 = DL->VtxBuffer.Size;

    const ImVec2 a = O, b = O + size;
    const float pulse = 0.75f + 0.25f * sinf(s_time * 1.6f);
    DrawFrame(a, b, CR * U, pulse);
    DrawHeader(s_time, avis::snd::Enabled());

    const bool checking = s.phase == avis::Phase::Checking;
    const bool locked = checking || succeeding || s_appear < .98f || (g_cfg.anim && s_enter < .58f);
    const bool ready = !TypedKey().empty() && !locked;
    DrawStatus(s);
    DrawField(locked);

    // клавиатура
    int pressedKey = -1;
    for (size_t i = 0; i < s_keys.size(); ++i) {
        const Key &k = s_keys[i];
        bool pressed = false, activated = false;
        DrawKey(k, (int)i, locked, ready, pressed, activated, dt);
        if (pressed && k.kind == K_CHAR) pressedKey = (int)i;
        if (k.kind == K_BACK) {                          // удержание стирает дальше
            if (pressed && !locked) {
                s_backHeld += dt;
                if (s_backHeld > 0.45f) { s_repeatT += dt; while (s_repeatT > 0.07f && s_len > 0) { s_repeatT -= 0.07f; s_chars[--s_len] = 0; avis::snd::Play(avis::snd::Sfx::Back); } }
            } else { s_backHeld = 0; s_repeatT = 0; }
        }
        if (!activated) continue;
        s_ripples.push_back({io.MousePos, 0.0f, (int)i});
        if (s_ripples.size() > 6) s_ripples.erase(s_ripples.begin());
        s_noteT = 0;
        switch (k.kind) {
            case K_CHAR:
                if (!CanAppend(k.ch)) { Note(L("Недопустимый символ ключа", "Invalid key character")); break; }
                s_chars[s_len++] = k.ch;
                s_chars[s_len] = 0;
                avis::snd::Play(avis::snd::Sfx::Key, KeyValid(k.ch) ? (int)(strchr(kAlphabet, k.ch) - kAlphabet) : 0);
                break;
            case K_BACK:  if (s_len > 0) { s_chars[--s_len] = 0; avis::snd::Play(avis::snd::Sfx::Back); } break;
            case K_CLEAR: if (s_len > 0) { s_len = 0; s_chars[0] = 0; avis::snd::Play(avis::snd::Sfx::Clear); } break;
            case K_GETKEY: avis::snd::Play(avis::snd::Sfx::Toggle); avis::OpenBot(); break;
            case K_ENTER:
                if (ready) { avis::snd::Play(avis::snd::Sfx::Enter); avis::Submit(TypedKey()); }
                else Note(L("Введите ключ полностью", "Enter the complete key"));
                break;
            default: break;
        }
    }
    s_heldKey = pressedKey;
    if (pressedKey >= 0) DrawBubble(s_keys[(size_t)pressedKey]);

    // проверка / успех — поверх поля и клавиатуры
    const float lockT = Anim(ImGui::GetID("##lock"), checking ? 1.0f : 0.0f, 12.0f);
    if (succeeding) DrawSuccess(s_success);
    else if (lockT > 0.01f) DrawChecking(lockT, s);

    // появление: масштаб от центра; завершение: растворение
    const float appear = 1.0f - powf(1.0f - s_appear,3);
    TransformVerts(DL, v0, ImVec2(O.x + size.x * 0.5f, O.y + size.y * 0.5f), 0.92f + 0.08f * appear, 0.0f, ImMin(1.0f, s_appear * 1.4f) * fade);
    Block = false;
    ImGui::End();
    if (s_burst && succeeding && g_cfg.anim && g_cfg.particles) { s_burst = false; SpawnBurst(ImVec2(O.x + size.x * 0.5f, O.y + (150 + (CH - 160) * 0.5f) * U)); }
    RenderEffects();
    MenuAutosaveTick(dt);
    return true;
}

#ifdef AVIS_PREVIEW
int AuthPreviewLength() { return s_len; }
void AuthPreviewType(const char *chars) { FillFrom(chars); s_prefilled = true; }
void AuthPreviewHold(char c) { s_previewHold = c; }
#endif
