#pragma once
// Мини-фреймворк отрисовки Trial: единицы дизайна, цвета, иконки, виджеты
#include "trial_config.h"

namespace UI {
    // Текущий контекст рисования
    extern ImDrawList *DL;
    extern ImVec2 O;        // начало координат (левый верхний угол окна)
    extern float U;         // размер одной дизайн-единицы в пикселях
    extern bool Block;      // открыт выпадающий список — остальные виджеты неактивны
    extern ImFont *FText, *FMed, *FTitle;
    extern float WinW, WinH; // размер окна в дизайн-единицах

    inline ImVec2 P(float x, float y) { return ImVec2(O.x + x * U, O.y + y * U); }
    inline const char *L(const char *ru, const char *en) { return g_cfg.lang == 0 ? ru : en; }
    const char *T(const char *en);             // перевод английской подписи на язык меню (i18n.cpp); неизвестное — как есть

    ImU32 Col(int r, int g, int b, float a = 1.0f);
    ImU32 Acc(float a = 1.0f);                 // акцентный цвет
    ImU32 AccLight(float a = 1.0f);
    ImU32 LerpCol(ImU32 a, ImU32 b, float t);
    float Anim(ImGuiID id, float target, float speed = 12.0f);

    void  Text(ImFont *f, float size, ImVec2 pos, ImU32 col, const char *t);
    void  TextV(ImFont *f, float size, ImVec2 leftCenter, ImU32 col, const char *t); // по центру по вертикали
    // Текст в пределах maxW пикселей: сначала немного сжимается, потом обрезается с многоточием (UTF-8 безопасно). maxW <= 0 — без лимита.
    void  FitText(ImFont *f, float size, ImVec2 leftCenter, ImU32 col, const char *t, float maxW);
    // Наш ролик (7 серых атласов, tools/make_banner.py) как фон прямоугольника: «cover», родной темп, без тонировки.
    void  VideoRect(ImVec2 a, ImVec2 b, float rounding, ImDrawFlags flags, float time);
    ImVec2 TextSize(ImFont *f, float size, const char *t);

    // Пост-обработка вершин: масштаб/поворот/прозрачность, блик
    void  TransformVerts(ImDrawList *dl, int start, ImVec2 pivot, float scale, float rot, float alphaMul);
    void  Shimmer(ImDrawList *dl, int start, float centerX, float width, ImU32 col, float strength);

    // Иконки (векторные, чёткие на любом масштабе)
    void  StarFilled(ImVec2 c, float r, ImU32 col, float thin = 0.14f);
    void  StarOutline(ImVec2 c, float r, ImU32 col, float thick, float thin = 0.16f);
    void  IconEye(ImVec2 c, float s, ImU32 col);
    void  IconSparkles(ImVec2 c, float s, ImU32 col);
    void  IconSliders(ImVec2 c, float s, ImU32 col, ImU32 bg);
    void  IconGear(ImVec2 c, float s, ImU32 col);
    void  IconChevron(ImVec2 c, float s, ImU32 col, bool up);
    void  IconCrosshair(ImVec2 c, float s, ImU32 col);
    void  IconChip(ImVec2 c, float s, ImU32 col);

    // Взаимодействие
    bool  Hit(const char *id, ImVec2 a, ImVec2 b, bool *held = nullptr);
    void  SpawnBurst(ImVec2 pos);
    void  RenderEffects();

    // Виджеты-строки карточек (координаты в дизайн-единицах относительно окна)
    void  Label(const char *text, float x, float y, float maxW = 0);   // maxW — в дизайн-единицах
    void  Switch(ImVec2 pos, float t);
    void  RowToggle(const char *id, const char *label, bool *v, float x0, float x1, float y);
    // zeroText — что показать вместо числа, пока ползунок в самом начале (например "Auto").
    void  RowSlider(const char *id, const char *label, float *v, float mn, float mx, const char *fmt,
                    float x0, float x1, float y, float trackStart, const char *zeroText = nullptr);
    void  RowCombo(const char *id, const char *label, int *v, const char *const *items, int n,
                   float x0, float x1, float y, float w);
    // Слайдер 0..1 с цветной дорожкой: mode 0 — оттенок (радуга), 1 — насыщенность (белый -> hue),
    // 2 — яркость (чёрный -> цвет при данных hue и sat). rgb — итоговый цвет, образец справа (только mode 0).
    void  RowGradient(const char *id, const char *label, float *v, int mode, float hue, const float rgb[3],
                      float x0, float x1, float y, float trackStart, float sat = 1.0f);
    bool  RowButton(const char *id, const char *label, const char *btn, float x0, float x1, float y);
    void  ComboPopup();   // рисуется последним
    bool  ComboOpen();
    void  CloseCombo();

    void  Card(float x0, float y0, float x1, float y1, int icon, const char *title, float highlight);
    // Выбор акцентного цвета: пять кружков справа, *v — номер палитры.
    void  RowAccent(const char *id, const char *label, int *v, float x0, float x1, float y);

    // Заливка скруглённого прямоугольника цветом по позиции вершины (AddRectFilledMultiColor скруглять не умеет).
    template <class F> void RoundFill(ImVec2 a, ImVec2 b, float r, F colorAt, ImDrawFlags flags = 0) {
        const int v0 = DL->VtxBuffer.Size;
        DL->PathRect(a, b, r, flags);
        DL->PathFillConvex(IM_COL32_WHITE);
        for (int i = v0; i < DL->VtxBuffer.Size; ++i) {
            ImDrawVert &v = DL->VtxBuffer[i];
            const float oa = ((v.col >> IM_COL32_A_SHIFT) & 0xFF) / 255.0f;   // края сглаживания несут нулевую альфу
            const ImU32 c = colorAt(v.pos);
            const float na = (((c >> IM_COL32_A_SHIFT) & 0xFF) / 255.0f) * oa;
            v.col = (c & ~IM_COL32_A_MASK) | ((ImU32)(na * 255.0f + 0.5f) << IM_COL32_A_SHIFT);
        }
    }
}
