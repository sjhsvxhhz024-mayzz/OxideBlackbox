#pragma once
void QuickActionsInit(const char *dataDir);
void QuickActionsFrame(bool &menuOpen); // Render-thread only; called after authentication.
void QuickActionsSettings();
void QuickActionsSaveTick(float dt);
void QuickActionsShutdown();