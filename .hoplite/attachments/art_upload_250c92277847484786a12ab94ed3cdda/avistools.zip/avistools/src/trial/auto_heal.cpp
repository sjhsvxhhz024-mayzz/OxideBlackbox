#include "auto_heal.h"
#include "trial_ui.h"
#include <cstdio>
#include <cerrno>
#include <cstring>
#include <string>
#include <fcntl.h>
#include <unistd.h>
#include <spawn.h>
#include <sys/wait.h>
#include <signal.h>
#include <sstream>
extern char **environ;
heal::Config g_autoHeal;
namespace {
using namespace UI;
heal::Controller controller;
std::string path,saved,status="Auto heal: off";
int capture=-1,pointIndex=0,lastRotation=-1;
double captureUntil=0;
float saveTimer=0;
// Render-thread subprocess polling: never block a frame on Android's Java input
// utility. A failed/late command stops the episode. No shell interpolation.
class Command {
 pid_t pid_=-1;int pipe_=-1,result_=-1;double until_=0;bool killed_=false;
 std::string output_;
public:
 bool Busy()const{return pid_>0;}
 int Result()const{return result_;}
 int TakeResult(){int r=result_;result_=-1;return r;}
 const std::string&Output()const{return output_;}
 void Cancel(){if(pid_>0){kill(pid_,SIGKILL);killed_=true;}if(pipe_>=0){close(pipe_);pipe_=-1;}}
 void Close(){Cancel();if(pid_>0){while(waitpid(pid_,nullptr,0)<0&&errno==EINTR){}pid_=-1;}}
 ~Command(){Close();}
 bool Start(const char *file,char *const argv[],double now,bool captureOutput){
  if(Busy())return false;
  output_.clear();result_=-1;killed_=false;
  int p[2]={-1,-1};if(captureOutput&&pipe2(p,O_CLOEXEC)<0){result_=0;return false;}
  if(p[0]>=0)fcntl(p[0],F_SETFL,O_NONBLOCK);
  posix_spawn_file_actions_t a;posix_spawn_file_actions_init(&a);
  posix_spawn_file_actions_addopen(&a,STDIN_FILENO,"/dev/null",O_RDONLY,0);
  posix_spawn_file_actions_addopen(&a,STDERR_FILENO,"/dev/null",O_WRONLY,0);
  if(captureOutput){posix_spawn_file_actions_adddup2(&a,p[1],STDOUT_FILENO);posix_spawn_file_actions_addclose(&a,p[0]);posix_spawn_file_actions_addclose(&a,p[1]);}
  else posix_spawn_file_actions_addopen(&a,STDOUT_FILENO,"/dev/null",O_WRONLY,0);
  pid_t child=-1;int rc=posix_spawn(&child,file,&a,nullptr,argv,environ);posix_spawn_file_actions_destroy(&a);
  if(p[1]>=0)close(p[1]);
  if(rc){if(p[0]>=0)close(p[0]);result_=0;return false;}
  pid_=child;pipe_=p[0];until_=now+2.5;return true;
 }
 void Poll(double now){
  if(pid_<0)return;
  if(pipe_>=0){char b[4096];for(int i=0;i<32;++i){ssize_t n=read(pipe_,b,sizeof(b));if(n<=0)break;if(output_.size()+n<=131072)output_.append(b,n);else {Cancel();break;}}}
  int st=0;pid_t r=waitpid(pid_,&st,WNOHANG);
  if(r==pid_||(r<0&&errno!=EINTR)){result_=!killed_&&r==pid_&&WIFEXITED(st)&&WEXITSTATUS(st)==0;pid_=-1;if(pipe_>=0){close(pipe_);pipe_=-1;}return;}
  if(now>until_)Cancel();
 }
};
Command input,focus;
bool focused=false;double nextFocus=0,focusAt=-100;
std::string focusedPackage;
bool ParseFocus(const std::string&text,const std::string&pkg){
 if(pkg.empty())return false;
 auto matches=[&](const std::string&line){const auto at=line.find(pkg+"/");return at!=std::string::npos&&(at==0||line[at-1]==' '||line[at-1]=='{');};
 std::istringstream in(text);std::string line;int legacy=0;bool legacyMatch=false;
 while(std::getline(in,line)){
  if(line.find("topResumedActivity=")!=std::string::npos)return matches(line);
  if(line.find("mResumedActivity:")!=std::string::npos||line.find("mResumedActivity=")!=std::string::npos){++legacy;legacyMatch=matches(line);}
 }
 return legacy==1&&legacyMatch;
}
std::string Serialize(){
 std::ostringstream o;o<<"AVIS_HEAL 1\n"<<g_autoHeal.medicine<<' '<<g_autoHeal.attempts<<' '<<g_autoHeal.threshold<<' '<<g_autoHeal.delay<<' '<<g_autoHeal.cooldown<<'\n';
 o<<g_autoHeal.width<<' '<<g_autoHeal.height<<' '<<g_autoHeal.rotation<<'\n';
 for(auto&p:g_autoHeal.points)o<<p.x<<' '<<p.y<<'\n';return o.str();
}
void Save(){if(path.empty())return;std::string text=Serialize();if(text==saved)return;FILE*f=fopen((path+".tmp").c_str(),"wb");if(!f)return;
 bool ok=fwrite(text.data(),1,text.size(),f)==text.size();if(fclose(f))ok=false;if(ok&&rename((path+".tmp").c_str(),path.c_str())==0)saved=text;else unlink((path+".tmp").c_str());}
const char *PhaseName(){switch(controller.State()){
 case heal::Phase::Selecting:case heal::Phase::WaitSelected:return "Selecting medicine";
 case heal::Phase::Using:case heal::Phase::WaitEffect:return "Healing";
 case heal::Phase::Returning:return "Returning item";
 case heal::Phase::Cooldown:return "Heal cooldown";
 case heal::Phase::Blocked:return "Heal stopped";
 default:return "Waiting for low HP";
}}
}
void AutoHealInit(const char*dir){AutoHealShutdown();g_autoHeal=heal::Config{};path=dir&&*dir?std::string(dir)+"/auto_heal.cfg":"";
 FILE*f=path.empty()?nullptr:fopen(path.c_str(),"rb");if(f){char b[4096]{};size_t n=fread(b,1,sizeof(b)-1,f);fclose(f);std::istringstream in(std::string(b,n));std::string line;std::getline(in,line);
 heal::Config c;bool ok=line=="AVIS_HEAL 1"&&bool(in>>c.medicine>>c.attempts>>c.threshold>>c.delay>>c.cooldown>>c.width>>c.height>>c.rotation);
 for(auto&p:c.points)ok=ok&&bool(in>>p.x>>p.y);if(ok){c.Normalize();g_autoHeal=c;}}
 g_autoHeal.enabled=false;saved=Serialize();status="Auto heal: off";
}
void AutoHealShutdown(){input.Close();focus.Close();Save();controller.Reset();capture=-1;captureUntil=0;focused=false;nextFocus=0;focusAt=-100;focusedPackage.clear();}
void AutoHealTick(const heal::Sample &sample,const char*pkg){
 input.Poll(sample.now);focus.Poll(sample.now);
 lastRotation=sample.rotation;
 if(g_autoHeal.rotation<0&&g_autoHeal.width==sample.width&&g_autoHeal.height==sample.height){g_autoHeal.rotation=sample.rotation;Save();}
 const std::string package=pkg?pkg:"";
 if(package!=focusedPackage){focus.Cancel();focusedPackage=package;focused=false;focusAt=-100;nextFocus=0;}
 if(!g_autoHeal.enabled||!sample.allowed){input.Cancel();focused=false;controller.Tick(g_autoHeal,sample);status=g_autoHeal.enabled?"Heal paused":"Auto heal: off";return;}
 if(!focus.Busy()&&focus.Result()>=0){focused=focus.TakeResult()==1&&ParseFocus(focus.Output(),package);focusAt=sample.now;}
 if(sample.now>=nextFocus&&!focus.Busy()){
  nextFocus=sample.now+.75;
  char a0[]="/system/bin/dumpsys",a1[]="activity",a2[]="activities";char*args[]={a0,a1,a2,nullptr};
#ifndef AVIS_PREVIEW
  if(!focus.Start(a0,args,sample.now,true)){focused=false;focusAt=-100;}
#else
  (void)args;focused=false;
#endif
 }
 heal::Sample s=sample;s.allowed=s.allowed&&focused&&sample.now-focusAt<1.5;
 if(!s.allowed){input.Cancel();controller.Tick(g_autoHeal,s);status="Game must be foreground";return;}
 g_autoHeal.Normalize();const auto request=controller.Tick(g_autoHeal,s,input.Busy()?-1:input.Result());status=PhaseName();
 if(request.action!=heal::Action::None){
  const heal::Point&p=g_autoHeal.points[request.point];char x[24],y[24];snprintf(x,sizeof(x),"%d",(int)std::lround(p.x*(s.width-1)));snprintf(y,sizeof(y),"%d",(int)std::lround(p.y*(s.height-1)));
  char a0[]="/system/bin/input",a1[]="touchscreen",a2[]="tap";char*args[]={a0,a1,a2,x,y,nullptr};
#ifndef AVIS_PREVIEW
  if(!input.Start(a0,args,s.now,false))status="Android input unavailable";
#else
  (void)args;status="Android input unavailable";
#endif
 }
}
void AutoHealCapture(bool &menuOpen){
 if(capture<0)return;
 if(captureUntil==0)captureUntil=ImGui::GetTime()+15;
 if(ImGui::GetTime()>captureUntil){capture=-1;captureUntil=0;menuOpen=true;return;}
 auto &io=ImGui::GetIO();menuOpen=false;
 ImDrawList *dl=ImGui::GetForegroundDrawList();dl->AddRect(ImVec2(8,8),io.DisplaySize-ImVec2(8,8),IM_COL32(25,103,210,180),12,0,2);
 const char*label=T("Tap the game control · Esc to cancel");dl->AddText(ImVec2(18,18),IM_COL32(255,255,255,255),label);
 if(ImGui::IsKeyPressed(ImGuiKey_Escape)){capture=-1;captureUntil=0;menuOpen=true;return;}
 if(ImGui::IsMouseReleased(0)&&io.MousePos.x>=0&&io.MousePos.y>=0&&io.MousePos.x<io.DisplaySize.x&&io.MousePos.y<io.DisplaySize.y){
  const int w=(int)io.DisplaySize.x,h=(int)io.DisplaySize.y;
  if(g_autoHeal.width!=w||g_autoHeal.height!=h||g_autoHeal.rotation!=lastRotation){for(auto&p:g_autoHeal.points)p=heal::Point{};g_autoHeal.rotation=-1;}
  g_autoHeal.width=w;g_autoHeal.height=h;g_autoHeal.rotation=lastRotation;
  g_autoHeal.points[capture]={io.MousePos.x/std::max(1,w-1),io.MousePos.y/std::max(1,h-1)};
  capture=-1;captureUntil=0;menuOpen=true;Save();
 }
}
void AutoHealSettings(){
 using namespace UI;const float top=154,bottom=WinH-24,row=(bottom-top-24)/7;float y=top+12+row/2;
 Card(180,top,508,bottom,0,nullptr,1);Card(522,top,850,bottom,0,nullptr,0);
 auto next=[&](float x0,float x1){DL->AddLine(P(x0+24,y+row/2),P(x1-24,y+row/2),Col(231,235,240),U);y+=row;};
 RowToggle("heal_on","Auto heal",&g_autoHeal.enabled,180,508,y);next(180,508);
 RowSlider("heal_hp","HP threshold",&g_autoHeal.threshold,5,90,"%.0f%%",180,508,y,180);next(180,508);
 static const char*slots[]={"1","2","3","4","5","6"};RowCombo("heal_med","Medicine slot",&g_autoHeal.medicine,slots,6,180,508,y,95);next(180,508);
 RowSlider("heal_delay","Use time ms",&g_autoHeal.delay,500,10000,"%.0f",180,508,y,170);next(180,508);
 RowSlider("heal_cool","Cooldown ms",&g_autoHeal.cooldown,2000,30000,"%.0f",180,508,y,170);next(180,508);
 int attempts=g_autoHeal.attempts-1;static const char*doses[]={"1","2","3"};RowCombo("heal_doses","Dose limit",&attempts,doses,3,180,508,y,95);g_autoHeal.attempts=attempts+1;
 y=top+12+row/2;static const char*points[]={"Slot 1","Slot 2","Slot 3","Slot 4","Slot 5","Slot 6","Use button"};
 RowCombo("heal_point","Game control",&pointIndex,points,7,522,850,y,155);next(522,850);
 if(RowButton("heal_pick","Position",g_autoHeal.points[pointIndex].Ready()?"Change":"Set",522,850,y)){g_autoHeal.enabled=false;controller.Reset();input.Cancel();capture=pointIndex;captureUntil=0;}next(522,850);
 if(RowButton("heal_reset","Calibration","Reset",522,850,y)){for(auto&p:g_autoHeal.points)p=heal::Point{};g_autoHeal.width=g_autoHeal.height=0;g_autoHeal.rotation=-1;g_autoHeal.enabled=false;controller.Reset();}next(522,850);
 Label(T(status.c_str()),546,y,280);y+=row;
 Label(T("Only bandage or medkit"),546,y,280);y+=row;
 Label(T("Returns the previous slot"),546,y,280);
 g_autoHeal.Normalize();saveTimer+=ImGui::GetIO().DeltaTime;if(saveTimer>.8f){saveTimer=0;Save();}
}
