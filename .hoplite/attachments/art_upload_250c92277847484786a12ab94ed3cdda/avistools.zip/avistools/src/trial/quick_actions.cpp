#include "quick_actions.h"
#include "auto_heal.h"
#include "quick_actions_core.h"
#include "trial_ui.h"
#include "auth/auth_client.h"
#include "auth/auth_sound.h"
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <linux/input.h>
#include <sys/ioctl.h>
#include <unistd.h>

extern bool espdraw, espbox, esplines_enabled, skeleton, espname, espclan;
extern bool espweapon, espArmor, espdist, radarEnabled, oreEsp, animalEsp, baseEsp;
extern bool aimm, silentAim, noRecoil, noSpread, stretchOn;
extern bool boostDraw, boostGrass, boostTrees, boostNoLog;

namespace {
using namespace UI;
#if defined(__x86_64__) && (!defined(AVIS_PREVIEW) || defined(AVIS_PREVIEW_PC))
constexpr bool kPc = true;
#else
constexpr bool kPc = false;
#endif
struct ActionDef { const char *name, *shortName; bool *state; };
const ActionDef kActions[] = {
    {"ESP", "ESP", &espdraw}, {"ESP Box", "BOX", &espbox},
    {"ESP Line", "LINE", &esplines_enabled}, {"Skeleton", "SKEL", &skeleton},
    {"ESP Name", "NAME", &espname}, {"ESP Clan", "CLAN", &espclan},
    {"Held item ESP", "ITEM", &espweapon}, {"Armor ESP", "ARM", &espArmor},
    {"Distance", "DIST", &espdist}, {"Radar", "RAD", &radarEnabled},
    {"Ore ESP", "ORE", &oreEsp}, {"Animal ESP", "ANIM", &animalEsp},
    {"Base ESP", "BASE", &baseEsp}, {"Aim", "AIM", &aimm},
    {"Silent", "SLT", &silentAim}, {"No Recoil", "REC", &noRecoil},
    {"No Spread", "SPR", &noSpread}, {"Stretch", "STR", &stretchOn},
    {"Draw distance", "DRAW", &boostDraw}, {"Hide grass", "GRAS", &boostGrass},
    {"Hide trees", "TREE", &boostTrees}, {"Disable logs", "LOG", &boostNoLog},
    {"Auto heal", "HEAL", &g_autoHeal.enabled},
};
static_assert(sizeof(kActions) / sizeof(kActions[0]) == quickcore::ActionCount, "Action IDs changed");
quickcore::Config g_config;
quickcore::Debounce g_debounce;
std::array<quickcore::Drag, quickcore::kSlots> g_drags;
std::string g_path, g_saved, g_message;
bool g_ready = false;
int g_selected = 0;
int g_capture = -2; // -2 none, -1 menu key, 0..5 slot
double g_captureDeadline = 0;

std::string KeyName(int key) {
    if (!key) return T("Unassigned");
    if (key >= KEY_F1 && key <= KEY_F10) return "F" + std::to_string(key - KEY_F1 + 1);
    if (key == KEY_F11) return "F11";
    if (key == KEY_F12) return "F12";
    if (key >= KEY_1 && key <= KEY_0) return std::string(1, "1234567890"[key - KEY_1]);
    if (key >= KEY_Q && key <= KEY_P) return std::string(1, "QWERTYUIOP"[key - KEY_Q]);
    if (key >= KEY_A && key <= KEY_L) return std::string(1, "ASDFGHJKL"[key - KEY_A]);
    if (key >= KEY_Z && key <= KEY_M) return std::string(1, "ZXCVBNM"[key - KEY_Z]);
    switch (key) {
        case KEY_INSERT: return "Insert"; case KEY_HOME: return "Home";
        case KEY_END: return "End"; case KEY_PAGEUP: return "Page Up";
        case KEY_PAGEDOWN: return "Page Down"; case KEY_PAUSE: return "Pause";
        case KEY_SCROLLLOCK: return "Scroll Lock"; case KEY_GRAVE: return "`";
        case KEY_SPACE: return "Space"; default: return T("Unassigned");
    }
}

// Raw evdev input is necessary: this standalone Android executable has no Activity
// delivering AInputEvent keyboard events. Never EVIOCGRAB: the game keeps its keys.
class Keyboard {
    static constexpr int kDevices = 16;
    struct Device { int fd = -1; std::string path; quickcore::KeyEdges edges; bool dropped = false; };
    std::array<Device, kDevices> devices_;
    double nextScan_ = 0;
    bool denied_ = false;
    static constexpr size_t kBitsBytes = (KEY_MAX + 8) / 8;
    static bool Bit(const unsigned char *bits, int code) { return (bits[code / 8] & (1u << (code % 8))) != 0; }
    static void Sync(Device &d) {
        unsigned char held[kBitsBytes]{};
        if (ioctl(d.fd, EVIOCGKEY(sizeof(held)), held) < 0) { d.edges.Reset(); return; }
        for (int i = 0; i < quickcore::kKeyCount; ++i) d.edges.down[i] = Bit(held, i);
    }
    void Scan(double now) {
        nextScan_ = now + 3.0;
        DIR *dir = opendir("/dev/input");
        if (!dir) { denied_ = true; return; }
        denied_ = false;
        while (dirent *e = readdir(dir)) {
            if (strncmp(e->d_name, "event", 5) || !e->d_name[5]) continue;
            bool numeric = true;
            for (const char *p = e->d_name + 5; *p; ++p) if (*p < '0' || *p > '9') numeric = false;
            if (!numeric) continue;
            std::string path = std::string("/dev/input/") + e->d_name;
            bool known = false; Device *free = nullptr;
            for (Device &d : devices_) {
                if (d.fd >= 0 && d.path == path) known = true;
                if (d.fd < 0 && !free) free = &d;
            }
            if (known || !free) continue;
            const int fd = open(path.c_str(), O_RDONLY | O_NONBLOCK | O_CLOEXEC);
            if (fd < 0) { if (errno == EACCES || errno == EPERM) denied_ = true; continue; }
            unsigned char bits[kBitsBytes]{};
            if (ioctl(fd, EVIOCGBIT(EV_KEY, sizeof(bits)), bits) < 0 ||
                !(Bit(bits, KEY_A) || Bit(bits, KEY_F1) || Bit(bits, KEY_F6))) { close(fd); continue; }
            free->fd = fd; free->path = path; free->dropped = false; Sync(*free);
        }
        closedir(dir);
    }
public:
    ~Keyboard() { Close(); }
    void Close() {
        for (Device &d : devices_) {
            if (d.fd >= 0) close(d.fd);
            d.fd = -1; d.path.clear(); d.edges.Reset(); d.dropped = false;
        }
        nextScan_ = 0;
    }
    int Count() const { int n = 0; for (const Device &d : devices_) if (d.fd >= 0) ++n; return n; }
    bool Denied() const { return denied_; }
    std::array<bool, quickcore::kKeyCount> Poll(double now) {
        std::array<bool, quickcore::kKeyCount> pressed{};
        if (now >= nextScan_) Scan(now);
        for (Device &d : devices_) {
            if (d.fd < 0) continue;
            input_event events[64];
            for (int batch = 0; batch < 4; ++batch) {
                const ssize_t bytes = read(d.fd, events, sizeof(events));
                if (bytes < 0 && errno == EINTR) { --batch; continue; }
                if (bytes < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) break;
                if (bytes <= 0) {
                    close(d.fd); d.fd = -1; d.path.clear(); d.edges.Reset(); nextScan_ = 0; break;
                }
                if (bytes % sizeof(input_event)) break;
                for (size_t i = 0; i < (size_t)bytes / sizeof(input_event); ++i) {
                    const input_event &e = events[i];
                    if (e.type == EV_SYN && e.code == SYN_DROPPED) { d.dropped = true; continue; }
                    if (d.dropped) {
                        if (e.type == EV_SYN && e.code == SYN_REPORT) { Sync(d); d.dropped = false; }
                        continue;
                    }
                    if (e.type == EV_KEY && d.edges.Feed(e.code, e.value)) pressed[e.code] = true;
                }
            }
        }
        return pressed;
    }
};
Keyboard g_keyboard;

void Toggle(int action) {
    if (action < 0 || action >= quickcore::ActionCount || !avis::Active()) return;
    bool &v = *kActions[action].state; v = !v;
    avis::snd::Play(avis::snd::Sfx::Toggle);
}
bool Save() {
    if (!g_ready || g_path.empty()) return false;
    const std::string text = quickcore::Serialize(g_config);
    if (text == g_saved) return true;
    const std::string tmp = g_path + ".tmp";
    FILE *f = fopen(tmp.c_str(), "wb");
    if (!f) { g_message = T("Quick controls could not be saved"); return false; }
    const bool wrote = fwrite(text.data(), 1, text.size(), f) == text.size();
    const bool closed = fclose(f) == 0;
    if (!wrote || !closed || rename(tmp.c_str(), g_path.c_str()) != 0) {
        unlink(tmp.c_str()); g_message = T("Quick controls could not be saved"); return false;
    }
    g_saved = text; return true;
}
void DrawFloating() {
    const ImGuiIO &io = ImGui::GetIO();
    const float scale = ImClamp(ImMin(io.DisplaySize.x, io.DisplaySize.y) / 1080.f, .6f, 1.8f);
    const float diameter = ImMin(g_config.size * scale, ImMin(io.DisplaySize.x, io.DisplaySize.y) - 16.f);
    if (diameter < 16.f) return;
    const float radius = diameter * .5f, margin = 8.f;
    const float rx = ImMax(1.f, io.DisplaySize.x - diameter - 2.f * margin);
    const float ry = ImMax(1.f, io.DisplaySize.y - diameter - 2.f * margin);
    for (int i = 0; i < quickcore::kSlots; ++i) {
        quickcore::Slot &s = g_config.slots[i];
        if (!s.enabled) continue;
        const ActionDef &a = kActions[s.action];
        ImVec2 center(margin + radius + s.x * rx, margin + radius + s.y * ry);
        char window[32]; snprintf(window, sizeof(window), "##quick_float_%d", i);
        ImGui::SetNextWindowPos(ImVec2(center.x - radius, center.y - radius), ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2(diameter, diameter), ImGuiCond_Always);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
        ImGui::Begin(window, nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBackground |
            ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoMove |
            ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoScrollWithMouse);
        ImGui::SetCursorScreenPos(ImVec2(center.x - radius, center.y - radius));
        const bool clicked = ImGui::InvisibleButton("##quick_tap", ImVec2(diameter, diameter));
        quickcore::Drag &drag = g_drags[i];
        if (ImGui::IsItemActivated()) drag.Begin(io.MousePos.x, io.MousePos.y, center.x, center.y);
        if (ImGui::IsItemActive() && io.MouseDown[0] && drag.Move(io.MousePos.x, io.MousePos.y, 8.f * scale)) {
            s.x = quickcore::Clamp((drag.centerX + io.MousePos.x - drag.startX - margin - radius) / rx, 0.f, 1.f, s.x);
            s.y = quickcore::Clamp((drag.centerY + io.MousePos.y - drag.startY - margin - radius) / ry, 0.f, 1.f, s.y);
            center = ImVec2(margin + radius + s.x * rx, margin + radius + s.y * ry);
        }
        // Account for a complete fast drag between two rendered frames as well.
        const float threshold = 8.f * scale;
        if (clicked && !drag.moved && io.MouseDragMaxDistanceSqr[0] < threshold * threshold) Toggle(s.action);
        ImDrawList *dl = ImGui::GetWindowDrawList();
        const bool on = *a.state;
        const float alpha = g_config.opacity;
        const ImU32 fill = on ? Acc(alpha) : Col(242, 247, 253, alpha);
        dl->AddCircleFilled(center, radius - 2.f * scale, fill, 40);
        dl->AddCircle(center, radius - 2.f * scale, on ? Col(255, 255, 255, alpha) : Col(113, 137, 168, alpha), 40, ImMax(1.f, scale));
        ImFont *font = FMed ? FMed : ImGui::GetFont();
        const float fs = diameter * .21f;
        const ImVec2 ts = font->CalcTextSizeA(fs, 10000.f, 0.f, a.shortName);
        dl->AddText(font, fs, ImVec2(center.x - ts.x * .5f, center.y - ts.y * .5f - 2.f * scale),
                    on ? Col(255, 255, 255, alpha) : Col(36, 54, 78, alpha), a.shortName);
        dl->AddCircleFilled(ImVec2(center.x, center.y + radius * .52f), 2.4f * scale,
                            on ? Col(255, 255, 255, alpha) : Col(130, 146, 166, alpha));
        ImGui::End(); ImGui::PopStyleVar();
    }
}
} // namespace

void QuickActionsInit(const char *dataDir) {
    if (g_ready) return;
    g_path = std::string(dataDir ? dataDir : "") + "/quick_actions.cfg";
    FILE *f = fopen(g_path.c_str(), "rb");
    if (f) {
        char buffer[8193]{};
        const size_t n = fread(buffer, 1, sizeof(buffer) - 1, f);
        const bool oversized = fgetc(f) != EOF; fclose(f);
        if (!oversized) quickcore::Load(std::string(buffer, n), g_config);
    }
    quickcore::Normalize(g_config);
    g_saved = quickcore::Serialize(g_config); g_debounce.observed = g_saved; g_ready = true;
}
void QuickActionsFrame(bool &menuOpen) {
    if (!g_ready || !avis::Active()) { g_capture = -2; g_keyboard.Close(); return; }
    if (!kPc) { if (g_config.enabled && !menuOpen) DrawFloating(); return; }
    if (!g_config.enabled && g_capture == -2) { g_keyboard.Close(); return; }
    const double now = ImGui::GetTime();
    const auto keys = g_keyboard.Poll(now);
    if (g_capture != -2) {
        if (now >= g_captureDeadline || keys[KEY_ESC]) { g_capture = -2; return; }
        if (keys[KEY_BACKSPACE] || keys[KEY_DELETE]) {
            if (g_capture >= 0) g_config.slots[g_capture].key = 0;
            g_capture = -2; return;
        }
        for (int k = 0; k < quickcore::kKeyCount; ++k) if (keys[k] && quickcore::ValidKey(k)) {
            if (quickcore::Bind(g_config, g_capture, k)) { g_capture = -2; g_message.clear(); }
            else g_message = T("This key is reserved for the menu");
            break;
        }
        return; // Learning a binding never activates a feature.
    }
    if (ImGui::GetIO().WantTextInput) return;
    if (keys[g_config.menuKey]) { menuOpen = !menuOpen; UI::CloseCombo(); }
    if (menuOpen || UI::ComboOpen()) return; // No feature shortcuts while editing settings.
    for (const quickcore::Slot &s : g_config.slots)
        if (s.enabled && s.key && keys[s.key]) Toggle(s.action);
}
void QuickActionsSettings() {
    g_selected = ImClamp(g_selected, 0, quickcore::kSlots - 1);
    const float x0 = 180, x1 = 508, top = 154.f, bottom = UI::WinH - 24.f;
    const float rowH = ImMin(58.f, (bottom - top - 24.f) / 7.f);
    Card(x0, top, x1, bottom, 0, nullptr, 1.f);
    float y = top + 12.f + rowH * .5f;
    auto next = [&]() {
        DL->AddLine(P(x0 + 24.f, y + rowH * .5f), P(x1 - 24.f, y + rowH * .5f), Col(231,235,240), ImMax(1.f, U));
        y += rowH;
    };
    RowToggle("qa_master", "Quick actions", &g_config.enabled, x0, x1, y); next();
    static const char *slotNames[] = {"1", "2", "3", "4", "5", "6"};
    RowCombo("qa_slot", "Quick slot", &g_selected, slotNames, quickcore::kSlots, x0, x1, y, 90); next();
    static const char *actionNames[quickcore::ActionCount];
    for (int i = 0; i < quickcore::ActionCount; ++i) actionNames[i] = kActions[i].name;
    quickcore::Slot &s = g_config.slots[g_selected];
    RowCombo("qa_action", "Function", &s.action, actionNames, quickcore::ActionCount, x0, x1, y, 170); next();
    RowToggle("qa_enabled", kPc ? "Enable binding" : "Show button", &s.enabled, x0, x1, y); next();
    if (kPc) {
        const std::string key = g_capture == g_selected ? T("Press a key") : KeyName(s.key);
        if (RowButton("qa_bind", "Bind key", key.c_str(), x0, x1, y)) {
            g_capture = g_selected; g_captureDeadline = ImGui::GetTime() + 10.;
        }
        next();
        if (RowButton("qa_unbind", "Remove binding", "Clear", x0, x1, y)) { s.key = 0; g_capture = -2; }
        next();
        const std::string menuKey = g_capture == -1 ? T("Press a key") : KeyName(g_config.menuKey);
        if (RowButton("qa_menu_bind", "Menu key", menuKey.c_str(), x0, x1, y)) {
            g_capture = -1; g_captureDeadline = ImGui::GetTime() + 10.;
        }
    } else {
        RowSlider("qa_size", "Button size", &g_config.size, 44.f, 96.f, "%.0f", x0, x1, y, 115); next();
        RowSlider("qa_opacity", "Button opacity", &g_config.opacity, .35f, 1.f, "%.2f", x0, x1, y, 115); next();
        if (RowButton("qa_reset", "Button positions", "Reset", x0, x1, y)) {
            const quickcore::Config defaults;
            for (int i = 0; i < quickcore::kSlots; ++i) { g_config.slots[i].x = defaults.slots[i].x; g_config.slots[i].y = defaults.slots[i].y; }
        }
    }
    Card(522, top, 850, bottom, 0, nullptr, 0.f);
    const float sx = 546.f;
    FitText(FMed, 20.f, P(sx, top + 38.f), Col(15,23,42),
            T(kPc ? "Keyboard shortcuts" : "Floating buttons"),280 * U);
    const ImVec2 ca=P(546,top+76), cb=P(826,bottom-90);
    DL->AddRectFilled(ca,cb,Col(243,246,250),12 * U);
    if (kPc) {
        const std::string key = KeyName(s.key);
        const ImVec2 c=P(686,top+152);
        DL->AddRectFilled(c-ImVec2(48,28)*U,c+ImVec2(48,28)*U,Col(255,255,255),8 * U);
        DL->AddRect(c-ImVec2(48,28)*U,c+ImVec2(48,28)*U,Col(211,219,230),8 * U,0,ImMax(1.f,U));
        const ImVec2 sz=TextSize(FMed,22,key.c_str());
        Text(FMed,22,c-sz*.5f,Acc(1),key.c_str());
        char devices[96]; snprintf(devices,sizeof(devices),"%s: %d",T("Keyboard devices"),g_keyboard.Count());
        FitText(FText,15,P(sx,top+240),g_keyboard.Count()?Col(52,133,97):Col(170,80,42),devices,280*U);
        if (!g_keyboard.Count()) FitText(FText,14,P(sx,top+273),Col(170,80,42),
            g_keyboard.Denied()?L("Нужен доступ к /dev/input","/dev/input access required"):
                               L("Клавиатура Android не найдена","No Android keyboard"),280*U);
        FitText(FText,15,P(sx,bottom-55),Col(71,85,105),L("Esc — отмена · Backspace — сброс","Esc cancels · Backspace clears"),280*U);
    } else {
        const ImVec2 c=P(686,top+164);
        const float radius=g_config.size*.5f*U;
        const bool enabled=*kActions[s.action].state;
        DL->AddCircleFilled(c+ImVec2(0,2*U),radius+2*U,Col(15,23,42,.08f),48);
        DL->AddCircleFilled(c,radius,enabled?Acc(g_config.opacity):Col(255,255,255,g_config.opacity),48);
        DL->AddCircle(c,radius,Col(179,192,211),48,ImMax(1.f,U));
        const char *label=kActions[s.action].shortName;
        const ImVec2 size=TextSize(FMed,14,label);
        Text(FMed,14,c-size*.5f,enabled?Col(255,255,255):Acc(1),label);
        FitText(FText,16,P(sx,top+245),Col(71,85,105),T(kActions[s.action].name),280*U);
        FitText(FText,15,P(sx,bottom-55),Col(71,85,105),L("Тап — вкл. · Потяни — перемести","Tap to toggle · Drag to move"),280*U);
    }
    if (!g_message.empty()) FitText(FText, 14.f, P(sx, bottom - 32.f), Col(194, 93, 62), g_message.c_str(), 280.f * U);
}
void QuickActionsSaveTick(float dt) {
    if (!g_ready) return;
    quickcore::Normalize(g_config);
    const std::string current = quickcore::Serialize(g_config);
    if (g_debounce.Tick(current, dt) || (current != g_saved && g_debounce.left < 0.f))
        if (!Save()) g_debounce.left = 2.f;
}
void QuickActionsShutdown() {
    Save(); g_capture = -2; g_keyboard.Close();
}