#pragma once
#include "auto_heal_core.h"
extern heal::Config g_autoHeal;
void AutoHealInit(const char*dataDir);
void AutoHealShutdown();
void AutoHealTick(const heal::Sample &sample,const char *packageName);
void AutoHealSettings();
void AutoHealCapture(bool &menuOpen);
