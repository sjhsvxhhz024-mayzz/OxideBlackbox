#pragma once
// Общие объявления меню Trial, встроенного в avistools.

#define IMGUI_DEFINE_MATH_OPERATORS

#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>

#include <string>
#include <vector>

#include "imgui.h"
#include "imgui_internal.h"

// ===================== Настройки =====================
// POD-структура: сохраняется в файл целиком.
#define SETTINGS_VERSION 7
struct Settings {
    int   version;

    bool  wmEnabled;      // водяной знак
    int   wmStyle;        // 0 неон, 1 стекло, 2 минимал
    bool  wmFps;
    bool  wmTime;
    bool  wmPulse;
    int   borderMode;     // 0 углы, 1 полная, 2 радуга
    bool  grid;
    bool  particles;
    bool  stars;
    bool  shimmer;
    bool  shadows;
    bool  glow;

    bool  anim;
    int   transition;     // 0 плавный, 1 пружина, 2 мгновенный
    int   accent;         // кибер-палитра
    int   backgroundIndex; // 0..7
    float animSpeed;
    float particleCount;
    float particleSpeed;
    float particleSize;
    float glowStrength;
    float rounding;
    float cardAlpha;
    float bgBright;
    bool  twinkle;

    int   wmPos;          // 0 справа, 1 слева
    bool  wmCompact;
    bool  fpsGraph;
    bool  lockMenu;
    bool  dimScreen;
    bool  menuOnStart;

    int   lang;           // 0 русский, 1 English
    int   quality;        // 0 = 30 FPS, 1 = 60 FPS, 2 = 120 FPS (плотность частиц)
    float uiScale;        // 80 .. 120 %
};

extern Settings g_cfg;
void ResetSettings(Settings &s);

// ===================== Текстуры =====================
enum TextureSlot {
    TEX_RESERVED = 0,
    TEX_STAR = 1,
    TEX_ESP_PERSON = 2,
    TEX_CUSTOM_BG = 3,
    TEX_BG_THUMB_FIRST = 4,
    TEX_BG_COUNT = 8,
    TEX_PARTICLE_ATLAS = TEX_BG_THUMB_FIRST + TEX_BG_COUNT,
    TEX_LOGO_ATLAS = TEX_PARTICLE_ATLAS + 1,   // кадры анимированного логотипа: сетка 8x7, ячейка 128 px, 55 кадров
    TEX_BANNER = TEX_LOGO_ATLAS + 1,           // фон экрана ключа: TEX_BANNER_COUNT серых атласов по 5x9 кадров 384x216
    TEX_BANNER_COUNT = 7,
    TEX_COUNT = TEX_BANNER + TEX_BANNER_COUNT
};
ImTextureID GetTexture(int slot, ImVec2 *size = nullptr);
// Декодирует встроенные ассеты и заливает их в GL. Вызывать из потока с активным GL-контекстом.
void TrialUploadTextures();

extern std::string g_DataDir;   // папка для настроек меню

// Шрифты строятся в draw.cpp до сборки атласа.
extern ImFont *g_trialFontText, *g_trialFontMed, *g_trialFontTitle;

// Экран ввода ключа (auth_screen.cpp): true, пока он занимает дисплей.
bool AuthScreenRender();
void MenuAutosaveTick(float dt);   // сохранение настроек меню (trial_menu.cpp)
int DetectSystemLang();      // язык по локали телефона: 0 русский, 1 English (i18n.cpp)
float MenuBaseScale();   // масштаб дизайн-единицы до учёта uiScale (trial_menu.cpp)
void MenuDrawLogo(ImVec2 center, float radius, float time);   // анимированный логотип в кружке (контекст рисования UI::DL/U уже задан)

namespace Menu {
    void Init(int screenLong, int screenShort);
    void Render();
    void Shutdown();
}
