#pragma once
// Platform-independent quick controls. Action IDs are persistent: append, never reorder.
#include <algorithm>
#include <array>
#include <cmath>
#include <iomanip>
#include <sstream>
#include <string>

namespace quickcore {
enum Action {
    Esp, Box, Line, Skeleton, Name, Clan, Weapon, Armor, Distance, Radar,
    Ore, Animals, Base, Aim, Silent, NoRecoil, NoSpread, Stretch,
    DrawDistance, HideGrass, HideTrees, DisableLogs, AutoHeal, ActionCount
};
constexpr int kSlots = 6, kKeyCount = 768;
constexpr int kEscape = 1, kBackspace = 14, kDelete = 111, kInsert = 110;

inline bool ValidKey(int k) {
    return (k >= 2 && k <= 11) || (k >= 16 && k <= 25) ||
           (k >= 30 && k <= 38) || (k >= 44 && k <= 50) ||
           (k >= 59 && k <= 68) || k == 87 || k == 88 ||
           k == 41 || k == 57 || k == 70 || k == 102 ||
           k == 104 || k == 107 || k == 109 || k == kInsert || k == 119;
}
inline float Clamp(float x, float lo, float hi, float fallback) {
    return std::isfinite(x) ? std::max(lo, std::min(hi, x)) : fallback;
}
struct Slot {
    bool enabled = false;
    int action = Esp, key = 0;
    float x = .92f, y = .25f;
};
struct Config {
    bool enabled = false;
    float size = 64.f, opacity = .9f;
    int menuKey = kInsert;
    std::array<Slot, kSlots> slots{};
    Config() {
        const int actions[kSlots] = { Esp, Aim, Silent, Radar, NoRecoil, NoSpread };
        const int keys[kSlots] = { 64, 65, 66, 67, 68, 87 }; // evdev F6..F11
        for (int i = 0; i < kSlots; ++i) {
            slots[i].action = actions[i]; slots[i].key = keys[i];
            slots[i].y = .20f + i * .12f;
        }
        slots[0].enabled = true;
    }
};
inline void Normalize(Config &c) {
    c.size = Clamp(c.size, 44.f, 96.f, 64.f);
    c.opacity = Clamp(c.opacity, .35f, 1.f, .9f);
    if (!ValidKey(c.menuKey)) c.menuKey = kInsert;
    std::array<bool, kKeyCount> used{};
    used[c.menuKey] = true;
    for (Slot &s : c.slots) {
        if (s.action < 0 || s.action >= ActionCount) s.action = Esp;
        s.x = Clamp(s.x, 0.f, 1.f, .92f);
        s.y = Clamp(s.y, 0.f, 1.f, .25f);
        if (!ValidKey(s.key) || used[s.key]) s.key = 0;
        else used[s.key] = true;
    }
}
inline bool Bind(Config &c, int target, int key) {
    if (!ValidKey(key) || target < -1 || target >= kSlots) return false;
    if (target >= 0 && key == c.menuKey) return false;
    if (target == -1) c.menuKey = key;
    for (int i = 0; i < kSlots; ++i)
        if (i != target && c.slots[i].key == key) c.slots[i].key = 0;
    if (target >= 0) c.slots[target].key = key;
    return true;
}
inline std::string Serialize(const Config &c) {
    std::ostringstream o;
    o << "AVIS_QUICK 1\n" << std::setprecision(6)
      << "enabled " << c.enabled << "\nsize " << c.size
      << "\nopacity " << c.opacity << "\nmenu_key " << c.menuKey << '\n';
    for (int i = 0; i < kSlots; ++i) {
        const Slot &s = c.slots[i];
        o << "slot " << i << ' ' << s.enabled << ' ' << s.action << ' '
          << s.key << ' ' << s.x << ' ' << s.y << '\n';
    }
    return o.str();
}
inline bool Load(const std::string &text, Config &out) {
    std::istringstream in(text);
    std::string line;
    if (!std::getline(in, line) || line != "AVIS_QUICK 1") return false;
    Config c;
    while (std::getline(in, line)) {
        std::istringstream row(line);
        std::string kind, extra;
        row >> kind;
        if (kind == "slot") {
            int i, enabled, action, key; float x, y;
            if (!(row >> i >> enabled >> action >> key >> x >> y) || row >> extra ||
                i < 0 || i >= kSlots || (enabled != 0 && enabled != 1)) continue;
            c.slots[i] = {enabled != 0, action, key, x, y};
        } else if (kind == "enabled") {
            int v; if ((row >> v) && !(row >> extra) && (v == 0 || v == 1)) c.enabled = v != 0;
        } else if (kind == "menu_key") {
            int v; if ((row >> v) && !(row >> extra)) c.menuKey = v;
        } else if (kind == "size" || kind == "opacity") {
            float v; if ((row >> v) && !(row >> extra) && std::isfinite(v))
                (kind == "size" ? c.size : c.opacity) = v;
        }
    }
    Normalize(c); out = c; return true;
}
// Value 2 is evdev auto-repeat; a held key must not toggle every frame.
struct KeyEdges {
    std::array<bool, kKeyCount> down{};
    bool Feed(int code, int value) {
        if (code < 0 || code >= kKeyCount) return false;
        if (value == 0) { down[code] = false; return false; }
        if (value != 1) return false;
        const bool edge = !down[code]; down[code] = true; return edge;
    }
    void Reset() { down.fill(false); }
};
struct Drag {
    float startX = 0, startY = 0, centerX = 0, centerY = 0;
    bool moved = false;
    void Begin(float mx, float my, float cx, float cy) {
        startX = mx; startY = my; centerX = cx; centerY = cy; moved = false;
    }
    bool Move(float mx, float my, float threshold) {
        const float dx = mx - startX, dy = my - startY;
        if (dx * dx + dy * dy >= threshold * threshold) moved = true;
        return moved;
    }
};
// Trailing-edge debounce: every edit restarts the interval.
struct Debounce {
    std::string observed;
    float left = -1.f;
    bool Tick(const std::string &current, float dt) {
        if (current != observed) { observed = current; left = .8f; return false; }
        if (left < 0) return false;
        left -= Clamp(dt, 0.f, .25f, 0.f);
        if (left > 0) return false;
        left = -1.f; return true;
    }
};
} // namespace quickcore