#pragma once
#include <condition_variable>
#include <functional>
#include <mutex>
#include <thread>
#include <utility>

namespace overlaycore {
// One bounded discovery slot. Rendering only submits/takes with try_lock;
// there is no future::get(), wait(), or unbounded queue in the frame loop.
// Work must own its inputs and must not call ImGui or mutate renderer state.
template<class Result> class DiscoveryJob {
    std::mutex mutex;
    std::condition_variable wake;
    bool stop=false, busy=false, ready=false;
    std::function<Result()> work;
    Result result{};
    std::thread worker;
    void Run() {
        for (;;) {
            std::function<Result()> fn;
            {
                std::unique_lock<std::mutex> lock(mutex);
                wake.wait(lock,[&]{return stop || (bool)work;});
                if (stop) return;
                fn=std::move(work); work=nullptr;
            }
            Result value=fn();
            {
                std::lock_guard<std::mutex> lock(mutex);
                result=std::move(value); ready=true; busy=false;
            }
        }
    }
public:
    DiscoveryJob()=default;
    DiscoveryJob(const DiscoveryJob&)=delete;
    DiscoveryJob& operator=(const DiscoveryJob&)=delete;
    ~DiscoveryJob() {
        {std::lock_guard<std::mutex> lock(mutex); stop=true;}
        wake.notify_one();
        if (worker.joinable()) worker.join();
    }
    bool Available() {
        std::unique_lock<std::mutex> lock(mutex,std::try_to_lock);
        return lock.owns_lock() && !busy && !ready && !stop;
    }
    bool Start(std::function<Result()> fn) {
        std::unique_lock<std::mutex> lock(mutex,std::try_to_lock);
        if (!lock.owns_lock() || busy || ready || stop || !fn) return false;
        // One worker for this object's lifetime; not a new thread per retry.
        if (!worker.joinable()) worker=std::thread([this]{Run();});
        work=std::move(fn); busy=true;
        lock.unlock(); wake.notify_one(); return true;
    }
    bool Take(Result &out) {
        std::unique_lock<std::mutex> lock(mutex,std::try_to_lock);
        if (!lock.owns_lock() || !ready) return false;
        out=std::move(result); ready=false; return true;
    }
};
} // namespace overlaycore
