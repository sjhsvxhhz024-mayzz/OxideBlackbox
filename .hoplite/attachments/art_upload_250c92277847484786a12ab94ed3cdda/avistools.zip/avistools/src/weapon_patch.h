#pragma once
// No Recoil / No Spread: правка конфигов оружия (ScriptableObject) с запоминанием оригиналов и возвратом при выключении.
// Чистая логика над абстрактной памятью — проверяется на хосте (tools/test_weapon_patch.cpp).
//
// Цепочка (дамп 1.14.11949):
//   FPManager._currentWeapon (0x50) -> FPHitscan | FPRocketLauncher | FPCrossbow
//     config (0x130 | 0x128 | 0x138) -> HitscanWeaponConfig
//        +0x3C BaseDispersion, +0x68 dispersionConfig -> DispersionConfig, +0x70 recoilConfig -> RecoilConfig
//   FPHitscan+0x1F8 -> калькулятор разброса (Fg): +0x10 DispersionConfig, +0x18 HitscanWeaponConfig, +0x20 текущий накопленный разброс
// Конфиги общие для всех экземпляров оружия этого типа, поэтому правка один раз действует, пока объект жив.
#include <cstdint>
#include <cstring>
#include "oxide_arch.h"
#include <cmath>
#include <string>
#include <vector>
#include <unordered_set>

namespace wpatch {

constexpr uint64_t kCfgOffsets[3] = { 0x130, 0x128, 0x138 };      // FPHitscan, FPRocketLauncher, FPCrossbow
constexpr uint64_t kHitscanDispersion = 0x3C, kHitscanDispCfg = 0x68, kHitscanRecoilCfg = 0x70;
constexpr uint64_t kFpHitscanCalc = 0x1F8, kCalcDispCfg = 0x10, kCalcWeaponCfg = 0x18, kCalcLive = 0x20;
constexpr uint64_t kRecoilFields[] = { 0x18, 0x1C, 0x20, 0x24, 0x28, 0x2C };        // MinRecoil.xy, MaxRecoil.xy, Min/MaxSideDelta
constexpr uint64_t kDispFields[]   = { 0x18, 0x1C, 0x20, 0x24, 0x28, 0x30 };        // min/max fire, min/max, increase per shot, MoveScale

enum Group { kRecoil = 0, kSpread = 1 };

struct Ctx {
    uint64_t weapon = 0, cfg = 0, recoil = 0, disp = 0, calc = 0;
    uint64_t cfgOff = 0;
    bool ok() const { return cfg && recoil && disp; }
};

struct Saved { uint64_t addr; uint32_t orig; int group; };

template <class M>
struct Patcher {
    std::vector<Saved> saved;
    std::unordered_set<uint64_t> keys;          // addr уже сохранён: повторная правка не затирает оригинал нулём

    static bool isPtr(uint64_t p) { return oxarch::isPtr(p) && (p & 3) == 0; }

    // Находит конфиги у текущего оружия. Каждый объект подтверждается именем класса; для FPHitscan дополнительно сверяется калькулятор разброса.
    bool resolve(M &m, uint64_t weapon, Ctx &c) {
        c = Ctx();
        if (!isPtr(weapon)) return false;
        for (uint64_t off : kCfgOffsets) {
            uint64_t cfg = 0;
            if (!m.rd(weapon + off, &cfg, 8) || !isPtr(cfg) || m.cls(cfg) != "HitscanWeaponConfig") continue;
            uint64_t disp = 0, rec = 0;
            if (!m.rd(cfg + kHitscanDispCfg, &disp, 8) || !m.rd(cfg + kHitscanRecoilCfg, &rec, 8)) continue;
            if (!isPtr(disp) || !isPtr(rec) || m.cls(disp) != "DispersionConfig" || m.cls(rec) != "RecoilConfig") continue;
            c.weapon = weapon; c.cfg = cfg; c.disp = disp; c.recoil = rec; c.cfgOff = off;
            uint64_t calc = 0, cd = 0, cw = 0;
            if (off == 0x130 && m.rd(weapon + kFpHitscanCalc, &calc, 8) && isPtr(calc) &&
                m.rd(calc + kCalcDispCfg, &cd, 8) && m.rd(calc + kCalcWeaponCfg, &cw, 8) && cd == disp && cw == cfg)
                c.calc = calc;
            return true;
        }
        return false;
    }

    int zeroField(M &m, uint64_t addr, int group) {
        uint32_t cur = 0;
        if (!m.rd(addr, &cur, 4)) return 0;
        if (keys.insert(addr).second) saved.push_back(Saved{ addr, cur, group });
        const uint32_t z = 0;
        return m.wr(addr, &z, 4) ? 1 : 0;
    }

    // Возвращает число записанных полей.
    int applyRecoil(M &m, const Ctx &c) {
        int n = 0;
        for (uint64_t f : kRecoilFields) n += zeroField(m, c.recoil + f, kRecoil);
        return n;
    }
    int applySpread(M &m, const Ctx &c) {
        int n = 0;
        for (uint64_t f : kDispFields) n += zeroField(m, c.disp + f, kSpread);
        n += zeroField(m, c.cfg + kHitscanDispersion, kSpread);
        return n;
    }
    // Накопленный разброс живёт в калькуляторе и растёт с каждым выстрелом: обнуляем каждый кадр (дёшево, пишем только ненулевое).
    bool zeroLiveSpread(M &m, const Ctx &c) {
        if (!c.calc) return false;
        float v = 0;
        if (!m.rd(c.calc + kCalcLive, &v, 4) || !std::isfinite(v) || v == 0.0f || fabsf(v) > 10.0f) return false;
        const float z = 0.0f;
        return m.wr(c.calc + kCalcLive, &z, 4);
    }

    // Возвращает оригиналы группы (или всех, group = -1). Число восстановленных полей.
    int restore(M &m, int group = -1) {
        int n = 0;
        std::vector<Saved> keep;
        for (const Saved &s : saved) {
            if (group >= 0 && s.group != group) { keep.push_back(s); continue; }
            if (m.wr(s.addr, &s.orig, 4)) ++n;
            keys.erase(s.addr);
        }
        saved.swap(keep);
        return n;
    }
    int count(int group) const { int n = 0; for (const Saved &s : saved) if (s.group == group) ++n; return n; }
};

} // namespace wpatch
