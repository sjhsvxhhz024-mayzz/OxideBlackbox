#pragma once
// Подмена значений нативной камеры Unity, которые видны в её матрице проекции: соотношение сторон (Stretch) и дальняя плоскость
// отсечения (Draw distance, Memory -> Boost). Один движок, два режима (Kind).
//
// Растяжение картинки (Stretch): подмена соотношения сторон нативной камеры Unity.
//
// Как это работает. Unity пересчитывает матрицу проекции камеры каждый кадр, потому что игра в LateUpdate пишет Camera.fieldOfView
// (FPManager), а при пересчёте берёт float m_Aspect самой камеры. Игра сама m_Aspect не трогает (его обновляет движок только при смене
// размера окна). Значит, достаточно записать нужное соотношение сторон в m_Aspect нативного объекта камеры: следующий пересчёт даст
// матрицу с другим m00 = cot(fov/2)/aspect, и картинка растянется на весь экран. Матрица VP, по которой строится ESP, читается из той же
// камеры, поэтому ESP остаётся на своих местах без поправок.
//
// Смещение m_Aspect заранее неизвестно (нативная камера в libunity, в дампе её нет), поэтому оно находится само и проверяется по реакции:
//   1. текущее соотношение сторон eff = m11/m00 берётся из матрицы проекции (она лежит в камере, смещение уже найдено ESP);
//   2. кандидаты — float внутри первых 0x600 байт камеры, равные eff (кроме самих матриц);
//   3. во все кандидаты пишется целевое значение; если матрица в течение ~0.8 с пришла к нему — смещение подтверждено;
//   4. не отреагировала — записи откатываются побайтно; пробуются ещё несколько вариантов вместе с флагом m_ImplicitAspect (байт 1 рядом
//      с полем -> 0), каждый с откатом при неудаче;
//   5. подтверждённое значение держится: если движок вернул своё (смена размера окна), запись повторяется.
// Выключение возвращает исходные значения. Все операции — через интерфейс памяти, логика проверяется на хосте (tools/test_stretch_core.cpp).
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
#include <algorithm>

namespace stretch {

static const int kPresetCount = 7;
inline const char *presetLabel(int i) {
    static const char *const k[kPresetCount] = { "16:9", "16:10", "3:2", "4:3", "5:4", "1:1", "Custom" };
    return k[i < 0 ? 0 : (i >= kPresetCount ? kPresetCount - 1 : i)];
}
inline float clampAspect(float a) {
    if (!isfinite(a)) return 4.f / 3.f;
    return a < 0.5f ? 0.5f : (a > 3.0f ? 3.0f : a);
}
inline float presetAspect(int mode, float custom) {
    static const float v[6] = { 16.f / 9.f, 1.6f, 1.5f, 4.f / 3.f, 1.25f, 1.0f };
    if (mode >= 0 && mode < 6) return v[mode];
    return clampAspect(custom);
}

// Unity хранит матрицы по столбцам: m00 = m[0], m11 = m[5], m23 = m[11] (= -1 у перспективы).
inline bool aspectFromProj(const float *m, float &out) {
    if (!isfinite(m[0]) || !isfinite(m[5]) || m[0] < 1e-3f || m[5] < 1e-3f) return false;
    if (fabsf(m[11] + 1.f) > 1e-3f) return false;                         // не перспектива
    const float a = m[5] / m[0];
    if (!(a > 0.2f && a < 6.f)) return false;
    out = a;
    return true;
}

enum class Kind { Aspect, FarClip };
enum class State { Idle, Verifying, Active, Failed };

inline float clampFar(float f) {
    if (!isfinite(f)) return 300.f;
    return f < 50.f ? 50.f : (f > 3000.f ? 3000.f : f);
}
// Дальняя плоскость из перспективной матрицы Unity (column-major): n = m32/(m22-1), f = m32/(m22+1).
inline bool farFromProj(const float *m, float &out) {
    if (!isfinite(m[10]) || !isfinite(m[14]) || fabsf(m[11] + 1.f) > 1e-3f || fabsf(m[15]) > 1e-4f) return false;
    if (!(m[10] < -1.f) || !(m[14] < 0.f)) return false;
    const float n = m[14] / (m[10] - 1.f), f = m[14] / (m[10] + 1.f);
    if (!(n > 0.001f && n < 50.f && f > n * 2.f && f < 100000.f) || !isfinite(f)) return false;
    out = f;
    return true;
}

class Engine {
public:
    static const int kWindow = 0x600;          // область поиска внутри нативной камеры
    static const int kMaxFloats = 6;           // больше совпадений — поле не определить однозначно
    static const int kMaxFlagVariants = 4;
    static constexpr double kVerifyFloat = 0.8, kVerifyFlag = 0.4, kRetry = 20.0, kDriftDrop = 3.0;

    explicit Engine(Kind k = Kind::Aspect) : kind(k) { status = std::string(name()) + ": off"; }
    const Kind kind;
    State state = State::Idle;
    float applied = 0.f;                       // значение в поле, пока Active
    std::string status = "off";
    int scans = 0, writes = 0;                 // для тестов и диагностики
    bool known() const { return known_; }
    int aspectOffset() const { return fOff_.empty() ? -1 : fOff_[0]; }
    int flagOffset() const { return flagOff_; }

    // Сообщения для лога (вызывающий забирает и пишет).
    std::vector<std::string> drain() { std::vector<std::string> o; o.swap(log_); return o; }

    template <class Mem>
    void tick(Mem &mem, uint64_t cam, int projOff, int viewOff, bool want, float target, float screenAspect, double now) {
        if (cam != cam_) {
            if (cam_ && (state == State::Active || state == State::Verifying)) note("camera object changed: re-applying to the new one");
            cam_ = cam;
            if (state == State::Active || state == State::Verifying || state == State::Failed) state = State::Idle;
            applied = 0.f; haveOrig_ = false;
        }
        float eff = 0.f;
        float P[16];
        const bool matOk = projOff >= 0 && cam && mem.rd(cam + (uint64_t)projOff, P, sizeof(P)) && quantity(P, eff);
        if (!want) { turnOff(mem, cam, matOk, eff, screenAspect); return; }
        if (!matOk) {
            if (state == State::Idle || state == State::Failed) status = std::string(name()) + ": waiting for the camera matrix";
            return;
        }
        const float T = clampT(target);
        switch (state) {
            case State::Idle: begin(mem, cam, projOff, viewOff, T, eff, screenAspect, now); break;
            case State::Verifying: verify(mem, cam, T, eff, now); break;
            case State::Active: hold(mem, cam, T, eff, now); break;
            case State::Failed: if (now >= retryAt_) { state = State::Idle; status = std::string(name()) + ": retrying"; } break;
        }
    }

private:
    uint64_t cam_ = 0;
    bool known_ = false, haveOrig_ = false;
    std::vector<int> fOff_;                    // смещения float-кандидатов (после подтверждения — поле)
    std::vector<float> origF_;
    int flagOff_ = -1;                         // подтверждённый флаг m_ImplicitAspect (-1 — не нужен)
    uint8_t origFlag_ = 0;
    std::vector<int> flagVariants_;
    int variant_ = -1;                         // -1 — только float, иначе индекс в flagVariants_
    int tryFlag_ = -1;                         // флаг, записанный в текущем варианте
    float restore_ = 0.f, T_ = 0.f;
    double deadline_ = 0.0, firstGood_ = 0.0, retryAt_ = 0.0, mismatchSince_ = 0.0, nextHold_ = 0.0;
    int streak_ = 0;
    int projOff_ = -1, viewOff_ = -1;
    std::vector<std::string> log_;

    void note(const std::string &s) { log_.push_back(s); }
    const char *tag() const { return kind == Kind::Aspect ? "[stretch]" : "[drawdist]"; }
    const char *name() const { return kind == Kind::Aspect ? "Stretch" : "Draw distance"; }
    bool quantity(const float *P, float &out) const { return kind == Kind::Aspect ? aspectFromProj(P, out) : farFromProj(P, out); }
    float clampT(float t) const { return kind == Kind::Aspect ? clampAspect(t) : clampFar(t); }
    float candTol(float v) const { return kind == Kind::Aspect ? 0.0015f : std::max(0.5f, 0.004f * v); }   // совпадение поля с текущим значением
    float verTol(float T) const { return kind == Kind::Aspect ? std::max(0.01f, 0.012f * T) : std::max(1.5f, 0.03f * T); }   // матрица дошла до цели
    float holdTol(float T) const { return kind == Kind::Aspect ? 1e-4f : std::max(1e-3f, 1e-4f * T); }
    const char *fmtVal() const { return kind == Kind::Aspect ? "%.4f" : "%.1f"; }
    template <class... A>
    static std::string fmt(const char *f, A... a) { char buf[320]; snprintf(buf, sizeof(buf), f, a...); return buf; }

    static bool excluded(int off, int len, int projOff, int viewOff) {
        auto in = [&](int a) { return a >= 0 && off < a + 64 && off + len > a; };
        return in(viewOff) || in(projOff) || in(projOff + 64);
    }

    template <class Mem>
    bool readWindow(Mem &mem, uint64_t cam, std::vector<uint8_t> &buf, std::vector<uint8_t> &ok) {
        buf.assign(kWindow, 0); ok.assign(kWindow / 0x100, 0);
        bool any = false;
        for (int o = 0; o < kWindow; o += 0x100) if (mem.rd(cam + (uint64_t)o, buf.data() + o, 0x100)) { ok[o / 0x100] = 1; any = true; }
        return any;
    }

    template <class Mem>
    bool writeFloat(Mem &mem, uint64_t cam, int off, float v) { ++writes; return mem.wr(cam + (uint64_t)off, &v, 4); }
    template <class Mem>
    bool writeByte(Mem &mem, uint64_t cam, int off, uint8_t v) { ++writes; return mem.wr(cam + (uint64_t)off, &v, 1); }

    template <class Mem>
    void fail(Mem &, uint64_t, double now, const std::string &why) {
        state = State::Failed; retryAt_ = now + kRetry; applied = 0.f;
        status = std::string(name()) + ": " + why;
        note(std::string(tag()) + " " + why);
    }

    // Откат: поля — к исходным значениям (в restore_ при подтверждённой записи), флаг — к исходному.
    template <class Mem>
    void rollback(Mem &mem, uint64_t cam) {
        for (size_t i = 0; i < fOff_.size() && i < origF_.size(); ++i) writeFloat(mem, cam, fOff_[i], origF_[i]);
        if (tryFlag_ >= 0) writeByte(mem, cam, tryFlag_, origFlag_);
        tryFlag_ = -1;
    }

    template <class Mem>
    void begin(Mem &mem, uint64_t cam, int projOff, int viewOff, float T, float eff, float screenAspect, double now) {
        projOff_ = projOff; viewOff_ = viewOff; T_ = T;
        if (known_) {                                                          // быстрый путь: смещения уже подтверждены
            origF_.clear(); bool ok = !fOff_.empty();
            for (int o : fOff_) { float v = 0; if (!mem.rd(cam + (uint64_t)o, &v, 4)) { ok = false; break; } origF_.push_back(v); if (fabsf(v - eff) > candTol(eff) && fabsf(v - T) > candTol(T)) ok = false; }
            if (flagOff_ >= 0 && !mem.rd(cam + (uint64_t)flagOff_, &origFlag_, 1)) ok = false;
            if (ok) { startWrite(mem, cam, T, screenAspect, now, flagOff_, 0.8); return; }
            known_ = false; fOff_.clear(); flagOff_ = -1;
            note(std::string(tag()) + " saved offsets no longer match this camera: searching again");
        }
        std::vector<uint8_t> buf, ok;
        ++scans;
        if (!readWindow(mem, cam, buf, ok)) { fail(mem, cam, now, "camera memory is not readable"); return; }
        fOff_.clear();
        for (int o = 0; o + 4 <= kWindow; o += 4) {
            if (!ok[o / 0x100] || excluded(o, 4, projOff, viewOff)) continue;
            float v; memcpy(&v, buf.data() + o, 4);
            if (isfinite(v) && fabsf(v - eff) <= candTol(eff)) fOff_.push_back(o);
        }
        if (fOff_.empty()) { fail(mem, cam, now, fmt((std::string("no float equal to the camera value ") + fmtVal() + " in the first 0x600 bytes of the camera").c_str(), (double)eff)); return; }
        if ((int)fOff_.size() > kMaxFloats) { fail(mem, cam, now, fmt((std::string("%d floats match the camera value ") + fmtVal() + ": field is ambiguous").c_str(), (int)fOff_.size(), (double)eff)); fOff_.clear(); return; }
        // Кандидаты во флаг m_ImplicitAspect: байты со значением 1 рядом с первым полем (вперёд, затем назад); сами матрицы и float-кандидаты исключены.
        flagVariants_.clear();
        const int f0 = fOff_[0];
        if (kind == Kind::Aspect) {
        struct Cand { int off, key; };
        std::vector<Cand> cs;
        for (int o = std::max(0, f0 - 0x20); o < std::min(kWindow, f0 + 0x90); ++o) {
            if (!ok[o / 0x100] || buf[o] != 1 || excluded(o, 1, projOff, viewOff)) continue;
            bool inF = false; for (int f : fOff_) if (o >= f && o < f + 4) inF = true;
            if (inF) continue;
            cs.push_back({ o, o >= f0 ? o - f0 : (f0 - o) + 0x100 });
        }
        std::sort(cs.begin(), cs.end(), [](const Cand &a, const Cand &b) { return a.key < b.key; });
        for (const Cand &c : cs) if ((int)flagVariants_.size() < kMaxFlagVariants) flagVariants_.push_back(c.off);
        }
        variant_ = -1;
        origF_.clear();
        for (int o : fOff_) { float v; memcpy(&v, buf.data() + o, 4); origF_.push_back(v); }
        note(fmt((std::string("%s candidates for the field: %d (first at +0x%X), value ") + fmtVal()).c_str(), tag(), (int)fOff_.size(), fOff_[0], (double)eff));
        startWrite(mem, cam, T, screenAspect, now, -1, kVerifyFloat);
    }

    template <class Mem>
    void startWrite(Mem &mem, uint64_t cam, float T, float screenAspect, double now, int flag, double window) {
        // Значение, к которому возвращаться при выключении: исходное поле, а если оно уже было растянуто прошлым запуском — экран.
        const float o0 = origF_.empty() ? screenAspect : origF_[0];
        restore_ = (kind == Kind::Aspect && screenAspect > 0.2f && fabsf(o0 - screenAspect) > 0.01f * screenAspect) ? screenAspect : o0;
        haveOrig_ = true;
        tryFlag_ = -1;
        if (flag >= 0) { if (!mem.rd(cam + (uint64_t)flag, &origFlag_, 1)) { fail(mem, cam, now, "flag byte is not readable"); return; } }
        bool wrote = true;
        for (int o : fOff_) wrote = writeFloat(mem, cam, o, T) && wrote;
        if (flag >= 0) { wrote = writeByte(mem, cam, flag, 0) && wrote; tryFlag_ = flag; }
        if (!wrote) { rollback(mem, cam); fail(mem, cam, now, "memory write was rejected"); return; }
        state = State::Verifying; deadline_ = now + window; streak_ = 0; firstGood_ = 0.0;
        status = std::string(name()) + ": checking";
    }

    template <class Mem>
    void verify(Mem &mem, uint64_t cam, float T, float eff, double now) {
        const float tol = verTol(T);
        if (T != T_) { for (int o : fOff_) writeFloat(mem, cam, o, T); T_ = T; streak_ = 0; deadline_ = std::max(deadline_, now + 0.5); }
        if (fabsf(eff - T) <= tol) {
            if (streak_++ == 0) firstGood_ = now;
            if (streak_ >= 2 && now - firstGood_ >= 0.03) {
                state = State::Active; known_ = true; flagOff_ = tryFlag_; tryFlag_ = -1; applied = T; mismatchSince_ = 0.0; nextHold_ = 0.0;
                status = fmt((std::string("%s: on (") + (kind == Kind::Aspect ? "%.3f" : "%.0f m") + ")").c_str(), name(), (double)T);
                note(fmt("%s CONFIRMED: field at +0x%X (%d candidates written)", tag(), fOff_[0], (int)fOff_.size()) +
                     (flagOff_ >= 0 ? fmt(", implicit-aspect flag at +0x%X", flagOff_) : std::string(", no flag needed")) +
                     fmt((std::string(", matrix value ") + fmtVal()).c_str(), (double)eff));
            }
            return;
        }
        streak_ = 0;
        if (now < deadline_) return;
        // Нет реакции: откат и следующий вариант.
        rollback(mem, cam);
        if (known_) { known_ = false; state = State::Idle; fOff_.clear(); flagOff_ = -1; note(std::string(tag()) + " saved offsets stopped working: searching again"); return; }
        ++variant_;
        if (variant_ < (int)flagVariants_.size()) {
            note(fmt((std::string("%s no reaction (matrix value ") + fmtVal() + "): trying together with the flag byte at +0x%X").c_str(), tag(), (double)eff, flagVariants_[variant_]));
            startWrite(mem, cam, T, restore_, now, flagVariants_[variant_], kVerifyFlag);
            return;
        }
        fail(mem, cam, now, fmt((std::string("the matrix did not react to the change (value ") + fmtVal() + "): field not found; all writes rolled back").c_str(), (double)eff));
        fOff_.clear(); flagVariants_.clear();
    }

    template <class Mem>
    void hold(Mem &mem, uint64_t cam, float T, float eff, double now) {
        if (now < nextHold_) return;
        nextHold_ = now + 0.04;
        bool rewrote = false;
        for (int o : fOff_) {
            float v = 0.f;
            if (!mem.rd(cam + (uint64_t)o, &v, 4)) continue;
            if (fabsf(v - T) > holdTol(T)) { writeFloat(mem, cam, o, T); rewrote = true; }
        }
        if (flagOff_ >= 0) { uint8_t f = 1; if (mem.rd(cam + (uint64_t)flagOff_, &f, 1) && f != 0) { writeByte(mem, cam, flagOff_, 0); rewrote = true; } }
        if (T != applied) { applied = T; status = fmt((std::string("%s: on (") + (kind == Kind::Aspect ? "%.3f" : "%.0f m") + ")").c_str(), name(), (double)T); }
        const float tol = verTol(T);
        if (fabsf(eff - T) > tol) {
            if (mismatchSince_ == 0.0) mismatchSince_ = now;
            else if (now - mismatchSince_ > kDriftDrop) { state = State::Idle; mismatchSince_ = 0.0; applied = 0.f; note(std::string(tag()) + " the matrix does not follow the written value: checking again"); }
        } else mismatchSince_ = 0.0;
        (void)rewrote;
    }

    template <class Mem>
    void turnOff(Mem &mem, uint64_t cam, bool matOk, float, float screenAspect) {
        if (state == State::Failed) state = State::Idle;
        if (state == State::Active || state == State::Verifying) {
            if (cam && haveOrig_) {
                for (int o : fOff_) writeFloat(mem, cam, o, restore_ > 0.2f ? restore_ : screenAspect);
                if (flagOff_ >= 0) writeByte(mem, cam, flagOff_, origFlag_);
                if (tryFlag_ >= 0) writeByte(mem, cam, tryFlag_, origFlag_);
            }
            tryFlag_ = -1; state = State::Idle; applied = 0.f;
            note(fmt((std::string("%s off: value returned to ") + fmtVal()).c_str(), tag(), (double)restore_));
        }
        (void)matOk;
        status = std::string(name()) + ": off";
    }
};

}  // namespace stretch
