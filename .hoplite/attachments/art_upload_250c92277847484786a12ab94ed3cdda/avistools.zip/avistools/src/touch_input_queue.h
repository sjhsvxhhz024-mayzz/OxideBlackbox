#pragma once
#include <deque>
#include <mutex>
#include <vector>
namespace touchinput {
struct Event { float x,y; bool down; };
class Queue {
    std::mutex mutex;
    std::deque<Event> events;
public:
    void Push(Event e) {
        std::lock_guard<std::mutex> lock(mutex);
        // Coalesce motion only. A press followed by release must survive even
        // if both arrive between two render frames.
        if (events.size() >= 2 && events.back().down==e.down && events[events.size()-2].down==e.down) events.back()=e;
        else { if(events.size()>=256) events.pop_front(); events.push_back(e); }
    }
    std::vector<Event> Take() {
        std::lock_guard<std::mutex> lock(mutex);
        std::vector<Event> result(events.begin(),events.end()); events.clear();return result;
    }
    void Clear(){std::lock_guard<std::mutex> lock(mutex);events.clear();}
};
inline bool ValidSlot(int s){return s>=0 && s<10;}
} // namespace touchinput
