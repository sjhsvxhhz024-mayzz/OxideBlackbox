#pragma once
// Чтение костей из иерархии нативных Transform (Unity). Шаблон по «памяти» M, поэтому код
// проверяется на хосте с поддельной памятью процесса (tools/test_bones.cpp), а в игре M —
// чтение через process_vm_readv.
//
// Известно только, что управляемый Transform + 0x10 -> нативный Transform. Дальше раскладка зависит
// от версии Unity (в этом билде — 6000.3), поэтому она не принимается на веру, а ПОДБИРАЕТСЯ по нескольким
// Transform одной модели (голова, корпус, держатели оружия):
//   * в нативном Transform ищется указатель на иерархию, одинаковый у всех костей модели, и индекс
//     узла, разный у каждой;
//   * в заголовке иерархии ищется пара указателей на массивы локальных TRS и индексов родителей;
//   * шаг записи узла берётся из разности указателей на блоки узлов (нативный Transform + 0x28 ->
//     блок узла, как нашёл автор репозитория по рантайм-дампу), плюс типовые значения;
//   * перебираются форматы записи TRS. Верным считается тот, при котором цепочка локальных TRS даёт
//     те же мировые позиции, что кэш движка (блок узла + 0x90); если кэша нет — кости модели должны
//     оказаться рядом друг с другом и рядом с игроком, а голова выше корпуса.
#include "skeleton.h"
#include <map>
#include <set>
#include <vector>
#include <memory>

namespace oxbone {
using namespace oxskel;

struct Layout {
    int hierOff = 0x38, idxOff = 0x40;      // в нативном Transform
    int localOff = 0x18, parentOff = 0x20;  // в заголовке иерархии
    TrsFmt fmt;
    bool ok = false;
    bool truth = false;                     // подтверждено мировыми позициями из кэша движка
};

struct CalibReport {
    int nNat = 0, nHier = 0, nPtr = 0, tried = 0, parentOk = 0, worldOk = 0, reads = 0, nTruth = 0, strides = 0;
    uint64_t nat0 = 0, nat1 = 0, hier = 0;
};

constexpr int kMaxNeed = 256;
constexpr int kMaxStride = 0x400;

struct BoneState {
    uint64_t internal = 0;                       // нативный Transform головы
    uint64_t hier = 0, localBase = 0, parentBase = 0;
    int headIdx = -1;
    bool mapped = false;
    double nextMap = 0.0;
    RigMap map;
    int N = 0;
    std::vector<int> parent;
    std::vector<TRS> loc;
    std::vector<uint8_t> have;
    std::vector<V3> wp;
    int need[kMaxNeed] = {};
    uint64_t addr[kMaxNeed] = {};
    float len0[kMaxNeed] = {};                        // длина локального смещения кости при разборе карты
    int needN = 0;
    std::vector<uint8_t> buf;                    // буфер покадрового чтения
    const char *why = "";                        // причина последней неудачи, для лога
};

namespace detail {

template <class M> struct CMem {
    M &mem;
    int reads = 0, cap = 4000;
    std::map<std::pair<uint64_t, int>, std::vector<uint8_t>> ok;
    std::set<std::pair<uint64_t, int>> bad;
    explicit CMem(M &m) : mem(m) {}
    bool rd(uint64_t a, void *b, size_t n) {
        const auto key = std::make_pair(a, (int)n);
        auto it = ok.find(key);
        if (it != ok.end()) { memcpy(b, it->second.data(), n); return true; }
        if (bad.count(key) || reads >= cap) return false;
        ++reads;
        std::vector<uint8_t> v(n);
        // Read into the caller's actual buffer first. With /proc/<pid>/mem an
        // invalid local destination is reported as EFAULT, whereas copying
        // from a temporary vector into it would segfault this worker.
        if (!mem.rd(a, b, n)) { bad.insert(key); return false; }
        memcpy(v.data(), b, n);
        ok.emplace(key, std::move(v));
        return true;
    }
};

inline uint64_t U64(const uint8_t *p) { uint64_t v; memcpy(&v, p, 8); return v; }
inline int I32(const uint8_t *p) { int v; memcpy(&v, p, 4); return v; }

// Форматы записи TRS для заданного шага: порядок pos/rot/scl, компоненты по 4 или по 3 float.
inline int GenFormats(int stride, TrsFmt *out, int cap) {
    int n = 0;
    static const int perms[6][3] = { {0,1,2}, {1,0,2}, {0,2,1}, {2,0,1}, {1,2,0}, {2,1,0} };   // 0 pos, 1 rot, 2 scl
    for (int pad = 1; pad >= 0; --pad) {
        for (const auto &pm : perms) {
            int off[3] = { 0, 0, 0 }, cur = 0;
            for (int k = 0; k < 3; ++k) {
                const int comp = pm[k];
                off[comp] = cur;
                cur += (comp == 1) ? 4 : (pad ? 4 : 3);
            }
            if (cur * 4 > stride || cur * 4 > 64) continue;
            if (stride == 0x28 && cur != 10) continue;
            if (n < cap) out[n++] = TrsFmt{ stride, off[0], off[1], off[2] };
        }
    }
    return n;
}

template <class C>
bool ChainW(C &cm, uint64_t L, uint64_t P, const TrsFmt &f, int idx, V3 *pos, Q4 *rot) {
    V3 p; Q4 q;
    bool first = true;
    int cur = idx, guard = 0;
    while (cur >= 0) {
        if (cur >= 4096 || ++guard > 64) return false;
        uint8_t buf[64];
        if (!cm.rd(L + (uint64_t)cur * (uint64_t)f.stride, buf, f.stride < 64 ? (size_t)f.stride : 64u)) return false;
        TRS t;
        if (!ParseTRS(buf, f, t)) return false;
        if (first) { p = t.pos; q = t.rot; first = false; }
        else { p = rotate(t.rot, V3{ p.x * t.scl.x, p.y * t.scl.y, p.z * t.scl.z }) + t.pos; q = qmul(t.rot, q); }
        int par;
        if (!cm.rd(P + (uint64_t)cur * 4, &par, 4)) return false;
        if (par < -1 || par >= 4096) return false;
        cur = par;
    }
    if (pos) *pos = p;
    if (rot) *rot = q;
    return true;
}

} // namespace detail

// Подбор раскладки. nat[0] — нативный Transform головы, nat[1] — корпуса (если есть), дальше любые
// Transform той же модели. feet — позиция игрока (грубая проверка «рядом»). matrixOff/worldOff — где в
// нативном Transform указатель на блок узла и где в блоке кэш мировой позиции (0 — не использовать).
template <class M>
bool Calibrate(M &mem, Layout &out, const uint64_t *nat, int n, V3 feet, CalibReport *rep = nullptr,
               int matrixOff = 0x28, int worldOff = 0x90) {
    using namespace detail;
    CalibReport R;
    CMem<M> cm(mem);
    uint64_t u[64];
    int nu = 0;
    for (int i = 0; i < n && nu < 64; ++i) {
        if (!mem.isPtr(nat[i])) continue;
        bool dup = false;
        for (int k = 0; k < nu; ++k) if (u[k] == nat[i]) dup = true;
        if (!dup) u[nu++] = nat[i];
    }
    R.nNat = nu;
    if (nu >= 1) R.nat0 = u[0];
    if (nu >= 2) R.nat1 = u[1];
    if (rep) *rep = R;
    if (nu < 2) return false;

    // Keep this scratch allocation local to the calibration job. A persistent
    // thread_local pointer was observed as a non-writable memcpy destination on
    // Android x86_64 when the worker entered this first native read.
    struct NativeScratch { uint8_t bytes[64][0xA0]; };
    std::unique_ptr<NativeScratch> nativeScratch(new NativeScratch{});
    auto &nb = nativeScratch->bytes;
    uint64_t un[64];
    int m = 0;
    for (int k = 0; k < nu; ++k) if (m < 64 && cm.rd(u[k], nb[m], 0xA0)) un[m++] = u[k];
    if (m < 2 || un[0] != u[0]) { R.reads = cm.reads; if (rep) *rep = R; return false; }
    nu = m;

    // кэш мировой позиции движка: опорная истина для проверки цепочки
    uint64_t mp[64];
    V3 gt[64];
    bool haveGt[64];
    int nGt = 0;
    for (int k = 0; k < nu; ++k) {
        mp[k] = 0; haveGt[k] = false;
        if (matrixOff <= 0 || matrixOff + 8 > 0xA0) continue;
        mp[k] = U64(nb[k] + matrixOff);
        float f[3];
        if (mem.isPtr(mp[k]) && cm.rd(mp[k] + (uint64_t)worldOff, f, sizeof(f)) &&
            isfinite(f[0]) && isfinite(f[1]) && isfinite(f[2]) && fabsf(f[0]) < 1e5f && fabsf(f[1]) < 1e5f && fabsf(f[2]) < 1e5f) {
            gt[k] = V3{ f[0], f[1], f[2] }; haveGt[k] = true; ++nGt;
        }
    }
    if (nGt >= 2) {                                  // истина годится, только если сама правдоподобна: части одной модели рядом с игроком
        bool consistent = true;
        for (int a = 0; a < nu && consistent; ++a) {
            if (!haveGt[a]) continue;
            if (hdist(gt[a], feet) > 8.0f) consistent = false;
            for (int b2 = 0; b2 < a && consistent; ++b2) if (haveGt[b2] && len(gt[a] - gt[b2]) > 3.5f) consistent = false;
        }
        if (!consistent) { for (int k = 0; k < nu; ++k) haveGt[k] = false; nGt = 0; }
    }
    R.nTruth = nGt;

    // Проход с опорной истиной (кэш мира движка) и, если он ничего не нашёл, проход без неё: кэш может отставать
    // от локальных TRS, и тогда он отвергал бы верную раскладку.
    auto search = [&](bool useGt) -> bool {
    // кандидаты смещения указателя на иерархию: одинаков у большинства костей
    int hoC[32], nHo = 0;
    for (int o = 0x08; o <= 0x90 && nHo < 32; o += 8) {
        const uint64_t v0 = U64(nb[0] + o);
        if (!mem.isPtr(v0)) continue;
        int same = 0;
        for (int k = 0; k < nu; ++k) if (U64(nb[k] + o) == v0) ++same;
        if (same >= 2 && same * 10 >= nu * 6) hoC[nHo++] = o;
    }
    for (int i = 0; i < nHo; ++i) if (hoC[i] == 0x38) { const int t = hoC[0]; hoC[0] = hoC[i]; hoC[i] = t; break; }
    R.nHier = nHo;

    for (int hi = 0; hi < nHo; ++hi) {
        const int ho = hoC[hi];
        const uint64_t H = U64(nb[0] + ho);
        int grp[64], ng = 0;
        for (int k = 0; k < nu; ++k) if (U64(nb[k] + ho) == H) grp[ng++] = k;
        if (ng < 2) continue;
        uint8_t hb[0xB0];
        if (!cm.rd(H, hb, sizeof(hb))) continue;
        R.hier = H;

        // кандидаты индекса узла: у всех костей группы значения в диапазоне и попарно различны
        int ioC[48], nIo = 0;
        for (int o = 0x08; o <= 0x98 && nIo < 48; o += 4) {
            if (o + 8 > ho && o < ho + 8) continue;
            bool good = true;
            for (int a = 0; a < ng && good; ++a) {
                const int v = I32(nb[grp[a]] + o);
                if (v < 0 || v >= kMaxNodes) { good = false; break; }
                for (int b2 = 0; b2 < a; ++b2) if (I32(nb[grp[b2]] + o) == v) { good = false; break; }
            }
            if (good) ioC[nIo++] = o;
        }
        for (int i = 0; i < nIo; ++i) if (ioC[i] == ho + 8) { const int t = ioC[0]; ioC[0] = ioC[i]; ioC[i] = t; break; }

        // кандидаты указателей на массивы в заголовке иерархии
        int poC[24], nPo = 0;
        for (int o = 0x08; o <= 0xA8 && nPo < 24; o += 8) {
            const uint64_t v = U64(hb + o);
            if (mem.isPtr(v) && v != H) poC[nPo++] = o;
        }
        R.nPtr += nPo;
        struct Pair { int lo, po; };
        Pair pairs[24 * 24];
        int np = 0;
        {
            bool hasL = false, hasP = false;
            for (int i = 0; i < nPo; ++i) { if (poC[i] == 0x18) hasL = true; if (poC[i] == 0x20) hasP = true; }
            if (hasL && hasP) pairs[np++] = { 0x18, 0x20 };
            for (int a = 0; a < nPo; ++a) for (int b2 = 0; b2 < nPo; ++b2) {
                if (a == b2) continue;
                if (hasL && hasP && poC[a] == 0x18 && poC[b2] == 0x20) continue;
                pairs[np++] = { poC[a], poC[b2] };
            }
        }

        for (int ii = 0; ii < nIo; ++ii) {
            const int io = ioC[ii];
            int idx[64];
            for (int a = 0; a < ng; ++a) idx[a] = I32(nb[grp[a]] + io);

            // шаги записи: из разности указателей на блоки узлов и типовые
            int strides[12], ns = 0;
            auto addStride = [&](int s) {
                if (s < 0x28 || s > kMaxStride || (s & 7)) return;
                for (int k = 0; k < ns; ++k) if (strides[k] == s) return;
                if (ns < 12) strides[ns++] = s;
            };
            for (int a = 0; a < ng; ++a) for (int b2 = 0; b2 < a; ++b2) {
                const int ka = grp[a], kb = grp[b2];
                if (mp[ka] == 0 || mp[kb] == 0 || idx[a] == idx[b2]) continue;
                const int64_t dp = (int64_t)(mp[ka] - mp[kb]), di = (int64_t)(idx[a] - idx[b2]);
                if (dp % di == 0) addStride((int)(dp / di));
            }
            addStride(0x30); addStride(0x40); addStride(0x28);
            R.strides = ns;
            TrsFmt fmts[12 * 16];
            int nf = 0;
            for (int k = 0; k < ns; ++k) nf += GenFormats(strides[k], fmts + nf, 12 * 16 - nf);

            for (int pi = 0; pi < np; ++pi) {
                const uint64_t L = U64(hb + pairs[pi].lo), P = U64(hb + pairs[pi].po);
                bool pOk = true;
                for (int a = 0; a < ng && pOk; ++a) {
                    int par;
                    if (!cm.rd(P + (uint64_t)idx[a] * 4, &par, 4) || par < -1 || par >= kMaxNodes * 2) pOk = false;
                }
                if (!pOk) continue;
                ++R.parentOk;
                for (int fi = 0; fi < nf; ++fi) {
                    ++R.tried;
                    V3 pos[64];
                    bool ok = true;
                    for (int a = 0; a < ng && ok; ++a) ok = ChainW(cm, L, P, fmts[fi], idx[a], &pos[a], nullptr);
                    if (!ok) continue;
                    ++R.worldOk;
                    bool truth = false;
                    int tg = 0, tgOk = 0;
                    for (int a = 0; a < ng; ++a) if (haveGt[grp[a]]) { ++tg; if (len(pos[a] - gt[grp[a]]) <= 0.30f) ++tgOk; }
                    if (tg >= 2 && useGt) {                                  // есть опорная истина: она решает
                        if (tgOk != tg) continue;
                        truth = true;
                    } else {                                                 // иначе — правдоподобие положения костей
                        float spread = 0.0f;
                        for (int a = 0; a < ng; ++a) for (int b2 = 0; b2 < a; ++b2) spread = fmaxf(spread, len(pos[a] - pos[b2]));
                        if (!(spread <= 3.5f)) continue;
                        if (!(hdist(pos[0], feet) <= 8.0f)) continue;
                        if (grp[0] == 0 && ng >= 2 && grp[1] == 1) {          // голова выше корпуса
                            const float dy = pos[0].y - pos[1].y;
                            if (!(dy >= 0.05f && dy <= 2.4f)) continue;
                        }
                    }
                    out.hierOff = ho; out.idxOff = io; out.localOff = pairs[pi].lo; out.parentOff = pairs[pi].po;
                    out.fmt = fmts[fi]; out.ok = true; out.truth = truth;
                    R.reads = cm.reads;
                    if (rep) *rep = R;
                    return true;
                }
            }
        }
    }
        return false;
    };
    if (nGt >= 2 && search(true)) return true;
    if (search(false)) return true;
    R.reads = cm.reads;
    if (rep) *rep = R;
    return false;
}

template <class M> bool ReadHeader(M &mem, const Layout &L, uint64_t internal, uint64_t &hier, int &idx) {
    uint8_t b[0x60];
    const int lo = L.hierOff < L.idxOff ? L.hierOff : L.idxOff;
    const int hi = (L.hierOff > L.idxOff ? L.hierOff : L.idxOff) + 8;
    if (hi - lo > (int)sizeof(b)) return false;
    if (!mem.rd(internal + (uint64_t)lo, b, (size_t)(hi - lo))) return false;
    memcpy(&hier, b + (L.hierOff - lo), 8);
    memcpy(&idx, b + (L.idxOff - lo), 4);
    return mem.isPtr(hier) && idx >= 0 && idx < kMaxNodes;
}

template <class M> bool ReadArrays(M &mem, const Layout &L, uint64_t hier, uint64_t &lb, uint64_t &pb) {
    return mem.rd(hier + (uint64_t)L.localOff, &lb, 8) && mem.rd(hier + (uint64_t)L.parentOff, &pb, 8) &&
           mem.isPtr(lb) && mem.isPtr(pb);
}

// Читает всю иерархию (редко), опознаёт кости, строит список узлов для покадрового чтения.
template <class M> bool Map(M &mem, const Layout &L, BoneState &b, float ref, V3 right) {
    b.mapped = false;
    uint64_t hier, lb, pb;
    int idx;
    if (!ReadHeader(mem, L, b.internal, hier, idx)) { b.why = "заголовок Transform не читается"; return false; }
    if (!ReadArrays(mem, L, hier, lb, pb)) { b.why = "массивы иерархии не читаются"; return false; }
    const int MAXN = kMaxNodes;
    const int stride = L.fmt.stride;
    b.parent.assign(MAXN, -1);
    b.loc.assign(MAXN, TRS());
    b.have.assign(MAXN, 0);
    b.wp.assign(MAXN, V3());
    std::vector<uint8_t> lbuf((size_t)64 * (size_t)stride);
    std::vector<int> pbuf(64);
    int N = 0;
    for (int base = 0; base < MAXN; base += 64) {
        int got = 0;
        if (mem.rd(lb + (uint64_t)base * (uint64_t)stride, lbuf.data(), lbuf.size()) &&
            mem.rd(pb + (uint64_t)base * 4, pbuf.data(), 64 * 4)) got = 64;
        else {                                         // конец массива внутри чанка: читаем по 8 узлов
            for (int s = 0; s < 64; s += 8) {
                if (!mem.rd(lb + (uint64_t)(base + s) * (uint64_t)stride, lbuf.data() + (size_t)s * stride, (size_t)8 * (size_t)stride) ||
                    !mem.rd(pb + (uint64_t)(base + s) * 4, pbuf.data() + s, 8 * 4)) break;
                got = s + 8;
            }
        }
        int valid = 0;
        for (int k = 0; k < got; ++k) {
            TRS t;
            if (ParseTRS(lbuf.data() + (size_t)k * stride, L.fmt, t) && pbuf[k] >= -1 && pbuf[k] < MAXN) {
                b.loc[base + k] = t; b.parent[base + k] = pbuf[k]; b.have[base + k] = 1; ++valid;
            }
        }
        N = base + got;
        if (got < 64 || (valid * 4 < got && base > idx)) break;       // хвост массива: мусор и нули
    }
    if (idx >= N || !b.have[idx]) { b.why = "узел головы вне иерархии"; return false; }
    b.N = N;

    Hier h; h.N = N; h.parent = b.parent.data(); h.loc = b.loc.data(); h.have = b.have.data();
    std::vector<uint8_t> okW(N, 0);
    for (int i = 0; i < N; ++i) { V3 p; if (b.have[i] && WorldPR(h, i, &p, nullptr)) { b.wp[i] = p; okW[i] = 1; } }
    const V3 hp = b.wp[idx];
    for (int i = 0; i < N; ++i) if (okW[i] && len(b.wp[i] - hp) > 4.0f) okW[i] = 0;    // остатки памяти вдали от модели

    RigIn in;
    in.N = N; in.parent = b.parent.data(); in.wpos = b.wp.data(); in.valid = okW.data();
    in.head = idx; in.ref = ref; in.right = right;
    RigMap m;
    if (!IdentifyRig(in, m)) { b.why = "кости гуманоида не опознаны"; return false; }

    // узлы для покадрового чтения: суставы, мелкие кости и все их предки
    std::vector<uint8_t> mark(N, 0);
    b.needN = 0;
    auto addChain = [&](int node) {
        int cur = node, g = 0;
        while (cur >= 0 && cur < N && !mark[cur] && g++ < 96) {
            mark[cur] = 1;
            if (b.needN >= kMaxNeed) return false;
            b.need[b.needN] = cur;
            b.addr[b.needN] = lb + (uint64_t)cur * (uint64_t)stride;
            b.len0[b.needN] = len(b.loc[cur].pos);
            ++b.needN;
            cur = b.parent[cur];
        }
        return true;
    };
    for (int k = 0; k < J_COUNT; ++k) if (m.j[k] >= 0 && !addChain(m.j[k])) { b.why = "слишком много узлов"; return false; }
    for (int k = 0; k < m.nf; ++k) {
        if (!addChain(m.fineN[k]) || !addChain(m.fineP[k])) { b.why = "слишком много узлов"; return false; }
    }
    b.map = m;
    b.hier = hier; b.localBase = lb; b.parentBase = pb; b.headIdx = idx;
    b.mapped = true;
    b.why = "";
    return true;
}

// Покадровое чтение: узлы из списка одним вызовом, мировые позиции, поза.
template <class M> bool ReadPose(M &mem, const Layout &L, BoneState &b, V3 feet, float ref, V3 right, V3 fwd,
                                 AxisCalib &ax, Pose &out) {
    if (!b.mapped) return false;
    uint64_t hier, lb, pb;
    int idx;
    if (!ReadHeader(mem, L, b.internal, hier, idx) || hier != b.hier || idx != b.headIdx) { b.mapped = false; b.why = "иерархия сменилась"; return false; }
    if (!ReadArrays(mem, L, hier, lb, pb) || lb != b.localBase || pb != b.parentBase) { b.mapped = false; b.why = "массивы переехали"; return false; }
    const int stride = L.fmt.stride;
    const size_t rec = stride < 64 ? (size_t)stride : 64u;                 // из каждой записи нужен только локальный TRS
    b.buf.resize((size_t)b.needN * rec);
    if (!mem.rdMulti(b.addr, b.needN, rec, b.buf.data())) { b.mapped = false; b.why = "узлы не читаются"; return false; }
    // Длины костей неизменны (аниматор крутит кости, а не растягивает): расхождение у нескольких костей значит,
    // что узлы в иерархии сдвинулись (взяли оружие, сменили модель) и карта устарела.
    int checked = 0, moved = 0;
    for (int i = 0; i < b.needN; ++i) {
        TRS t;
        if (!ParseTRS(b.buf.data() + (size_t)i * rec, L.fmt, t)) { b.mapped = false; b.why = "запись узла испорчена"; return false; }
        const float l0 = b.len0[i];
        if (l0 > 0.005f && l0 < 0.8f) { ++checked; if (fabsf(len(t.pos) - l0) > 0.15f * l0 + 0.01f) ++moved; }
        b.loc[b.need[i]] = t;
        b.have[b.need[i]] = 1;
    }
    if (moved >= 3 && moved * 5 >= checked) { b.mapped = false; b.why = "кости сместились в иерархии"; return false; }
    Hier h; h.N = b.N; h.parent = b.parent.data(); h.loc = b.loc.data(); h.have = b.have.data();
    auto world = [&](int n) {
        if (n < 0) return true;
        V3 p;
        if (!WorldPR(h, n, &p, nullptr)) return false;
        b.wp[n] = p;
        return true;
    };
    for (int k = 0; k < J_COUNT; ++k) if (!world(b.map.j[k])) { b.mapped = false; b.why = "цепочка до корня разорвана"; return false; }
    for (int k = 0; k < b.map.nf; ++k) if (!world(b.map.fineN[k]) || !world(b.map.fineP[k])) { b.mapped = false; b.why = "цепочка до корня разорвана"; return false; }
    Q4 hq;
    if (!WorldPR(h, b.headIdx, nullptr, &hq)) { b.mapped = false; b.why = "голова"; return false; }
    if (!BuildPose(b.map, b.wp.data(), b.have.data(), feet, ref, right, fwd, out)) { b.mapped = false; b.why = "поза не собрана"; return false; }
    if (!PoseSane(out, ref)) { b.mapped = false; b.why = "длины костей неправдоподобны"; return false; }
    ax.Feed(hq, fwd);
    out.face = ax.Face(hq, fwd);
    return true;
}

} // namespace oxbone
