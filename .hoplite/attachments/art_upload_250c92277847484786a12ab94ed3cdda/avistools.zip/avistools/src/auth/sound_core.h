#pragma once
// Звуки клавиатуры экрана ключа: синтез и микшер (без Android, проверяются на хосте: tools/test_sound.cpp).
// Звуки не лежат файлами, а считаются при запуске (≈60 КБ int16): нет ассетов, нет декодеров, нет задержки на чтении.
#include <math.h>
#include <stdint.h>
#include <atomic>
#include <vector>

namespace avsnd {

constexpr int kRate = 48000;

// Номера звуков в банке. Нажатие клавиши — 8 вариантов высоты: подряд набранные символы звучат как «перебор» нот.
enum Idx { KEY0 = 0, KEY_COUNT = 8, BACK = 8, CLEAR, PASTE, ENTER, SUCCESS, ERROR_, TOGGLE, COUNT };

namespace detail {
inline float Rnd(uint32_t &s) { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return (s & 0xFFFFFF) / 8388607.5f - 1.0f; }
inline float Smooth(float x) { x = x < 0 ? 0 : x > 1 ? 1 : x; return x * x * (3 - 2 * x); }

// Одна «нота»: синус с гармониками и экспоненциальным затуханием; частота плавно ползёт от f0 к f1.
struct Note { float t0, f0, f1, glide, decay, amp, h2, h3, attack; };

inline void AddNote(std::vector<float> &buf, const Note &n) {
    const size_t start = (size_t)(n.t0 * kRate);
    double phase = 0;
    for (size_t i = start; i < buf.size(); ++i) {
        const float t = (float)(i - start) / kRate;
        const float f = n.f1 + (n.f0 - n.f1) * expf(-t / n.glide);
        phase += 2.0 * M_PI * f / kRate;
        const float env = (t < n.attack ? t / n.attack : 1.0f) * expf(-t / n.decay);
        if (env < 1e-4f && t > n.attack) break;
        const float s = sinf((float)phase) + n.h2 * sinf(2 * (float)phase) + n.h3 * sinf(3 * (float)phase);
        buf[i] += n.amp * env * s;
    }
}

inline void AddTick(std::vector<float> &buf, float t0, float len, float amp, uint32_t seed) {   // короткий щелчок-«атака»
    uint32_t s = seed;
    const size_t a = (size_t)(t0 * kRate), n = (size_t)(len * kRate);
    float lp = 0;
    for (size_t i = 0; i < n && a + i < buf.size(); ++i) {
        lp += 0.55f * (Rnd(s) - lp);
        const float ramp = i < 12 ? (float)i / 12.0f : 1.0f;            // короткое нарастание: звук начинается с нуля, без «пощёлкивания» динамика
        buf[a + i] += amp * lp * ramp * (1.0f - (float)i / n);
    }
}

inline std::vector<int16_t> Finish(std::vector<float> &buf, float peak) {
    float m = 1e-6f;
    for (float v : buf) m = fmaxf(m, fabsf(v));
    const size_t fade = (size_t)(0.012f * kRate);                 // плавный хвост: без щелчка в конце
    std::vector<int16_t> out(buf.size());
    for (size_t i = 0; i < buf.size(); ++i) {
        float g = buf.size() - i < fade ? Smooth((float)(buf.size() - i) / fade) : 1.0f;
        out[i] = (int16_t)lrintf(buf[i] / m * peak * g * 32767.0f);
    }
    return out;
}
}  // namespace detail

// Звук номер idx (см. Idx).
inline std::vector<int16_t> Synth(int idx) {
    using namespace detail;
    auto make = [](float sec) { return std::vector<float>((size_t)(sec * kRate), 0.0f); };
    if (idx >= KEY0 && idx < KEY0 + KEY_COUNT) {          // «капля»: короткий взлёт по высоте + щелчок
        const float semis = ((float)(idx - KEY0) - 3.5f) * 0.85f;
        const float r = powf(2.0f, semis / 12.0f);
        std::vector<float> b = make(0.12f);
        AddNote(b, {0.0f, 1020.0f * r, 520.0f * r, 0.007f, 0.022f, 1.0f, 0.28f, 0.06f, 0.0012f});
        AddTick(b, 0.0f, 0.0018f, 0.20f, 0x9E3779B9u + (uint32_t)idx * 7919u);
        return Finish(b, 0.60f);
    }
    switch (idx) {
        case BACK: {                                       // мягкий глухой «тук» вниз
            std::vector<float> b = make(0.15f);
            AddNote(b, {0.0f, 230.0f, 400.0f, 0.020f, 0.030f, 1.0f, 0.20f, 0.0f, 0.0015f});
            AddTick(b, 0.0f, 0.0015f, 0.12f, 0xA5A5A5A5u);
            return Finish(b, 0.62f);
        }
        case CLEAR: {                                      // «вжух»: тон ползёт вниз
            std::vector<float> b = make(0.26f);
            AddNote(b, {0.0f, 260.0f, 1150.0f, 0.075f, 0.075f, 1.0f, 0.35f, 0.10f, 0.004f});
            AddTick(b, 0.0f, 0.004f, 0.14f, 0x1234567u);
            return Finish(b, 0.55f);
        }
        case PASTE: {                                      // две «капли» вверх
            std::vector<float> b = make(0.24f);
            AddNote(b, {0.00f, 1300.0f, 700.0f, 0.007f, 0.030f, 1.0f, 0.25f, 0.05f, 0.0012f});
            AddNote(b, {0.075f, 1900.0f, 1000.0f, 0.007f, 0.040f, 1.0f, 0.25f, 0.05f, 0.0012f});
            return Finish(b, 0.60f);
        }
        case ENTER: {                                      // короткий «динь»: до-ми-соль
            std::vector<float> b = make(0.55f);
            AddNote(b, {0.00f, 1046.5f, 1046.5f, 1.0f, 0.110f, 0.80f, 0.18f, 0.0f, 0.002f});
            AddNote(b, {0.06f, 1318.5f, 1318.5f, 1.0f, 0.120f, 0.80f, 0.16f, 0.0f, 0.002f});
            AddNote(b, {0.12f, 1568.0f, 1568.0f, 1.0f, 0.150f, 0.90f, 0.14f, 0.0f, 0.002f});
            return Finish(b, 0.60f);
        }
        case SUCCESS: {                                    // восходящее арпеджио
            std::vector<float> b = make(1.0f);
            const float f[4] = {523.25f, 659.25f, 783.99f, 1046.5f};
            for (int i = 0; i < 4; ++i)
                AddNote(b, {0.095f * i, f[i], f[i], 1.0f, i == 3 ? 0.30f : 0.14f, 0.9f, 0.20f, 0.08f, 0.003f});
            return Finish(b, 0.62f);
        }
        case ERROR_: {                                     // два низких «бз-бз»
            std::vector<float> b = make(0.34f);
            for (int i = 0; i < 2; ++i)
                AddNote(b, {0.13f * i, 190.0f, 175.0f, 0.05f, 0.045f, 1.0f, 0.55f, 0.35f, 0.003f});
            return Finish(b, 0.55f);
        }
        default: {                                         // TOGGLE: тихий «тик»
            std::vector<float> b = make(0.07f);
            AddNote(b, {0.0f, 880.0f, 880.0f, 1.0f, 0.012f, 1.0f, 0.15f, 0.0f, 0.001f});
            AddTick(b, 0.0f, 0.0012f, 0.10f, 0xC0FFEEu);
            return Finish(b, 0.45f);
        }
    }
}

struct Bank {
    std::vector<std::vector<int16_t>> s;
    Bank() { for (int i = 0; i < COUNT; ++i) s.push_back(Synth(i)); }
};

// Микшер: до 8 одновременных звуков. Post() зовёт поток интерфейса, Mix() — аудиопоток; общение через кольцо без блокировок.
class Mixer {
public:
    explicit Mixer(const Bank &bank) : bank_(bank) {}

    void Post(int idx, float gain) {
        const uint32_t h = head_.load(std::memory_order_relaxed);
        if (h - tail_.load(std::memory_order_acquire) >= kRing) return;          // кольцо забито — пропускаем звук, не блокируем
        ring_[h % kRing] = {idx, gain};
        head_.store(h + 1, std::memory_order_release);
    }

    void Mix(int16_t *out, int frames) {
        const uint32_t h = head_.load(std::memory_order_acquire);
        for (uint32_t t = tail_.load(std::memory_order_relaxed); t != h; ++t) {
            const Cmd c = ring_[t % kRing];
            if (c.idx < 0 || c.idx >= COUNT) continue;
            int slot = -1, oldest = 0, oldestPos = -1;
            for (int v = 0; v < kVoices; ++v) {
                if (!voices_[v].d) { slot = v; break; }
                if (voices_[v].pos > oldestPos) { oldestPos = voices_[v].pos; oldest = v; }
            }
            if (slot < 0) slot = oldest;                                            // все заняты — вытесняем самый старый
            voices_[slot] = {bank_.s[c.idx].data(), (int)bank_.s[c.idx].size(), 0, c.gain};
        }
        tail_.store(h, std::memory_order_release);

        for (int i = 0; i < frames; ++i) {
            float acc = 0;
            for (Voice &v : voices_) {
                if (!v.d) continue;
                acc += v.d[v.pos] * v.gain;
                if (++v.pos >= v.n) v.d = nullptr;
            }
            acc = acc > 32767.0f ? 32767.0f : acc < -32767.0f ? -32767.0f : acc;   // симметрично: ±32767
            out[i] = (int16_t)acc;
        }
    }

    bool Idle() const {
        for (const Voice &v : voices_) if (v.d) return false;
        return head_.load() == tail_.load();
    }

private:
    static constexpr int kVoices = 8;
    static constexpr uint32_t kRing = 32;
    struct Cmd { int idx; float gain; };
    struct Voice { const int16_t *d = nullptr; int n = 0, pos = 0; float gain = 0; };
    const Bank &bank_;
    Cmd ring_[kRing] = {};
    std::atomic<uint32_t> head_{0}, tail_{0};
    Voice voices_[kVoices];
};

}  // namespace avsnd
