#pragma once
// Протокол клиент-сервер и вспомогательные функции (без сети и без UI, проверяются на хосте).
#include <stdint.h>
#include <string>
#include <vector>

namespace avis {

// Временный локальный ключ. Храним и показываем в одном каноническом виде.
constexpr char kLocalKey[] = "t.me/AvisTools";
bool IsLocalKey(const std::string &raw);

struct Reply {
    std::string kind, status, nonce, a, b;
    int64_t serverTime = 0;
};

// Разбирает ответ сервера: строка payload + строка подписи. Проверяет подпись вшитым публичным ключом,
// тип ответа и nonce (защита от повтора). Для kind=="verify" дополнительно сверяет эхо hwid.
bool ParseReply(const std::string &text, const char *kind, const std::string &nonce, const std::string &hwidEcho,
                Reply &out, std::string &err);

// Версия с явным публичным ключом (для тестов).
bool ParseReplyWithKey(const std::string &pem, const std::string &text, const char *kind, const std::string &nonce,
                       const std::string &hwidEcho, Reply &out, std::string &err);

std::string RandomHex(int bytes);
std::string Sha256Hex(const std::string &data);

// Любой ввод/буфер обмена -> "AVIS-XXXX-XXXX-XXXX" или kLocalKey; иначе "".
std::string NormalizeKey(const std::string &raw);
// Ищет ключ внутри произвольного текста («Твой ключ: AVIS-7KQ2-M9XP-LR4T»); пробелы, дефисы и регистр не важны.
// Если в тексте только 12 символов алфавита ключа — это тоже ключ (без префикса AVIS). Иначе "".
std::string FindKeyInText(const std::string &text);

// Вывод `service call clipboard ...` (дамп Parcel) -> байты.
std::vector<unsigned char> ParcelBytes(const std::string &dump);
// 1 — вернулся клип, 0 — клипа нет (буфер пуст), -1 — исключение (нет доступа/не та сигнатура) или вывод не разобран.
int ParcelStatus(const std::vector<unsigned char> &bytes);

// Вывод хелпера avis.Clip: "OK <base64>" / "EMPTY" / "ERR <причина>". text — текст из буфера либо причина ошибки.
enum class HelperStatus { Ok, Empty, Error };
HelperStatus ParseHelperOutput(const std::string &out, std::string &text);

// Только 12 значащих символов ключа (без AVIS и дефисов) из того, что набрано сейчас.
bool IsKeyChar(char c);

}  // namespace avis
