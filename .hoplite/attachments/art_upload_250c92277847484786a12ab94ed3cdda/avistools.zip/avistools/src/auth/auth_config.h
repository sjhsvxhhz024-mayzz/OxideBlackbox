#pragma once
// Настройки системы ключей Avis tools.
//
// Публичный ключ проверки подписи ответов сервера. Парный приватный лежит ТОЛЬКО на сервере (server/signing_key.pem).
// Сменить пару: `python gen_keys.py --force` на сервере и подставить новую публичную часть сюда.
#define AVIS_PUBLIC_KEY_PEM \
    "-----BEGIN PUBLIC KEY-----\n" \
    "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEWQdXiNx2COzT5AkFTCbglq/V0zAH\n" \
    "ZmrMCaZm4xiv6cSbfwfiIZSTF58Ca798+Oqymb7MfTSPQJkRTR8rPaZAAA==\n" \
    "-----END PUBLIC KEY-----\n"

// Адрес сервера ключей. Задаётся при сборке (AVIS_API_URL=https://host ./build.sh) либо файлом server.txt
// в папке данных (одна строка). Подмена адреса безопасна: без приватного ключа сервер ответ не подпишет.
#ifndef AVIS_API_URL
#define AVIS_API_URL "https://avistools-keys.kseniaferty03.workers.dev"
#endif

#define AVIS_DATA_DIR "/sdcard/Download/AvisTools"
#define AVIS_CHANNEL_DEFAULT "AvisTools"   // запасное имя канала, пока сервер не ответил
#define AVIS_BRAND "Avis tools"

namespace avis {
constexpr int kConnectTimeoutMs = 1500;  // квант на адрес: IPv6 не блокирует IPv4
constexpr int kRequestTimeoutMs = 5000;  // бюджет connect/TLS/HTTP; DNS выполняет ОС
constexpr int kIoTimeoutMs      = kRequestTimeoutMs;
constexpr int kReverifySec      = 600;   // как часто сверяться с сервером, пока ключ активен
constexpr int kRetryInfoSec     = 5;
constexpr int kVerifyRetryMs    = 5000;  // минимальный интервал между началами попыток
}
