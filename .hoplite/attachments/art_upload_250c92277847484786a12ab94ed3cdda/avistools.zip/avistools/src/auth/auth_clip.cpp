#include "auth_clip.h"
#include "auth_proto.h"

#include <errno.h>
#include <stdarg.h>
#include <fcntl.h>
#include <grp.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#if defined(__ANDROID__)
#include <sys/system_properties.h>
#endif

extern char **environ;
extern "C" const unsigned char trial_clipjar_start[], trial_clipjar_end[];   // assets/trial/avis_clip.jar (trial_assets.S)

namespace avis {
namespace {

int64_t NowMs() {
    timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

constexpr int kShellUid = 2000;
// Группы, в которых состоит `adb shell`: доступ к /sdcard, log, inet и т.д. (без них shell-процесс был бы «беднее» настоящего).
const gid_t kShellGroups[] = {2000, 1004, 1007, 1011, 1015, 1028, 3001, 3002, 3003, 3006, 3009};

int SdkLevel() {
#if defined(__ANDROID__)
    char v[PROP_VALUE_MAX] = {0};
    __system_property_get("ro.build.version.sdk", v);
    return atoi(v);
#else
    return 0;
#endif
}

std::string FirstLine(const std::string &s, size_t max = 160) {
    size_t e = s.find('\n');
    std::string l = s.substr(0, e == std::string::npos ? std::string::npos : e);
    if (l.size() > max) l.resize(max);
    return l;
}

// Журнал попыток. Содержимое буфера сюда не попадает — только статусы и тексты ошибок системы.
struct Log {
    std::string text;
    void add(const char *fmt, ...) __attribute__((format(printf, 2, 3))) {
        char b[512];
        va_list ap;
        va_start(ap, fmt);
        vsnprintf(b, sizeof(b), fmt, ap);
        va_end(ap);
        text += b;
        text += '\n';
    }
};

bool FileHasSize(const std::string &path, size_t size) {
    struct stat st;
    return stat(path.c_str(), &st) == 0 && (size_t)st.st_size == size;
}

bool WriteFileMode(const std::string &path, const unsigned char *data, size_t n, mode_t mode) {
    const std::string tmp = path + ".tmp";
    FILE *f = fopen(tmp.c_str(), "wb");
    if (!f) return false;
    bool ok = fwrite(data, 1, n, f) == n;
    ok = fclose(f) == 0 && ok;
    if (!ok || chmod(tmp.c_str(), mode) != 0 || rename(tmp.c_str(), path.c_str()) != 0) { remove(tmp.c_str()); return false; }
    return true;
}

// Кладёт хелпер туда, откуда его прочитает и shell (uid 2000). Возвращает путь или "".
std::string InstallHelper(const std::string &dataDir, Log &log) {
    const size_t n = (size_t)(trial_clipjar_end - trial_clipjar_start);
    for (const std::string &dir : {std::string("/data/local/tmp"), dataDir}) {
        const std::string path = dir + "/avis_clip.jar";
        if (FileHasSize(path, n) || WriteFileMode(path, trial_clipjar_start, n, 0444)) return path;
    }
    log.add("helper: не удалось записать avis_clip.jar (нет прав на /data/local/tmp и в папке данных)");
    return "";
}

}  // namespace

RunResult RunProcess(const std::vector<std::string> &argv, const std::vector<std::string> &extraEnv, int uid, int timeoutMs) {
    RunResult r;
    if (argv.empty()) return r;
    // Всё, что нужно ребёнку, готовим до fork: после него в многопоточном процессе безопасны только простые вызовы.
    std::vector<char *> av, ev;
    for (const std::string &a : argv) av.push_back(const_cast<char *>(a.c_str()));
    av.push_back(nullptr);
    std::vector<std::string> env;
    for (char **e = environ; e && *e; ++e) {
        bool replaced = false;
        for (const std::string &x : extraEnv) {
            const size_t eq = x.find('=');
            if (eq != std::string::npos && strncmp(*e, x.c_str(), eq + 1) == 0) replaced = true;
        }
        if (!replaced) env.push_back(*e);
    }
    for (const std::string &x : extraEnv) env.push_back(x);
    for (const std::string &e : env) ev.push_back(const_cast<char *>(e.c_str()));
    ev.push_back(nullptr);

    int pfd[2];
    if (pipe2(pfd, O_CLOEXEC) != 0) return r;
    const pid_t pid = fork();
    if (pid < 0) { close(pfd[0]); close(pfd[1]); return r; }
    if (pid == 0) {
        const int nul = open("/dev/null", O_RDONLY);
        if (nul >= 0) dup2(nul, 0);
        dup2(pfd[1], 1);
        dup2(pfd[1], 2);
        if (uid >= 0) {
            if (uid == kShellUid) setgroups(sizeof(kShellGroups) / sizeof(kShellGroups[0]), kShellGroups);
            else setgroups(0, nullptr);
            if (setgid((gid_t)uid) != 0 || setuid((uid_t)uid) != 0) _exit(126);
        }
        execve(av[0], av.data(), ev.data());
        _exit(127);
    }
    close(pfd[1]);
    r.started = true;
    const int64_t deadline = NowMs() + timeoutMs;
    char buf[2048];
    for (;;) {
        const int64_t left = deadline - NowMs();
        if (left <= 0) { r.timedOut = true; break; }
        pollfd p = {pfd[0], POLLIN, 0};
        const int pr = poll(&p, 1, (int)left);
        if (pr < 0 && errno == EINTR) continue;
        if (pr <= 0) { r.timedOut = pr == 0; break; }
        const ssize_t n = read(pfd[0], buf, sizeof(buf));
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) break;                              // конец вывода
        if (r.output.size() < 16384) r.output.append(buf, (size_t)n);
    }
    close(pfd[0]);
    if (r.timedOut) kill(pid, SIGKILL);
    int st = 0;
    while (waitpid(pid, &st, 0) < 0 && errno == EINTR) {}
    if (WIFEXITED(st)) r.exitCode = WEXITSTATUS(st);
    return r;
}

namespace {

struct Attempt {
    ClipKind kind = ClipKind::NoAccess;
    std::string key;
    bool done = false;     // получили определённый ответ (ключ или «в буфере нет ключа») — дальше не пробуем
};

const char *IdName(int uid) { return uid == kShellUid ? "shell" : "root"; }

Attempt TryHelper(const std::string &jar, int uid, Log &log) {
    Attempt a;
    RunResult r = RunProcess({"/system/bin/app_process", "/", "avis.Clip"}, {"CLASSPATH=" + jar}, uid, 9000);
    if (!r.started) { log.add("helper(%s): процесс не запустился", IdName(uid)); return a; }
    if (r.timedOut) { log.add("helper(%s): таймаут", IdName(uid)); return a; }
    std::string text;
    switch (ParseHelperOutput(r.output, text)) {
        case HelperStatus::Ok: {
            a.key = FindKeyInText(text);
            a.kind = a.key.empty() ? ClipKind::NoKey : ClipKind::Found;
            a.done = true;
            log.add("helper(%s): буфер прочитан (%zu байт), ключ %s", IdName(uid), text.size(), a.key.empty() ? "не найден" : "найден");
            break;
        }
        case HelperStatus::Empty:
            a.kind = ClipKind::NoKey;
            a.done = true;
            log.add("helper(%s): буфер пуст", IdName(uid));
            break;
        case HelperStatus::Error:
            log.add("helper(%s): ошибка: %s (код выхода %d)", IdName(uid), FirstLine(text).c_str(), r.exitCode);
            break;
    }
    return a;
}

// service call: код транзакции и аргументы зависят от версии Android.
//   API <= 27: getPrimaryClip = 2 (pkg, userId)       API 28-30: 3 (pkg, userId)
//   API 31-34: 3 (pkg, attributionTag, userId)         API 35+:   3 (pkg, attributionTag, userId, deviceId)
Attempt TryServiceCall(int uid, int sdk, Log &log) {
    Attempt a;
    struct V { const char *name; std::vector<std::string> args; };
    const std::string pkg = "com.android.shell";
    std::vector<V> vs;
    if (sdk > 0 && sdk <= 27) vs.push_back({"2/pkg,user", {"2", "s16", pkg, "i32", "0"}});
    if (sdk <= 0 || sdk <= 30) vs.push_back({"3/pkg,user", {"3", "s16", pkg, "i32", "0"}});
    if (sdk <= 0 || sdk >= 31) vs.push_back({"3/pkg,tag,user", {"3", "s16", pkg, "s16", "", "i32", "0"}});
    if (sdk <= 0 || sdk >= 34) vs.push_back({"3/pkg,tag,user,dev", {"3", "s16", pkg, "s16", "", "i32", "0", "i32", "0"}});
    for (const V &v : vs) {
        std::vector<std::string> argv = {"/system/bin/service", "call", "clipboard"};
        argv.insert(argv.end(), v.args.begin(), v.args.end());
        RunResult r = RunProcess(argv, {}, uid, 4000);
        if (!r.started || r.timedOut) { log.add("service(%s,%s): %s", IdName(uid), v.name, r.started ? "таймаут" : "не запустился"); continue; }
        const std::vector<unsigned char> bytes = ParcelBytes(r.output);
        const int st = ParcelStatus(bytes);
        if (st < 0) { log.add("service(%s,%s): исключение/не разобрано (%zu байт)", IdName(uid), v.name, bytes.size()); continue; }
        a.done = true;
        if (st == 0) { a.kind = ClipKind::NoKey; log.add("service(%s,%s): буфер пуст", IdName(uid), v.name); return a; }
        // Ключ ищем в тексте клипа; сначала целиком, как есть.
        std::string k;
        std::string u16, u8;
        for (size_t i = 0; i + 1 < bytes.size(); ++i) {
            const bool pr = bytes[i] >= 32 && bytes[i] < 127;
            if (pr) u8 += (char)bytes[i];
            if (pr && bytes[i + 1] == 0) u16 += (char)bytes[i];
        }
        k = FindKeyInText(u16);
        if (k.empty()) k = FindKeyInText(u8);
        a.key = k;
        a.kind = k.empty() ? ClipKind::NoKey : ClipKind::Found;
        log.add("service(%s,%s): клип получен, ключ %s", IdName(uid), v.name, k.empty() ? "не найден" : "найден");
        return a;
    }
    return a;
}

}  // namespace

ClipResult ReadClipboard(const std::string &dataDir) {
    Log log;
    const int sdk = SdkLevel();
    log.add("sdk=%d uid=%d", sdk, (int)getuid());
    ClipResult out;
    bool answered = false;

#if defined(__ANDROID__)
    const std::string jar = InstallHelper(dataDir, log);
    std::vector<std::pair<std::string, int>> steps;      // (метод, uid)
    if (!jar.empty()) { steps.push_back({"helper", kShellUid}); steps.push_back({"helper", 0}); }
    steps.push_back({"service", kShellUid});
    steps.push_back({"service", 0});
    for (const auto &st : steps) {
        Attempt a = st.first == "helper" ? TryHelper(jar, st.second, log) : TryServiceCall(st.second, sdk, log);
        if (!a.done) continue;                      // система отказала или ответ не разобран — следующий способ
        out.kind = a.kind;                          // определённый ответ: ключ найден либо в буфере его нет
        out.key = a.key;
        answered = true;
        break;
    }
    if (!answered) out.kind = ClipKind::NoAccess;
#else
    (void)dataDir;
    log.add("не Android: буфер обмена недоступен");
#endif
    log.add("итог: %s", out.kind == ClipKind::Found ? "ключ найден" : out.kind == ClipKind::NoKey ? "в буфере нет ключа" : "буфер недоступен");
    if (!dataDir.empty()) {
        FILE *f = fopen((dataDir + "/paste_debug.txt").c_str(), "wb");
        if (f) { fwrite(log.text.data(), 1, log.text.size(), f); fclose(f); }
    }
    return out;
}

}  // namespace avis
