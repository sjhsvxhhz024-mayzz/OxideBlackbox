#pragma once
// Клиент системы ключей: фоновый поток, состояние для UI. Всё сетевое — вне потока отрисовки.
#include <stdint.h>
#include <string>

namespace avis {

enum class Phase { NeedKey, Checking, Active };

// Что показать пользователю после последней попытки.
enum class Msg {
    None, BadFormat, Invalid, Expired, Revoked, Banned, Hwid, Unsub, Network, BadServer, NoServer,
};

struct Snapshot {
    Phase phase = Phase::NeedKey;
    Msg msg = Msg::None;
    bool infoReady = false;     // получили подписанный ответ /info (сервер жив и подлинный)
    bool infoFailed = false;    // последняя попытка достучаться до сервера не удалась
    bool serverSet = false;     // адрес сервера задан
    std::string bot, channel;
    std::string savedKey;       // ключ из прошлого запуска (для подстановки в поле)
    int64_t remainingSec = 0;   // сколько ещё действует активный ключ
    bool autoLogin = false;     // идёт автоматический вход по сохранённому ключу
    bool localKey = false;      // временный локальный ключ: без срока и сетевой перепроверки
    bool retrying = false;      // временный сбой: проверка продолжается автоматически
    int retryInSec = 0;         // до следующей попытки (0 — запрос выполняется)
    unsigned verifyAttempts = 0;
};

void Init(const char *dataDir);          // один раз при старте; запускает фоновый поток
void Shutdown();
Snapshot Get();
bool Active();                           // дёшево, можно звать каждый кадр
int64_t RemainingSec();                  // дёшево: сколько ещё действует ключ (0, если не активен)
void Submit(const std::string &rawKey);  // ввод пользователя (любой формат, нормализуется внутри)
void Logout();
void CancelCheck();                      // отменить ожидание; запоздалый ответ не активирует сессию
void RetryServer();                      // кнопка «повторить», если сервер не ответил

// Вставка из буфера обмена — асинхронно (внешний процесс на Android, до нескольких секунд).
struct PasteResult {
    enum Kind { Found, NoKey, NoAccess } kind = NoAccess;   // ключ найден / буфер прочитан, но ключа нет / прочитать не удалось
    std::string key;
};
void RequestPaste();
bool PasteBusy();
// Забирает результат: true, если попытка завершилась.
bool TakePaste(PasteResult &out);

void OpenBot();       // открыть бота (или канал) в Telegram
void OpenChannel();

// Для тестов.
std::string ExtractKeyFromParcelDump(const std::string &dump);
std::string DeviceId();

}  // namespace avis
