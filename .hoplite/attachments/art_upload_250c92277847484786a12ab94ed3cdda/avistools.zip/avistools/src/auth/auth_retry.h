#pragma once
namespace avis {
// Only transport / temporary HTTP failures are retried. An unsigned HTTP error
// is never interpreted as a definitive key rejection.
inline bool RetryableHttpStatus(int status) {
    return status == 0 || status == 408 || status == 425 || status == 429 ||
           (status >= 500 && status <= 599);
}
}