#include "auth_net.h"
#include "auth_config.h"
#include "auth_http.h"

#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <poll.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include <mbedtls/ctr_drbg.h>
#include <mbedtls/entropy.h>
#include <mbedtls/net_sockets.h>
#include <mbedtls/ssl.h>
#include <psa/crypto.h>

namespace avis {

static int64_t NowMs() {
    timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

bool ParseUrl(const std::string &s, Url &o) {
    size_t p = s.find("://");
    if (p == std::string::npos) return false;
    std::string scheme = s.substr(0, p);
    if (scheme == "https") { o.https = true; o.port = 443; }
    else if (scheme == "http") { o.https = false; o.port = 80; }
    else return false;
    size_t hs = p + 3, he = s.find('/', hs);
    std::string hostport = s.substr(hs, he == std::string::npos ? std::string::npos : he - hs);
    o.path = he == std::string::npos ? "/" : s.substr(he);
    size_t colon = hostport.rfind(':');
    if (colon != std::string::npos && hostport.find(']') == std::string::npos) {
        o.port = atoi(hostport.c_str() + colon + 1);
        hostport.resize(colon);
    }
    o.host = hostport;
    return !o.host.empty() && o.port > 0 && o.port < 65536;
}

namespace {

struct Conn {
    int fd = -1;
    bool tls = false;
    mbedtls_net_context net;
    mbedtls_ssl_context ssl;
    mbedtls_ssl_config conf;
    mbedtls_entropy_context ent;
    mbedtls_ctr_drbg_context drbg;
    bool tlsInit = false;

    ~Conn() {
        if (tlsInit) {
            mbedtls_ssl_free(&ssl);
            mbedtls_ssl_config_free(&conf);
            mbedtls_ctr_drbg_free(&drbg);
            mbedtls_entropy_free(&ent);
        }
        if (fd >= 0) close(fd);
    }
};

bool WaitSocket(int fd, short events, int64_t deadline) {
    while (NowMs() < deadline) {
        pollfd p = {fd, events, 0};
        const int ms = (int)(deadline - NowMs());
        if (ms <= 0) return false;
        int r = poll(&p, 1, ms);
        if (r < 0 && errno == EINTR) continue;
        if (r <= 0 || (p.revents & (POLLERR | POLLNVAL))) return false;
        return (p.revents & (events | POLLHUP)) != 0;
    }
    return false;
}

bool Connect(const Url &u, Conn &c, int64_t deadline, std::string &err) {
    addrinfo hints;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    addrinfo *res = nullptr;
    char port[8];
    snprintf(port, sizeof(port), "%d", u.port);
    int gai = getaddrinfo(u.host.c_str(), port, &hints, &res);
    if (gai != 0 || !res) { err = "dns"; return false; }
    bool ok = false;
    for (addrinfo *a = res; a && !ok && NowMs() < deadline; a = a->ai_next) {
        int fd = socket(a->ai_family, a->ai_socktype, a->ai_protocol);
        if (fd < 0) continue;
        int fl = fcntl(fd, F_GETFL, 0);
        fcntl(fd, F_SETFL, fl | O_NONBLOCK);
        int r = connect(fd, a->ai_addr, a->ai_addrlen);
        if (r < 0 && errno == EINPROGRESS) {
            pollfd p = {fd, POLLOUT, 0};
            int left = (int)(deadline - NowMs());
            int wait = left < kConnectTimeoutMs ? left : kConnectTimeoutMs;
            if (wait > 0 && poll(&p, 1, wait) == 1) {
                int e = 0;
                socklen_t el = sizeof(e);
                getsockopt(fd, SOL_SOCKET, SO_ERROR, &e, &el);
                r = e == 0 ? 0 : -1;
            } else r = -1;
        }
        if (r == 0) {
            // Keep O_NONBLOCK. mbedtls_net_recv treats EAGAIN as WANT_READ
            // ONLY on a non-blocking descriptor; SO_RCVTIMEO on a blocking
            // socket previously became NET_RECV_FAILED after just one second.
            c.fd = fd;
            ok = true;
        } else close(fd);
    }
    freeaddrinfo(res);
    if (!ok) err = "connect";
    return ok;
}

bool StartTls(const Url &u, Conn &c, int64_t deadline, std::string &err) {
    static bool psaInit = (psa_crypto_init() == PSA_SUCCESS);
    (void)psaInit;
    mbedtls_ssl_init(&c.ssl);
    mbedtls_ssl_config_init(&c.conf);
    mbedtls_entropy_init(&c.ent);
    mbedtls_ctr_drbg_init(&c.drbg);
    c.tlsInit = true;
    if (mbedtls_ctr_drbg_seed(&c.drbg, mbedtls_entropy_func, &c.ent, nullptr, 0) != 0) { err = "rng"; return false; }
    if (mbedtls_ssl_config_defaults(&c.conf, MBEDTLS_SSL_IS_CLIENT, MBEDTLS_SSL_TRANSPORT_STREAM, MBEDTLS_SSL_PRESET_DEFAULT) != 0) { err = "tls cfg"; return false; }
    mbedtls_ssl_conf_authmode(&c.conf, MBEDTLS_SSL_VERIFY_NONE);   // см. комментарий в auth_net.h
    mbedtls_ssl_conf_rng(&c.conf, mbedtls_ctr_drbg_random, &c.drbg);
    if (mbedtls_ssl_setup(&c.ssl, &c.conf) != 0) { err = "tls setup"; return false; }
    mbedtls_ssl_set_hostname(&c.ssl, u.host.c_str());
    c.net.fd = c.fd;
    mbedtls_ssl_set_bio(&c.ssl, &c.net, mbedtls_net_send, mbedtls_net_recv, nullptr);
    int r;
    while ((r = mbedtls_ssl_handshake(&c.ssl)) != 0) {
        if ((r == MBEDTLS_ERR_SSL_WANT_READ || r == MBEDTLS_ERR_SSL_WANT_WRITE) &&
            WaitSocket(c.fd, r == MBEDTLS_ERR_SSL_WANT_READ ? POLLIN : POLLOUT, deadline)) continue;
        err = "tls handshake";
        return false;
    }
    c.tls = true;
    return true;
}

bool SendAll(Conn &c, const std::string &data, int64_t deadline) {
    size_t off = 0;
    while (off < data.size()) {
        if (NowMs() > deadline) return false;
        int n;
        if (c.tls) {
            n = mbedtls_ssl_write(&c.ssl, (const unsigned char *)data.data() + off, data.size() - off);
            if (n == MBEDTLS_ERR_SSL_WANT_READ || n == MBEDTLS_ERR_SSL_WANT_WRITE) {
                if (!WaitSocket(c.fd, n == MBEDTLS_ERR_SSL_WANT_READ ? POLLIN : POLLOUT, deadline)) return false;
                continue;
            }
        } else {
            n = (int)send(c.fd, data.data() + off, data.size() - off, MSG_NOSIGNAL);
            if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)) {
                if (!WaitSocket(c.fd, POLLOUT, deadline)) return false;
                continue;
            }
        }
        if (n <= 0) return false;
        off += (size_t)n;
    }
    return true;
}

// Читает всё до закрытия соединения (мы шлём Connection: close). Лимит — чтобы мусорный сервер не съел память.
bool ReadAll(Conn &c, std::string &out, int64_t deadline) {
    char buf[2048];
    auto atEof = [&] {
        const auto frame = InspectHttpFrame(out);
        return frame == HttpFrame::Complete || frame == HttpFrame::UntilClose;
    };
    for (;;) {
        if (NowMs() > deadline) return false;
        int n;
        if (c.tls) {
            n = mbedtls_ssl_read(&c.ssl, (unsigned char *)buf, sizeof(buf));
            if (n == MBEDTLS_ERR_SSL_WANT_READ || n == MBEDTLS_ERR_SSL_WANT_WRITE) {
                if (!WaitSocket(c.fd, n == MBEDTLS_ERR_SSL_WANT_READ ? POLLIN : POLLOUT, deadline)) return false;
                continue;
            }
            if (n == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY || n == 0) return atEof();
        } else {
            n = (int)recv(c.fd, buf, sizeof(buf), 0);
            if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)) {
                if (!WaitSocket(c.fd, POLLIN, deadline)) return false;
                continue;
            }
            if (n == 0) return atEof();
        }
        if (n < 0) return InspectHttpFrame(out) == HttpFrame::Complete;
        out.append(buf, (size_t)n);
        if (out.size() > 32768) return false;
        const auto frame = InspectHttpFrame(out);
        if (frame == HttpFrame::Complete) return true;
        if (frame == HttpFrame::Invalid) return false;
    }
}

std::string Lower(std::string s) {
    for (char &ch : s) if (ch >= 'A' && ch <= 'Z') ch = (char)(ch + 32);
    return s;
}

bool ParseHttp(const std::string &raw, HttpResponse &o, std::string &location) {
    size_t he = raw.find("\r\n\r\n");
    if (he == std::string::npos || raw.compare(0, 5, "HTTP/") != 0) return false;
    size_t sp = raw.find(' ');
    if (sp == std::string::npos) return false;
    o.status = atoi(raw.c_str() + sp + 1);
    std::string head = Lower(raw.substr(0, he));
    std::string body = raw.substr(he + 4);
    size_t lp = head.find("\r\nlocation:");
    if (lp != std::string::npos) {
        size_t s = lp + 11, e = head.find("\r\n", s);
        std::string v = raw.substr(s, e == std::string::npos ? std::string::npos : e - s);   // регистр значения важен
        size_t a = v.find_first_not_of(' ');
        location = a == std::string::npos ? "" : v.substr(a);
    }
    if (head.find("transfer-encoding: chunked") != std::string::npos) {
        std::string dec;
        size_t p = 0;
        while (p < body.size()) {
            size_t le = body.find("\r\n", p);
            if (le == std::string::npos) break;
            long len = strtol(body.c_str() + p, nullptr, 16);
            if (len <= 0) break;
            p = le + 2;
            if (p + (size_t)len > body.size()) break;
            dec.append(body, p, (size_t)len);
            p += (size_t)len + 2;
        }
        body.swap(dec);
    }
    o.body.swap(body);
    return true;
}

}  // namespace

bool HttpRequest(const std::string &url0, const char *method, const std::string &body, HttpResponse &out, std::string &err) {
    std::string url = url0;
    const int64_t deadline = NowMs() + kRequestTimeoutMs;
    out = HttpResponse{};
    err.clear();
    for (int hop = 0; hop < 4; ++hop) {
        Url u;
        if (!ParseUrl(url, u)) { err = "bad url"; return false; }
        Conn c;
        if (!Connect(u, c, deadline, err)) return false;
        if (u.https && !StartTls(u, c, deadline, err)) return false;

        std::string req = std::string(method) + " " + u.path + " HTTP/1.1\r\nHost: " + u.host + "\r\n" +
                          "User-Agent: AvisTools/1\r\nAccept: text/plain\r\nConnection: close\r\n";
        if (!strcmp(method, "POST"))
            req += "Content-Type: application/x-www-form-urlencoded\r\nContent-Length: " + std::to_string(body.size()) + "\r\n";
        req += "\r\n";
        if (!strcmp(method, "POST")) req += body;
        if (!SendAll(c, req, deadline)) { err = "send"; return false; }
        std::string raw;
        if (!ReadAll(c, raw, deadline)) { err = "timeout"; return false; }
        std::string loc;
        HttpResponse r;
        if (!ParseHttp(raw, r, loc)) { err = "bad response"; return false; }
        if ((r.status == 301 || r.status == 302 || r.status == 307 || r.status == 308) && !loc.empty()) {
            url = loc;
            continue;
        }
        out = r;
        return true;
    }
    err = "too many redirects";
    return false;
}

}  // namespace avis
