#pragma once
// Звуки экрана ключа. На Android — AAudio (libaaudio.so подгружается в рантайме, без зависимости при сборке);
// если звук не поднялся, всё остальное работает без него, причина пишется в <папка данных>/sound_debug.txt.
namespace avis {
namespace snd {

enum class Sfx { Key, Back, Clear, Paste, Enter, Success, Error, Toggle };

void Init(const char *dataDir);     // один раз; открывает аудиопоток в фоне
void Play(Sfx s, int variant = 0);  // variant — вариант высоты для Key (любое число)
void Tick();                        // раз в кадр: усыпляет поток после паузы
bool Enabled();
void SetEnabled(bool on);           // запоминается файлом sound_off в папке данных
void Shutdown();

}  // namespace snd
}  // namespace avis
