#pragma once
#include <string>
#include <cstdlib>
#include <cctype>
namespace avis {
// Framing only (not authenticity): lets the network reader finish without
// waiting for a keep-alive peer to close and rejects truncated HTTP bodies.
enum class HttpFrame { Pending, Complete, Invalid, UntilClose };
inline HttpFrame InspectHttpFrame(const std::string &raw) {
    const size_t he = raw.find("\r\n\r\n");
    if (he == std::string::npos) return raw.size() > 16384 ? HttpFrame::Invalid : HttpFrame::Pending;
    const size_t first = raw.find("\r\n");
    if (raw.compare(0,5,"HTTP/") != 0 || first == std::string::npos) return HttpFrame::Invalid;
    bool chunked = false, haveLength = false;
    size_t length = 0;
    for (size_t p = first + 2; p < he;) {
        const size_t e = raw.find("\r\n",p), colon = raw.find(':',p);
        if (e == std::string::npos || colon == std::string::npos || colon >= e) return HttpFrame::Invalid;
        std::string name = raw.substr(p,colon-p), value = raw.substr(colon+1,e-colon-1);
        for (char &c:name) c=(char)std::tolower((unsigned char)c);
        while (!value.empty() && (value.front()==' ' || value.front()=='\t')) value.erase(0,1);
        while (!value.empty() && (value.back()==' ' || value.back()=='\t')) value.pop_back();
        if (name=="content-length") {
            if (value.empty()) return HttpFrame::Invalid;
            size_t n = 0;
            for (char c:value) {
                if (c<'0' || c>'9' || n>32768) return HttpFrame::Invalid;
                n=n*10+(size_t)(c-'0');
            }
            if (n>32768 || (haveLength && n!=length)) return HttpFrame::Invalid;
            length=n; haveLength=true;
        } else if (name=="transfer-encoding") {
            for (char &c:value) c=(char)std::tolower((unsigned char)c);
            if (value!="chunked") return HttpFrame::Invalid;
            chunked=true;
        }
        p=e+2;
    }
    if (chunked && haveLength) return HttpFrame::Invalid;
    const size_t start=he+4;
    if (haveLength) return raw.size()-start>=length ? HttpFrame::Complete : HttpFrame::Pending;
    if (!chunked) return HttpFrame::UntilClose;
    size_t p=start, decoded=0;
    for (;;) {
        const size_t e=raw.find("\r\n",p);
        if (e==std::string::npos) return HttpFrame::Pending;
        std::string size=raw.substr(p,e-p);
        size=size.substr(0,size.find(';'));
        if (size.empty() || size.size()>8) return HttpFrame::Invalid;
        size_t n=0;
        for (char c:size) {
            int digit=c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:c>='A'&&c<='F'?c-'A'+10:-1;
            if (digit<0 || n>32768) return HttpFrame::Invalid;
            n=n*16+(size_t)digit;
        }
        p=e+2;
        if (n==0) {
            if (raw.size()<p+2) return HttpFrame::Pending;
            if (raw.compare(p,2,"\r\n")==0) return HttpFrame::Complete;
            return raw.find("\r\n\r\n",p)!=std::string::npos ? HttpFrame::Complete : HttpFrame::Pending;
        }
        if (n>32768 || decoded+n>32768) return HttpFrame::Invalid;
        if (raw.size()-p<n+2) return HttpFrame::Pending;
        if (raw.compare(p+n,2,"\r\n")!=0) return HttpFrame::Invalid;
        p+=n+2; decoded+=n;
    }
}
}