#include "auth_client.h"
#include "auth_clip.h"
#include "auth_config.h"
#include "auth_net.h"
#include "auth_proto.h"
#include "auth_retry.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <mutex>
#include <thread>
#include <vector>

#if defined(__ANDROID__)
#include <spawn.h>
#include <sys/system_properties.h>
#include <sys/wait.h>
extern char **environ;
#endif

namespace avis {
namespace {

int64_t NowMs() {
    timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

std::mutex g_mu;
std::condition_variable g_cv;
Snapshot g_snap;                       // под g_mu
std::string g_dataDir;
std::string g_pendingKey;              // под g_mu
std::string g_activeKey;               // под g_mu: ключ действующей сессии (для периодической сверки)
bool g_pendingAuto = false;
bool g_retryInfo = false;
uint64_t g_generation = 0;             // invalidates in-flight verification on cancel/logout
int64_t g_retryAtMs = 0;
std::atomic<bool> g_stop{false};
std::atomic<bool> g_started{false};
std::atomic<bool> g_active{false};
std::atomic<bool> g_localActive{false};
std::atomic<int64_t> g_deadlineMs{0};
std::thread g_thread;

std::mutex g_pasteMu;
bool g_pasteBusy = false, g_pasteDone = false;
PasteResult g_pasteRes;

std::string ReadFileTrim(const std::string &path, size_t max = 256) {
    FILE *f = fopen(path.c_str(), "rb");
    if (!f) return "";
    std::string s(max, '\0');
    size_t n = fread(&s[0], 1, max, f);
    fclose(f);
    s.resize(n);
    while (!s.empty() && (s.back() == '\n' || s.back() == '\r' || s.back() == ' ')) s.pop_back();
    size_t a = s.find_first_not_of(" \r\n\t");
    return a == std::string::npos ? "" : s.substr(a);
}

void WriteFile(const std::string &path, const std::string &data) {
    FILE *f = fopen(path.c_str(), "wb");
    if (!f) return;
    fwrite(data.data(), 1, data.size(), f);
    fclose(f);
}

// Вызывается под g_mu. Локальная сессия не зависит от HTTP и не имеет таймера.
void ActivateLocalLocked() {
    g_localActive = true;
    g_deadlineMs = 0;
    g_active = true;
    g_snap.phase = Phase::Active;
    g_snap.msg = Msg::None;
    g_snap.localKey = true;
    g_snap.autoLogin = false;
    g_snap.retrying = false;
    g_retryAtMs = 0;
    g_activeKey = kLocalKey;
    g_snap.savedKey = kLocalKey;
    WriteFile(g_dataDir + "/key.txt", kLocalKey);
}

std::string ServerUrl() {
    std::string u = ReadFileTrim(g_dataDir + "/server.txt");
    if (u.empty()) u = AVIS_API_URL;
    while (!u.empty() && u.back() == '/') u.pop_back();
    return u;
}

Msg MapStatus(const std::string &s) {
    if (s == "invalid") return Msg::Invalid;
    if (s == "expired") return Msg::Expired;
    if (s == "revoked") return Msg::Revoked;
    if (s == "banned") return Msg::Banned;
    if (s == "hwid") return Msg::Hwid;
    if (s == "unsub") return Msg::Unsub;
    return Msg::BadServer;
}

void FetchInfo() {
    const std::string url = ServerUrl();
    {
        std::lock_guard<std::mutex> l(g_mu);
        g_snap.serverSet = !url.empty();
    }
    if (url.empty()) return;
    const std::string nonce = RandomHex(16);
    HttpResponse r;
    std::string err;
    Reply rep;
    bool ok = HttpRequest(url + "/api/v1/info?nonce=" + nonce, "GET", "", r, err) && r.status == 200 &&
              ParseReply(r.body, "info", nonce, "", rep, err);
    std::lock_guard<std::mutex> l(g_mu);
    if (ok && rep.status == "ok") {
        g_snap.infoReady = true;
        g_snap.infoFailed = false;
        g_snap.bot = rep.a == "-" ? "" : rep.a;
        g_snap.channel = rep.b;
    } else {
        g_snap.infoFailed = true;
    }
}

// Returns true only for a temporary failure requiring another attempt.
// Every result is bound to a generation, so cancel/logout wins over late HTTP.
bool DoVerify(const std::string &key, bool interactive, uint64_t generation) {
    const int64_t attemptStarted = NowMs();
    {
        std::lock_guard<std::mutex> l(g_mu);
        if (generation != g_generation || g_stop) return false;
        ++g_snap.verifyAttempts;
        g_retryAtMs = 0;
    }
    // Защита от сетевой проверки, даже если локальный ключ попал в очередь.
    if (IsLocalKey(key)) {
        std::lock_guard<std::mutex> l(g_mu);
        if (generation == g_generation && !g_stop) ActivateLocalLocked();
        return false;
    }
    const std::string url = ServerUrl();
    Msg msg = Msg::None;
    bool ok = false, retry = false;
    int64_t remain = 0;
    if (url.empty()) {
        msg = Msg::NoServer;
    } else {
        const std::string hwid = DeviceId(), nonce = RandomHex(16);
        HttpResponse r;
        std::string err;
        Reply rep;
        if (!HttpRequest(url + "/api/v1/verify", "POST", "key=" + key + "&hwid=" + hwid + "&nonce=" + nonce + "&ver=1", r, err)) {
            retry = err != "bad url" && err != "too many redirects";
            msg = retry ? Msg::Network : Msg::BadServer;
        } else if (r.status != 200) {
            retry = RetryableHttpStatus(r.status);
            msg = retry ? Msg::Network : Msg::BadServer;
        } else if (!ParseReply(r.body, "verify", nonce, hwid, rep, err)) {
            msg = Msg::BadServer; // signature/nonce/HWID failure is not a network verdict
        } else if (rep.status == "ok") {
            remain = atoll(rep.b.c_str()) - rep.serverTime;
            if (remain > 0) ok = true; else msg = Msg::Expired;
        } else {
            msg = MapStatus(rep.status);
        }
    }

    std::lock_guard<std::mutex> l(g_mu);
    if (generation != g_generation || g_stop) return false;
    if (ok) {
        g_localActive = false;
        g_deadlineMs = NowMs() + remain * 1000;
        g_active = true;
        g_snap.phase = Phase::Active;
        g_snap.msg = Msg::None;
        g_snap.localKey = false;
        g_snap.autoLogin = false;
        g_snap.retrying = false;
        g_retryAtMs = 0;
        g_activeKey = key;
        g_snap.savedKey = key;
        WriteFile(g_dataDir + "/key.txt", key);
        return false;
    }
    if (retry) {
        g_retryAtMs = attemptStarted + kVerifyRetryMs;
        g_snap.retrying = true;
        if (interactive) {
            g_active = false;
            g_snap.phase = Phase::Checking;
            g_snap.msg = Msg::Network;
        }
        // Keep a previously verified session only until its original deadline.
        return true;
    }
    g_snap.retrying = false;
    g_retryAtMs = 0;
    if (!interactive && msg == Msg::BadServer) return false;
    g_active = false;
    g_localActive = false;
    g_snap.phase = Phase::NeedKey;
    g_snap.msg = msg;
    g_snap.localKey = false;
    g_snap.autoLogin = false;
    if (msg != Msg::BadServer && msg != Msg::NoServer) {
        g_activeKey.clear();
        g_snap.savedKey.clear();
        remove((g_dataDir + "/key.txt").c_str());
    }
    return false;
}

void Worker() {
    int64_t nextInfo = 0, nextVerify = 0, retryAt = 0;
    std::string retryKey;
    uint64_t retryGeneration = 0;
    bool retryInteractive = false;
    while (!g_stop) {
        std::string key;
        bool doInfo = false;
        uint64_t generation;
        {
            std::unique_lock<std::mutex> l(g_mu);
            g_cv.wait_for(l, std::chrono::milliseconds(100));
            if (g_stop) break;
            generation = g_generation;
            key.swap(g_pendingKey);
            g_pendingAuto = false;
            doInfo = g_retryInfo;
            g_retryInfo = false;
            if (!retryKey.empty() && retryGeneration != generation) retryKey.clear();
            if (g_active && !g_localActive && NowMs() >= g_deadlineMs) {
                g_active = false;
                g_snap.phase = Phase::NeedKey;
                g_snap.msg = Msg::Expired;
                g_snap.retrying = false;
                g_retryAtMs = 0;
                retryKey.clear();
            }
        }
        auto attempt = [&](const std::string &k, bool interactive, uint64_t gen) {
            if (DoVerify(k, interactive, gen)) {
                retryKey = k;
                retryGeneration = gen;
                retryInteractive = interactive;
                { std::lock_guard<std::mutex> l(g_mu); retryAt = g_retryAtMs; }
            } else retryKey.clear();
            nextVerify = NowMs() + (int64_t)kReverifySec * 1000;
        };
        if (!key.empty()) { retryKey.clear(); attempt(key, true, generation); continue; }
        if (!retryKey.empty()) {
            if (NowMs() >= retryAt) {
                const std::string k = retryKey;
                attempt(k, retryInteractive, retryGeneration);
            }
            // Metadata requests must not delay the five-second key retry.
            continue;
        }
        bool haveInfo;
        { std::lock_guard<std::mutex> l(g_mu); haveInfo = g_snap.infoReady; }
        if (!g_localActive && (doInfo || (!haveInfo && NowMs() >= nextInfo))) {
            FetchInfo(); nextInfo = NowMs() + (int64_t)kRetryInfoSec * 1000;
        }
        if (g_active && !g_localActive && NowMs() >= nextVerify) {
            std::string cur;
            { std::lock_guard<std::mutex> l(g_mu); cur = g_activeKey; generation = g_generation; }
            if (!cur.empty()) attempt(cur, false, generation);
        }
    }
}

}  // namespace

// ---------------------------------------------------------------- устройство
std::string DeviceId() {
    std::string parts;
    bool strong = false;
#if defined(__ANDROID__)
    auto prop = [](const char *n) {
        char v[PROP_VALUE_MAX] = {0};
        __system_property_get(n, v);
        return std::string(v);
    };
    for (const char *n : {"ro.serialno", "ro.boot.serialno"}) {
        std::string v = prop(n);
        if (!v.empty() && v != "unknown") { parts += v + "|"; strong = true; }
    }
    for (const char *n : {"ro.product.brand", "ro.product.model", "ro.product.device", "ro.hardware"}) parts += prop(n) + "|";
#else
    std::string mid = ReadFileTrim("/etc/machine-id", 64);
    if (!mid.empty()) { parts += mid + "|"; strong = true; }
#endif
    if (!strong) {   // нет стабильного серийника: держим случайный идентификатор в папке данных
        const std::string path = g_dataDir + "/.id";
        std::string id = ReadFileTrim(path, 64);
        if (id.size() < 16) { id = RandomHex(16); mkdir(g_dataDir.c_str(), 0777); WriteFile(path, id); }
        parts += id + "|";
    }
    return Sha256Hex("avis1|" + parts);
}

// ---------------------------------------------------------------- публичное API
void Init(const char *dataDir) {
    if (g_started.exchange(true)) return;
    g_stop = false;
    g_active = false;
    g_localActive = false;
    g_deadlineMs = 0;
    g_dataDir = dataDir;
    mkdir(g_dataDir.c_str(), 0777);
    std::string saved = ReadFileTrim(g_dataDir + "/key.txt");
    saved = NormalizeKey(saved);
    {
        std::lock_guard<std::mutex> l(g_mu);
        g_snap = Snapshot{};
        ++g_generation;
        g_retryAtMs = 0;
        g_pendingKey.clear();
        g_activeKey.clear();
        g_snap.savedKey = saved;
        g_snap.serverSet = !ServerUrl().empty();
        if (IsLocalKey(saved)) {
            ActivateLocalLocked();
        } else if (!saved.empty()) {
            g_snap.phase = Phase::Checking;
            g_snap.autoLogin = true;
            g_pendingKey = saved;
            g_pendingAuto = true;
        }
    }
    g_thread = std::thread(Worker);
}

void Shutdown() {
    if (!g_started) return;
    g_stop = true;
    g_cv.notify_all();
    if (g_thread.joinable()) g_thread.join();
    g_active = false;
    g_localActive = false;
    g_started = false;
}

Snapshot Get() {
    std::lock_guard<std::mutex> l(g_mu);
    Snapshot s = g_snap;
    s.retryInSec = g_retryAtMs > NowMs() ? (int)((g_retryAtMs - NowMs() + 999) / 1000) : 0;
    s.remainingSec = g_active && !g_localActive ? (g_deadlineMs - NowMs()) / 1000 : 0;
    if (s.remainingSec < 0) s.remainingSec = 0;
    return s;
}

bool Active() { return g_active.load(std::memory_order_relaxed) &&
                       (g_localActive.load(std::memory_order_relaxed) || NowMs() < g_deadlineMs.load(std::memory_order_relaxed)); }

int64_t RemainingSec() {
    if (!g_active.load(std::memory_order_relaxed)) return 0;
    if (g_localActive.load(std::memory_order_relaxed)) return 0;
    const int64_t r = (g_deadlineMs.load(std::memory_order_relaxed) - NowMs()) / 1000;
    return r > 0 ? r : 0;
}

void Submit(const std::string &raw) {
    std::string key = NormalizeKey(raw);
    std::lock_guard<std::mutex> l(g_mu);
    if (g_snap.phase == Phase::Checking) return;
    if (key.empty()) { g_snap.msg = Msg::BadFormat; return; }
    ++g_generation;
    g_snap.phase = Phase::Checking;
    g_snap.msg = Msg::None;
    g_snap.retrying = false;
    g_snap.verifyAttempts = 0;
    g_retryAtMs = 0;
    if (IsLocalKey(key)) {
        g_pendingKey.clear();
        ActivateLocalLocked();
        g_cv.notify_all();
        return;
    }
    g_pendingKey = key;
    g_cv.notify_all();
}

void CancelCheck() {
    std::lock_guard<std::mutex> l(g_mu);
    if (g_snap.phase != Phase::Checking) return;
    ++g_generation;
    g_pendingKey.clear();
    g_pendingAuto = false;
    g_snap.phase = Phase::NeedKey;
    g_snap.msg = Msg::None;
    g_snap.autoLogin = false;
    g_snap.retrying = false;
    g_retryAtMs = 0;
    g_cv.notify_all();
}

void Logout() {
    std::lock_guard<std::mutex> l(g_mu);
    ++g_generation;
    g_pendingKey.clear();
    g_pendingAuto = false;
    g_snap.retrying = false;
    g_retryAtMs = 0;
    g_cv.notify_all();
    g_active = false;
    g_localActive = false;
    g_activeKey.clear();
    g_snap.phase = Phase::NeedKey;
    g_snap.msg = Msg::None;
    g_snap.localKey = false;
    g_snap.savedKey.clear();
    remove((g_dataDir + "/key.txt").c_str());
}

void RetryServer() {
    std::lock_guard<std::mutex> l(g_mu);
    g_retryInfo = true;
    g_cv.notify_all();
}

// ---------------------------------------------------------------- буфер обмена
std::string ExtractKeyFromParcelDump(const std::string &dump) {
    const std::vector<unsigned char> bytes = ParcelBytes(dump);
    std::string u16, u8;                     // текст в UTF-16LE (так он лежит в Parcel) и в однобайтовом виде
    for (size_t i = 0; i + 1 < bytes.size(); ++i) {
        const bool printable = bytes[i] >= 32 && bytes[i] < 127;
        if (printable) u8 += (char)bytes[i];
        if (printable && bytes[i + 1] == 0) u16 += (char)bytes[i];
    }
    const std::string k = FindKeyInText(u16);
    return k.empty() ? FindKeyInText(u8) : k;
}

void RequestPaste() {
    {
        std::lock_guard<std::mutex> l(g_pasteMu);
        if (g_pasteBusy) return;
        g_pasteBusy = true;
        g_pasteDone = false;
        g_pasteRes = PasteResult();
    }
    std::thread([] {
        ClipResult c = ReadClipboard(g_dataDir);
        PasteResult r;
        r.key = c.key;
        r.kind = c.kind == ClipKind::Found ? PasteResult::Found : c.kind == ClipKind::NoKey ? PasteResult::NoKey : PasteResult::NoAccess;
        if (r.kind != PasteResult::Found) {             // запасной путь: ключ можно положить в файл paste.txt
            std::string f = FindKeyInText(ReadFileTrim(g_dataDir + "/paste.txt"));
            if (!f.empty()) { r.key = f; r.kind = PasteResult::Found; }
        }
        std::lock_guard<std::mutex> l(g_pasteMu);
        g_pasteRes = r;
        g_pasteBusy = false;
        g_pasteDone = true;
    }).detach();
}

bool PasteBusy() { std::lock_guard<std::mutex> l(g_pasteMu); return g_pasteBusy; }

bool TakePaste(PasteResult &out) {
    std::lock_guard<std::mutex> l(g_pasteMu);
    if (!g_pasteDone) return false;
    g_pasteDone = false;
    out = g_pasteRes;
    return true;
}

// ---------------------------------------------------------------- Telegram
static void OpenUrl(const std::string &url) {
#if defined(__ANDROID__)
    if (url.compare(0, 13, "https://t.me/") != 0) return;
    for (size_t i = 13; i < url.size(); ++i) if (!isalnum((unsigned char)url[i]) && url[i] != '_') return;   // без аргументов-сюрпризов
    const char *argv[] = {"am", "start", "--user", "0", "-a", "android.intent.action.VIEW", "-d", url.c_str(), nullptr};
    pid_t pid;
    if (posix_spawnp(&pid, "am", nullptr, nullptr, (char *const *)argv, environ) == 0) {
        std::thread([pid] { int st; waitpid(pid, &st, 0); }).detach();
    }
#else
    (void)url;
#endif
}

void OpenBot() {
    std::string bot, ch;
    { std::lock_guard<std::mutex> l(g_mu); bot = g_snap.bot; ch = g_snap.channel; }
    if (!bot.empty()) OpenUrl("https://t.me/" + bot);
    else OpenUrl("https://t.me/" + (ch.empty() ? std::string(AVIS_CHANNEL_DEFAULT) : ch));
}

void OpenChannel() {
    std::string ch;
    { std::lock_guard<std::mutex> l(g_mu); ch = g_snap.channel; }
    OpenUrl("https://t.me/" + (ch.empty() ? std::string(AVIS_CHANNEL_DEFAULT) : ch));
}

}  // namespace avis
