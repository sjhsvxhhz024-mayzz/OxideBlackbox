#include "auth_sound.h"
#include "sound_core.h"

#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include <atomic>
#include <mutex>
#include <string>
#include <thread>

#if defined(__ANDROID__) && defined(__has_include)
#if __has_include(<aaudio/AAudio.h>)
#include <aaudio/AAudio.h>
#include <dlfcn.h>
#define AVIS_AAUDIO 1
#endif
#endif

namespace avis {
namespace snd {
namespace {

std::string g_dir;
std::atomic<bool> g_enabled{true};

std::string FlagPath() { return g_dir + "/sound_off"; }

void WriteDebug(const std::string &text) {
    if (g_dir.empty()) return;
    if (FILE *f = fopen((g_dir + "/sound_debug.txt").c_str(), "wb")) { fwrite(text.data(), 1, text.size(), f); fclose(f); }
}

int64_t NowMs() {
    timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

constexpr float kKeyGain = 0.55f;    // общая громкость: клавиатура не должна оглушать

#ifdef AVIS_AAUDIO

struct Api {
    void *lib = nullptr;
    decltype(&AAudio_createStreamBuilder) createBuilder = nullptr;
    decltype(&AAudioStreamBuilder_setDirection) setDirection = nullptr;
    decltype(&AAudioStreamBuilder_setSharingMode) setSharing = nullptr;
    decltype(&AAudioStreamBuilder_setSampleRate) setRate = nullptr;
    decltype(&AAudioStreamBuilder_setChannelCount) setChannels = nullptr;
    decltype(&AAudioStreamBuilder_setFormat) setFormat = nullptr;
    decltype(&AAudioStreamBuilder_setPerformanceMode) setPerf = nullptr;
    decltype(&AAudioStreamBuilder_setUsage) setUsage = nullptr;
    decltype(&AAudioStreamBuilder_setContentType) setContent = nullptr;
    decltype(&AAudioStreamBuilder_setDataCallback) setData = nullptr;
    decltype(&AAudioStreamBuilder_setErrorCallback) setError = nullptr;
    decltype(&AAudioStreamBuilder_openStream) open = nullptr;
    decltype(&AAudioStreamBuilder_delete) del = nullptr;
    decltype(&AAudioStream_requestStart) start = nullptr;
    decltype(&AAudioStream_requestStop) stop = nullptr;
    decltype(&AAudioStream_close) close = nullptr;
    decltype(&AAudio_convertResultToText) text = nullptr;
};

Api g_api;
avsnd::Bank *g_bank = nullptr;
avsnd::Mixer *g_mixer = nullptr;
AAudioStream *g_stream = nullptr;
std::mutex g_mu;                       // открытие/запуск/остановка потока; аудиопоток этот замок не берёт
std::atomic<bool> g_running{false}, g_broken{false}, g_ready{false}, g_failed{false}, g_wantStart{false};
std::atomic<int64_t> g_lastPlay{0};
std::thread g_initThread;

aaudio_data_callback_result_t OnData(AAudioStream *, void *, void *audio, int32_t frames) {
    g_mixer->Mix((int16_t *)audio, frames);
    return AAUDIO_CALLBACK_RESULT_CONTINUE;
}

void OnError(AAudioStream *, void *, aaudio_result_t) { g_broken = true; }    // отключили наушники и т.п.: переоткроем при следующем звуке

template <class T> bool Sym(T &fn, const char *name) { fn = (T)dlsym(g_api.lib, name); return fn != nullptr; }

bool LoadApi(std::string &why) {
    if (g_api.lib) return true;
    g_api.lib = dlopen("libaaudio.so", RTLD_NOW);
    if (!g_api.lib) { why = std::string("dlopen libaaudio.so: ") + (dlerror() ? dlerror() : "?"); return false; }
    bool ok = Sym(g_api.createBuilder, "AAudio_createStreamBuilder") && Sym(g_api.setDirection, "AAudioStreamBuilder_setDirection") &&
              Sym(g_api.setSharing, "AAudioStreamBuilder_setSharingMode") && Sym(g_api.setRate, "AAudioStreamBuilder_setSampleRate") &&
              Sym(g_api.setChannels, "AAudioStreamBuilder_setChannelCount") && Sym(g_api.setFormat, "AAudioStreamBuilder_setFormat") &&
              Sym(g_api.setPerf, "AAudioStreamBuilder_setPerformanceMode") && Sym(g_api.setData, "AAudioStreamBuilder_setDataCallback") &&
              Sym(g_api.setError, "AAudioStreamBuilder_setErrorCallback") && Sym(g_api.open, "AAudioStreamBuilder_openStream") &&
              Sym(g_api.del, "AAudioStreamBuilder_delete") && Sym(g_api.start, "AAudioStream_requestStart") &&
              Sym(g_api.stop, "AAudioStream_requestStop") && Sym(g_api.close, "AAudioStream_close");
    Sym(g_api.setUsage, "AAudioStreamBuilder_setUsage");            // API 28+, необязательные
    Sym(g_api.setContent, "AAudioStreamBuilder_setContentType");
    Sym(g_api.text, "AAudio_convertResultToText");
    if (!ok) why = "в libaaudio.so нет нужных функций";
    return ok;
}

const char *Txt(aaudio_result_t r) { return g_api.text ? g_api.text(r) : "?"; }

// Вызывать под g_mu.
bool OpenStreamLocked(std::string &log) {
    if (g_stream) { g_api.close(g_stream); g_stream = nullptr; }
    g_broken = false;
    // Сначала малая задержка, при отказе — обычный режим.
    const aaudio_performance_mode_t modes[2] = {AAUDIO_PERFORMANCE_MODE_LOW_LATENCY, AAUDIO_PERFORMANCE_MODE_NONE};
    for (aaudio_performance_mode_t mode : modes) {
        AAudioStreamBuilder *b = nullptr;
        aaudio_result_t r = g_api.createBuilder(&b);
        if (r != AAUDIO_OK) { log += std::string("createStreamBuilder: ") + Txt(r) + "\n"; return false; }
        g_api.setDirection(b, AAUDIO_DIRECTION_OUTPUT);
        g_api.setSharing(b, AAUDIO_SHARING_MODE_SHARED);
        g_api.setRate(b, avsnd::kRate);
        g_api.setChannels(b, 1);
        g_api.setFormat(b, AAUDIO_FORMAT_PCM_I16);
        g_api.setPerf(b, mode);
        if (g_api.setUsage) g_api.setUsage(b, AAUDIO_USAGE_GAME);
        if (g_api.setContent) g_api.setContent(b, AAUDIO_CONTENT_TYPE_SONIFICATION);
        g_api.setData(b, OnData, nullptr);
        g_api.setError(b, OnError, nullptr);
        r = g_api.open(b, &g_stream);
        g_api.del(b);
        if (r == AAUDIO_OK) {
            log += mode == AAUDIO_PERFORMANCE_MODE_LOW_LATENCY ? "поток открыт (малая задержка)\n" : "поток открыт (обычный режим)\n";
            return true;
        }
        log += std::string("openStream(") + (mode == AAUDIO_PERFORMANCE_MODE_LOW_LATENCY ? "low-latency" : "none") + "): " + Txt(r) + "\n";
        g_stream = nullptr;
    }
    return false;
}

void StartLocked() {
    if (!g_stream || g_running) return;
    const aaudio_result_t r = g_api.start(g_stream);
    if (r == AAUDIO_OK) g_running = true;
    else g_broken = true;
}

void InitThread() {
    std::string log = "AAudio\n";
    if (!LoadApi(log)) { log += "\n"; g_failed = true; WriteDebug(log); return; }
    g_bank = new avsnd::Bank();
    g_mixer = new avsnd::Mixer(*g_bank);
    std::lock_guard<std::mutex> l(g_mu);
    if (!OpenStreamLocked(log)) { g_failed = true; WriteDebug(log); return; }
    g_ready = true;
    WriteDebug(log);
    if (g_wantStart) StartLocked();
}

#endif  // AVIS_AAUDIO

}  // namespace

void Init(const char *dataDir) {
    g_dir = dataDir;
    struct stat st;
    g_enabled = stat(FlagPath().c_str(), &st) != 0;
#ifdef AVIS_AAUDIO
    static bool once = false;
    if (once) return;
    once = true;
    g_initThread = std::thread(InitThread);
#endif
}

void Play(Sfx s, int variant) {
    if (!g_enabled) return;
#ifdef AVIS_AAUDIO
    if (g_failed) return;
    int idx = avsnd::TOGGLE;
    switch (s) {
        case Sfx::Key: idx = avsnd::KEY0 + ((variant % avsnd::KEY_COUNT) + avsnd::KEY_COUNT) % avsnd::KEY_COUNT; break;
        case Sfx::Back: idx = avsnd::BACK; break;
        case Sfx::Clear: idx = avsnd::CLEAR; break;
        case Sfx::Paste: idx = avsnd::PASTE; break;
        case Sfx::Enter: idx = avsnd::ENTER; break;
        case Sfx::Success: idx = avsnd::SUCCESS; break;
        case Sfx::Error: idx = avsnd::ERROR_; break;
        case Sfx::Toggle: idx = avsnd::TOGGLE; break;
    }
    g_lastPlay = NowMs();
    if (!g_ready) { g_wantStart = true; return; }       // поток ещё открывается: этот звук пропускаем
    g_mixer->Post(idx, kKeyGain);
    std::unique_lock<std::mutex> l(g_mu, std::try_to_lock);
    if (!l.owns_lock()) return;
    if (g_broken) {
        std::string log;
        if (!OpenStreamLocked(log)) return;
    }
    StartLocked();
#else
    (void)s; (void)variant;
#endif
}

void Tick() {
#ifdef AVIS_AAUDIO
    if (!g_running || g_failed) return;
    if (NowMs() - g_lastPlay.load() < 2500 || !g_mixer->Idle()) return;
    std::unique_lock<std::mutex> l(g_mu, std::try_to_lock);
    if (l.owns_lock() && g_stream && g_running) { g_api.stop(g_stream); g_running = false; }   // пауза: не держим аудиотракт зря
#endif
}

bool Enabled() { return g_enabled; }

void SetEnabled(bool on) {
    g_enabled = on;
    if (g_dir.empty()) return;
    if (on) remove(FlagPath().c_str());
    else if (FILE *f = fopen(FlagPath().c_str(), "wb")) fclose(f);
}

void Shutdown() {
#ifdef AVIS_AAUDIO
    if (g_initThread.joinable()) g_initThread.join();
    std::lock_guard<std::mutex> l(g_mu);
    if (g_stream) { g_api.stop(g_stream); g_api.close(g_stream); g_stream = nullptr; }
    g_running = false;
#endif
}

}  // namespace snd
}  // namespace avis
