#include "auth_proto.h"
#include "auth_config.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>

#include <mbedtls/base64.h>
#include <mbedtls/md.h>
#include <mbedtls/pk.h>
#include <mbedtls/sha256.h>

#include <fcntl.h>
#include <unistd.h>

namespace avis {

static const char kAlphabet[] = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

static char UpperAscii(char c) { return c >= 'a' && c <= 'z' ? (char)(c - 'a' + 'A') : c; }

bool IsLocalKey(const std::string &raw) {
    if (raw.size() != sizeof(kLocalKey) - 1) return false;
    for (size_t i = 0; i < raw.size(); ++i)
        if (UpperAscii(raw[i]) != UpperAscii(kLocalKey[i])) return false;
    return true;
}

bool IsKeyChar(char c) { return c && strchr(kAlphabet, c) != nullptr; }

std::string NormalizeKey(const std::string &raw) {
    if (IsLocalKey(raw)) return kLocalKey;
    std::string s;
    for (char c : raw) {
        if (c >= 'a' && c <= 'z') c = (char)(c - 32);
        if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) s += c;
    }
    std::string body;
    if (s.size() == 16 && s.compare(0, 4, "AVIS") == 0) body = s.substr(4);
    else if (s.size() == 12) body = s;
    else return "";
    for (char c : body) if (!IsKeyChar(c)) return "";
    return "AVIS-" + body.substr(0, 4) + "-" + body.substr(4, 4) + "-" + body.substr(8, 4);
}

std::string FindKeyInText(const std::string &text) {
    // Вставка принимает и сам локальный ключ, и его упоминание в сообщении/ссылке.
    for (size_t i = 0; i + sizeof(kLocalKey) - 1 <= text.size(); ++i) {
        if (!IsLocalKey(text.substr(i, sizeof(kLocalKey) - 1))) continue;
        const size_t end = i + sizeof(kLocalKey) - 1;
        const auto partOfName = [](char c) {
            c = UpperAscii(c);
            return (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '.';
        };
        if ((i == 0 || !partOfName(text[i - 1])) && (end == text.size() || !partOfName(text[end])))
            return kLocalKey;
    }
    std::string t;
    for (char c : text) {
        if (c >= 'a' && c <= 'z') c = (char)(c - 32);
        if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) t += c;
    }
    for (size_t i = 0; i + 16 <= t.size(); ++i) {
        if (t.compare(i, 4, "AVIS") != 0) continue;
        bool ok = true;
        for (size_t k = 4; k < 16 && ok; ++k) ok = IsKeyChar(t[i + k]);
        if (ok) return "AVIS-" + t.substr(i + 4, 4) + "-" + t.substr(i + 8, 4) + "-" + t.substr(i + 12, 4);
    }
    return t.size() == 12 ? NormalizeKey(t) : "";
}

std::vector<unsigned char> ParcelBytes(const std::string &dump) {
    // Строки вида:  0x00000010: 00410056 00530049 ...   '.V.A.I.S.'
    std::vector<unsigned char> bytes;
    size_t p = 0;
    while (p < dump.size()) {
        size_t e = dump.find('\n', p);
        if (e == std::string::npos) e = dump.size();
        std::string line = dump.substr(p, e - p);
        p = e + 1;
        size_t x = line.find("0x"), c = line.find(':');
        if (x == std::string::npos || c == std::string::npos || c < x) continue;
        size_t i = c + 1;
        while (i < line.size()) {
            while (i < line.size() && line[i] == ' ') ++i;
            size_t j = i;
            while (j < line.size() && isxdigit((unsigned char)line[j])) ++j;
            if (j - i != 8) break;                       // дошли до текстовой колонки
            unsigned long w = strtoul(line.substr(i, 8).c_str(), nullptr, 16);
            for (int k = 0; k < 4; ++k) bytes.push_back((unsigned char)((w >> (8 * k)) & 0xFF));   // little-endian
            i = j;
        }
    }
    return bytes;
}

int ParcelStatus(const std::vector<unsigned char> &b) {
    auto word = [&](size_t i) { return (uint32_t)b[i] | ((uint32_t)b[i + 1] << 8) | ((uint32_t)b[i + 2] << 16) | ((uint32_t)b[i + 3] << 24); };
    if (b.size() < 8) return -1;
    if (word(0) != 0) return -1;            // исключение (SecurityException и др.)
    return word(4) == 0 ? 0 : 1;            // дальше — флаг «объект не null»
}

HelperStatus ParseHelperOutput(const std::string &out, std::string &text) {
    size_t p = 0;
    while (p < out.size()) {                // шум app_process (предупреждения) бывает до нужной строки
        size_t e = out.find('\n', p);
        std::string line = out.substr(p, e == std::string::npos ? std::string::npos : e - p);
        p = e == std::string::npos ? out.size() : e + 1;
        while (!line.empty() && (line.back() == '\r' || line.back() == ' ')) line.pop_back();
        if (line == "EMPTY") { text.clear(); return HelperStatus::Empty; }
        if (line.compare(0, 3, "OK ") == 0) {
            unsigned char buf[8192];
            size_t n = 0;
            if (mbedtls_base64_decode(buf, sizeof(buf), &n, (const unsigned char *)line.data() + 3, line.size() - 3) == 0) {
                text.assign((const char *)buf, n);
                return HelperStatus::Ok;
            }
            text = "bad base64";
            return HelperStatus::Error;
        }
        if (line.compare(0, 3, "ERR") == 0) { text = line.size() > 4 ? line.substr(4) : "unknown"; return HelperStatus::Error; }
    }
    text = out.empty() ? "no output" : "unexpected output";
    return HelperStatus::Error;
}

std::string RandomHex(int bytes) {
    std::vector<unsigned char> b((size_t)bytes);
    int fd = open("/dev/urandom", O_RDONLY);
    size_t got = 0;
    if (fd >= 0) {
        while (got < b.size()) {
            ssize_t n = read(fd, b.data() + got, b.size() - got);
            if (n <= 0) break;
            got += (size_t)n;
        }
        close(fd);
    }
    for (; got < b.size(); ++got) b[got] = (unsigned char)(rand() & 0xFF);   // запасной путь, на Android не используется
    static const char *hx = "0123456789abcdef";
    std::string s;
    for (unsigned char v : b) { s += hx[v >> 4]; s += hx[v & 15]; }
    return s;
}

std::string Sha256Hex(const std::string &data) {
    unsigned char h[32];
    mbedtls_sha256((const unsigned char *)data.data(), data.size(), h, 0);
    static const char *hx = "0123456789abcdef";
    std::string s;
    for (unsigned char v : h) { s += hx[v >> 4]; s += hx[v & 15]; }
    return s;
}

static std::vector<std::string> Split(const std::string &s, char d) {
    std::vector<std::string> out;
    size_t p = 0;
    for (;;) {
        size_t e = s.find(d, p);
        if (e == std::string::npos) { out.push_back(s.substr(p)); break; }
        out.push_back(s.substr(p, e - p));
        p = e + 1;
    }
    return out;
}

bool ParseReplyWithKey(const std::string &pem, const std::string &text, const char *kind, const std::string &nonce,
                       const std::string &hwidEcho, Reply &out, std::string &err) {
    size_t nl = text.find('\n');
    if (nl == std::string::npos) { err = "format"; return false; }
    std::string payload = text.substr(0, nl);
    std::string sig64 = text.substr(nl + 1);
    while (!sig64.empty() && (sig64.back() == '\n' || sig64.back() == '\r' || sig64.back() == ' ')) sig64.pop_back();
    if (payload.empty() || sig64.empty() || payload.size() > 512) { err = "format"; return false; }

    unsigned char der[160];
    size_t derLen = 0;
    if (mbedtls_base64_decode(der, sizeof(der), &derLen, (const unsigned char *)sig64.data(), sig64.size()) != 0) { err = "sig encoding"; return false; }

    mbedtls_pk_context pk;
    mbedtls_pk_init(&pk);
    int r = mbedtls_pk_parse_public_key(&pk, (const unsigned char *)pem.c_str(), pem.size() + 1);
    if (r != 0) { mbedtls_pk_free(&pk); err = "pubkey"; return false; }
    unsigned char h[32];
    mbedtls_sha256((const unsigned char *)payload.data(), payload.size(), h, 0);
    r = mbedtls_pk_verify(&pk, MBEDTLS_MD_SHA256, h, sizeof(h), der, derLen);
    mbedtls_pk_free(&pk);
    if (r != 0) { err = "bad signature"; return false; }

    std::vector<std::string> f = Split(payload, '|');
    if (f.size() != 7 || f[0] != "AV1") { err = "format"; return false; }
    if (f[1] != kind) { err = "type"; return false; }
    if (f[3] != nonce) { err = "nonce"; return false; }
    if (!strcmp(kind, "verify") && f[4] != hwidEcho && f[4] != "-") { err = "hwid echo"; return false; }
    out.kind = f[1]; out.status = f[2]; out.nonce = f[3]; out.a = f[4]; out.b = f[5];
    out.serverTime = atoll(f[6].c_str());
    return true;
}

bool ParseReply(const std::string &text, const char *kind, const std::string &nonce, const std::string &hwidEcho,
                Reply &out, std::string &err) {
    return ParseReplyWithKey(AVIS_PUBLIC_KEY_PEM, text, kind, nonce, hwidEcho, out, err);
}

}  // namespace avis
