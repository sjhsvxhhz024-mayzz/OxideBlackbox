#pragma once
// Чтение буфера обмена Android из внешнего процесса (оверлей не приложение, у него нет ClipboardManager).
//
// Порядок попыток, пока не получится:
//   1. хелпер avis.Clip (assets/trial/avis_clip.jar) через app_process от имени shell, затем root — так буфер читает scrcpy;
//   2. `service call clipboard` с сигнатурами под версию Android, от имени shell, затем root.
// Что именно сказала система, пишется в <папка данных>/paste_debug.txt (без содержимого буфера).
#include <string>
#include <vector>

namespace avis {

enum class ClipKind { Found, NoKey, NoAccess };

struct ClipResult {
    ClipKind kind = ClipKind::NoAccess;
    std::string key;
};

ClipResult ReadClipboard(const std::string &dataDir);

// Запуск процесса с таймаутом (используется и тестами). uid >= 0 — сменить uid/gid перед exec (нужен root); -1 — как есть.
// extraEnv — строки "NAME=value", добавляются к окружению (одноимённые заменяются).
struct RunResult {
    bool started = false, timedOut = false;
    int exitCode = -1;
    std::string output;      // stdout+stderr, не больше 16 КБ
};
RunResult RunProcess(const std::vector<std::string> &argv, const std::vector<std::string> &extraEnv, int uid, int timeoutMs);

}  // namespace avis
