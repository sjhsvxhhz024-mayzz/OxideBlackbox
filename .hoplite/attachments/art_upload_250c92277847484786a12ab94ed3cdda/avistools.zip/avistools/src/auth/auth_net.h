#pragma once
// Минимальный HTTP/HTTPS-клиент (mbedtls). Сертификат сервера НЕ проверяется: подлинность ответов
// гарантирует подпись ECDSA (см. auth_proto), а TLS нужен лишь чтобы достучаться до хостингов, где открыт только https.
#include <string>

namespace avis {

struct Url {
    bool https = false;
    std::string host, path;
    int port = 80;
};

bool ParseUrl(const std::string &s, Url &out);

struct HttpResponse {
    int status = 0;
    std::string body;
};

// method: "GET" | "POST". Для POST body отправляется как application/x-www-form-urlencoded.
// Возвращает false и заполняет err при сетевой ошибке. Редиректы (301/302/307/308) выполняются до 3 раз.
bool HttpRequest(const std::string &url, const char *method, const std::string &body, HttpResponse &out, std::string &err);

}  // namespace avis
