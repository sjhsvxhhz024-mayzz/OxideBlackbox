#pragma once
// Названия оружия и брони для подписей ESP: английский текст, без иконок. Чистая логика без чтения памяти игры (проверяется на хосте:
// tools/test_gear_names.cpp).
//  · Название берётся из самой игры (ItemData.m_DisplayName.english), если оно прочиталось; иначе из таблицы ниже; иначе id вида
//    "metal.chestplate" превращается в "Metal Chestplate".
//  · Броня: слот и класс (материал) берутся из таблицы по id, для неизвестных id — по словам в названии.
//  · Индекс в SyncList<EquipPiece> чужого игрока смещён относительно реестра equipments[]: первые элементы списка — не броня. Смещение
//    подбирается по согласованности набора (одна деталь на слот, один материал), см. ShiftVoter.
#include <ctype.h>
#include <string.h>
#include <string>
#include <unordered_set>
#include <vector>

namespace gear {

inline std::string key(const std::string &s) {
    std::string o;
    for (unsigned char c : s) if (isalnum(c)) o.push_back((char)tolower(c));
    return o;
}

// slot: 0 голова, 1 торс, 2 ноги, 3 ботинки, 4 цельный костюм, 5 рюкзак, -1 не броня. rank: 0 косметика, 1 дерево, 2 кожа, 3 кость, 4 металл,
// 5 хазмат, 6 военный.
struct Entry { const char *id; const char *name; int slot; int rank; };

static const Entry kArmor[] = {
    { "wooden.helmet", "Wooden Helmet", 0, 1 },     { "wood.chestplate", "Wooden Breastplate", 1, 1 },
    { "wooden.leggings", "Wooden Leggings", 2, 1 }, { "wooden.sandals", "Wooden Sandals", 3, 1 },
    { "leather.helmet", "Leather Helmet", 0, 2 },   { "leather.chestplate", "Leather Breastplate", 1, 2 },
    { "leather.leggings", "Leather Leggings", 2, 2 }, { "leather.boots", "Leather Boots", 3, 2 },
    { "bone.helmet", "Bone Helmet", 0, 3 },         { "bone.chestplate", "Bone Breastplate", 1, 3 },
    { "bone.leggings", "Bone Leggings", 2, 3 },     { "bone.boots", "Bone Boots", 3, 3 },
    { "metal.helmet", "Metal Helmet", 0, 4 },       { "metal.chestplate", "Metal Breastplate", 1, 4 },
    { "metal.leggings", "Metal Leggings", 2, 4 },   { "metal.boots", "Metal Boots", 3, 4 },
    { "hazmat", "Hazmat Suit", 4, 5 },              { "military.suit", "Military Suit", 4, 6 },
    { "backpack", "Backpack", 5, 1 },               { "backpack.big", "Big Backpack", 5, 2 },
    { "elf.hat", "Elf Hat", 0, 0 },                 { "pumpkin.head", "Pumpkin Head", 0, 0 },
    { "pumpkin", "Pumpkin Head", 0, 0 },            { "santa.hat", "Santa Hat", 0, 0 },
    { "ski.head", "Ski Mask", 0, 0 },               { "snowman.head", "Snowman Head", 0, 0 },
    { "snowman", "Snowman Head", 0, 0 },            { "witch.hat", "Witch Hat", 0, 0 },
    { "party.cone", "Party Hat", 0, 0 },
};

static const Entry kWeapons[] = {
    { "stone.hatchet", "Stone Hatchet", -1, 0 },    { "axe", "Axe", -1, 0 },
    { "pickaxe", "Pickaxe", -1, 0 },                { "pickaxehammer", "Pickaxe Hammer", -1, 0 },
    { "revolver", "Revolver", -1, 0 },              { "shotgun", "Shotgun", -1, 0 },
    { "hunting.rifle", "Hunting Rifle", -1, 0 },    { "assault.rifle", "Assault Rifle", -1, 0 },
    { "bone.club", "Bone Club", -1, 0 },            { "wooden.spear", "Wooden Spear", -1, 0 },
    { "iron.spear", "Iron Spear", -1, 0 },          { "ice.spear", "Ice Spear", -1, 0 },
    { "wooden.bow", "Wooden Bow", -1, 0 },          { "crossbow", "Crossbow", -1, 0 },
    { "torch", "Torch", -1, 0 },                    { "building.plan", "Building Plan", -1, 0 },
    { "building.hammer", "Building Hammer", -1, 0 }, { "rocket.launcher", "Rocket Launcher", -1, 0 },
    { "explosive.charge", "Explosive Charge", -1, 0 }, { "snowball", "Snowball", -1, 0 },
    { "event.grenade.smoke", "Smoke Grenade", -1, 0 }, { "event.grenade.makeshift", "Makeshift Grenade", -1, 0 },
    { "grenade.military", "Military Grenade", -1, 0 }, { "grenade.cupcake", "Cupcake Grenade", -1, 0 },
    { "submachine.gun", "Submachine Gun", -1, 0 },  { "flare.gun", "Flare Gun", -1, 0 },
    { "weapon.flare.signal", "Signal Flare", -1, 0 }, { "wooden.spiked.club", "Spiked Club", -1, 0 },
    { "machete", "Machete", -1, 0 },                { "mace", "Mace", -1, 0 },
    { "desert.eagle", "Desert Eagle", -1, 0 },      { "thompson", "Thompson", -1, 0 },
    { "dmr", "DMR", -1, 0 },                        { "winchester", "Winchester", -1, 0 },
    { "dvl", "DVL-10", -1, 0 },                     { "hmlmg", "HMLMG", -1, 0 },
    { "saw.ripper", "Saw Ripper", -1, 0 },          { "handmade.pistol", "Handmade Pistol", -1, 0 },
    { "kriss.vector", "Kriss Vector", -1, 0 },      { "chainsaw", "Chainsaw", -1, 0 },
    { "jackhammer", "Jackhammer", -1, 0 },          { "steel.ball.gun", "Steel Ball Gun", -1, 0 },
    { "fn.fal", "FN FAL", -1, 0 },                  { "double.barrel", "Double Barrel", -1, 0 },
};

template <size_t N>
inline const Entry *find(const Entry (&tab)[N], const std::string &k) {
    for (const Entry &e : tab) if (k == key(e.id)) return &e;
    return nullptr;
}

struct Info { int slot = -1; int rank = 0; };

// Слот и класс по id: таблица, затем слова в названии (для предметов, которых в таблице нет).
inline Info armorInfo(const std::string &id) {
    const std::string k = key(id);
    if (const Entry *e = find(kArmor, k)) return { e->slot, e->rank };
    auto has = [&](const char *w) { return k.find(w) != std::string::npos; };
    Info in;
    if (has("backpack")) in.slot = 5;
    else if (has("hazmat") || has("militarysuit") || has("fullsuit") || has("costume") || has("suit")) in.slot = 4;
    else if (has("boot") || has("feet") || has("foot") || has("shoe") || has("sneaker") || has("sandal")) in.slot = 3;
    else if (has("legging") || has("legs") || has("pants") || has("trouser")) in.slot = 2;
    else if (has("chest") || has("torso") || has("vest") || has("jacket") || has("body") || has("plate") || has("coat") || has("shirt")) in.slot = 1;
    else if (has("helmet") || has("mask") || has("head") || has("hat") || has("cap") || has("hood") || has("crown")) in.slot = 0;
    else return in;
    if (has("pumpkin") || has("santa") || has("witch") || has("elf") || has("party") || has("cone") || has("christmas") || has("crown")) in.rank = 0;
    else if (has("military") || has("mvk")) in.rank = 6;
    else if (has("hazmat")) in.rank = 5;
    else if (has("metal") || has("iron") || has("steel")) in.rank = 4;
    else if (has("bone")) in.rank = 3;
    else if (has("leather")) in.rank = 2;
    else if (has("wood")) in.rank = 1;
    else in.rank = in.slot == 5 ? 1 : 2;
    return in;
}

// "metal.chestplate" -> "Metal Chestplate"; короткие слова-сокращения — заглавными.
inline std::string titleCase(const std::string &id) {
    static const char *const kUpper[] = { "smg", "dmr", "lmg", "fn", "fal", "ak", "hq", "bp", "rpg", "c4" };
    std::string out, word;
    auto flush = [&]() {
        if (word.empty()) return;
        bool up = false;
        for (const char *u : kUpper) if (word == u) up = true;
        if (up) for (char &c : word) c = (char)toupper((unsigned char)c);
        else { word[0] = (char)toupper((unsigned char)word[0]); }
        if (!out.empty()) out.push_back(' ');
        out += word; word.clear();
    };
    for (unsigned char c : id) {
        if (c == '.' || c == '_' || c == '-' || c == ' ') flush();
        else word.push_back((char)tolower(c));
    }
    flush();
    return out;
}

// Название из игры годится, если это короткая печатная ASCII-строка (английский текст).
inline bool goodGameName(const std::string &s) {
    if (s.size() < 2 || s.size() > 40) return false;
    bool letter = false;
    for (unsigned char c : s) {
        if (c < 32 || c > 126) return false;
        if (isalpha(c)) letter = true;
    }
    return letter;
}

// Итоговая подпись: название из игры -> таблица -> id словами.
inline std::string label(const std::string &id, const std::string &gameEnglish = std::string()) {
    if (goodGameName(gameEnglish)) return gameEnglish;
    const std::string k = key(id);
    if (const Entry *e = find(kArmor, k)) return e->name;
    if (const Entry *e = find(kWeapons, k)) return e->name;
    return titleCase(id);
}

struct Worn { std::string id, label; int slot = -1; int rank = 0; };

// Из набора надетых id выбирает то, что рисовать: по одной детали на слот (с наибольшим классом; косметика — только если брони в слоте нет),
// цельный костюм заменяет четыре детали; рюкзак — отдельной строкой в конце. Порядок: голова, торс, ноги, ботинки, рюкзак.
template <class Lab>
inline std::vector<Worn> pickWorn(const std::vector<std::string> &ids, Lab labelOf) {
    Worn best[6]; bool has[6] = { false, false, false, false, false, false };
    for (const std::string &id : ids) {
        if (id.empty()) continue;
        const Info in = armorInfo(id);
        if (in.slot < 0 || in.slot > 5) continue;
        if (!has[in.slot] || in.rank > best[in.slot].rank) {
            best[in.slot].id = id; best[in.slot].slot = in.slot; best[in.slot].rank = in.rank; has[in.slot] = true;
        }
    }
    std::vector<Worn> out;
    auto push = [&](int s) { Worn w = best[s]; w.label = labelOf(w.id); out.push_back(w); };
    if (has[4] && best[4].rank > 0) push(4);
    else for (int s = 0; s < 4; ++s) if (has[s]) push(s);
    if (has[5]) push(5);
    return out;
}

// Оценка гипотезы «индекс списка = индекс реестра + s»: у настоящего набора по одной детали на слот и один материал.
template <class IdAt>
inline int shiftScore(const std::vector<int> &idx, int s, IdAt idAt) {
    int seen = 0, distinct = 0, dup = 0, unresolved = 0, mat[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };
    for (int i : idx) {
        const int r = i - s;
        const std::string id = r >= 0 ? idAt(r) : std::string();
        if (id.empty()) { ++unresolved; continue; }
        const Info in = armorInfo(id);
        if (in.slot < 0) { ++unresolved; continue; }
        if (in.slot == 5) continue;
        const int bit = 1 << in.slot;
        if (seen & bit) ++dup; else { seen |= bit; ++distinct; }
        if (in.rank > 0 && in.slot <= 3) ++mat[in.rank & 7];
    }
    int top = 0;
    for (int m : mat) if (m > top) top = m;
    return 2 * distinct - 3 * dup - 2 * unresolved + top;
}

// Накапливает оценки по всем увиденным наборам (каждый набор учитывается один раз) и выбирает смещение; без явного преимущества остаётся prior.
struct ShiftVoter {
    static const int kMax = 5;
    int prior = 2, cur = 2, votes[kMax] = { 0, 0, 0, 0, 0 }, bonus = 4;
    std::unordered_set<std::string> seen;
    template <class IdAt>
    int vote(const std::vector<int> &idx, IdAt idAt) {
        if (idx.size() >= 3) {
            std::string k;
            for (int i : idx) k += std::to_string(i) + ",";
            if (seen.size() > 400) seen.clear();
            if (seen.insert(k).second) for (int s = 0; s < kMax; ++s) votes[s] += shiftScore(idx, s, idAt);
        }
        int best = prior, bv = votes[prior] + bonus;
        for (int s = 0; s < kMax; ++s) if (votes[s] + (s == prior ? bonus : 0) > bv) { bv = votes[s] + (s == prior ? bonus : 0); best = s; }
        cur = best;
        return cur;
    }
};

}  // namespace gear
