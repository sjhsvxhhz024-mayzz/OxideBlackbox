#pragma once
// Procedural, bone-attached overlay silhouette. No model mesh, shaders or writes
// to game memory. Death particles are stored in WORLD space and reprojected.
#include "imgui.h"
#include "skeleton.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <unordered_map>
#include <vector>

namespace chams {
using oxskel::V3;
using oxskel::Pose;
inline float Clamp(float v,float lo,float hi,float def) {
    return std::isfinite(v) ? std::max(lo,std::min(hi,v)) : def;
}
struct Settings {
    int style=0;
    float opacity=.58f,glow=.65f,speed=1.f,duration=1.4f;
    bool animated=true;
};
inline uint32_t Hash(uint32_t v) { v^=v>>16;v*=0x7feb352dU;v^=v>>15;v*=0x846ca68bU;return v^(v>>16); }
inline float Random(uint32_t v) { return (Hash(v)&0xffff)/65535.f; }
inline ImVec4 Mix(ImVec4 a,ImVec4 b,float t) {
    return ImVec4(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,a.z+(b.z-a.z)*t,1);
}
inline ImVec4 Color(int style,float t,double now,bool animated,float speed) {
    static const ImVec4 colors[4][2]={
        {ImVec4(.10f,.94f,1.f,1),ImVec4(.72f,.24f,1.f,1)},
        {ImVec4(.16f,1.f,.67f,1),ImVec4(.98f,.18f,.69f,1)},
        {ImVec4(1.f,.83f,.18f,1),ImVec4(1.f,.23f,.12f,1)},
        {ImVec4(.89f,1.f,1.f,1),ImVec4(.22f,.58f,1.f,1)}
    };
    style=std::max(0,std::min(3,style));
    const float wave=animated ? .11f*std::sin((float)now*Clamp(speed,.2f,3.f,1.f)*1.8f-t*4.f) : 0.f;
    return Mix(colors[style][0],colors[style][1],Clamp(t+wave,0,1,.5f));
}
inline ImU32 Pack(ImVec4 c,float a) {
    c.w=Clamp(a,0,1,0);return ImGui::ColorConvertFloat4ToU32(c);
}
// GLES uses 16-bit indices without base-vertex support. Leave room for the
// ordinary ESP/radar; cosmetic geometry must not overflow their draw list.
inline bool Room(ImDrawList *dl,int reserve) {
    return (dl->Flags & ImDrawListFlags_AllowVtxOffset) ||
           sizeof(ImDrawIdx)>2 || dl->_VtxCurrentIdx+(unsigned)reserve<48000;
}
inline bool ValidPose(const Pose &p) {
    using namespace oxskel;
    for (const auto &v:p.j) if (!finite3(v) || std::fabs(v.x)>50000 || std::fabs(v.z)>50000 || std::fabs(v.y)>5000) return false;
    if (!finite3(p.headC)) return false;
    const float h=len(p.j[J_HEAD]-p.j[J_PELVIS]);
    if (h<.12f || h>2.f) return false;
    for (const auto &v:p.j) if (len(v-p.j[J_PELVIS])>3.f) return false;
    return true;
}

// Same renderer is used in the game and in the menu preview.
template<class Project>
bool Draw(ImDrawList *dl,const Pose &pose,Project project,const Settings &s,
          double now,float dissolve=-1.f,uint32_t seed=1) {
    using namespace oxskel;
    if (!dl || !ValidPose(pose) || !Room(dl,2500)) return false;
    ImVec2 p[J_COUNT];bool visible[J_COUNT]{};
    for (int i=0;i<J_COUNT;++i) {
        visible[i]=project(pose.j[i],p[i]) && std::isfinite(p[i].x) && std::isfinite(p[i].y);
    }
    ImVec2 hc,ht;
    if (!visible[J_PELVIS] || !visible[J_HEAD] || !project(pose.headC,hc) ||
        !project(pose.headC+V3{0,Clamp(pose.headR,.07f,.18f,.105f),0},ht)) return false;
    const float hr=Clamp(std::fabs(ht.y-hc.y),1.2f,90.f,2.f);
    const float feetY=visible[J_FOOT_R] && visible[J_FOOT_L] ? (p[J_FOOT_R].y+p[J_FOOT_L].y)*.5f : p[J_PELVIS].y+hr*6;
    const float top=hc.y-hr, height=std::fabs(feetY-top);
    if (!std::isfinite(height) || height<9.f || height>ImGui::GetIO().DisplaySize.y*2.5f) return false;
    const float ppm=Clamp(height/1.72f,5.f,700.f,50.f);
    const float alpha=Clamp(s.opacity,.15f,.95f,.58f);
    const float glow=Clamp(s.glow,0,1,.65f);
    const float progress=dissolve<0 ? -1.f : Clamp(dissolve,0,1,1);
    if (progress>=1.f) return false;
    const float pulse=s.animated ? .86f+.14f*std::sin((float)now*2.1f*Clamp(s.speed,.2f,3.f,1.f)) : 1.f;
    int part=0;
    auto shape=[&](const ImVec2 *v,int count,bool edge=true) {
        if (count<3 || !Room(dl,count*24)) return;
        ImVec2 c(0,0);
        for (int i=0;i<count;++i) { if (!std::isfinite(v[i].x)||!std::isfinite(v[i].y)) return;c.x+=v[i].x;c.y+=v[i].y; }
        c.x/=count;c.y/=count;
        const float t=Clamp((c.y-top)/height,0,1,.5f);
        const float noise=Random(seed+(uint32_t)(++part)*97);
        const float remaining=progress<0 ? 1.f : Clamp((.22f+.70f*(1.f-t)+.16f*noise-progress)*9.f,0,1,0);
        if (remaining<=0) return;
        const ImVec4 base=Color(s.style,t,now,s.animated,s.speed);
        // Two expanded halo contours: deliberately low alpha to avoid a solid blob.
        if (glow>.01f && height>28.f) for (int pass=0;pass<2;++pass) {
            ImVec2 q[24];
            const float pad=(pass ? 1.6f : 4.f)*Clamp(height/210.f,.6f,2.f,1.f);
            for (int i=0;i<count;++i) {
                const float dx=v[i].x-c.x,dy=v[i].y-c.y,l=std::sqrt(dx*dx+dy*dy);
                q[i]=l>.01f ? ImVec2(v[i].x+dx/l*pad,v[i].y+dy/l*pad) : v[i];
            }
            dl->AddConvexPolyFilled(q,count,Pack(base,(pass ? .07f : .035f)*glow*pulse*remaining));
        }
        const int start=dl->VtxBuffer.Size;
        dl->AddConvexPolyFilled(v,count,Pack(base,alpha*remaining));
        const float band=s.animated ? std::fmod((float)now*Clamp(s.speed,.2f,3.f,1.f)*.23f,1.5f)-.25f : -2.f;
        for (int i=start;i<dl->VtxBuffer.Size;++i) {
            auto &vertex=dl->VtxBuffer[i];
            const float y=Clamp((vertex.pos.y-top)/height,0,1,.5f);
            const float sheen=std::max(0.f,1.f-std::fabs(y-band)/.09f);
            ImVec4 color=Mix(Color(s.style,y,now,s.animated,s.speed),ImVec4(.94f,1.f,1.f,1),sheen*.55f);
            const float coverage=((vertex.col>>IM_COL32_A_SHIFT)&255)/255.f;
            color.w=coverage;vertex.col=ImGui::ColorConvertFloat4ToU32(color);
        }
        // Thin prismatic edge; no thick black "stick skeleton".
        if (edge) for (int i=0;i<count;++i)
            dl->AddLine(v[i],v[(i+1)%count],Pack(Mix(base,ImVec4(1,1,1,1),.36f),(.28f+.20f*glow)*remaining),Clamp(height/230.f,.7f,1.8f,1));
    };
    auto ellipse=[&](ImVec2 center,float rx,float ry) {
        ImVec2 v[20];
        for (int i=0;i<20;++i) { float a=i*6.2831853f/20;v[i]=ImVec2(center.x+std::cos(a)*rx,center.y+std::sin(a)*ry); }
        shape(v,20);
    };
    auto limb=[&](int a,int b,float ra,float rb) {
        if (!visible[a] || !visible[b]) return;
        const float dx=p[b].x-p[a].x,dy=p[b].y-p[a].y,l=std::sqrt(dx*dx+dy*dy);
        if (l<.5f || l>height*.9f) return;
        ra=std::max(.75f,ra*ppm);rb=std::max(.65f,rb*ppm);
        // One rounded capsule, not a quad plus two overlapping translucent
        // circles: avoids bright "bubble joints" and reduces geometry.
        const float angle=std::atan2(dy,dx);
        ImVec2 v[18];
        for (int i=0;i<9;++i) {
            const float aa=angle+1.5707963f+i*3.1415926f/8;
            const float ab=angle-1.5707963f+i*3.1415926f/8;
            v[i]=ImVec2(p[a].x+std::cos(aa)*ra,p[a].y+std::sin(aa)*ra);
            v[i+9]=ImVec2(p[b].x+std::cos(ab)*rb,p[b].y+std::sin(ab)*rb);
        }
        shape(v,18,false);
    };
    // Limbs first, torso masks shoulder/hip overlaps.
    limb(J_HIP_R,J_KNEE_R,.095f,.070f);limb(J_KNEE_R,J_FOOT_R,.070f,.045f);
    limb(J_HIP_L,J_KNEE_L,.095f,.070f);limb(J_KNEE_L,J_FOOT_L,.070f,.045f);
    limb(J_SH_R,J_EL_R,.070f,.052f);limb(J_EL_R,J_HAND_R,.052f,.034f);
    limb(J_SH_L,J_EL_L,.070f,.052f);limb(J_EL_L,J_HAND_L,.052f,.034f);
    if (visible[J_SH_R] && visible[J_SH_L] && visible[J_HIP_R] && visible[J_HIP_L]) {
        // Convex hull, rather than a potentially self-crossing torso in a side pose.
        ImVec2 v[4]={p[J_SH_R],p[J_SH_L],p[J_HIP_R],p[J_HIP_L]};
        std::sort(v,v+4,[](ImVec2 a,ImVec2 b){return a.x==b.x ? a.y<b.y : a.x<b.x;});
        auto cross=[](ImVec2 a,ImVec2 b,ImVec2 c){return (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);};
        ImVec2 hull[8];int n=0;
        for (int i=0;i<4;++i) {while(n>=2 && cross(hull[n-2],hull[n-1],v[i])<=0)--n;hull[n++]=v[i];}
        const int lower=n+1;
        for (int i=2;i>=0;--i) {while(n>=lower && cross(hull[n-2],hull[n-1],v[i])<=0)--n;hull[n++]=v[i];}
        if (n>3) shape(hull,n-1);
        else limb(J_PELVIS,J_CHEST,.12f,.16f);
    } else limb(J_PELVIS,J_CHEST,.12f,.16f);
    limb(J_CHEST,J_NECK,.10f,.065f);
    limb(J_NECK,J_HEAD,.055f,.055f);
    ellipse(hc,hr*.92f,hr*1.12f);
    return true;
}

struct Burst {
    Pose pose;
    double born=0;
    float duration=1.4f;
    uint32_t seed=1;
    Settings appearance;
};
template<class Project>
void Particles(ImDrawList *dl,const Burst &burst,Project project,double now) {
    using namespace oxskel;
    const float age=(float)(now-burst.born),duration=Clamp(burst.duration,.5f,2.8f,1.4f);
    if (!dl || age<0 || age>duration) return;
    for (uint32_t i=0;i<72;++i) {
        if (!Room(dl,90)) break;
        const uint32_t seed=Hash(burst.seed+i*101);
        static const int links[][2]={
            {J_PELVIS,J_CHEST},{J_PELVIS,J_CHEST},{J_CHEST,J_NECK},{J_NECK,J_HEAD},
            {J_SH_R,J_EL_R},{J_EL_R,J_HAND_R},{J_SH_L,J_EL_L},{J_EL_L,J_HAND_L},
            {J_HIP_R,J_KNEE_R},{J_KNEE_R,J_FOOT_R},{J_HIP_L,J_KNEE_L},{J_KNEE_L,J_FOOT_L},
            {J_SH_R,J_SH_L},{J_HIP_R,J_HIP_L},{J_PELVIS,J_SPINE},{J_SPINE,J_CHEST}
        };
        const auto &link=links[i%16];
        const V3 origin=lerp(burst.pose.j[link[0]],burst.pose.j[link[1]],Random(seed+29))+
            V3{(Random(seed+31)-.5f)*.07f,(Random(seed+37)-.5f)*.04f,(Random(seed+41)-.5f)*.07f};
        const float feet=(burst.pose.j[J_FOOT_R].y+burst.pose.j[J_FOOT_L].y)*.5f;
        const float bodyHeight=std::max(.5f,burst.pose.headC.y-feet);
        const float level=Clamp((origin.y-feet)/bodyHeight,0,1,.5f),delay=level*duration*.35f;
        const float t=age-delay;
        if (t<0) continue;
        const float life=duration-delay;
        const float fade=std::max(0.f,1.f-t/life);
        if (fade<=0) continue;
        const float angle=Random(seed+7)*6.2831853f,vel=.2f+Random(seed+11)*.55f;
        auto position=[&](float at) {
            const float swirl=angle+at*2.5f;
            return origin+V3{std::cos(swirl)*vel*at,.25f*at+.12f*at*at,std::sin(swirl)*vel*at};
        };
        ImVec2 p,tail,sizePoint;
        const V3 w=position(t);
        if (!project(w,p)) continue;
        if (!std::isfinite(p.x)||!std::isfinite(p.y)) continue;
        const float physical=.012f+Random(seed+17)*.014f;
        if (!project(w+V3{0,physical,0},sizePoint)) continue;
        const float r=Clamp(std::fabs(sizePoint.y-p.y),.7f,5.f,1.f)*(.4f+.6f*fade);
        const ImVec4 color=Color(burst.appearance.style,level,now,false,1);
        if (project(position(std::max(0.f,t-.055f)),tail))
            dl->AddLine(tail,p,Pack(color,.5f*fade*fade),std::max(.7f,r*.55f));
        dl->AddCircleFilled(p,r*2.4f,Pack(color,.07f*fade*fade),10);
        const float spin=angle+t*3.f;
        ImVec2 q[3];
        for (int k=0;k<3;++k) {const float a=spin+k*2.0943951f;q[k]=ImVec2(p.x+std::cos(a)*r,p.y+std::sin(a)*r);}
        dl->AddTriangleFilled(q[0],q[1],q[2],Pack(Mix(color,ImVec4(1,1,1,1),.35f),.9f*fade*fade));
    }
}

class Effects {
public:
    struct Seen { Pose pose;double stamp=0;uint64_t klass=0;uint32_t netId=0; };
    std::unordered_map<uint64_t,Seen> seen;
    std::vector<Burst> bursts;
    void clear() {seen.clear();bursts.clear();}
    void observe(uint64_t id,uint64_t klass,uint32_t netId,const Pose &pose,double now) {
        if (!id || !klass || !netId || !ValidPose(pose)) return;
        if (seen.size()>=32 && !seen.count(id)) return;
        seen[id]={pose,now,klass,netId};
    }
    void death(uint64_t id,double now,const Settings &s,bool enabled) {
        auto it=seen.find(id);if(it==seen.end())return;
        if (enabled && now>=it->second.stamp && now-it->second.stamp<=.25) {
            if (bursts.size()>=8) bursts.erase(bursts.begin());
            bursts.push_back({it->second.pose,now,Clamp(s.duration,.5f,2.8f,1.4f),Hash((uint32_t)id),s});
        }
        seen.erase(it); // One event, not another explosion every frame.
    }
    void prune(double now) {
        for (auto it=seen.begin();it!=seen.end();) {
            if (now<it->second.stamp || now-it->second.stamp>.4) it=seen.erase(it);else ++it;
        }
        bursts.erase(std::remove_if(bursts.begin(),bursts.end(),[&](const Burst &b){return now<b.born || now-b.born>b.duration;}),bursts.end());
    }
    template<class Project> void draw(ImDrawList *dl,Project project,double now) {
        prune(now);
        for (const auto &b:bursts) {
            Draw(dl,b.pose,project,b.appearance,now,(float)((now-b.born)/b.duration),b.seed);
            Particles(dl,b,project,now);
        }
    }
};
}