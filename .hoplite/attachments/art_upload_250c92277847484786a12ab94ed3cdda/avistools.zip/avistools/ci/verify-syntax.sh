#!/usr/bin/env bash
# ============================================================================
#  verify-syntax.sh — семантическая проверка всех TU из Android.mk БЕЗ NDK.
#
#  Зачем: в песочнице агента закрыт dl.google.com, NDK не поставить. Но проверить,
#  что весь #include-граф сходится и код компилируется, можно и хостовым g++ —
#  если подсунуть ему заголовки Android/Khronos из открытых источников.
#
#  Что это НЕ делает: не линкует, не даёт arm64-бинарь, не проверяет кодоген.
#  Настоящая сборка — ci/github-actions-build.yml (ndk-build на раннере).
#
#  Запуск:  bash ci/verify-syntax.sh
# ============================================================================
set -uo pipefail

ROOT=$(cd "$(dirname "$0")/.." && pwd)
SYSROOT=${SYSROOT:-/tmp/derh-sysroot}
INC="$SYSROOT/inc"

# ---------------------------------------------------------------- заголовки --
if [ ! -f "$INC/android/keycodes.h" ]; then
  echo ">> собираю псевдо-sysroot в $SYSROOT"
  mkdir -p "$INC"/{android,sys,GLES3} && cd "$SYSROOT"

  # Khronos: EGL + GLES (официальные реестры).
  curl -sSL -o egl.tgz https://codeload.github.com/KhronosGroup/EGL-Registry/tar.gz/refs/heads/main
  curl -sSL -o gl.tgz  https://codeload.github.com/KhronosGroup/OpenGL-Registry/tar.gz/refs/heads/main
  tar xzf egl.tgz && tar xzf gl.tgz
  cp -r EGL-Registry-main/api/EGL EGL-Registry-main/api/KHR "$INC"/
  cp -r OpenGL-Registry-main/api/GLES OpenGL-Registry-main/api/GLES2 OpenGL-Registry-main/api/GLES3 "$INC"/
  rm -rf EGL-Registry-main OpenGL-Registry-main ./*.tgz
  echo '/* пуст и в самом NDK */' > "$INC/GLES3/gl3ext.h"

  # Настоящие android/*.h из вендоренного дерева AOSP (raw.githubusercontent
  # заблокирован, поэтому через Contents API).
  for h in input.h keycodes.h native_window.h rect.h looper.h; do
    gh api "repos/alibaba/atlas/contents/atlas-aapt/frameworks/native/include/android/$h" \
       --jq .content | base64 -d > "$INC/android/$h"
  done

  # log.h и system_properties.h — минимальные, но точные по сигнатурам.
  cat > "$INC/android/log.h" <<'H'
#ifndef _ANDROID_LOG_H
#define _ANDROID_LOG_H
#include <stdarg.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef enum android_LogPriority {
    ANDROID_LOG_UNKNOWN = 0, ANDROID_LOG_DEFAULT, ANDROID_LOG_VERBOSE,
    ANDROID_LOG_DEBUG, ANDROID_LOG_INFO, ANDROID_LOG_WARN, ANDROID_LOG_ERROR,
    ANDROID_LOG_FATAL, ANDROID_LOG_SILENT,
} android_LogPriority;
int  __android_log_write(int prio, const char* tag, const char* text);
int  __android_log_print(int prio, const char* tag, const char* fmt, ...)
     __attribute__((__format__(printf, 3, 4)));
int  __android_log_vprint(int prio, const char* tag, const char* fmt, va_list ap);
void __android_log_assert(const char* cond, const char* tag, const char* fmt, ...)
     __attribute__((__noreturn__));
#ifdef __cplusplus
}
#endif
#endif
H
  cat > "$INC/sys/system_properties.h" <<'H'
#ifndef _SYS_SYSTEM_PROPERTIES_H
#define _SYS_SYSTEM_PROPERTIES_H
#include <stddef.h>
#define PROP_VALUE_MAX 92
#define PROP_NAME_MAX  32
#ifdef __cplusplus
extern "C" {
#endif
int __system_property_get(const char* __name, char* __value);
int __system_property_set(const char* __key, const char* __value);
#ifdef __cplusplus
}
#endif
#endif
H
fi

# ------------------------------------------------------------------ сборка --
# Пути 1-в-1 из LOCAL_C_INCLUDES + сам корень (ndk-build добавляет LOCAL_PATH).
INCS="-I$ROOT -I$ROOT/include -I$ROOT/src -I$ROOT/third_party/mbedtls/include
      -I$ROOT/include/ImGui -I$ROOT/include/ImGui/backends -I$ROOT/include/ImGui/font
      -I$ROOT/include/native_surface -I$ROOT/include/Android_draw
      -I$ROOT/include/Android_touch -I$ROOT/src/oxorany -I$ROOT/src/trial -isystem $INC"

# -include: libc++ из NDK тянет <cstdint>/<fcntl.h> транзитивно, glibc-g++ — нет.
# Это разница хостовых заголовков, а не проблема кода.
FLAGS="-std=c++17 -fsyntax-only -fno-rtti -fexceptions -w
       -DUSE_OPENGL -DOX_ENABLE_LOG -DOX_VERBOSE_LOG -D__ANDROID__=1 -D__ANDROID_API__=29
       -include cstdint -include cstddef -include cstdio -include fcntl.h"

# Список TU берём из Android.mk, чтобы он не разъезжался с реальной сборкой.
SRC=$(sed -n '/LOCAL_SRC_FILES/,/^$/p' "$ROOT/Android.mk" | grep -o 'src/[A-Za-z0-9_/]*\.cpp')

pass=0; fail=0
for f in $SRC; do
  if out=$(g++ $FLAGS $INCS -c "$ROOT/$f" 2>&1); then
    printf '  PASS  %s\n' "$f"; pass=$((pass+1))
  else
    printf '  FAIL  %s\n' "$f"
    echo "$out" | grep -E 'error:' | head -5 | sed 's/^/          /'
    fail=$((fail+1))
  fi
done

echo "-------- $pass passed, $fail failed --------"
[ "$fail" -eq 0 ]
