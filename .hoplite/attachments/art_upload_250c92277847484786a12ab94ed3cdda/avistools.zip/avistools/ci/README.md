# ci/ — сборка и проверки

## Включить настоящую сборку (одно действие от вас)

Агент не может сам создать файл в `.github/workflows/` — GitHub App отклоняет
push без права `workflows`:

```
! [remote rejected] refusing to allow a GitHub App to create or update
  workflow `.github/workflows/build.yml` without `workflows` permission
```

Поэтому workflow лежит здесь. Перенесите его:

```bash
mkdir -p .github/workflows
git mv ci/github-actions-build.yml .github/workflows/build.yml
git commit -m "CI: сборка ndk-build + APK"
git push
```

После этого агент сможет **запускать сборку и читать логи** (`gh workflow run`,
`gh run watch`) — доступ на чтение Actions у токена уже есть.

Альтернатива: выдать Arena GitHub App право `workflows: write` — тогда агент
положит файл сам.

## Что делает workflow

| Джоба | Что |
|---|---|
| `native` | ставит NDK **r26d** (`26.3.11579264`, как в README), сверяет md5 `Font.h`, гоняет `ndk-build` сразу под **arm64-v8a и x86_64**, проверяет архитектуру каждого бинарника (ARM aarch64 / x86-64, PIE), прогоняет хост-тесты, отдаёт два артефакта |

В этой поставке нет исходников отдельного Android-загрузчика, поэтому workflow
публикует два исполняемых ELF, без APK.

Раннер `ubuntu-latest` подходит потому, что на нём уже есть Android SDK/NDK
и открыт доступ к `dl.google.com`.

## Почему не собирается в песочнице агента

Проверено: `dl.google.com` и `developer.android.com` не резолвятся (TLS рвётся),
GitHub release-ассеты редиректят на заблокированный
`release-assets.githubusercontent.com`, зеркал NDK на npm/PyPI нет, `apt` без
root. Доступны только `codeload.github.com`, `api.github.com` и PyPI — NDK там
не лежит.

Чтобы агент собирал **локально**, в сетевой политике песочницы нужно открыть:

```
dl.google.com                 # NDK/SDK и Android-репозиторий Maven
dl.google.com/android/repository
services.gradle.org           # дистрибутив Gradle
repo.maven.apache.org         # зависимости
```

## verify-syntax.sh — что можно прогнать уже сейчас

```bash
bash ci/verify-syntax.sh
```

Компилирует **все 19 TU из `Android.mk`** хостовым `g++` с теми же флагами
(`-std=c++17 -DUSE_OPENGL`) и псевдо-sysroot: заголовки EGL/GLES из реестров
Khronos, настоящие `android/input.h`, `keycodes.h`, `native_window.h` из дерева
AOSP, плюс точные по сигнатурам `log.h` и `system_properties.h`.

Ловит: битые `#include`, отсутствующие файлы, ошибки парсинга и семантики.
**Не ловит:** ошибки линковки и кодогенерации под arm64 — для этого нужен
настоящий `ndk-build` из workflow выше.
