LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE    := avistools
LOCAL_CPP_FEATURES := exceptions

# --- Sources ---
LOCAL_SRC_FILES := \
    src/main.cpp \
    src/memory.cpp \
    src/utils.cpp \
    src/oxlog.cpp \
    src/trial/trial_menu.cpp \
    src/trial/i18n.cpp \
    src/trial/trial_ui.cpp \
    src/trial/trial_configs.cpp \
    src/trial/quick_actions.cpp \
    src/trial/auto_heal.cpp \
    src/trial/trial_platform.cpp \
    src/trial/auth_screen.cpp \
    src/trial/trial_assets.S \
    src/auth/auth_client.cpp \
    src/auth/auth_clip.cpp \
    src/auth/auth_sound.cpp \
    src/auth/auth_net.cpp \
    src/auth/auth_proto.cpp \
    src/oxorany/oxorany.cpp \
    src/Android_draw/draw.cpp \
    src/Android_touch/TouchHelperA.cpp \
    src/ImGui/imgui.cpp \
    src/ImGui/imgui_draw.cpp \
    src/ImGui/imgui_tables.cpp \
    src/ImGui/imgui_widgets.cpp \
    src/ImGui/backends/imgui_impl_android.cpp \
    src/ImGui/backends/imgui_impl_opengl3.cpp

# --- Include paths ---
LOCAL_C_INCLUDES := \
    $(LOCAL_PATH)/include \
    $(LOCAL_PATH)/src \
    $(LOCAL_PATH)/src/trial \
    $(LOCAL_PATH)/assets/trial \
    $(LOCAL_PATH)/third_party/mbedtls/include \
    $(LOCAL_PATH)/include/ImGui \
    $(LOCAL_PATH)/include/ImGui/backends \
    $(LOCAL_PATH)/include/ImGui/font \
    $(LOCAL_PATH)/include/native_surface \
    $(LOCAL_PATH)/include/Android_draw \
    $(LOCAL_PATH)/include/Android_touch \
    $(LOCAL_PATH)/include/oxorany \
    $(LOCAL_PATH)/src/oxorany

# --- Compile flags ---
# -DUSE_OPENGL: forces the EGL/GLES3 path in draw.cpp (not Vulkan).
# -std=c++17: required by ANativeWindowCreator.h (structured bindings) and oxorany.
# -fvisibility=hidden: keep symbol table small (matches existing binary).
LOCAL_CFLAGS := \
    -DUSE_OPENGL \
    -Wno-unused-result \
    -Wno-deprecated-declarations \
    -Wno-format-security \
    -Wno-format \
    -Wno-format-pedantic

LOCAL_CPPFLAGS := -std=c++17 -fno-rtti -fexceptions

# --- Оптимизация ---
# -O3 + ThinLTO: межмодульное встраивание горячих функций ImGui и main; gc-sections/icf убирают мёртвый и дублирующийся код.
LOCAL_CFLAGS += -O3 -fvisibility=hidden -fno-stack-protector -fomit-frame-pointer -flto=thin
LOCAL_LDFLAGS += -flto=thin -Wl,--gc-sections -Wl,--icf=all -Wl,-O2

# --- Link flags ---
# Standalone PIE executable. Links against public Android libs only:
#   -llog     android/log.h (__android_log_print)
#   -landroid android/native_window.h (ANativeWindow_*)
#   -lEGL     EGL
#   -lGLESv3  OpenGL ES 3 (USE_OPENGL path)
#   -ldl      dlopen/dlsym (ANativeWindowCreator runtime symbol resolution)
#   -lm       math
# Private SurfaceComposer symbols (libgui.so/libutils.so) are resolved at
# runtime via dlsym — no link-time dependency.
#
# libc++_static / libc++abi.a — НЕ линкуем здесь: APP_STL в Application.mk
# уже стоит `c++_static`, ndk-build подтягивает правильную статическую пару
# из хостового NDK сам (Linux / macOS / Windows). Прошлая версия жёстко
# ссылалась на `C:/ndk/toolchains/...` — работало только на Windows и ломало
# кросс-сборку на CI/Linux.
# Система ключей: TLS и проверка подписи (mbedtls). Адрес сервера можно зашить при сборке:
#   AVIS_API_URL=https://keys.example.com bash build.sh
LOCAL_STATIC_LIBRARIES := avis_mbedtls
ifneq ($(strip $(AVIS_API_URL)),)
LOCAL_CFLAGS += -DAVIS_API_URL=\"$(strip $(AVIS_API_URL))\"
endif

LOCAL_LDLIBS := \
    -llog \
    -landroid \
    -lEGL \
    -lGLESv3 \
    -ldl \
    -lm

# Build as a standalone executable (not a .so). Runs under `su` on device.
include $(BUILD_EXECUTABLE)

# --- Mbed TLS 3.6.2 (third_party/mbedtls), статическая библиотека для клиента ключей ---
include $(CLEAR_VARS)
LOCAL_MODULE := avis_mbedtls
LOCAL_SRC_FILES := $(addprefix third_party/mbedtls/library/,$(notdir $(wildcard $(LOCAL_PATH)/third_party/mbedtls/library/*.c)))
LOCAL_C_INCLUDES := $(LOCAL_PATH)/third_party/mbedtls/include $(LOCAL_PATH)/third_party/mbedtls/library
LOCAL_CFLAGS := -O2 -w -fvisibility=hidden
include $(BUILD_STATIC_LIBRARY)
