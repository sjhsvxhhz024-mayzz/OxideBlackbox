Mbed TLS 3.6.2 (LTS), без изменений. Лицензия: Apache-2.0 OR GPL-2.0-or-later (см. LICENSE).
Источник: https://github.com/Mbed-TLS/mbedtls/releases/tag/mbedtls-3.6.2
Из `library/` взяты только файлы, входящие в сборку по официальному CMakeLists (crypto + x509 + tls).
Нужен клиенту для TLS-запросов к серверу ключей и проверки подписи ответов (ECDSA P-256/SHA-256).
